﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace TestHtmlAgilityPack
{
    //序列化（Serialization）：序列化是将对象状态转换为可保持或传输的格式的过程。
    //反序列化(Deserialization) ：与序列化相对的是反序列化，它将流转换为对象。
    class CSerializer
    {
        /// <summary> 
        /// 使用二进制序列化对象。 
        /// </summary> 
        /// <param name="value"></param> 
        /// <returns></returns> 
        public static byte[] SerializeBytes(object value)
        {
            if (value == null) return null;

            var stream = new MemoryStream();
            new BinaryFormatter().Serialize(stream, value);

            //var dto = Encoding.UTF8.GetString(stream.GetBuffer()); 
            var bytes = stream.ToArray();
            return bytes;
        }

        /// <summary> 
        /// 使用二进制反序列化对象。 
        /// </summary> 
        /// <param name="bytes"></param> 
        /// <returns></returns> 
        public static object DeserializeBytes(byte[] bytes)
        {
            if (bytes == null) return null;

            //var bytes = Encoding.UTF8.GetBytes(dto as string); 
            var stream = new MemoryStream(bytes);

            var result = new BinaryFormatter().Deserialize(stream);

            return result;
        }
    }
    #region 调用方法
    //本例命名空间
    //using System.Runtime.Serialization.Formatters.Binary;
    //using System.IO;

    /// <summary>
    /// 类：武林高手
    /// MartialArtsMaster
    /// </summary>
    //[Serializable]
    //class MartialArtsMaster
    //{
    //    /// <summary>
    //    /// 编号
    //    /// </summary>
    //    public int Id { get; set; }
    //    /// <summary>
    //    /// 姓名
    //    /// </summary>
    //    public string Name { get; set; }
    //    /// <summary>
    //    /// 年龄
    //    /// </summary>
    //    public int Age { get; set; }
    //    /// <summary>
    //    /// 门派
    //    /// </summary>
    //    public string Menpai { get; set; }
    //    /// <summary>
    //    /// 武学
    //    /// </summary>
    //    public string Kungfu { get; set; }
    //    /// <summary>
    //    /// 级别
    //    /// </summary>
    //    public int Level { get; set; }
    //}

    //初始化武林高手
    //var master = new List<MartialArtsMaster>(){
    //    new MartialArtsMaster(){ Id = 1, Name = "黄蓉",    Age = 18, Menpai = "丐帮", Kungfu = "打狗棒法",  Level = 9  },
    //    new MartialArtsMaster(){ Id = 2, Name = "洪七公",  Age = 70, Menpai = "丐帮", Kungfu = "打狗棒法",  Level = 10 },
    //    new MartialArtsMaster(){ Id = 3, Name = "郭靖",    Age = 22, Menpai = "丐帮", Kungfu = "降龙十八掌",Level = 10 },
    //    new MartialArtsMaster(){ Id = 4, Name = "任我行",  Age = 50, Menpai = "明教", Kungfu = "葵花宝典",  Level = 1  },
    //    new MartialArtsMaster(){ Id = 5, Name = "东方不败",Age = 35, Menpai = "明教", Kungfu = "葵花宝典",  Level = 10 },
    //    new MartialArtsMaster(){ Id = 6, Name = "林平之",  Age = 23, Menpai = "华山", Kungfu = "葵花宝典",  Level = 7  },
    //    new MartialArtsMaster(){ Id = 7, Name = "岳不群",  Age = 50, Menpai = "华山", Kungfu = "葵花宝典",  Level = 8  }
    //};
    //文件流写入
    //using (FileStream fs = new FileStream(@"F:\360同步云盘\360同步云盘\博客\序列化\master.obj", FileMode.Append))
    //{
    //    var myByte = Serializer.SerializeBytes(master);
    //    fs.Write(myByte, 0, myByte.Length);
    //    fs.Close();
    //};

    ////文件流读取
    //using (FileStream fsRead = new FileStream(@"F:\360同步云盘\360同步云盘\博客\序列化\master.obj", FileMode.Open))
    //{
    //    int fsLen = (int)fsRead.Length;
    //    byte[] heByte = new byte[fsLen];
    //    int r = fsRead.Read(heByte, 0, heByte.Length);
    //    var myObj = Serializer.DeserializeBytes(heByte) as List<MartialArtsMaster>;
    //    Console.WriteLine("编号---姓名---年龄---门派---武功---等级");
    //    myObj.ForEach(m => 
    //        Console.WriteLine(m.Id + "---" + m.Name + "---" + m.Age + "---" + m.Menpai + "---" + m.Kungfu + "---" + m.Level)
    //    );  
    //}
    #endregion
}
