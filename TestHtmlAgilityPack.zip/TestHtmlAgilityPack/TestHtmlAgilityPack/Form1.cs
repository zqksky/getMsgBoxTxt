﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using HtmlAgilityPack;
using System.IO;
using System.Xml;
using System.Net;

namespace TestHtmlAgilityPack
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        #region HtmlDocument类
        //以指定的Stream对象为主的有：

        //（1）public void Load(Stream stream)    ///从指定的Stream对象中加载html；
        //（2）public void Load(Stream stream, bool detectEncodingFromByteOrderMarks)    ///指定是否从顺序字节流中解析编码格式
        //（3）public void Load(Stream stream, Encoding encoding)    ///指定编码格式
        //（4）public void Load(Stream stream, Encoding encoding, bool detectEncodingFromByteOrderMarks)
        //（5）public void Load(Stream stream, Encoding encoding, bool detectEncodingFromByteOrderMarks, int buffersize)

        //以指定的物理路径为主的有：

        //（1）public void Load(string path)
        //（2）public void Load(string path, bool detectEncodingFromByteOrderMarks)    ///指定是否从顺序字节流中解析编码格式
        //（3）public void Load(string path, Encoding encoding)    ///指定编码格式
        //（4）public void Load(string path, Encoding encoding, bool detectEncodingFromByteOrderMarks)
        //（5）public void Load(string path, Encoding encoding, bool detectEncodingFromByteOrderMarks, int buffersize)

        #endregion

        #region HtmlNode类
        //获取父节点的系列方法：

        //GetElementbyId(string id) 使用元素ID取得该元素

        //1）public IEnumerable<HtmlNode> Ancestors()

        //获取当前节点的父节点列表（不包含自身）。

        //2）public IEnumerable<HtmlNode> Ancestors(string name)

        //以指定一个名称来获取父节点的列表（不包含自身）。

        //3）public IEnumerable<HtmlNode> AncestorsAndSelf()

        //获取当前节点的父节点列表（包含自身）。

        //4）public IEnumerable<HtmlNode> AncestorsAndSelf(string name)

        //以指定一个名称来获取父节点的列表（包含自身）。

        //获取子节点的系列方法：

        //1）public IEnumerable<HtmlNode> DescendantNodes()

        //获取当前节点下的所有子节点的列表，包括子节点的子节点（不包含自身）。

        //2）public IEnumerable<HtmlNode> DescendantNodesAndSelf()

        //获取当前节点下的所有子节点的列表，包括子节点的子节点（包含自身）。

        //3）public IEnumerable<HtmlNode> Descendants()

        //获取当前节点下的直接子节点的列表（不包含自身）。

        //4）public IEnumerable<HtmlNode> DescendantsAndSelf()

        //获取当前节点下的直接子节点的列表（包含自身）。

        //5）public IEnumerable<HtmlNode> Descendants(string name)

        //获取当前节点下的以指定名称的子节点列表。

        //6）public IEnumerable<HtmlNode> DescendantsAndSelf(string name)

        //获取当前节点下的以指定名称的子节点的列表（包含自身）。

        //7）public HtmlNode Element(string name)

        //获取第一个符合指定名称的直接子节点的节点元素。

        //8）public IEnumerable<HtmlNode> Elements(string name)

        //获取符合指定名称的所有直接子节点的节点列表。

        //9）public HtmlNodeCollection SelectNodes(string xpath)

        //获取符合指定的xpath的子节点列表。

        //10）public HtmlNode SelectSingleNode(string xpath)

        //获取符合指定的xpath的单个字节点元素。
        #endregion

        #region 操作系列方法
        //移除调用节点调用名字的子节点，第二个参数确定是否保留子孙节点
        //public void Remove(); 
        //public void RemoveAll();
        //public void RemoveAllChildren();
        //public HtmlNode RemoveChild(HtmlNode oldChild);
        //public HtmlNode RemoveChild(HtmlNode oldChild, bool keepGrandChildren);

        //将调用节点原有的一个子节点替换为一个新的节点
        //public HtmlNode ReplaceChild(HtmlNode newChild, HtmlNode oldChild);
        //public HtmlNode InsertAfter(HtmlNode newChild, HtmlNode refChild);
        //public HtmlNode InsertBefore(HtmlNode newChild, HtmlNode refChild);

        //HtmlDocument类的重要方法
        //public HtmlAttribute CreateAttribute(string name);
        //public HtmlAttribute CreateAttribute(string name, string value);
        //public HtmlNode CreateElement(string name);
        //public XPathNavigator CreateNavigator();
        //public HtmlTextNode CreateTextNode();
        //public HtmlTextNode CreateTextNode(string text);
        //public HtmlNode GetElementbyId(string id);
        #endregion

        #region HtmlNode类的属性
        //Attributes 　　　　　　　　　　 获取节点的属性集合，如果某一个属性名称不存在的话，Attributes["attriname"]返回的是null值
        //ChildNodes　　　　　　　　　　　获取子节点集合(包括文本节点)
        //Closed　　　　　　　　　　　　　该节点是否已关闭(</xxx>)
        //ClosingAttributes　　　　　　　　  在关闭标签的属性集合
        //FirstChild　　　　　　　　　　　　获取第一个子节点
        //HasAttributes　　　　　　　　　　 判断该节点是否含有属性
        //HasChildNodes　　　　　　　　　判断该节点是否含有子节点
        //HasClosingAttributes　　　　　　   判断该节点的关闭标签是否含有属性(</xxx class="xxx">)
        //Id　　　　　　　　　　　　　　　   获取该节点的Id属性
        //InnerHtml　　　　　　　　　　　　获取该节点的Html代码
        //InnerText　　　　　　　　　　　　  获取该节点的内容，与InnerHtml不同的地方在于它会过滤掉Html代码，而InnerHtml是连Html代码一起输出
        //LastChild　　　　　　　　　　　　 获取最后一个子节点
        //Line　　　　　　　　　　　　　　  获取该节点的开始标签或开始代码位于整个HTML源代码的第几行(行号)
        //LinePosition　　　　　　　　　　　获取该节点位于第几列
        //Name　　　　　　　　　　　　　　Html元素名
        //NextSibling　　　　　　　　　　       获取下一个兄弟节点
        //NodeType　　　　　　　　　　　　 获取该节点的节点类型
        //OriginalName　　　　　　　　　　获取原始的未经更改的元素名
        //OuterHtml　　　　　　　　　　　   整个节点的代码
        //OwnerDocument　　　　　　　　   节点所在的HtmlDocument文档
        //ParentNode　　　　　　　　　　　获取该节点的父节点
        //PreviousSibling　　　　　　　　　获取前一个兄弟节点
        //StreamPosition　　　　　　　　　该节点位于整个Html文档的字符位置
        //XPath　　　　　　　　　　　　　  根据节点返回该节点的XPath
        #endregion

        private void Form1_Load(object sender, EventArgs e)
        {
            //TestHtml();
            ReadBindraryFile();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TestHtml();
        }

        private void TestHtml()
        {
            //HtmlNode   表示一个节点
            //HtmlNodeCollection   表示一个节点集合
            //DocumentNode   文档根节点,本身也是一个HtmlNode
            //HtmlAttribute  表示节点属性

            try
            {
                string htmlstr = "<div id=\"wapper\"><p id=\"pid\">article content1...</p><p>article content2...</p></div>";
                HtmlAgilityPack.HtmlDocument parser = new HtmlAgilityPack.HtmlDocument();
                parser.LoadHtml(htmlstr);

                //使用xpath表达式查找所有P标签
                HtmlNodeCollection nodes = parser.DocumentNode.SelectNodes("//p");

                foreach (HtmlNode tmpNode in nodes)
                {
                    if (tmpNode.Attributes["id"] == null)
                    {
                        //取节点属性ID的值
                        string pid = "newpid";
                        string text = tmpNode.InnerText;

                        //创建一个新节点
                        HtmlNode newNode = HtmlNode.CreateNode("<p id=" + pid + ">" + text + " add " + pid + "</p>");
                        //HtmlNode newNode = HtmlNode.CreateNode("<font size=" + Font.Size + ">" + text + "</font>");

                        //替换子节点 
                        tmpNode.ParentNode.ReplaceChild(newNode, tmpNode);
                    }
                    else
                    {
                        HtmlNode rvNode = tmpNode.ParentNode.RemoveChild(tmpNode, true);  //删除标签,但保留标签内文本
                    }
                }
                parser.Save(@"D:\GitHub\TestHtmlAgilityPack\TestHtmlAgilityPack\file\test.html", Encoding.UTF8);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        private void GetAllLink()
        {
            // The HtmlWeb class is a utility class to get the HTML over HTTP
            HtmlWeb htmlWeb = new HtmlWeb();

            // Creates an HtmlDocument object from an URL
            HtmlAgilityPack.HtmlDocument document = htmlWeb.Load("http://www.somewebsite.com");

            #region
            // Targets a specific node
            HtmlNode someNode = document.GetElementbyId("mynode");

            // If there is no node with that Id, someNode will be null
            if (someNode != null)
            {
                // Extracts all links within that node
                IEnumerable<HtmlNode> allLinks = someNode.Descendants("a");

                // Outputs the href for external links
                foreach (HtmlNode link in allLinks)
                {
                    // Checks whether the link contains an HREF attribute
                    if (link.Attributes.Contains("href"))
                    {
                        // Simple check: if the href begins with "http://", prints it out
                        if (link.Attributes["href"].Value.StartsWith("http://"))
                        {
                            MessageBox.Show(link.Attributes["href"].Value);
                        }
                    }
                }
            }
            #endregion

            #region use Xpath
            // Extracts all links under a specific node that have an href that begins with "http://"
            HtmlNodeCollection allLinks2 = document.DocumentNode.SelectNodes("//*[@id='mynode']//a[starts-with(@href,'http://')]");

            // Outputs the href for external links
            foreach (HtmlNode link in allLinks2)
            {
                MessageBox.Show(link.Attributes["href"].Value);
            }
            #endregion

            #region 删除注释，script，style
            //someNode.Descendants()
            //            .Where(n => n.Name == "script" || n.Name == "style" || n.Name == "#comment")
            //            .ToList().ForEach(n => n.Remove());

            ////遍历node节点的所有后代节点
            //foreach (var HtmlNode in someNode.Descendants())
            //{

            //}
            #endregion
        }
        private void Test()
        {
            //HtmlWeb web = new HtmlWeb();
            //HtmlAgilityPack.HtmlDocument doc = web.Load("http://www.hao123.com");
            //HtmlNode rootnode = doc.DocumentNode;

            string htmlstr = GetHtmlStr("http://www.hao123.com");
            HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
            doc.LoadHtml(htmlstr);
            HtmlNode rootnode = doc.DocumentNode;

            //XPath路径表达式，这里表示选取所有span节点中的font最后一个子节点，其中span节点的class属性值为num
            //根据网页的内容设置XPath路径表达式
            string xpathstring = "//span[@class='num']/font[last()]";

            HtmlNodeCollection aa = rootnode.SelectNodes(xpathstring);    //所有找到的节点都是一个集合

            if (aa != null)
            {
                string innertext = aa[0].InnerText;
                string color = aa[0].GetAttributeValue("color", "");    //获取color属性，第二个参数为默认值
                //其他属性大家自己尝试
            }
        }

        public static string GetHtmlStr(string url)
        {
            try
            {
                WebRequest rGet = WebRequest.Create(url);
                WebResponse rSet = rGet.GetResponse();
                Stream s = rSet.GetResponseStream();
                StreamReader reader = new StreamReader(s, Encoding.UTF8);
                return reader.ReadToEnd();
            }
            catch (WebException)
            {
                //连接失败
                return null;
            }
        }

        private void AnalysisXml()
        {
            #region
            //XmlElement Article = null, theElem = null, root = null;
            //XmlDocument xmldoc = new XmlDocument();

            //try
            //{
            //    xmldoc.Load(@"D:\GitHub\TestHtmlAgilityPack\TestHtmlAgilityPack\file\test.xml");
            //    root = xmldoc.DocumentElement;
            //    Article = (XmlElement)root.SelectSingleNode("/Articles/Article[1]");
            //    //MessageBox.Show(Article.OuterXml);

            //    XmlNodeList Articles = root.SelectNodes("//CreateAt[@type='zh-cn']");
            //    for (int i = 0; i < Articles.Count; i++)
            //    {
            //        MessageBox.Show(Articles.Item(i).OuterXml);
            //    }

            //    foreach (var item in Articles)
            //    {
            //    }

            //}
            //catch(Exception e)
            //{
            //    MessageBox.Show(e.Message);
            //}
            #endregion

            #region
            try
            {
                HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
                StreamReader sr = File.OpenText(@"D:\GitHub\TestHtmlAgilityPack\TestHtmlAgilityPack\file\test.xml");
                doc.Load(sr);

                HtmlNode node = doc.DocumentNode;

                //节点中的大写字母必须小写
                //var result = node.SelectSingleNode("/articles/article[1]");
                //MessageBox.Show(node.InnerText);

                var results = node.SelectNodes("//createat[@type='zh-cn']");

                foreach (var item in results)
                {
                    MessageBox.Show(item.InnerText);
                }

                //var results = doc.DocumentNode
                //     .Descendants("CreateAt")
                //     .Where(x => x.Attributes.Contains("type") &&
                //               x.Attributes["type"].Value.Contains("zh-cn"));

                //foreach (var item in results)
                //{
                //    MessageBox.Show(item.InnerText);
                //}
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            #endregion

            /* XPath 使用路径表达式来选取 XML 文档中的节点或节点集
            nodename:选取此节点的所有子节点。 
            /:从根节点选取。 
            //:从匹配选择的当前节点选择文档中的节点，而不考虑它们的位置。 
            .:选取当前节点。 
            ..:选取当前节点的父节点。
            */

            /*
            /Articles/Article[1]：选取属于Articles子元素的第一个Article元素。 
            /Articles/Article[last()]：选取属于Articles子元素的最后一个Article元素。 
            /Articles/Article[last()-1]：选取属于Articles子元素的倒数第二个Article元素。 
            /Articles/Article[position()<3]：选取最前面的两个属于 bookstore 元素的子元素的Article元素。 
            //Title[@lang]：选取所有拥有名为lang的属性的title元素。 
            //CreateAt[@type='zh-cn']：选取所有CreateAt元素，且这些元素拥有值为zh-cn的type属性。 
            /Articles/Article[Order>2]：选取Articles元素的所有Article元素，且其中的Order元素的值须大于2。 
            /Articles/Article[Order<3]/Title：选取Articles元素中的Article元素的所有Title元素，且其中的Order元素的值须小于3
            */
        }
        private void XPathWeb()
        {
            //加载Web 的页面并解析内容
            HtmlWeb web = new HtmlWeb();
            HtmlAgilityPack.HtmlDocument doc = web.Load("http://www.gongjuji.net");
            HtmlNode row = doc.DocumentNode.SelectSingleNode("//div[@class='row']");
            //以document为基准查询
            HtmlNodeCollection col = row.SelectNodes("//div[@class='thumbnail']");
            foreach (HtmlNode item in col)
            {
                //使用CreateNode（）来创建新的查询基准
                HtmlNode thumbnail = HtmlNode.CreateNode(item.OuterHtml);
                HtmlNode title = thumbnail.SelectSingleNode("//h3");
                MessageBox.Show("标题：" + title.InnerText);
                HtmlNode a = thumbnail.SelectSingleNode("//a");
                MessageBox.Show("\t链接：" + a.Attributes["href"].Value);
            }
            //Console.WriteLine("------解析结束");
        }

        private void AnalysisWeb()
        {
            //加载Web 的页面并解析内容
            string rowPath = "/html/body/div[2]/div[2]";
            HtmlWeb web = new HtmlWeb();
            HtmlAgilityPack.HtmlDocument doc = web.Load("http://www.gongjuji.net");
            //以document 为基准
            HtmlNode row = doc.DocumentNode.SelectSingleNode(rowPath);
            //创建row为基准
            row = HtmlNode.CreateNode(row.OuterHtml);
            HtmlNodeCollection titles = row.SelectNodes("//h3");
            foreach (var item in titles)
            {
                MessageBox.Show(item.InnerText);
            }
            HtmlNodeCollection links = doc.DocumentNode.SelectNodes("//a");
            foreach (HtmlNode item in links)
            {
                MessageBox.Show(item.Attributes["href"].Value);
            }
            //Console.WriteLine("------->解析结束");
        }

        private void AnalysisHtml()
        {
            //解析html 字符串或者本地html文件
            HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
            string html = "<div id=\"demo\"><span style=\"color: red; \"><h1>Hello</h1> </span></div>";
            doc.LoadHtml(html);
            HtmlNode demo = doc.GetElementbyId("demo");

            MessageBox.Show(demo.InnerHtml);
            //注：InnerText中会有换行或空格等，需要特殊处理
            MessageBox.Show(demo.InnerText);
            MessageBox.Show(demo.InnerText.Length.ToString());
        }
        private void GenerateHtml()
        {
            //生成DOM字符串结构
            HtmlNode container = HtmlNode.CreateNode("<div />");
            HtmlNode title = HtmlNode.CreateNode("<h3 />");
            title.InnerHtml = "张三丰";
            HtmlNode link = HtmlNode.CreateNode("<a />");
            link.InnerHtml = "点击进入";
            link.SetAttributeValue("href", "http://wwww.gongjuji.net");
            container.AppendChild(title).AppendChild(link);

            MessageBox.Show(container.OuterHtml);
        }
        private void testFun()
        {
            HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();

            string html = "<div id=\"demo\"><span style=\"color:red;\"><h1>Hello World!</h1></span></div>";
            doc.LoadHtml(html);

            HtmlAgilityPack.HtmlNode node = doc.DocumentNode;

            //MessageBox.Show(node.OuterHtml); // return "<div id="demo"><span style="color:red;"><h1>Hello World!</h1></span></div>";
            //MessageBox.Show(node.InnerHtml); // return "<span style="color:red;"><h1>Hello World!</h1></span>";
            //MessageBox.Show(node.InnerText); // return "Hello World!";

            string html2 = "<div id=\"title\" name=\"title_name\" class=\"class-name\" title=\"title div\">***</div>";
            doc.LoadHtml(html2);
            HtmlAgilityPack.HtmlNode node2 = doc.GetElementbyId("title");
            string titleValue = node2.Attributes["title"].Value;
            //MessageBox.Show(titleValue);
            foreach (HtmlAttribute attr in node2.Attributes)
            {
                //MessageBox.Show(attr.Name + "=" + attr.Value);
            }
        }

        /// <summary>
        /// 简单断点续传实例
        /// 如果要下载文件存在，追加保存文件，指定Range开始位置请求
        /// </summary>
        public static void TestFileLoad()
        {
            string url = "http://d.bootcss.com/bootstrap-3.3.0-source.zip";
            DateTime start = DateTime.Now;
            Uri uri = new Uri(url);
            string filename = uri.AbsolutePath.Substring(uri.AbsolutePath.LastIndexOf("/") + 1);
            filename = @"D:\GitHub\TestHtmlAgilityPack\TestHtmlAgilityPack\file\" + filename;
            //创建写入流
            FileStream fs = new FileStream(filename, FileMode.Create, FileAccess.Write);
            //指定url 下载文件
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            long position = 0;
            /*
                *  判断文件是否存在，如果存在获取文件继续的位置
                */
            FileInfo info = new FileInfo(filename);
            if (info.Exists)
            {
                position = info.Length;
                //将文件写入流指针移动到最后
                fs.Seek(position, SeekOrigin.Current);
            }
            //获取响应流
            //添加Range段标识
            request.AddRange(position);
            Stream stream = request.GetResponse().GetResponseStream();
            byte[] bytes = new byte[1024 * 512];
            int readCount = 0;
            while (true)
            {
                readCount = stream.Read(bytes, 0, bytes.Length);
                if (readCount <= 0)
                    break;
                fs.Write(bytes, 0, readCount);
                fs.Flush();
                MessageBox.Show("已经下载大小：" + readCount);
            }
            fs.Close();
            stream.Close();
            MessageBox.Show("下载文件成功,用时：" + (DateTime.Now - start).TotalSeconds + "秒");
        }

        private void ReadBindraryFile()
        {
            #region
            //BinaryReader类用来读取二进制数据，其读取数据的方法很多，常用方法如下：
            //Close()：关闭BinaryReader对象；
            //Read()：从指定流读取数据，并将指针迁移，指向下一个字符。
            //ReadDecimal()：从指定流读取一个十进制数值，并将在流中的位置向前移动16个字节。
            //ReadByte()：从指定流读取一个字节值，并将在流中的位置向前移动一个字节。
            //ReadInt16()：从指定流读取两个字节带符号整数值，并将在流中的位置向前移动两个字节。
            //ReadInt32()：从指定流读取两个字节带符号整数值，并将在流中的位置向前移动两个字节。
            //ReadString()：从指定流读取字符串，该字符串的前缀为字符串长度，编码为整数，每次7比特
            #endregion

            string path = @"D:\xrt49T00.TAG";
            FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            char cha;
            int num;
            double doub;
            string str;
            try
            {
                while (true)
                {
                    cha = br.ReadChar();
                    num = br.ReadInt32();
                    doub = br.ReadDouble();
                    str = br.ReadString();
                    MessageBox.Show("char="+cha + ";num="+num+";double="+doub+";str="+str);
                }
            }
            catch (EndOfStreamException e)
            {
                MessageBox.Show(e.Message);
                MessageBox.Show("已经读到末尾");
            }
            finally
            {
                //Console.ReadKey();
            }
        }
    }
}
