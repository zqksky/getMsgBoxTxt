﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Present.BatchOperation
{
    public partial class frmBatchOVLModel : Form
    {
        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmBatchOVLModel()
        {
            InitializeComponent();
        }
        public frmBatchOVLModel(string strServiceName, string strCurrentUserName, string strCurrentPwd, string strFrmProduct, string strFrmLayer, string strFrmTool, UIServiceFun.structPH_OVL_Batch_GetOVLModel structDataOVLModel)
        {
            InitializeComponent();
            strServiceAddres = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;

            strProduct = strFrmProduct;
            strLayer = strFrmLayer;
            strTool = strFrmTool;
            structData = structDataOVLModel;
            strOVLModel = structData.strOVLModel;
            bIsCPEModelOn = structData.bIsCPEModelOn;
            strCPEModeName = structData.strCPEModelName;
            strCPEModeTimeStamp = structData.strCPEModelTimeStamp;
        }

        #region Param
        string strServiceAddres;
        string strUserName;
        string strPassword;

        string strProduct;
        string strLayer;
        string strTool;
        string strOVLModel;
        bool bIsCPEModelOn;
        string strCPEModeName;
        string strCPEModeTimeStamp;

        UIServiceFun.structPH_OVL_Batch_GetOVLModel structData = new UIServiceFun.structPH_OVL_Batch_GetOVLModel();
        #endregion

        private void InitOVLMode()
        {
            if (strOVLModel.Equals("LINEAR"))
            {
                rdoLinear.Checked = true;
            }
            else if (strOVLModel.Equals("HOPC"))
            {
                rdoHOPC.Checked = true;
            }
            else if (strOVLModel.Equals("IHOPC"))
            {
                rdoIHOPC.Checked = true;
            }
            else
            {
                rdoLinear.Checked = true;
            }
        }

        private void InitCPEMode()
        {
            if (bIsCPEModelOn)
            {
                chkCPE.Checked = true;
            }
            else
            {
                chkCPE.Checked = false;
            }
        }

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        DataTable dbGetContext = new DataTable("GetContext");
        private void frmBatchOVLModel_Load(object sender, EventArgs e)
        {
            #region 双缓冲
            DataGridViewHelp.DoubleBuffered(dgvContext, true);
            CtlDoubleBuffer();
            #endregion

            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmBatchOVLModel_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            #region Set Lbl
            string strLbl = "Current Selected Context:" + strProduct + " /" + strTool + " /" + strLayer;
            AddControlHelp.SetLable(panLbl, lblContext, strLbl);
            
            string strDgvLblContext = "List of context group";
            AddControlHelp.SetLable(panDgvLblContext, lblDgvContext, strDgvLblContext);
            #endregion

            #region Init Control
            InitOVLMode();
            InitCPEMode();
            txtCPEModelName.Text = strCPEModeName;
            txtCPEModelTime.Text = strCPEModeTimeStamp;
            #endregion

            #region
            dbGetContext = DataTableHelp.CreateBatchOVLModelContextGroupTable(structData);

            DataTable dbContextGroup = new DataTable("ContextGroup");
            List<string> strListColumn = new List<string>(structData.strListContexts);
            dbContextGroup = DataTableHelp.GetDistinctTable(dbGetContext, strListColumn);

            DataGridViewHelp.InitDgvGrid(dgvContext, dbContextGroup);
            #endregion
        }

        private void frmBatchOVLModel_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmBatchOVLModel_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    bool bSuccess;
                    try
                    {
                        #region PH_OVL_Batch_UpdateOVLModel
                        bIsCPEModelOn = chkCPE.Checked;
                        strCPEModeName = txtCPEModelName.Text.ToString().Trim();
                        bSuccess = UIServiceFun.R2R_UI_PH_OVL_Batch_UpdateOVLModel(strServiceAddres, strUserName, strProduct, strLayer, strTool, strOVLModel, bIsCPEModelOn, strCPEModeName);
                        if (bSuccess)
                        {
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Set Failed!");
                        }
                        #endregion

                        this.DialogResult = DialogResult.OK;
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void chkCPE_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdoType_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoLinear.Checked)
            {
                strOVLModel = "LINEAR";
            }
            else if (rdoHOPC.Checked)
            {
                strOVLModel = "HOPC";
            }
            else if (rdoIHOPC.Checked)
            {
                strOVLModel = "IHOPC";
            }
        }

        #region Test DataGridView Event
        private void dgvContext_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //DataGridViewHelp.dgv_CellPainting(sender,  e);
        }

        private void dgvContext_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //DataGridViewHelp.dgv_RowPostPaint(sender, e);
        }

        private void dgvContext_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            //DataGridViewHelp.dgv_CellFormatting(sender, e);
        }
        #endregion
    }
}
