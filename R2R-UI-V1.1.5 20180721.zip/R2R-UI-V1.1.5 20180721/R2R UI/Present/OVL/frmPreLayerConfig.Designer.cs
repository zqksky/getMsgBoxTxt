﻿namespace R2R_UI.Present.OVL
{
    partial class frmPreLayerConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panSet = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.txtTool = new System.Windows.Forms.TextBox();
            this.txtCPEUpdatedTime = new System.Windows.Forms.TextBox();
            this.txtModelUpdatedTime = new System.Windows.Forms.TextBox();
            this.txtPMTime = new System.Windows.Forms.TextBox();
            this.txtReticle = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtLot = new System.Windows.Forms.TextBox();
            this.txtLayer = new System.Windows.Forms.TextBox();
            this.txtProduct = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panBtnOk = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.panText = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.btnQuery = new System.Windows.Forms.Button();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.txtPreLayer = new System.Windows.Forms.TextBox();
            this.txtPreLot = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoReferenceMode = new System.Windows.Forms.RadioButton();
            this.rdoManualMode = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.panSet.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panBtnOk.SuspendLayout();
            this.panText.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panSet);
            this.panel1.Controls.Add(this.panBtnOk);
            this.panel1.Controls.Add(this.panText);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(656, 393);
            this.panel1.TabIndex = 0;
            // 
            // panSet
            // 
            this.panSet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panSet.Controls.Add(this.panel2);
            this.panSet.Controls.Add(this.panel5);
            this.panSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panSet.Location = new System.Drawing.Point(0, 82);
            this.panSet.Name = "panSet";
            this.panSet.Size = new System.Drawing.Size(656, 278);
            this.panSet.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 54);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(654, 222);
            this.panel2.TabIndex = 9;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox11);
            this.groupBox3.Controls.Add(this.textBox13);
            this.groupBox3.Controls.Add(this.textBox15);
            this.groupBox3.Controls.Add(this.textBox12);
            this.groupBox3.Controls.Add(this.txtTool);
            this.groupBox3.Controls.Add(this.txtCPEUpdatedTime);
            this.groupBox3.Controls.Add(this.txtModelUpdatedTime);
            this.groupBox3.Controls.Add(this.txtPMTime);
            this.groupBox3.Controls.Add(this.txtReticle);
            this.groupBox3.Controls.Add(this.textBox14);
            this.groupBox3.Location = new System.Drawing.Point(11, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(625, 193);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            // 
            // textBox11
            // 
            this.textBox11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11.Location = new System.Drawing.Point(18, 19);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(153, 20);
            this.textBox11.TabIndex = 4;
            this.textBox11.Text = "Pre-layer Tool:";
            // 
            // textBox13
            // 
            this.textBox13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox13.Location = new System.Drawing.Point(18, 89);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(153, 20);
            this.textBox13.TabIndex = 6;
            this.textBox13.Text = " Pre-layer PM Time:";
            // 
            // textBox15
            // 
            this.textBox15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox15.Location = new System.Drawing.Point(18, 159);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(153, 20);
            this.textBox15.TabIndex = 8;
            this.textBox15.Text = "Pre-layer Model Update Time:";
            // 
            // textBox12
            // 
            this.textBox12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12.Location = new System.Drawing.Point(18, 54);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(153, 20);
            this.textBox12.TabIndex = 5;
            this.textBox12.Text = " Pre-layer Reticle: ";
            // 
            // txtTool
            // 
            this.txtTool.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.txtTool.Location = new System.Drawing.Point(188, 19);
            this.txtTool.Name = "txtTool";
            this.txtTool.Size = new System.Drawing.Size(234, 20);
            this.txtTool.TabIndex = 3;
            // 
            // txtCPEUpdatedTime
            // 
            this.txtCPEUpdatedTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.txtCPEUpdatedTime.Location = new System.Drawing.Point(188, 124);
            this.txtCPEUpdatedTime.Name = "txtCPEUpdatedTime";
            this.txtCPEUpdatedTime.Size = new System.Drawing.Size(234, 20);
            this.txtCPEUpdatedTime.TabIndex = 6;
            // 
            // txtModelUpdatedTime
            // 
            this.txtModelUpdatedTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.txtModelUpdatedTime.Location = new System.Drawing.Point(188, 159);
            this.txtModelUpdatedTime.Name = "txtModelUpdatedTime";
            this.txtModelUpdatedTime.Size = new System.Drawing.Size(234, 20);
            this.txtModelUpdatedTime.TabIndex = 7;
            // 
            // txtPMTime
            // 
            this.txtPMTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.txtPMTime.Location = new System.Drawing.Point(188, 89);
            this.txtPMTime.Name = "txtPMTime";
            this.txtPMTime.Size = new System.Drawing.Size(234, 20);
            this.txtPMTime.TabIndex = 5;
            // 
            // txtReticle
            // 
            this.txtReticle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.txtReticle.Location = new System.Drawing.Point(188, 54);
            this.txtReticle.Name = "txtReticle";
            this.txtReticle.Size = new System.Drawing.Size(234, 20);
            this.txtReticle.TabIndex = 4;
            // 
            // textBox14
            // 
            this.textBox14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox14.Location = new System.Drawing.Point(18, 124);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(153, 20);
            this.textBox14.TabIndex = 7;
            this.textBox14.Text = " Pre-layer CPE Update Time:";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.groupBox4);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(654, 54);
            this.panel5.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtLot);
            this.groupBox4.Controls.Add(this.txtLayer);
            this.groupBox4.Controls.Add(this.txtProduct);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Location = new System.Drawing.Point(11, 5);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(625, 38);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            // 
            // txtLot
            // 
            this.txtLot.Location = new System.Drawing.Point(486, 13);
            this.txtLot.Name = "txtLot";
            this.txtLot.Size = new System.Drawing.Size(130, 20);
            this.txtLot.TabIndex = 6;
            // 
            // txtLayer
            // 
            this.txtLayer.Location = new System.Drawing.Point(278, 13);
            this.txtLayer.Name = "txtLayer";
            this.txtLayer.Size = new System.Drawing.Size(129, 20);
            this.txtLayer.TabIndex = 5;
            // 
            // txtProduct
            // 
            this.txtProduct.Location = new System.Drawing.Point(82, 13);
            this.txtProduct.Name = "txtProduct";
            this.txtProduct.Size = new System.Drawing.Size(117, 20);
            this.txtProduct.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Location = new System.Drawing.Point(424, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "Lot Id:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(18, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "Product:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Location = new System.Drawing.Point(234, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "Layer:";
            // 
            // panBtnOk
            // 
            this.panBtnOk.Controls.Add(this.btnCancel);
            this.panBtnOk.Controls.Add(this.btnOk);
            this.panBtnOk.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBtnOk.Location = new System.Drawing.Point(0, 360);
            this.panBtnOk.Name = "panBtnOk";
            this.panBtnOk.Size = new System.Drawing.Size(656, 33);
            this.panBtnOk.TabIndex = 1;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(544, 7);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(73, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(451, 7);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(73, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panText
            // 
            this.panText.Controls.Add(this.groupBox2);
            this.panText.Controls.Add(this.groupBox1);
            this.panText.Dock = System.Windows.Forms.DockStyle.Top;
            this.panText.Location = new System.Drawing.Point(0, 0);
            this.panText.Name = "panText";
            this.panText.Size = new System.Drawing.Size(656, 82);
            this.panText.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox17);
            this.groupBox2.Controls.Add(this.btnQuery);
            this.groupBox2.Controls.Add(this.textBox16);
            this.groupBox2.Controls.Add(this.txtPreLayer);
            this.groupBox2.Controls.Add(this.txtPreLot);
            this.groupBox2.Location = new System.Drawing.Point(179, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(458, 68);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            // 
            // textBox17
            // 
            this.textBox17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox17.Location = new System.Drawing.Point(17, 41);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(98, 20);
            this.textBox17.TabIndex = 6;
            this.textBox17.Text = "Reference Lot:";
            // 
            // btnQuery
            // 
            this.btnQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnQuery.Location = new System.Drawing.Point(364, 29);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(73, 21);
            this.btnQuery.TabIndex = 0;
            this.btnQuery.Text = "Query";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // textBox16
            // 
            this.textBox16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox16.Location = new System.Drawing.Point(17, 16);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(98, 20);
            this.textBox16.TabIndex = 5;
            this.textBox16.Text = "Reference Layer:";
            // 
            // txtPreLayer
            // 
            this.txtPreLayer.Location = new System.Drawing.Point(133, 15);
            this.txtPreLayer.Name = "txtPreLayer";
            this.txtPreLayer.Size = new System.Drawing.Size(211, 20);
            this.txtPreLayer.TabIndex = 2;
            // 
            // txtPreLot
            // 
            this.txtPreLot.Location = new System.Drawing.Point(133, 41);
            this.txtPreLot.Name = "txtPreLot";
            this.txtPreLot.Size = new System.Drawing.Size(211, 20);
            this.txtPreLot.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoReferenceMode);
            this.groupBox1.Controls.Add(this.rdoManualMode);
            this.groupBox1.Location = new System.Drawing.Point(12, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(150, 68);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // rdoReferenceMode
            // 
            this.rdoReferenceMode.AutoSize = true;
            this.rdoReferenceMode.Location = new System.Drawing.Point(18, 44);
            this.rdoReferenceMode.Name = "rdoReferenceMode";
            this.rdoReferenceMode.Size = new System.Drawing.Size(105, 17);
            this.rdoReferenceMode.TabIndex = 9;
            this.rdoReferenceMode.Text = "Reference Mode";
            this.rdoReferenceMode.UseVisualStyleBackColor = true;
            this.rdoReferenceMode.CheckedChanged += new System.EventHandler(this.rdoMode_CheckedChanged);
            // 
            // rdoManualMode
            // 
            this.rdoManualMode.AutoSize = true;
            this.rdoManualMode.Checked = true;
            this.rdoManualMode.Location = new System.Drawing.Point(18, 18);
            this.rdoManualMode.Name = "rdoManualMode";
            this.rdoManualMode.Size = new System.Drawing.Size(90, 17);
            this.rdoManualMode.TabIndex = 8;
            this.rdoManualMode.TabStop = true;
            this.rdoManualMode.Text = "Manual Mode";
            this.rdoManualMode.UseVisualStyleBackColor = true;
            this.rdoManualMode.CheckedChanged += new System.EventHandler(this.rdoMode_CheckedChanged);
            // 
            // frmPreLayerConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 393);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(663, 425);
            this.Name = "frmPreLayerConfig";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PreLayerConfig";
            this.Load += new System.EventHandler(this.frmPreLayerConfig_Load);
            this.SizeChanged += new System.EventHandler(this.frmPreLayerConfig_SizeChanged);
            this.Resize += new System.EventHandler(this.frmPreLayerConfig_Resize);
            this.panel1.ResumeLayout(false);
            this.panSet.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panBtnOk.ResumeLayout(false);
            this.panText.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panText;
        private System.Windows.Forms.Panel panSet;
        private System.Windows.Forms.Panel panBtnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtModelUpdatedTime;
        private System.Windows.Forms.TextBox txtCPEUpdatedTime;
        private System.Windows.Forms.TextBox txtPMTime;
        private System.Windows.Forms.TextBox txtReticle;
        private System.Windows.Forms.TextBox txtTool;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox txtLot;
        private System.Windows.Forms.TextBox txtLayer;
        private System.Windows.Forms.TextBox txtProduct;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox txtPreLot;
        private System.Windows.Forms.TextBox txtPreLayer;
        private System.Windows.Forms.RadioButton rdoReferenceMode;
        private System.Windows.Forms.RadioButton rdoManualMode;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}