﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Present.OVL
{
    public partial class frmCDMode : Form
    {
        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmCDMode()
        {
            InitializeComponent();
        }
        public frmCDMode(string strServiceName, string strCurrentUserName, string strCurrentPwd, List<string> strListFrmR2RContexts, UIServiceFun.structPH_CD_GetDoseSettings structDataSetting)
        {
            InitializeComponent();
            strServiceAddress = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;

            strListR2RContexts = new List<string>(strListFrmR2RContexts);
            structData = structDataSetting;
            strR2RMode = structDataSetting.strR2RMode;
            strInitR2RMode = structDataSetting.strR2RMode;
            dDoseMax = structDataSetting.dDoseMax;
            dDoseMin = structDataSetting.dDoseMin;
            dDoseFixedValue = structDataSetting.dDoseFixedValue;
            dDoseCurrentValue = structDataSetting.dDoseCurrentValue;
        }

        #region Param
        bool bModeChanged = false;
        bool bActive;
        string strServiceAddress;
        string strUserName;
        string strPassword;

        string strInitR2RMode;
        string strR2RMode;
        double dDoseMax;
        double dDoseMin;
        double dDoseFixedValue;
        double dDoseCurrentValue;
        List<string> strListR2RContexts = new List<string>();
        UIServiceFun.structPH_CD_GetDoseSettings structData = new UIServiceFun.structPH_CD_GetDoseSettings();

        double dDoseNewValue;
        UIServiceFun.structPH_CD_UpdateDoseSettings structDataUpdate = new UIServiceFun.structPH_CD_UpdateDoseSettings();
        #endregion

        private void InitControl()
        {
            txtNew.Enabled = false;
            btnOk.Enabled = false;
        }

        private void InitValue()
        {
            if (strR2RMode.Equals("Active"))
            {
                rdoActive.Checked = true;
                bActive = true;
            }
            else if (strR2RMode.Equals("Fixed"))
            {
                rdoFixed.Checked = true;
                bActive = false;
            }

            txtMax.Text = dDoseMax.ToString();
            txtMin.Text = dDoseMin.ToString();
            txtCurrent.Text = dDoseCurrentValue.ToString();
            txtFixed.Text = dDoseFixedValue.ToString();
            if (bActive)
            {
                txtNew.Text = dDoseCurrentValue.ToString();
            }
            else
            {
                txtNew.Text = dDoseFixedValue.ToString();
            }
        }

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmCDMode_Load(object sender, EventArgs e)
        {
            #region 双缓冲
            CtlDoubleBuffer();
            #endregion

            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmCDMode_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            InitControl();
            InitValue();
        }

        private void frmCDMode_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmCDMode_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void rdoType_CheckedChanged(object sender, EventArgs e)
        {
            bModeChanged = true;
            txtNew.Enabled = true;
            btnOk.Enabled = true;
            if (rdoActive.Checked)
            {
                bActive = true;
                strR2RMode = "Active";
                txtNew.Text = txtCurrent.Text;
            }
            else if (rdoFixed.Checked)
            {
                bActive = false;
                strR2RMode = "Fixed";
                txtNew.Text = txtFixed.Text;
            }
            if (strInitR2RMode.Equals(strR2RMode))
            {
                InitControl();
            }
        }
        private void GetUpdateValue()
        {
            dDoseNewValue = double.Parse(txtNew.Text.ToString());
            structDataUpdate.strR2RMode = strR2RMode;
            structDataUpdate.dDoseMax = dDoseMax;
            structDataUpdate.dDoseMin = dDoseMin;
            structDataUpdate.strDoseNewValue = dDoseNewValue.ToString();
        }
        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    bool bSuccess;
                    try
                    {
                        #region PH_CD_UpdateDoseSettings
                        GetUpdateValue();
                        bSuccess = UIServiceFun.R2R_UI_PH_CD_UpdateDoseSettings(strServiceAddress, strUserName, strListR2RContexts, structDataUpdate);
                        if (bSuccess)
                        {
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Set Failed!");
                        }
                        this.DialogResult = DialogResult.OK;
                        #endregion
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
