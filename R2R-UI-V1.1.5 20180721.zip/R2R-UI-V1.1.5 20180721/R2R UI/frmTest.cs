﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI
{
    public partial class frmTest : Form
    {
        public frmTest()
        {
            InitializeComponent();
        }
        private void InitOptContext()
        {
            DataGridViewHelp.InitDgvSet(dgvSet, DataTableHelp.CreateContextTable());
        }
        private void AddRowToOptContext(string strCell)
        {
            DataGridViewColumn myCol = new DataGridViewColumn();
            DataGridViewColumn myCol2 = new DataGridViewComboBoxColumn();
            myCol.Name = "Key";
            myCol.HeaderText = "Name";
            myCol2.Name = "Value";
            myCol2.HeaderText = "Value";
            dgvSet.Columns.Add(myCol);
            dgvSet.Columns.Add(myCol2);

            DataGridViewRow row = new DataGridViewRow();
            DataGridViewTextBoxCell textboxcell = new DataGridViewTextBoxCell();
            textboxcell.Value = strCell;
            row.Cells.Add(textboxcell);
            DataGridViewComboBoxCell comboxcell = new DataGridViewComboBoxCell();
            comboxcell.Items.Add("1");
            comboxcell.Items.Add("2");
            row.Cells.Add(comboxcell);
            dgvSet.Rows.Add(row);
        }

        private void SetDgvCmb(int rowIndex, int colIndex)
        {
            List<string> strList = new List<string>() { "NA", "C1", "C2" };
            dgvSet.Rows[rowIndex].Cells[colIndex] = new DataGridViewComboBoxCell();

            ((DataGridViewComboBoxCell)dgvSet.Rows[rowIndex].Cells[colIndex]).DataSource = strList;
            //((DataGridViewComboBoxCell)dgvSet.Rows[rowIndex].Cells[colIndex]).DisplayMember = "Key";
            //((DataGridViewComboBoxCell)dgvSet.Rows[rowIndex].Cells[colIndex]).ValueMember = "Value";
            //((DataGridViewComboBoxCell)dgvSet.Rows[rowIndex].Cells[colIndex]).Value= strList[0];
            //((DataGridViewComboBoxCell)dgvSet.Rows[rowIndex].Cells[colIndex]).Items[0] = strList[0];
            dgvSet.Rows[rowIndex].Cells[colIndex].Value = strList[0];

        }
       
        private void SetDgvCmb(int colIndex, List<string> strList)
        {
            DataGridViewColumn myCol = new DataGridViewComboBoxColumn();
            myCol.Name = "选择框";
            myCol.HeaderText = "选择框";
            //dgvSet.Columns.Add(myCol);

            strList = new List<string>() { "NA", "C1", "C2" };
            dgvSet.AllowUserToAddRows = false;
            dgvSet.AutoGenerateColumns = false;

            dgvSet.Columns.Insert(colIndex, myCol);

            ((DataGridViewComboBoxColumn)dgvSet.Columns[colIndex]).DataSource = strList;
            ((DataGridViewComboBoxColumn)dgvSet.Columns[colIndex]).DefaultCellStyle.NullValue = strList[0];
        }

        private void SetDgvCmbTest(int colIndex)
        {
            //DataGridViewComboBoxColumn salColumn = new DataGridViewComboBoxColumn();
            //salColumn.Items.Add("张三");
            //salColumn.Items.Add("李四");
            //salColumn.Items.Add("王五");
            //salColumn.DefaultCellStyle.NullValue = "王五";
            //((DataGridViewComboBoxColumn)dgvSet.Columns[colIndex]).DataSource = salColumn;

            List<string> strList = new List<string>() { "NA", "C1", "C2" };
            DataGridViewComboBoxColumn cbo = (DataGridViewComboBoxColumn)dgvSet.Columns[colIndex] as DataGridViewComboBoxColumn;
            cbo.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing;
            cbo.DataSource = strList;
            //cbo.DisplayMember = "Key";
            //cbo.ValueMember = "Value";

            //dgvSet.Rows[0].Cells[1] = new DataGridViewCheckBoxCell();
        }

        private void frmTest_Load(object sender, EventArgs e)
        {
            //AddRowToOptContext("123");

            //List<string> strList = new List<string>();
            //SetDgvCmb(1, strList);

            //InitChuckComboBox();

            InitOptContext();
            //SetDgvCmb(1,1);

            SetDgvCmbTest(1);

        }

        #region test
        private ComboBox cmbDgv = new ComboBox();//全局变量
        private void InitChuckComboBox()
        {
            #region test
            //List<string> strList = new List<string>() { "NA", "C1", "C2" };
            //cmbDgv.DataSource = strList;
            cmbDgv.Items.Add("NA");
            cmbDgv.Items.Add("C1");
            cmbDgv.Items.Add("C2");
            cmbDgv.Text = "NA";

            cmbDgv.Leave += new EventHandler(cmbDgv_TextChanged);
            cmbDgv.SelectedIndexChanged += new EventHandler(cmbDgv_TextChanged);
            cmbDgv.Visible = false;
            cmbDgv.DropDownStyle = ComboBoxStyle.DropDownList;

            ////为生成的组合框控件，添加文本改变事件处理函数
            //cmbDgv.TextChanged += new EventHandler(cmbDgv_changed);

            //// 添加下拉列表框事件
            //cmbDgv.SelectedIndexChanged += new EventHandler(cmbDgv_SelectedIndexChanged);

            dgvSet.Controls.Add(cmbDgv); //把组合框添加到dataGridView1中
            #endregion
        }

        private void cmbDgv_TextChanged(object sender, EventArgs e)
        {
            try
            {
                ((ComboBox)sender).Text = ((ComboBox)sender).Text.ToString();
                int row_index = this.dgvSet.CurrentCell.RowIndex;
                DataTable data = (this.dgvSet.DataSource as DataTable);
                data.Rows[row_index][1] = ((ComboBox)sender).Text;
                this.cmbDgv.Visible = false;
            }
            catch (Exception ex)
            {

            }
        }

        //当文本改变时，把dataGridView当前单元格内容设为组合框的内容
        private void cmbDgv_changed(object sender, EventArgs e)
        {
            if (dgvSet.CurrentCell.ColumnIndex == 1)
            {
                dgvSet.CurrentCell.Value = cmbDgv.Text;
            }
        }
        // 当用户选择下拉列表框时改变DataGridView单元格的内容
        private void cmbDgv_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dgvSet.CurrentCell.ColumnIndex == 1)
            {
                dgvSet.CurrentCell.Value = cmbDgv.Text;
            }
        }

        private void dgvSet_CurrentCellChanged(object sender, EventArgs e)
        {
            //if (this.dgvSet.CurrentCell.ColumnIndex == 1)
            //{
            //    Rectangle rect = dgvSet.GetCellDisplayRectangle(dgvSet.CurrentCell.ColumnIndex, dgvSet.CurrentCell.RowIndex, false);
            //    string sexValue = dgvSet.CurrentCell.Value.ToString();
            //    cmbDgv.Left = rect.Left;
            //    cmbDgv.Top = rect.Top;
            //    cmbDgv.Width = rect.Width;
            //    cmbDgv.Height = rect.Height;
            //    cmbDgv.Visible = true;
            //}
            //else
            //{
            //    cmbDgv.Visible = false;
            //}
        }

        private void dgvSet_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            //cmbDgv.Visible = false;
        }
        #endregion

        #region test
        /// <summary>
        /// ComboBox或CheckedListBox或DataGridViewComboBoxColumn绑定到数据源
        /// </summary>
        /// <param name="obj"> 要绑定数据源的控件 </param>
        /// <param name="strValueColumn"> ValueMember属性要绑定的列名称 </param>
        /// <param name="strTextColumn"> DisplayMember属性要绑定的列名称 </param>
        /// <param name="strSql"> SQL查询语句 </param>
        /// <param name="strTable"> 数据表的名称 </param>
        public static void BindComboBox(Object obj, string strValueColumn, string strTextColumn, string strSql, string strTable)        //Component —替换—> Object
        {
            try
            {
                string strType = obj.GetType().ToString();
                strType = strType.Substring(strType.LastIndexOf(".") + 1);

                //判断控件的类型
                switch (strType)
                {
                    case "ComboBox":
                        ComboBox cbx = (ComboBox)obj;
                        cbx.BeginUpdate();
                        //cbx.DataSource = DbHelperOleDb.Query(strSql, strTable).Tables[strTable];
                        cbx.DisplayMember = strTextColumn;
                        cbx.ValueMember = strValueColumn;
                        cbx.EndUpdate();
                        break;

                    case "CheckedListBox":

                        CheckedListBox clb = (CheckedListBox)obj;
                        //clb.DataSource = DbHelperOleDb.Query(strSql, strTable).Tables[strTable];
                        clb.DisplayMember = strTextColumn;
                        clb.ValueMember = strValueColumn;
                        break;

                    case "DataGridViewComboBoxColumn":

                        DataGridViewComboBoxColumn dgvcbx = (DataGridViewComboBoxColumn)obj;
                        ///dgvcbx.DataSource = DbHelperOleDb.Query(strSql, strTable).Tables[strTable];
                        dgvcbx.DisplayMember = strTextColumn;
                        dgvcbx.ValueMember = strValueColumn;
                        break;

                    case "DataGridViewComboBoxCell":

                        DataGridViewComboBoxCell dgvcbc = (DataGridViewComboBoxCell)obj;
                        //dgvcbc.DataSource = DbHelperOleDb.Query(strSql, strTable).Tables[strTable];
                        dgvcbc.DisplayMember = strTextColumn;
                        dgvcbc.ValueMember = strValueColumn;
                        break;

                    default:
                        break;
                }
            }
            catch (Exception ex)
            {

            }
        }
        #endregion

        #region 下拉列表框改变事件
        private void dgvSet_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //if (dgvSet.CurrentCell != null && e.Control.GetType() == typeof(DataGridViewComboBoxEditingControl))
            //{
            //    //创建下拉列表框改变事件
            //    (e.Control as ComboBox).SelectedIndexChanged += new EventHandler(cmbDgv_SelectedIndexChanged);

            //    //创建下拉列表框离开焦点事件 添加该事件是为了删除动态事件 以免多次调用
            //    (e.Control as ComboBox).Leave += new EventHandler(cmbDgv_Leave);
            //}
        }
        //离开焦点事件
        private void cmbDgv_Leave(object sender, EventArgs e)
        {
            ////删除动态调用
            //(sender as ComboBox).SelectedIndexChanged -= new EventHandler(cmbDgv_SelectedIndexChanged);
            //(sender as ComboBox).Leave -= new EventHandler(cmbDgv_Leave);
        }
        #endregion

        #region 
        private void dgvSet_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //if (e.ColumnIndex < 0 && e.RowIndex >= 0) // 绘制 自动序号
            //{
            //    e.Paint(e.ClipBounds, DataGridViewPaintParts.All);
            //    Rectangle vRect = e.CellBounds;
            //    vRect.Inflate(-2, 2);
            //    TextRenderer.DrawText(e.Graphics, (e.RowIndex + 1).ToString(), e.CellStyle.Font, vRect, e.CellStyle.ForeColor, TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
            //    e.Handled = true;
            //}

            //// ----- 其它样式设置 -------
            //if (e.RowIndex % 2 == 0)
            //{ // 行序号为双数（含0）时 
            //    e.CellStyle.BackColor = Color.White;
            //}
            //else
            //{
            //    e.CellStyle.BackColor = Color.Honeydew;
            //}
            //e.CellStyle.SelectionBackColor = Color.Gray; // 选中单元格时，背景色
            //e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; //单位格内

        }

        private void dgvSet_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            #region fun1    datagridview显示行号 
            //var grid = sender as DataGridView;
            //var rowIdx = (e.RowIndex + 1).ToString();

            //var centerFormat = new StringFormat()
            //{
            //    // right alignment might actually make more sense for numbers
            //    Alignment = StringAlignment.Center,
            //    LineAlignment = StringAlignment.Center
            //};
            //var headerBounds = new System.Drawing.Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            //e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
            #endregion

            #region fun2    datagridview显示行号 
            Rectangle rectangle = new Rectangle(e.RowBounds.Location.X,
                e.RowBounds.Location.Y,
                dgvSet.RowHeadersWidth - 4,
                e.RowBounds.Height);


            TextRenderer.DrawText(e.Graphics, (e.RowIndex + 1).ToString(),
                dgvSet.RowHeadersDefaultCellStyle.Font, rectangle,
                dgvSet.RowHeadersDefaultCellStyle.ForeColor,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
            #endregion
        }
        #endregion

        // CellFormatting事件处理器
        private void dgvSet_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //DataGridView dgv = (DataGridView)sender;

            ////确认单元格的列
            //if (dgv.Columns[e.ColumnIndex].Name == "Column1" && e.Value is string)
            //{
            //    e.Value = e.Value.ToString();
            //}
        }
    }
}
