﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;

namespace R2R_UI.Common
{
    class ChartHelp
    {
        #region Create Chart
        public static Chart CreateColumnChart(string strChartTitle, List<double> dListValue, List<string> strListChartColumn)
        {
            Chart chart = new Chart();
            chart.Titles.Add(strChartTitle);

            ChartArea chartArea = new ChartArea();
            chart.ChartAreas.Add(chartArea);
            SetChartAreaAxisX(chartArea);
            SetChartAreaAxisY(chartArea);

            chart.Series.Clear();
            Series series = new Series("series");
            SetSeries(series,2);
            series.Points.DataBindXY(strListChartColumn, dListValue);
            //series.LegendToolTip = "value";//鼠标放到系列上出现的文字 
            chart.Series.Add(series);

            return chart;
        }

        public static Chart CreateLineChart(string strChartTitle, List<double> dListValue, List<double> dListMax, List<double> dListMin, List<string> strListChartColumn)
        {
            Chart chart = new Chart();

            return chart;
        }

        public static Chart CreateLineChart(string strChartTitle, List<double> dListValue, List<string> strListChartColumn)
        {
            Chart chart = new Chart();
            chart.Titles.Add(strChartTitle);

            ChartArea chartArea = new ChartArea();           
            chart.ChartAreas.Add(chartArea);
            SetChartAreaAxisX(chartArea);
            SetChartAreaAxisY(chartArea);
            //chartArea.Area3DStyle.Enable3D = true;

            chart.Series.Clear();
            Series series = new Series("series");
            SetSeries(series);
            series.Points.DataBindXY(strListChartColumn, dListValue);
            //series.LegendToolTip = "value";//鼠标放到系列上出现的文字 
            chart.Series.Add(series);

            return chart;
        }
        #endregion

        #region Set Chart
        private static void SetChartAreaAxisX(ChartArea chartArea)
        {
            //chartArea.AxisX.Title = strTitle;
            chartArea.AxisX.MajorGrid.Interval = 0.5;
            chartArea.AxisX.MajorGrid.Enabled = true;
            chartArea.AxisX.MinorTickMark.Enabled = false;
            chartArea.AxisX.IsMarginVisible = true;
            chartArea.AxisX.TitleForeColor = Color.Crimson;
            //chartArea.AxisX.TextOrientation = TextOrientation.Rotated90;
            //chartArea.AxisX.IsInterlaced = true;  //显示交错带 
            //chartArea.AxisX.LabelStyle.Format = "#";                      //设置X轴显示样式

            //chartArea.AxisX.Interval = 1;
            //chartArea.AxisX.IntervalAutoMode = IntervalAutoMode.VariableCount;
            //chartArea.AxisX.IsStartedFromZero = true;
            //chartArea.AxisX.LabelStyle.Angle = -90;                      //设置X轴显示样式
            chartArea.AxisX.LabelStyle.Angle = -90;                      //设置X轴显示样式
        }
        private static void SetChartAreaAxisY(ChartArea chartArea)
        {
            //chartArea.AxisY.Title = strTitle;
            //chartArea.AxisY.MajorGrid.Interval = 0.5;
            chartArea.AxisY.MajorGrid.Enabled = true;
            chartArea.AxisY.TitleForeColor = Color.Crimson;
            chartArea.AxisY.TextOrientation = TextOrientation.Horizontal;
        }
        private static void SetSeries(Series series)
        {
            series.ChartType = SeriesChartType.Line;
            //series.ChartType = SeriesChartType.Column;
            series.BorderWidth = 3;            //线条粗细
            series.Color = Color.YellowGreen;            //线条颜色

            //series.IsValueShownAsLabel = true;
            //series.Label = "#VAL";                //设置显示X Y的值

            series.ToolTip = "#VAL";     //鼠标移动到对应点显示数值

            SetSeriesMarker(series);

            ////饼图说明设置，这用来设置饼图每一块的信息显示在什么地方
            //series["PieLabelStyle"] = "Outside";//将文字移到外侧
            //series["PieLineColor"] = "Black";//绘制黑色的连线。

            ////柱状图其他设置
            //series["DrawingStyle"] = "Emboss";   //设置柱状平面形状
            //series["PointWidth"] = "0.5"; //设置柱状大小
        }
        private static void SetSeries(Series series,int chartType)
        {
            if (chartType == 1)
            {
                series.ChartType = SeriesChartType.Line;
            }
            else if(chartType == 2)
            {
                series.ChartType = SeriesChartType.Column;
            }

            series.BorderWidth = 3;            //线条粗细
            series.Color = Color.YellowGreen;            //线条颜色

            //series.IsValueShownAsLabel = true;
            //series.Label = "#VAL";                //设置显示X Y的值

            series.ToolTip = "#VAL";     //鼠标移动到对应点显示数值

            SetSeriesMarker(series);

            ////饼图说明设置，这用来设置饼图每一块的信息显示在什么地方
            //series["PieLabelStyle"] = "Outside";//将文字移到外侧
            //series["PieLineColor"] = "Black";//绘制黑色的连线。

            ////柱状图其他设置
            //series["DrawingStyle"] = "Emboss";   //设置柱状平面形状
            //series["PointWidth"] = "0.5"; //设置柱状大小
        }
        private static void SetSeriesMarker(Series series)
        {
            series.MarkerBorderColor = Color.Black;            //标记点边框颜色     
            series.MarkerBorderWidth = 3;            //标记点边框大小
            series.MarkerColor = Color.Red;            //标记点中心颜色
            series.MarkerSize = 8;            //标记点大小
            series.MarkerStyle = MarkerStyle.Circle;            //标记点类型    
        }

        private void SetMajorGridX(ChartArea chartArea)
        {
            //设置主刻度线和副刻度线 一般只有主刻度线才有对应标签值。  
            chartArea.AxisX.MajorGrid.Interval = 0.5;
            chartArea.AxisX.MajorGrid.Enabled = true;
            chartArea.AxisX.MinorTickMark.Enabled = false;
            chartArea.AxisX.MajorGrid.Enabled = false;       //X轴上网格
            chartArea.AxisX.MajorGrid.Enabled = false;      //y轴上网格
            chartArea.AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dash;   //网格类型 短横线
            chartArea.AxisX.MajorGrid.LineColor = Color.Gray;
            chartArea.AxisX.MajorTickMark.Enabled = false;                   //  x轴上突出的小点
            chartArea.AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dash;   //网格类型 短横线
            chartArea.AxisX.MajorGrid.LineColor = Color.Gray;
            chartArea.AxisX.MajorGrid.LineWidth = 3;
        }
        private void SetMajorGridY(ChartArea chartArea)
        {
            chartArea.AxisY.MajorGrid.Interval = 0.5;
            chartArea.AxisY.MajorGrid.Enabled = true;
            chartArea.AxisY.MinorTickMark.Enabled = false;
        }
        private void SetChart(Chart Chart)
        {
            #region 图表样式
            Chart.BackGradientStyle = GradientStyle.TopBottom;//指定图表元素的渐变样式(中心向外，从左到右，从上到下等等)
            Chart.BackSecondaryColor = Color.Yellow;//设置背景的辅助颜色
            Chart.BorderlineColor = Color.Yellow;//设置图像边框的颜色
            Chart.BorderlineDashStyle = ChartDashStyle.Solid;//设置图像边框线的样式(实线、虚线、点线)
            Chart.BorderlineWidth = 2;//设置图像的边框宽度
            Chart.BorderSkin.SkinStyle = BorderSkinStyle.Emboss;//设置图像的边框外观样式
            Chart.BackColor = Color.Yellow;//设置图表的背景颜色
            #endregion

            #region 数据样式

            Chart.Series["Series1"].XValueMember = "name";//设置X轴的数据源

            Chart.Series["Series1"].YValueMembers = "mobile";//设置Y轴的数据源

            Chart.Series["Series2"].XValueMember = "name";

            Chart.Series["Series2"].YValueMembers = "id";

            Chart.Series["Series2"].Color = System.Drawing.Color.Red;//设置颜色

            Chart.Series["Series2"].ChartType = SeriesChartType.Line;//设置图表的类型(饼状、线状等等)

            Chart.Series["Series1"].IsValueShownAsLabel = true;//设置是否在Chart中显示坐标点值

            Chart.Series["Series1"].BorderColor = System.Drawing.Color.Red;//设置数据边框的颜色

            Chart.BackColor = System.Drawing.Color.Red;//设置图表的背景颜色

            Chart.Series["Series1"].Color = System.Drawing.Color.Black;//设置数据的颜色

            Chart.Series["Series1"].Name = "数据1";//设置数据名称

            Chart.Series["数据1"].ShadowOffset = 1;//设置阴影偏移量

            Chart.Series["数据1"].ShadowColor = System.Drawing.Color.PaleGreen;//设置阴影颜色

            #endregion

            #region 图表区域样式
            Chart.ChartAreas["ChartArea1"].Name = "图表区域";

            Chart.ChartAreas["图表区域"].Position.Auto = true;//设置是否自动设置合适的图表元素

            Chart.ChartAreas["图表区域"].ShadowColor = Color.YellowGreen;//设置图表的阴影颜色

            Chart.ChartAreas["图表区域"].Position.X = 5.089137F;//设置图表元素左上角对应的X坐标

            Chart.ChartAreas["图表区域"].Position.Y = 5.895753F;//设置图表元素左上角对应的Y坐标

            Chart.ChartAreas["图表区域"].Position.Height = 86.76062F;//设置图表元素的高度

            Chart.ChartAreas["图表区域"].Position.Width = 88F;//设置图表元素的宽度



            Chart.ChartAreas["图表区域"].InnerPlotPosition.Auto = false;//设置是否在内部绘图区域中自动设置合适的图表元素

            Chart.ChartAreas["图表区域"].InnerPlotPosition.Height = 85F;//设置图表元素内部绘图区域的高度

            Chart.ChartAreas["图表区域"].InnerPlotPosition.Width = 86F;//设置图表元素内部绘图区域的宽度

            Chart.ChartAreas["图表区域"].InnerPlotPosition.X = 8.3969F;//设置图表元素内部绘图区域左上角对应的X坐标

            Chart.ChartAreas["图表区域"].InnerPlotPosition.Y = 3.63068F;//设置图表元素内部绘图区域左上角对应的Y坐标



            Chart.ChartAreas["图表区域"].Area3DStyle.Inclination = 10;//设置三维图表的旋转角度

            Chart.ChartAreas["图表区域"].Area3DStyle.IsClustered = true;//设置条形图或柱形图的的数据系列是否为簇状

            Chart.ChartAreas["图表区域"].Area3DStyle.IsRightAngleAxes = true;//设置图表区域是否使用等角投影显示

            Chart.ChartAreas["图表区域"].Area3DStyle.LightStyle = System.Windows.Forms.DataVisualization.Charting.LightStyle.Realistic;//设置图表的照明类型(色调随旋转角度改变而改变，不应用照明，色调不改变)

            Chart.ChartAreas["图表区域"].Area3DStyle.Perspective = 50;//设置三维图区的透视百分比

            Chart.ChartAreas["图表区域"].Area3DStyle.Rotation = 60;//设置三维图表区域绕垂直轴旋转的角度

            Chart.ChartAreas["图表区域"].Area3DStyle.WallWidth = 0;//设置三维图区中显示的墙的宽度

            Chart.ChartAreas["图表区域"].Area3DStyle.Enable3D = true;//设置是否显示3D效果



            Chart.ChartAreas["图表区域"].BackColor = Color.Green;//设置图表区域的背景颜色

            Chart.ChartAreas["图表区域"].BackGradientStyle = GradientStyle.LeftRight;//指定图表元素的渐变样式(中心向外，从左到右，从上到下等等)

            Chart.ChartAreas["图表区域"].BackSecondaryColor =Color.White;//设置图表区域的辅助颜色

            Chart.ChartAreas["图表区域"].BorderColor = Color.White;//设置图表区域边框颜色

            Chart.ChartAreas["图表区域"].BorderDashStyle = ChartDashStyle.Solid;//设置图像边框线的样式(实线、虚线、点线)



            Chart.ChartAreas["图表区域"].AxisX.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);//设置X轴下方的提示信息的字体属性

            Chart.ChartAreas["图表区域"].AxisX.LabelStyle.Format = "";//设置标签文本中的格式字符串

            Chart.ChartAreas["图表区域"].AxisX.LabelStyle.Interval = 5D;//设置标签间隔的大小

            Chart.ChartAreas["图表区域"].AxisX.LabelStyle.IntervalType = DateTimeIntervalType.Number;//设置间隔大小的度量单位

            Chart.ChartAreas["图表区域"].AxisX.LineColor = System.Drawing.Color.White;//设置X轴的线条颜色

            Chart.ChartAreas["图表区域"].AxisX.MajorGrid.Interval = 5D;//设置主网格线与次要网格线的间隔

            Chart.ChartAreas["图表区域"].AxisX.MajorGrid.IntervalType = DateTimeIntervalType.Number;//设置主网格线与次网格线的间隔的度量单位

            Chart.ChartAreas["图表区域"].AxisX.MajorGrid.LineColor = System.Drawing.Color.Snow;//设置网格线的颜色

            Chart.ChartAreas["图表区域"].AxisX.MajorTickMark.Interval = 5D;//设置刻度线的间隔

            Chart.ChartAreas["图表区域"].AxisX.MajorTickMark.IntervalType = DateTimeIntervalType.Number;//设置刻度线的间隔的度量单位



            Chart.ChartAreas["图表区域"].AxisY.IsLabelAutoFit = false;//设置是否自动调整轴标签

            Chart.ChartAreas["图表区域"].AxisY.IsStartedFromZero = false;//设置是否自动将数据值均为正值时轴的最小值设置为0，存在负数据值时，将使用数据轴最小值

            Chart.ChartAreas["图表区域"].AxisY.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);//设置Y轴左侧的提示信息的字体属性

            Chart.ChartAreas["图表区域"].AxisY.LineColor = System.Drawing.Color.DarkBlue;//设置轴的线条颜色

            Chart.ChartAreas["图表区域"].AxisY.MajorGrid.LineColor = System.Drawing.Color.White;//设置网格线颜色



            Chart.ChartAreas["图表区域"].AxisY.Maximum = 100;//设置Y轴最大值

            Chart.ChartAreas["图表区域"].AxisY.Minimum = 0;//设置Y轴最小值



            #endregion

            #region 图例样式

            Legend legend = new Legend();//初始化一个图例的实例

            legend.Alignment = System.Drawing.StringAlignment.Near;//设置图表的对齐方式(中间对齐，靠近原点对齐，远离原点对齐)

            legend.BackColor = System.Drawing.Color.Black;//设置图例的背景颜色

            legend.DockedToChartArea = "ChartArea1";//设置图例要停靠在哪个区域上

            legend.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;//设置停靠在图表区域的位置(底部、顶部、左侧、右侧)

            legend.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);//设置图例的字体属性

            legend.IsTextAutoFit = true;//设置图例文本是否可以自动调节大小

            legend.LegendStyle = System.Windows.Forms.DataVisualization.Charting.LegendStyle.Column;//设置显示图例项方式(多列一行、一列多行、多列多行)

            legend.Name = "l1";//设置图例的名称

            Chart.Legends.Add(legend.Name);

            #endregion

        }

        #endregion
    }
}
