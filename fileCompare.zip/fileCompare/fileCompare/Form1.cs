﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;

namespace fileCompare
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //GetSelectionTxtData(@"D:\Qiankun Zheng\txtOutput\selection\APO_SALES\selection19XR_library1_APO_20170314_zqk\PerfOut31.txt");
            //DealWithTxt(@"D:\txtTest\file1\PerfOut1.txt");
            txtPath1.Text = @"D:\txtTest\file1";
            txtPath2.Text = @"D:\txtTest\file2";      
        }

        private void btnOpenPath1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择文件路径";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtPath1.Text = dialog.SelectedPath;
            }
        }

        private void btnOpenPath2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择文件路径";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtPath2.Text = dialog.SelectedPath;
            }
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            int  strTxtPathLen1=0;
            int  strTxtPathLen2=0;
            strTxtPathLen1=txtPath1.Text.ToString().Length;
            strTxtPathLen2=txtPath2.Text.ToString().Length;
            string strDirectoryPath1 = txtPath1.Text.ToString();
            string strDirectoryPath2 = txtPath2.Text.ToString();
            string strSavePath = strDirectoryPath1.TrimEnd('\\');
            strSavePath = strSavePath.Substring(0, strSavePath.LastIndexOf('\\') + 1);
            string strDestPath1;
            string strDestPath2;
            if (txtPath1.Text.ToString() == "" || txtPath2.Text.ToString() == "")
            {
                MessageBox.Show("文件路径不能为空！");
            }
            //判断文件路径是否存在，不存在则创建文件夹 
            else if (!Directory.Exists(txtPath1.Text.ToString()))
            {
                MessageBox.Show("文件路径1不存在！");
            }
            else if (!Directory.Exists(txtPath2.Text.ToString()))
            {
                MessageBox.Show("文件路径2不存在！");
            }
            else
            {
                #region 因为要处理TXT文件，所以先复制一份
                strDestPath1 = strDirectoryPath1 + "_copy";
                strDestPath2 = strDirectoryPath2 + "_copy";
                if (Directory.Exists(strDestPath1) && Directory.Exists(strDestPath2))
                {
                    DeleteDirectory(strDestPath1);
                    DeleteDirectory(strDestPath2);
                }
                DirectoryInfo dirTemp = new DirectoryInfo(strDestPath1);
                DirectoryInfo dirTemp2 = new DirectoryInfo(strDestPath2);
                dirTemp.Create();
                dirTemp2.Create();

                CopyDirectory(strDirectoryPath1, strDestPath1);
                CopyDirectory(strDirectoryPath2, strDestPath2);
                #endregion

                #region hashtable实现
                Hashtable ht1 = new Hashtable();
                Hashtable ht2 = new Hashtable();

                if (Directory.Exists(strDestPath1) && Directory.Exists(strDestPath2))
                {
                    ht1 = getDirectoryAllFiles(strDestPath1, ht1, strTxtPathLen1 + 5);//strTxtPathLen1 + "_copy".length
                    ht2 = getDirectoryAllFiles(strDestPath2, ht2, strTxtPathLen2 + 5);//strTxtPathLen1 + "_copy".length
                    //ht1 = getDirectoryAllFiles(strDestPath1,0, ht1);
                    //ht2 = getDirectoryAllFiles(strDestPath2,0, ht2);
                }
                fileCompare(ht1, ht2, strSavePath + "result.txt", strTxtPathLen1, strTxtPathLen2);
                #endregion

                #region 删除备份的临时文件夹
                if (Directory.Exists(strDestPath1) && Directory.Exists(strDestPath2))
                {
                    DeleteDirectory(strDestPath1);
                    DeleteDirectory(strDestPath2);
                }
                #endregion
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region 方法
        public static void CopyDirectory(string srcPath, string destPath)
        {
            try
            {
                DirectoryInfo dir = new DirectoryInfo(srcPath);
                FileSystemInfo[] fileinfo = dir.GetFileSystemInfos();  //获取目录下（不包含子目录）的文件和子目录
                foreach (FileSystemInfo i in fileinfo)
                {
                    if (i is DirectoryInfo)     //判断是否文件夹
                    {
                        if (!Directory.Exists(destPath + "\\" + i.Name))
                        {
                            Directory.CreateDirectory(destPath + "\\" + i.Name);   //目标目录下不存在此文件夹即创建子文件夹
                        }
                        CopyDirectory(i.FullName, destPath + "\\" + i.Name);    //递归调用复制子文件夹
                    }
                    else
                    {
                        File.Copy(i.FullName, destPath + "\\" + i.Name, true);      //不是文件夹即复制文件，true表示可以覆盖同名文件
                    }
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }
        public static void DeleteDirectory(string srcPath)
        {
            try
            {
                DirectoryInfo dir = new DirectoryInfo(srcPath);
                FileSystemInfo[] fileinfo = dir.GetFileSystemInfos();  //返回目录中所有文件和子目录
                foreach (FileSystemInfo i in fileinfo)
                {
                    if (i is DirectoryInfo)            //判断是否文件夹
                    {
                        DirectoryInfo subdir = new DirectoryInfo(i.FullName);
                        subdir.Delete(true);          //删除子目录和文件
                    }
                    else
                    {
                        File.Delete(i.FullName);      //删除指定文件
                    }
                }
                if (Directory.Exists(srcPath))
                {
                    Directory.Delete(srcPath, true); 
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }
        public void DealWithTxt(string filePath1)
        {
            bool bProjectName = false;
            bool bSalesOffice = false;
            string str;
            List<string> lines = new List<string>(File.ReadAllLines(filePath1));//先读取到内存变量 

            for (int i = 0; i < lines.Count; i++)
            {
                if (lines[i].IndexOf("Project Name:") == 0)
                {
                    str = lines[i];
                    lines.Remove(str);
                    str = str.Substring(str.IndexOf(":") + 2);
                    str = new System.Text.RegularExpressions.Regex("[\\s]+").Replace(str, " ");
                    if (str.IndexOf(" ") > 0)
                    {
                        str = "_Project Name: " + str.Substring(0, str.IndexOf(" "));
                    }
                    lines.Insert(i, str);
                    bProjectName = true;
                }
                if (lines[i].IndexOf("Sales Office:") == 0)
                {
                    str = lines[i];
                    lines.Remove(str);
                    str = str.Substring(str.IndexOf(":") + 2);
                    str = new System.Text.RegularExpressions.Regex("[\\s]+").Replace(str, " ");
                    if (str.IndexOf(" ") > 0)
                    {
                        str = "_Sales Office: " + str.Substring(0, str.IndexOf(" "));
                    }
                    lines.Insert(i, str);
                    bSalesOffice = true;
                }
                if (bProjectName && bSalesOffice)
                {
                    break;
                }
            }
            File.WriteAllLines(filePath1, lines.ToArray());//再写回
        }

        public bool CompareFile(string filePath1, string filePath2)
        {
            //使用System.security.Cryptography.HashAlgorithm类为每个文件生成一个哈希码，然后比较两个哈希码是否一致
            var hash = System.Security.Cryptography.HashAlgorithm.Create();

            DealWithTxt(filePath1);
            //计算第一个文件的哈希值
            var stream_1 = new System.IO.FileStream(filePath1, System.IO.FileMode.Open);
            byte[] hashByte_1 = hash.ComputeHash(stream_1);
            stream_1.Close();

            DealWithTxt(filePath2);
            //计算第二个文件的哈希值
            var stream_2 = new System.IO.FileStream(filePath2, System.IO.FileMode.Open);
            byte[] hashByte_2 = hash.ComputeHash(stream_2);
            stream_2.Close();

            //比较两个哈希值
            if (BitConverter.ToString(hashByte_1) == BitConverter.ToString(hashByte_2))
            {
                //MessageBox.Show("两个文件相等");
                return true;
            }
            else
            {
                //MessageBox.Show("两个文件不等");
                return false;
            }
        }

        public bool CompareFile2(string filePath1, string filePath2)
        {
            //创建一个哈希算法对象
            using (HashAlgorithm hash = HashAlgorithm.Create())
            {
                using (FileStream file1 = new FileStream(filePath1, FileMode.Open), file2 = new FileStream(filePath2, FileMode.Open))
                {
                    byte[] hashByte1 = hash.ComputeHash(file1);//哈希算法根据文本得到哈希码的字节数组
                    byte[] hashByte2 = hash.ComputeHash(file2);
                    string str1 = BitConverter.ToString(hashByte1);//将字节数组装换为字符串
                    string str2 = BitConverter.ToString(hashByte2);
                    return (str1 == str2);
                }
            }
        }
        private bool fileCompare(Hashtable ht1, Hashtable ht2, string SaveFilePath,int txtPathLen1,int txtPathLen2)
        {
            bool flagSame = false;
            string strTemp1;
            string strTemp2;
            List<string> strList1 = new List<string>();
            List<string> strList2 = new List<string>();
            List<string> strList3 = new List<string>();

            foreach (DictionaryEntry de in ht1)
            {
                if (ht2.ContainsKey(de.Key))
                {
                    if (CompareFile(de.Value.ToString(),ht2[de.Key].ToString()))
                    {
                        ht2.Remove(de.Key);
                    }
                    else
                    {
                        strTemp1=de.Value.ToString();
                        strTemp1=strTemp1.Remove(txtPathLen1, 5);//保存到TXT时去掉目录中自己复制时的_copy
                        strTemp2 = ht2[de.Key].ToString();
                        strTemp2 = strTemp2.Remove(txtPathLen2, 5);//保存到TXT时去掉目录中自己复制时的_copy
                        strList1.Add(strTemp1 + "; " + strTemp2);
                        //strList1.Add(de.Value.ToString() + "; " + ht2[de.Key].ToString());
                        ht2.Remove(de.Key);
                    }
                }
                else
                {
                    strTemp1 = de.Value.ToString();
                    strTemp1 = strTemp1.Remove(txtPathLen1, 5);//保存到TXT时去掉目录中自己复制时的_copy
                    strList2.Add(strTemp1);
                    //strList2.Add(de.Value.ToString());
                }
            }
            foreach (DictionaryEntry de in ht2)
            {
                strTemp1 = de.Value.ToString();
                strTemp1 = strTemp1.Remove(txtPathLen1, 5);//保存到TXT时去掉目录中自己复制时的_copy
                strList3.Add(strTemp1);
                //strList3.Add(de.Value.ToString());
            }
            if ((strList1.Count + strList2.Count + strList3.Count) > 0)
            {
                string str = SaveFilePath.Substring(SaveFilePath.LastIndexOf('\\') + 1);

                using (FileStream fs = new FileStream(SaveFilePath, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    //开始写入
                    //sw.WriteLine("****************比较结果如下**********************");
                    if (strList1.Count > 0)
                    {
                        //sw.WriteLine("");
                        //sw.WriteLine("The data in A and B is not the same");
                        sw.WriteLine("************两个文件中不相同的文件如下*********");
                        //sw.WriteLine("");
                        foreach (var s in strList1)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList2.Count > 0)
                    {
                        sw.WriteLine("");
                        //sw.WriteLine("There is no file1 in file2");
                        sw.WriteLine("************路径1中有而2中没有的文件如下*******");
                        //sw.WriteLine("");
                        foreach (var s in strList2)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList3.Count > 0)
                    {
                        sw.WriteLine("");
                        //sw.WriteLine("There is no file2 in file1");
                        sw.WriteLine("************路径2中有而1中没有的文件如下*******");
                        //sw.WriteLine("");
                        foreach (var s in strList3)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    //清空缓冲区
                    sw.Flush();
                    //关闭流
                    sw.Close();
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
                flagSame = false;
            }
            else
            {
                string str = SaveFilePath.Substring(SaveFilePath.LastIndexOf('\\') + 1);
                str = str.Substring(0, str.LastIndexOf('.'));
                MessageBox.Show(str + " 结果相同");
                using (FileStream fs = new FileStream(SaveFilePath, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);

                    //开始写入
                    sw.WriteLine("****************比较结果相同**********************");

                    //清空缓冲区
                    sw.Flush();
                    //关闭流
                    sw.Close();
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
                flagSame = true;
            }
            return flagSame;
        }

        private Hashtable getDirectoryAllFiles2(string path, Hashtable ht)
        {
            //List<string> strFilesList = new List<string>();

            DirectoryInfo theFolder = new DirectoryInfo(path);

            //遍历文件
            foreach (FileInfo NextFile in theFolder.GetFiles())
            {
                ht.Add(NextFile.Name, NextFile.FullName);
                //MessageBox.Show(NextFile.FullName);
            }

            //遍历文件夹
            foreach (DirectoryInfo NextFolder in theFolder.GetDirectories())
            {
                getDirectoryAllFiles2(NextFolder.FullName, ht);
            }
            return ht;
        }

        private Hashtable getDirectoryAllFiles(string path, Hashtable ht,int txtPathlen)
        {
            DirectoryInfo theFolder = new DirectoryInfo(path);

            //遍历文件
            foreach (FileInfo NextFile in theFolder.GetFiles())
            {
                string strKey;
                strKey = NextFile.FullName;
                strKey = strKey.Substring(txtPathlen);
                ht.Add(strKey, NextFile.FullName);
            }

            //遍历文件夹
            foreach (DirectoryInfo NextFolder in theFolder.GetDirectories())
            {
                getDirectoryAllFiles(NextFolder.FullName, ht, txtPathlen);
            }
            return ht;
        }

        private Hashtable getDirectoryAllFiles(string path, int leval, Hashtable ht)
        {
            DirectoryInfo theFolder = new DirectoryInfo(path);

            leval++;

            //遍历文件
            foreach (FileInfo NextFile in theFolder.GetFiles())
            {
                string str;
                str = NextFile.FullName;
                str = str.Substring(str.IndexOf('\\')+1);
                str = str.Substring(str.IndexOf('\\')+1);
                str = str.Substring(str.IndexOf('\\'));
                ht.Add(leval + str, NextFile.FullName);
                //ht.Add(leval + str + NextFile.Name, NextFile.FullName);
            }

            //遍历文件夹
            foreach (DirectoryInfo NextFolder in theFolder.GetDirectories())
            {
                getDirectoryAllFiles(NextFolder.FullName, leval, ht);
            }
            return ht;
        }

        private List<string> getDirectoryAllFiles(string path, List<string> strFilesList)
        {
            //List<string> strFilesList = new List<string>();

            DirectoryInfo theFolder = new DirectoryInfo(path);

            //遍历文件
            foreach (FileInfo NextFile in theFolder.GetFiles())
            {
                strFilesList.Add(NextFile.FullName);
                //MessageBox.Show(NextFile.FullName);
            }

            //遍历文件夹
            foreach (DirectoryInfo NextFolder in theFolder.GetDirectories())
            {
                getDirectoryAllFiles(NextFolder.FullName, strFilesList);
            }
            return strFilesList;
        }

        public void GetSelectionTxtData(string strTxtFilePath)
        {
            bool haveSelection = false;
            string strLineData;
            
            txtSelectionDataStruct selectionSruct = new txtSelectionDataStruct();
            txtSelectionErrorDataStruct selectionErrorStruct = new txtSelectionErrorDataStruct();
            List<txtSelectionDataStruct> strListSeletionStruct = new List<txtSelectionDataStruct>();
            List<txtSelectionErrorDataStruct> strListSeletionErrorStruct = new List<txtSelectionErrorDataStruct>();

            // 判断文件是否存在，不存在则创建，否则读取值显示到窗体
            if (!File.Exists(strTxtFilePath))
            {
                MessageBox.Show("文件不存在");
            }
            else
            {
                using (FileStream fs = new FileStream(strTxtFilePath, FileMode.Open, FileAccess.Read))
                {
                    StreamReader sr = new StreamReader(fs);
                    string readLine;
                    while ((readLine = sr.ReadLine()) != null)
                    {
                        if (readLine.IndexOf("Error:") == 0)
                        { 
                            strLineData = readLine.Trim();
                            selectionErrorStruct.strError = strLineData;

                            readLine = sr.ReadLine();
                            readLine = sr.ReadLine();
                            strLineData = readLine.Trim();
                            selectionErrorStruct.strTagName = strLineData;

                            readLine = sr.ReadLine();
                            readLine = sr.ReadLine();
                            strLineData = readLine.Trim();
                            selectionErrorStruct.strChillerModel = strLineData;

                            readLine = sr.ReadLine();
                            readLine = sr.ReadLine();
                            strLineData = readLine.Trim();
                            selectionErrorStruct.strChillerCapacity = strLineData;

                            readLine = sr.ReadLine();
                            readLine = sr.ReadLine();
                            strLineData = readLine.Trim();
                            selectionErrorStruct.strStarterVFD = strLineData;

                            readLine = sr.ReadLine();
                            readLine = sr.ReadLine();
                            strLineData = readLine.Trim();
                            selectionErrorStruct.strCmpSize = strLineData;

                            readLine = sr.ReadLine();
                            readLine = sr.ReadLine();
                            strLineData = readLine.Trim();
                            selectionErrorStruct.strOperationType = strLineData;
                            MessageBox.Show(selectionErrorStruct.ToString());
                            strListSeletionErrorStruct.Add(selectionErrorStruct);
                            break;
                        }
                        if (readLine.IndexOf("Chiller Selection Summary") == 0 || readLine.IndexOf("Chiller Selection Summary (Continued)") == 0)
                        {
                            readLine = sr.ReadLine();
                            readLine = sr.ReadLine();
                            if (readLine.IndexOf("Model") >= 0)
                            {
                                strLineData = readLine.Trim();
                                strLineData = MergeSpace(strLineData);
                                strLineData = strLineData.Replace(" ", ";"); 
                                //MessageBox.Show(strLineData);

                                readLine = sr.ReadLine();
                                strLineData = readLine.Trim();
                                //strLineData = MergeSpace(strLineData);
                                strLineData = Regex.Replace(strLineData, @"\s{2}", ";");
                                strLineData = new System.Text.RegularExpressions.Regex("[;]+").Replace(strLineData, ";");
                                //MessageBox.Show(strLineData);

                                haveSelection = true;
                            }
                        }
                        if (haveSelection && readLine.IndexOf("Selection") >= 0)
                        {
                            strLineData = readLine.Trim();
                            strLineData = Regex.Replace(strLineData, @"\s{2}", ";");
                            strLineData = new System.Text.RegularExpressions.Regex("[;]+").Replace(strLineData, ";");
                            //MessageBox.Show(strLineData);
                            string[] strArray = strLineData.Split(new char[] { ';' });
                            selectionSruct.strSelectionNum = Regex.Replace(strArray[0], @"\s", "");
                            selectionSruct.strModel = Regex.Replace(strArray[1], @"\s", "");
                            selectionSruct.strPass = strArray[2];
                            selectionSruct.strTons = strArray[3];
                            selectionSruct.strValue1=strArray[4];
                            selectionSruct.strValue2=strArray[5];

                            readLine = sr.ReadLine();
                            strLineData = MergeSpace(readLine);
                            strLineData = strLineData.Replace(" ", ";");
                            strLineData = strLineData.TrimEnd(';');
                            //MessageBox.Show(strLineData);
                            string[] strArray2 = strLineData.Split(new char[] { ';' });
                            selectionSruct.strValue3=strArray2[0];
                            selectionSruct.strValue4=strArray2[1];
                            selectionSruct.strValue5=strArray2[2];
                            MessageBox.Show(selectionSruct.ToString());
                        }
                    }
                    sr.Close();
                    fs.Close();
                    strListSeletionStruct.Add(selectionSruct);
                }
            }
        }
        #region 字符串处理
        /// <summary>
        /// 字符串中多个连续空格转为一个空格
        /// </summary>
        /// <param name="str">待处理的字符串</param>
        /// <returns>合并空格后的字符串</returns>
        public static string MergeSpace(string str)
        {
            if (str != string.Empty && str != null && str.Length > 0)
            {
                str = new System.Text.RegularExpressions.Regex("[\\s]+").Replace(str, " ");
            }
            return str;
        }

        /// <summary>
        /// 去除字符串中“\t”或空格
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string MergeSpace2(string str)
        {
            string strResult = string.Empty;
            foreach (char c in str)
            {
                if (c == '\t' || c == ' ')
                {
                    continue;
                }
                strResult += c;
            }
            return strResult;
        }

        //1）string mStr= str.Trim();
        //去除字符串的头和尾的空格

        //2)  string mStr= str.Replace( " ", "" ); 
        //替换字符串中的空格

        //3）string mStr= Regex.Replace(str, @"\s", "" );
        //替换字符串中的：空格, tab字符, 换行符和新行（""，"\t","\n","\r")

        #endregion

        #region txt数据结构
        public struct txtSelectionErrorDataStruct
        {
            public string strError;
            public string strTagName;
            public string strChillerModel;
            public string strChillerCapacity;
            public string strStarterVFD;
            public string strCmpSize;
            public string strOperationType;

            public override string ToString()
            {
                return strError + "\r\n" +
                       strTagName + "\r\n" +
                       strChillerModel + "\r\n" +
                       strChillerCapacity + "\r\n" +
                       strStarterVFD + "\r\n" +
                       strCmpSize + "\r\n" +
                       strOperationType + "\r\n";
            }
        }

        public struct txtSelectionDataStruct
        {
            public string strSelectionNum;
            public string strModel;
            public string strPass;
            public string strTons;
            public string strValue1;
            public string strValue2;
            public string strValue3;
            public string strValue4;
            public string strValue5;

            public override string ToString()
            {
                return "SelectionNum: " + strSelectionNum + "\r\n" +
                       "Model: " + strModel + "\r\n" +
                       "Pass: " + strPass + "\r\n" +
                       "Tons: " + strTons + "\r\n" +
                       "Value1: " + strValue1 + "\r\n" +
                       "Value2: " + strValue2 + "\r\n" +
                       "Value3: " + strValue3 + "\r\n" +
                       "Value4: " + strValue4 + "\r\n" +
                       "Value5: " + strValue5 + "\r\n";
            }
        }

        public struct txtDataStruct
        {
            public string strTagName;
            public string strChillerModel;
            public List<string> strListPercentLoad;
            public List<string> strListChillerCapacity;
            public List<string> strListChillerInputkW;
            public List<string> strListChillerEfficiency;
            public List<string> strListChillerCOPR;

            public override string ToString()
            {
                string strListPercentLoadTemp = "";
                string strListChillerCapacityTemp = "";
                string strListChillerInputkWTemp = "";
                string strListChillerEfficiencyTemp = "";
                string strListChillerCOPRTemp = "";

                foreach (var str in strListPercentLoad)
                {
                    strListPercentLoadTemp += str + ";";
                }
                foreach (var str in strListChillerCapacityTemp)
                {
                    strListPercentLoadTemp += str + ";";
                }
                foreach (var str in strListChillerInputkWTemp)
                {
                    strListPercentLoadTemp += str + ";";
                }
                foreach (var str in strListChillerEfficiencyTemp)
                {
                    strListPercentLoadTemp += str + ";";
                }
                foreach (var str in strListChillerCOPRTemp)
                {
                    strListPercentLoadTemp += str + ";";
                }
                return "TagName: " + strTagName + "\r\n" +
                       "ChillerModel: " + strChillerModel + "\r\n" +
                       "PercentLoad: " + strListPercentLoadTemp + "\r\n" +
                       "ChillerCapacity: " + strListChillerCapacityTemp + "\r\n" +
                       "ChillerInputkW: " + strListChillerInputkWTemp + "\r\n" +
                       "ChillerEfficiency: " + strListChillerEfficiencyTemp + "\r\n" +
                       "ChillerCOPR: " + strListChillerCOPRTemp + "\r\n";
            }
        }
        public class txtDataClass
        {
            public string strTagName;
            public string strChillerModel;
            public List<string> strListPercentLoad = new List<string>();
            public List<string> strListChillerCapacity = new List<string>();
            public List<string> strListChillerInputkW = new List<string>();
            public List<string> strListChillerEfficiency = new List<string>();
            public List<string> strListChillerCOPR = new List<string>();

            public override string ToString()
            {
                string strListPercentLoadTemp="";
                string strListChillerCapacityTemp = "";
                string strListChillerInputkWTemp = "";
                string strListChillerEfficiencyTemp = "";
                string strListChillerCOPRTemp = "";

                foreach(var str in strListPercentLoad)
                {
                    strListPercentLoadTemp+=str+";";
                }
                foreach (var str in strListChillerCapacityTemp)
                {
                    strListPercentLoadTemp += str + ";";
                }
                foreach (var str in strListChillerInputkWTemp)
                {
                    strListPercentLoadTemp += str + ";";
                }
                foreach (var str in strListChillerEfficiencyTemp)
                {
                    strListPercentLoadTemp += str + ";";
                }
                foreach (var str in strListChillerCOPRTemp)
                {
                    strListPercentLoadTemp += str + ";";
                }
                return "TagName: " + strTagName + "\r\n" +
                       "ChillerModel: " + strChillerModel + "\r\n" +
                       "PercentLoad: " + strListPercentLoadTemp + "\r\n" +
                       "ChillerCapacity: " + strListChillerCapacityTemp + "\r\n" +
                       "ChillerInputkW: " + strListChillerInputkWTemp + "\r\n" +
                       "ChillerEfficiency: " + strListChillerEfficiencyTemp + "\r\n" +
                       "ChillerCOPR: " + strListChillerCOPRTemp + "\r\n";
            }
        }
        #endregion

        public Hashtable GetTxtDataToHashtable(string strTxtFilePath)
        {
            string strLineData;
            //List<string> strList = new List<string>();
            txtDataStruct txtData = new txtDataStruct();
            //txtDataClass txtData = new txtDataClass();
            Hashtable ht = new Hashtable();

            // 判断文件是否存在，不存在则创建，否则读取值显示到窗体
            if (!File.Exists(strTxtFilePath))
            {
                MessageBox.Show("文件不存在");
            }
            else
            {
                using (FileStream fs = new FileStream(strTxtFilePath, FileMode.Open, FileAccess.Read))
                {
                    StreamReader sr = new StreamReader(fs);
                    string readLine;
                    while ((readLine = sr.ReadLine()) != null)
                    {
                        if (readLine.IndexOf("Tag Name:") == 0)
                        {
                            strLineData = readLine.Substring(readLine.IndexOf(';') + 1);
                            strLineData = strLineData.Trim();
                            //MessageBox.Show(strLineData);
                            txtData.strTagName = strLineData;
                        }
                        if (readLine.IndexOf("Chiller Model") >= 0)
                        {
                            strLineData = readLine.Substring(readLine.IndexOf("Model") + 5);
                            strLineData = strLineData.Trim();
                            //MessageBox.Show(strLineData);
                            txtData.strChillerModel = strLineData;
                        }
                        if (readLine.IndexOf("Percent Load") == 0)
                        {
                            //txtData.strListPercentLoad = new List<string>();
                            while ((readLine = sr.ReadLine()) != "")
                            {
                                strLineData = readLine.Trim();
                                //MessageBox.Show(strLineData);
                                txtData.strListPercentLoad.Add(strLineData);
                            }
                        }
                        if (readLine.IndexOf("Chiller Capacity") == 0)
                        {
                            //txtData.strListChillerCapacity = new List<string>();
                            while ((readLine = sr.ReadLine()) != "")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                strLineData = strLineData.Trim();
                                txtData.strListChillerCapacity.Add(strLineData);
                                //MessageBox.Show(strLineData);
                            }
                        }
                        if (readLine.IndexOf("Chiller Input kW") == 0)
                        {
                            //txtData.strListChillerInputkW = new List<string>();
                            while ((readLine = sr.ReadLine()) != "")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                strLineData = strLineData.Trim();
                                txtData.strListChillerInputkW.Add(strLineData);
                                //MessageBox.Show(strLineData);
                            }
                        }
                        if (readLine.IndexOf("Chiller Efficiency") == 0)
                        {
                            //txtData.strListChillerEfficiency = new List<string>();
                            while ((readLine = sr.ReadLine()) != "")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                strLineData = strLineData.Replace("/", "");
                                strLineData = strLineData.Trim();
                                txtData.strListChillerEfficiency.Add(strLineData);
                                //MessageBox.Show(strLineData);
                            }
                        }
                        if (readLine.IndexOf("Chiller COPR") == 0)
                        {
                            //txtData.strListChillerCOPR = new List<string>();
                            while ((readLine = sr.ReadLine()) != "")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                strLineData = strLineData.Replace("/", "");
                                strLineData = strLineData.Trim();
                                txtData.strListChillerCOPR.Add(strLineData);
                                //MessageBox.Show(strLineData);
                            }
                        }
                    }
                    sr.Close();
                    fs.Close();
                }
            }
            MessageBox.Show(txtData.ToString());
            ht.Add(txtData.strTagName, txtData);
            return ht;
        }

        #region 如何获取指定目录包含的文件和子目录
        //1. DirectoryInfo.GetFiles()：获取目录中（不包含子目录）的文件，返回类型为FileInfo[]，支持通配符查找；
        //2. DirectoryInfo.GetDirectories()：获取目录（不包含子目录）的子目录，返回类型为DirectoryInfo[]，支持通配符查找；
        //3. DirectoryInfo. GetFileSystemInfos()：获取指定目录下（不包含子目录）的文件和子目录，返回类型为FileSystemInfo[]，支持通配符查找；
        //如何获取指定文件的基本信息；
        //FileInfo.Exists：获取指定文件是否存在；
        //FileInfo.Name，FileInfo.Extensioin：获取文件的名称和扩展名；
        //FileInfo.FullName：获取文件的全限定名称（完整路径）；
        //FileInfo.Directory：获取文件所在目录，返回类型为DirectoryInfo；
        //FileInfo.DirectoryName：获取文件所在目录的路径（完整路径）；
        //FileInfo.Length：获取文件的大小（字节数）；
        //FileInfo.IsReadOnly：获取文件是否只读；
        //FileInfo.Attributes：获取或设置指定文件的属性，返回类型为FileAttributes枚举，可以是多个值的组合
        //FileInfo.CreationTime、FileInfo.LastAccessTime、FileInfo.LastWriteTime：分别用于获取文件的创建时间、访问时间、修改时间；
        #endregion

        private List<string> getFiles(string path)
        {
            //List<string> strFolderList = new List<string>();
            //List<string> strFileList = new List<string>();
            //DirectoryInfo TheFolder = new DirectoryInfo(path);

            ////遍历文件夹
            //foreach (DirectoryInfo NextFolder in TheFolder.GetDirectories())
            //{
            //    strFolderList.Add(NextFolder.Name);
            //}
            ////遍历文件
            //foreach (FileInfo NextFile in TheFolder.GetFiles())
            //{
            //    strFileList.Add(NextFile.Name);
            //}

            List<string> strFileList = new List<string>();
            DirectoryInfo mydir = new DirectoryInfo(path);
            foreach (FileSystemInfo fsi in mydir.GetFileSystemInfos())
            {
                if (fsi is FileInfo)
                {
                    FileInfo fi = (FileInfo)fsi;
                    string x = System.IO.Path.GetDirectoryName(fi.FullName);
                    //Console.WriteLine(x);
                    string s = System.IO.Path.GetExtension(fi.FullName);
                    string y = System.IO.Path.GetFileNameWithoutExtension(fi.FullName);
                    //Console.WriteLine(y);
                    strFileList.Add(fi.Name);
                    MessageBox.Show(fi.Name);
                }
            }
            return strFileList;
        }
        #endregion

    }
}
