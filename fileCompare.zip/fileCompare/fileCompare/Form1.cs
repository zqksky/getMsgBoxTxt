﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using System.Collections;

namespace fileCompare
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtPath1.Text = @"D:\txtTest\file1";
            txtPath2.Text = @"D:\txtTest\file2";
            
        }

        private void btnOpenPath1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择文件路径";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtPath1.Text = dialog.SelectedPath;
            }
        }

        private void btnOpenPath2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择文件路径";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtPath2.Text = dialog.SelectedPath;
            }
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            string strDirectoryPath1 = txtPath1.Text.ToString();
            string strDirectoryPath2 = txtPath2.Text.ToString();
            string strSavePath = strDirectoryPath1.TrimEnd('\\');
            strSavePath = strSavePath.Substring(0, strSavePath.LastIndexOf('\\') + 1);

            //getAllFiles(@"D:\xmlTest");

            if (txtPath1.Text.ToString() == "" || txtPath2.Text.ToString() == "")
            {
                MessageBox.Show("文件路径不能为空！");
            }
            //判断文件路径是否存在，不存在则创建文件夹 
            else if (!Directory.Exists(txtPath1.Text.ToString()))
            {
                MessageBox.Show("文件路径1不存在！");
            }
            else if (!Directory.Exists(txtPath2.Text.ToString()))
            {
                MessageBox.Show("文件路径2不存在！");
            }
            else
            {
                #region hashtable实现
                Hashtable ht1 = new Hashtable();
                Hashtable ht2 = new Hashtable();

                ht1 = getDirectoryAllFiles(strDirectoryPath1, ht1);
                ht2 = getDirectoryAllFiles(strDirectoryPath2, ht2);
                //ht1 = getDirectoryAllFiles(strDirectoryPath1,0, ht1);
                //ht2 = getDirectoryAllFiles(strDirectoryPath2,0, ht2);
                fileCompare(ht1, ht2, strSavePath + "result.txt");
                #endregion
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region 方法
        public bool CompareFile(string filePath1, string filePath2)
        {
            //创建一个哈希算法对象
            using (HashAlgorithm hash = HashAlgorithm.Create())
            {
                using (FileStream file1 = new FileStream(filePath1, FileMode.Open), file2 = new FileStream(filePath2, FileMode.Open))
                {
                    byte[] hashByte1 = hash.ComputeHash(file1);//哈希算法根据文本得到哈希码的字节数组
                    byte[] hashByte2 = hash.ComputeHash(file2);
                    string str1 = BitConverter.ToString(hashByte1);//将字节数组装换为字符串
                    string str2 = BitConverter.ToString(hashByte2);
                    return (str1 == str2);
                }
            }
        }
        private bool fileCompare(Hashtable ht1, Hashtable ht2, string SaveFilePath)
        {
            bool flagSame = false;

            List<string> strList1 = new List<string>();
            List<string> strList2 = new List<string>();
            List<string> strList3 = new List<string>();

            foreach (DictionaryEntry de in ht1)
            {
                if (ht2.ContainsKey(de.Key))
                {
                    if (CompareFile(de.Value.ToString(),ht2[de.Key].ToString()))
                    {
                        ht2.Remove(de.Key);
                    }
                    else
                    {
                        strList1.Add(de.Value.ToString() + "; " + ht2[de.Key].ToString());
                        ht2.Remove(de.Key);
                    }
                }
                else
                {
                    strList2.Add(de.Value.ToString());
                }
            }
            foreach (DictionaryEntry de in ht2)
            {
                strList3.Add(de.Value.ToString());
            }
            if ((strList1.Count + strList2.Count + strList3.Count) > 0)
            {
                string str = SaveFilePath.Substring(SaveFilePath.LastIndexOf('\\') + 1);

                using (FileStream fs = new FileStream(SaveFilePath, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    //开始写入
                    //sw.WriteLine("****************比较结果如下**********************");
                    if (strList1.Count > 0)
                    {
                        //sw.WriteLine("");
                        //sw.WriteLine("The data in A and B is not the same");
                        sw.WriteLine("************两个文件中不相同的文件如下*********");
                        //sw.WriteLine("");
                        foreach (var s in strList1)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList2.Count > 0)
                    {
                        sw.WriteLine("");
                        //sw.WriteLine("There is no file1 in file2");
                        sw.WriteLine("************路径1中有而2中没有的文件如下*******");
                        //sw.WriteLine("");
                        foreach (var s in strList2)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList3.Count > 0)
                    {
                        sw.WriteLine("");
                        //sw.WriteLine("There is no file2 in file1");
                        sw.WriteLine("************路径2中有而1中没有的文件如下*******");
                        //sw.WriteLine("");
                        foreach (var s in strList3)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    //清空缓冲区
                    sw.Flush();
                    //关闭流
                    sw.Close();
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
                flagSame = false;
            }
            else
            {
                string str = SaveFilePath.Substring(SaveFilePath.LastIndexOf('\\') + 1);
                str = str.Substring(0, str.LastIndexOf('.'));
                //MessageBox.Show(str + " 结果相同");
                flagSame = true;
            }
            return flagSame;
        }

        private Hashtable getDirectoryAllFiles2(string path, Hashtable ht)
        {
            //List<string> strFilesList = new List<string>();

            DirectoryInfo theFolder = new DirectoryInfo(path);

            //遍历文件
            foreach (FileInfo NextFile in theFolder.GetFiles())
            {
                ht.Add(NextFile.Name, NextFile.FullName);
                //MessageBox.Show(NextFile.FullName);
            }

            //遍历文件夹
            foreach (DirectoryInfo NextFolder in theFolder.GetDirectories())
            {
                getDirectoryAllFiles2(NextFolder.FullName, ht);
            }
            return ht;
        }

        private Hashtable getDirectoryAllFiles(string path, Hashtable ht)
        {
            DirectoryInfo theFolder = new DirectoryInfo(path);

            //遍历文件
            foreach (FileInfo NextFile in theFolder.GetFiles())
            {
                string str;
                str = NextFile.FullName;
                //str = str.Substring(0, str.LastIndexOf('\\') + 1);
                str = str.Substring(str.IndexOf('\\') + 1);
                str = str.Substring(str.IndexOf('\\') + 1);
                str = str.Substring(str.IndexOf('\\'));
                ht.Add(str, NextFile.FullName);
                //ht.Add(str + NextFile.Name, NextFile.FullName);
            }

            //遍历文件夹
            foreach (DirectoryInfo NextFolder in theFolder.GetDirectories())
            {
                getDirectoryAllFiles(NextFolder.FullName, ht);
            }
            return ht;
        }

        private Hashtable getDirectoryAllFiles(string path, int leval, Hashtable ht)
        {
            DirectoryInfo theFolder = new DirectoryInfo(path);

            leval++;

            //遍历文件
            foreach (FileInfo NextFile in theFolder.GetFiles())
            {
                string str;
                str = NextFile.FullName;
                //str = str.Substring(0,str.LastIndexOf('\\')+1);
                str = str.Substring(str.IndexOf('\\')+1);
                str = str.Substring(str.IndexOf('\\')+1);
                str = str.Substring(str.IndexOf('\\'));
                ht.Add(leval + str, NextFile.FullName);
                //ht.Add(leval + str + NextFile.Name, NextFile.FullName);
            }

            //遍历文件夹
            foreach (DirectoryInfo NextFolder in theFolder.GetDirectories())
            {
                getDirectoryAllFiles(NextFolder.FullName, leval, ht);
            }
            return ht;
        }

        private List<string> getDirectoryAllFiles(string path, List<string> strFilesList)
        {
            //List<string> strFilesList = new List<string>();

            DirectoryInfo theFolder = new DirectoryInfo(path);

            //遍历文件
            foreach (FileInfo NextFile in theFolder.GetFiles())
            {
                strFilesList.Add(NextFile.FullName);
                //MessageBox.Show(NextFile.FullName);
            }

            //遍历文件夹
            foreach (DirectoryInfo NextFolder in theFolder.GetDirectories())
            {
                getDirectoryAllFiles(NextFolder.FullName, strFilesList);
            }
            return strFilesList;
        }

        //如何获取指定目录包含的文件和子目录
        //1. DirectoryInfo.GetFiles()：获取目录中（不包含子目录）的文件，返回类型为FileInfo[]，支持通配符查找；
        //2. DirectoryInfo.GetDirectories()：获取目录（不包含子目录）的子目录，返回类型为DirectoryInfo[]，支持通配符查找；
        //3. DirectoryInfo. GetFileSystemInfos()：获取指定目录下（不包含子目录）的文件和子目录，返回类型为FileSystemInfo[]，支持通配符查找；
        //如何获取指定文件的基本信息；
        //FileInfo.Exists：获取指定文件是否存在；
        //FileInfo.Name，FileInfo.Extensioin：获取文件的名称和扩展名；
        //FileInfo.FullName：获取文件的全限定名称（完整路径）；
        //FileInfo.Directory：获取文件所在目录，返回类型为DirectoryInfo；
        //FileInfo.DirectoryName：获取文件所在目录的路径（完整路径）；
        //FileInfo.Length：获取文件的大小（字节数）；
        //FileInfo.IsReadOnly：获取文件是否只读；
        //FileInfo.Attributes：获取或设置指定文件的属性，返回类型为FileAttributes枚举，可以是多个值的组合
        //FileInfo.CreationTime、FileInfo.LastAccessTime、FileInfo.LastWriteTime：分别用于获取文件的创建时间、访问时间、修改时间；
        private List<string> getFiles(string path)
        {
            //List<string> strFolderList = new List<string>();
            //List<string> strFileList = new List<string>();
            //DirectoryInfo TheFolder = new DirectoryInfo(path);

            ////遍历文件夹
            //foreach (DirectoryInfo NextFolder in TheFolder.GetDirectories())
            //{
            //    strFolderList.Add(NextFolder.Name);
            //}
            ////遍历文件
            //foreach (FileInfo NextFile in TheFolder.GetFiles())
            //{
            //    strFileList.Add(NextFile.Name);
            //}

            List<string> strFileList = new List<string>();
            DirectoryInfo mydir = new DirectoryInfo(path);
            foreach (FileSystemInfo fsi in mydir.GetFileSystemInfos())
            {
                if (fsi is FileInfo)
                {
                    FileInfo fi = (FileInfo)fsi;
                    string x = System.IO.Path.GetDirectoryName(fi.FullName);
                    //Console.WriteLine(x);
                    string s = System.IO.Path.GetExtension(fi.FullName);
                    string y = System.IO.Path.GetFileNameWithoutExtension(fi.FullName);
                    //Console.WriteLine(y);
                    strFileList.Add(fi.Name);
                    MessageBox.Show(fi.Name);
                }
            }
            return strFileList;
        }
        #endregion

    }
}
