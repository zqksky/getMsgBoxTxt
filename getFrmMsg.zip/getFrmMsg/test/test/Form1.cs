﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Security.Cryptography;

namespace test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //MessageBox.Show("需要获取的消息", "frmMsg");
        }
        #region  wMsg参数常量值, Windows消息的WPARAM, LPARAM参数解释
        ////创建一个窗口   
        //const int WM_CREATE = 0x01;   
        // //当一个窗口被破坏时发送   
        //const int WM_DESTROY = 0x02;   
        // //移动一个窗口   
        //const int WM_MOVE = 0x03;   
        // //改变一个窗口的大小   
        //const int WM_SIZE = 0x05;   
        // //一个窗口被激活或失去激活状态   
        //const int WM_ACTIVATE = 0x06;   
        // //一个窗口获得焦点   
        //const int WM_SETFOCUS = 0x07;   
        // //一个窗口失去焦点   
        //const int WM_KILLFOCUS = 0x08;   
        // //一个窗口改变成Enable状态   
        //const int WM_ENABLE = 0x0A;   
        // //设置窗口是否能重画   
        //const int WM_SETREDRAW = 0x0B;   
        // //应用程序发送此消息来设置一个窗口的文本   
        //const int WM_SETTEXT = 0x0C;   
        // //应用程序发送此消息来复制对应窗口的文本到缓冲区   
        //const int WM_GETTEXT = 0x0D;   
        // //得到与一个窗口有关的文本的长度（不包含空字符）   
        //const int WM_GETTEXTLENGTH = 0x0E;   
        // //要求一个窗口重画自己   
        //const int WM_PAINT = 0x0F;   
        // //当一个窗口或应用程序要关闭时发送一个信号   
        //const int WM_CLOSE = 0x10;   
        // //当用户选择结束对话框或程序自己调用ExitWindows函数   
        //const int WM_QUERYENDSESSION = 0x11;   
        // //用来结束程序运行   
        //const int WM_QUIT = 0x12;   
        // //当用户窗口恢复以前的大小位置时，把此消息发送给某个图标   
        //const int WM_QUERYOPEN = 0x13;   
        // //当窗口背景必须被擦除时（例在窗口改变大小时）   
        //const int WM_ERASEBKGND = 0x14;   
        // //当系统颜色改变时，发送此消息给所有顶级窗口   
        //const int WM_SYSCOLORCHANGE = 0x15;   
        // //当系统进程发出WM_QUERYENDSESSION消息后，此消息发送给应用程序，通知它对话是否结束   
        //const int WM_ENDSESSION = 0x16;   
        // //当隐藏或显示窗口是发送此消息给这个窗口   
        //const int WM_SHOWWINDOW = 0x18;   
        // //发此消息给应用程序哪个窗口是激活的，哪个是非激活的   
        //const int WM_ACTIVATEAPP = 0x1C;   
        // //当系统的字体资源库变化时发送此消息给所有顶级窗口   
        //const int WM_FONTCHANGE = 0x1D;   
        // //当系统的时间变化时发送此消息给所有顶级窗口   
        //const int WM_TIMECHANGE = 0x1E;   
        // //发送此消息来取消某种正在进行的摸态（操作）   
        //const int WM_CANCELMODE = 0x1F;   
        // //如果鼠标引起光标在某个窗口中移动且鼠标输入没有被捕获时，就发消息给某个窗口   
        //const int WM_SETCURSOR = 0x20;   
        // //当光标在某个非激活的窗口中而用户正按着鼠标的某个键发送此消息给//当前窗口   
        //const int WM_MOUSEACTIVATE = 0x21;   
        // //发送此消息给MDI子窗口//当用户点击此窗口的标题栏，或//当窗口被激活，移动，改变大小   
        //const int WM_CHILDACTIVATE = 0x22;   
        // //此消息由基于计算机的训练程序发送，通过WH_JOURNALPALYBACK的hook程序分离出用户输入消息   
        //const int WM_QUEUESYNC = 0x23;   
        // //此消息发送给窗口当它将要改变大小或位置   
        //const int WM_GETMINMAXINFO = 0x24;   
        // //发送给最小化窗口当它图标将要被重画   
        //const int WM_PAINTICON = 0x26;   
        // //此消息发送给某个最小化窗口，仅//当它在画图标前它的背景必须被重画   
        //const int WM_ICONERASEBKGND = 0x27;   
        // //发送此消息给一个对话框程序去更改焦点位置   
        //const int WM_NEXTDLGCTL = 0x28;   
        // //每当打印管理列队增加或减少一条作业时发出此消息    
        //const int WM_SPOOLERSTATUS = 0x2A;   
        // //当button，combobox，listbox，menu的可视外观改变时发送   
        //const int WM_DRAWITEM = 0x2B;   
        // //当button, combo box, list box, list view control, or menu item 被创建时   
        //const int WM_MEASUREITEM = 0x2C;   
        // //此消息有一个LBS_WANTKEYBOARDINPUT风格的发出给它的所有者来响应WM_KEYDOWN消息    
        //const int WM_VKEYTOITEM = 0x2E;   
        // //此消息由一个LBS_WANTKEYBOARDINPUT风格的列表框发送给他的所有者来响应WM_CHAR消息    
        //const int WM_CHARTOITEM = 0x2F;   
        // //当绘制文本时程序发送此消息得到控件要用的颜色   
        //const int WM_SETFONT = 0x30;   
        // //应用程序发送此消息得到当前控件绘制文本的字体   
        //const int WM_GETFONT = 0x31;   
        // //应用程序发送此消息让一个窗口与一个热键相关连    
        //const int WM_SETHOTKEY = 0x32;   
        // //应用程序发送此消息来判断热键与某个窗口是否有关联   
        //const int WM_GETHOTKEY = 0x33;   
        // //此消息发送给最小化窗口，当此窗口将要被拖放而它的类中没有定义图标，应用程序能返回一个图标或光标的句柄，当用户拖放图标时系统显示这个图标或光标   
        //const int WM_QUERYDRAGICON = 0x37;   
        // //发送此消息来判定combobox或listbox新增加的项的相对位置   
        //const int WM_COMPAREITEM = 0x39;   
        // //显示内存已经很少了   
        //const int WM_COMPACTING = 0x41;   
        // //发送此消息给那个窗口的大小和位置将要被改变时，来调用setwindowpos函数或其它窗口管理函数   
        //const int WM_WINDOWPOSCHANGING = 0x46;   
        // //发送此消息给那个窗口的大小和位置已经被改变时，来调用setwindowpos函数或其它窗口管理函数   
        //const int WM_WINDOWPOSCHANGED = 0x47;   
        // //当系统将要进入暂停状态时发送此消息   
        //const int WM_POWER = 0x48;   
        // //当一个应用程序传递数据给另一个应用程序时发送此消息   
        //const int WM_COPYDATA = 0x4A;   
        // //当某个用户取消程序日志激活状态，提交此消息给程序   
        //const int WM_CANCELJOURNA = 0x4B;   
        // //当某个控件的某个事件已经发生或这个控件需要得到一些信息时，发送此消息给它的父窗口    
        //const int WM_NOTIFY = 0x4E;   
        // //当用户选择某种输入语言，或输入语言的热键改变   
        //const int WM_INPUTLANGCHANGEREQUEST = 0x50;   
        // //当平台现场已经被改变后发送此消息给受影响的最顶级窗口   
        //const int WM_INPUTLANGCHANGE = 0x51;   
        // //当程序已经初始化windows帮助例程时发送此消息给应用程序   
        //const int WM_TCARD = 0x52;   
        // //此消息显示用户按下了F1，如果某个菜单是激活的，就发送此消息个此窗口关联的菜单，否则就发送给有焦点的窗口，如果//当前都没有焦点，就把此消息发送给//当前激活的窗口   
        //const int WM_HELP = 0x53;   
        // //当用户已经登入或退出后发送此消息给所有的窗口，//当用户登入或退出时系统更新用户的具体设置信息，在用户更新设置时系统马上发送此消息   
        //const int WM_USERCHANGED = 0x54;   
        // //公用控件，自定义控件和他们的父窗口通过此消息来判断控件是使用ANSI还是UNICODE结构   
        //const int WM_NOTIFYFORMAT = 0x55;   
        // //当用户某个窗口中点击了一下右键就发送此消息给这个窗口   
        // //const int WM_CONTEXTMENU = ??;   
        // //当调用SETWINDOWLONG函数将要改变一个或多个 窗口的风格时发送此消息给那个窗口   
        //const int WM_STYLECHANGING = 0x7C;   
        // //当调用SETWINDOWLONG函数一个或多个 窗口的风格后发送此消息给那个窗口   
        //const int WM_STYLECHANGED = 0x7D;   
        // //当显示器的分辨率改变后发送此消息给所有的窗口   
        //const int WM_DISPLAYCHANGE = 0x7E;   
        // //此消息发送给某个窗口来返回与某个窗口有关连的大图标或小图标的句柄   
        //const int WM_GETICON = 0x7F;   
        // //程序发送此消息让一个新的大图标或小图标与某个窗口关联   
        //const int WM_SETICON = 0x80;   
        // //当某个窗口第一次被创建时，此消息在WM_CREATE消息发送前发送   
        //const int WM_NCCREATE = 0x81;   
        // //此消息通知某个窗口，非客户区正在销毁    
        //const int WM_NCDESTROY = 0x82;   
        // //当某个窗口的客户区域必须被核算时发送此消息   
        //const int WM_NCCALCSIZE = 0x83;   
        // //移动鼠标，按住或释放鼠标时发生   
        //const int WM_NCHITTEST = 0x84;   
        // //程序发送此消息给某个窗口当它（窗口）的框架必须被绘制时   
        //const int WM_NCPAINT = 0x85;   
        // //此消息发送给某个窗口仅当它的非客户区需要被改变来显示是激活还是非激活状态   
        //const int WM_NCACTIVATE = 0x86;   
        // //发送此消息给某个与对话框程序关联的控件，widdows控制方位键和TAB键使输入进入此控件通过应   
        //const int WM_GETDLGCODE = 0x87;   
        // //当光标在一个窗口的非客户区内移动时发送此消息给这个窗口 非客户区为：窗体的标题栏及窗 的边框体   
        //const int WM_NCMOUSEMOVE = 0xA0;   
        // //当光标在一个窗口的非客户区同时按下鼠标左键时提交此消息   
        //const int WM_NCLBUTTONDOWN = 0xA1;   
        // //当用户释放鼠标左键同时光标某个窗口在非客户区十发送此消息    
        //const int WM_NCLBUTTONUP = 0xA2;   
        // //当用户双击鼠标左键同时光标某个窗口在非客户区十发送此消息   
        //const int WM_NCLBUTTONDBLCLK = 0xA3;   
        // //当用户按下鼠标右键同时光标又在窗口的非客户区时发送此消息   
        //const int WM_NCRBUTTONDOWN = 0xA4;   
        // //当用户释放鼠标右键同时光标又在窗口的非客户区时发送此消息   
        //const int WM_NCRBUTTONUP = 0xA5;   
        // //当用户双击鼠标右键同时光标某个窗口在非客户区十发送此消息   
        //const int WM_NCRBUTTONDBLCLK = 0xA6;   
        // //当用户按下鼠标中键同时光标又在窗口的非客户区时发送此消息   
        //const int WM_NCMBUTTONDOWN = 0xA7;   
        // //当用户释放鼠标中键同时光标又在窗口的非客户区时发送此消息   
        //const int WM_NCMBUTTONUP = 0xA8;   
        // //当用户双击鼠标中键同时光标又在窗口的非客户区时发送此消息   
        //const int WM_NCMBUTTONDBLCLK = 0xA9;   
        // //WM_KEYDOWN 按下一个键   
        //const int WM_KEYDOWN = 0x0100;   
        // //释放一个键   
        //const int WM_KEYUP = 0x0101;   
        // //按下某键，并已发出WM_KEYDOWN， WM_KEYUP消息   
        //const int WM_CHAR = 0x102;   
        // //当用translatemessage函数翻译WM_KEYUP消息时发送此消息给拥有焦点的窗口   
        //const int WM_DEADCHAR = 0x103;   
        // //当用户按住ALT键同时按下其它键时提交此消息给拥有焦点的窗口   
        //const int WM_SYSKEYDOWN = 0x104;   
        // //当用户释放一个键同时ALT 键还按着时提交此消息给拥有焦点的窗口   
        //const int WM_SYSKEYUP = 0x105;   
        // //当WM_SYSKEYDOWN消息被TRANSLATEMESSAGE函数翻译后提交此消息给拥有焦点的窗口   
        //const int WM_SYSCHAR = 0x106;   
        // //当WM_SYSKEYDOWN消息被TRANSLATEMESSAGE函数翻译后发送此消息给拥有焦点的窗口   
        //const int WM_SYSDEADCHAR = 0x107;   
        // //在一个对话框程序被显示前发送此消息给它，通常用此消息初始化控件和执行其它任务   
        //const int WM_INITDIALOG = 0x110;   
        // //当用户选择一条菜单命令项或当某个控件发送一条消息给它的父窗口，一个快捷键被翻译   
        //const int WM_COMMAND = 0x111;   
        // //当用户选择窗口菜单的一条命令或//当用户选择最大化或最小化时那个窗口会收到此消息   
        //const int WM_SYSCOMMAND = 0x112;   
        // //发生了定时器事件   
        //const int WM_TIMER = 0x113;   
        // //当一个窗口标准水平滚动条产生一个滚动事件时发送此消息给那个窗口，也发送给拥有它的控件   
        //const int WM_HSCROLL = 0x114;   
        // //当一个窗口标准垂直滚动条产生一个滚动事件时发送此消息给那个窗口也，发送给拥有它的控件   
        //const int WM_VSCROLL = 0x115;   
        // //当一个菜单将要被激活时发送此消息，它发生在用户菜单条中的某项或按下某个菜单键，它允许程序在显示前更改菜单   
        //const int WM_INITMENU = 0x116;   
        // //当一个下拉菜单或子菜单将要被激活时发送此消息，它允许程序在它显示前更改菜单，而不要改变全部   
        //const int WM_INITMENUPOPUP = 0x117;   
        // //当用户选择一条菜单项时发送此消息给菜单的所有者（一般是窗口）   
        //const int WM_MENUSELECT = 0x11F;   
        // //当菜单已被激活用户按下了某个键（不同于加速键），发送此消息给菜单的所有者   
        //const int WM_MENUCHAR = 0x120;   
        // //当一个模态对话框或菜单进入空载状态时发送此消息给它的所有者，一个模态对话框或菜单进入空载状态就是在处理完一条或几条先前的消息后没有消息它的列队中等待   
        //const int WM_ENTERIDLE = 0x121;   
        // //在windows绘制消息框前发送此消息给消息框的所有者窗口，通过响应这条消息，所有者窗口可以通过使用给定的相关显示设备的句柄来设置消息框的文本和背景颜色   
        //const int WM_CTLCOLORMSGBOX = 0x132;   
        // //当一个编辑型控件将要被绘制时发送此消息给它的父窗口通过响应这条消息，所有者窗口可以通过使用给定的相关显示设备的句柄来设置编辑框的文本和背景颜色   
        //const int WM_CTLCOLOREDIT = 0x133;   

        // //当一个列表框控件将要被绘制前发送此消息给它的父窗口通过响应这条消息，所有者窗口可以通过使用给定的相关显示设备的句柄来设置列表框的文本和背景颜色   
        //const int WM_CTLCOLORLISTBOX = 0x134;   
        // //当一个按钮控件将要被绘制时发送此消息给它的父窗口通过响应这条消息，所有者窗口可以通过使用给定的相关显示设备的句柄来设置按纽的文本和背景颜色   
        //const int WM_CTLCOLORBTN = 0x135;   
        // //当一个对话框控件将要被绘制前发送此消息给它的父窗口通过响应这条消息，所有者窗口可以通过使用给定的相关显示设备的句柄来设置对话框的文本背景颜色   
        //const int WM_CTLCOLORDLG = 0x136;   
        // //当一个滚动条控件将要被绘制时发送此消息给它的父窗口通过响应这条消息，所有者窗口可以通过使用给定的相关显示设备的句柄来设置滚动条的背景颜色   
        //const int WM_CTLCOLORSCROLLBAR = 0x137;   
        // //当一个静态控件将要被绘制时发送此消息给它的父窗口通过响应这条消息，所有者窗口可以 通过使用给定的相关显示设备的句柄来设置静态控件的文本和背景颜色   
        //const int WM_CTLCOLORSTATIC = 0x138;   
        // //当鼠标轮子转动时发送此消息个当前有焦点的控件   
        //const int WM_MOUSEWHEEL = 0x20A;   
        // //双击鼠标中键   
        //const int WM_MBUTTONDBLCLK = 0x209;   
        // //释放鼠标中键   
        //const int WM_MBUTTONUP = 0x208;   
        // //移动鼠标时发生，同WM_MOUSEFIRST   
        // const int WM_MOUSEMOVE = 0x200;   
        // //按下鼠标左键   
        //const int WM_LBUTTONDOWN = 0x201;   
        // //释放鼠标左键   
        //const int WM_LBUTTONUP = 0x202;   
        // //双击鼠标左键   
        //const int WM_LBUTTONDBLCLK = 0x203;   
        // //按下鼠标右键   
        //const int WM_RBUTTONDOWN = 0x204;   
        // //释放鼠标右键   
        //const int WM_RBUTTONUP = 0x205;   
        // //双击鼠标右键   
        //const int WM_RBUTTONDBLCLK = 0x206;   
        // //按下鼠标中键   
        //const int WM_MBUTTONDOWN = 0x207;   

        //const int WM_USER = 0x0400;   
        //const int MK_LBUTTON = 0x0001;   
        //const int MK_RBUTTON = 0x0002;   
        //const int MK_SHIFT = 0x0004;   
        //const int MK_CONTROL = 0x0008;   
        //const int MK_MBUTTON = 0x0010;   
        //const int MK_XBUTTON1 = 0x0020;   
        //const int MK_XBUTTON2 = 0x0040;

        //[已知 ：0x0313, 0x01e2, 0x01e5, 0x01eb, 0x006a]
        // WM_NULL                  0x0000
        // WM_CREATE                0x0001
        // WM_DESTROY               0x0002
        // WM_MOVE                  0x0003
        // WM_SIZEWAIT              0x0004
        // WM_SIZE                  0x0005
        // WM_ACTIVATE              0x0006
        // WM_SETFOCUS              0x0007
        // WM_KILLFOCUS             0x0008
        // WM_SETVISIBLE            0x0009
        // WM_ENABLE                0x000A
        // WM_SETREDRAW             0x000B
        // WM_SETTEXT               0x000C
        // WM_GETTEXT               0x000D
        // WM_GETTEXTLENGTH         0x000E
        // WM_PAINT                 0x000F

        // WM_CLOSE                 0x0010
        // WM_QUERYENDSESSION       0x0011
        // WM_QUIT                  0x0012
        // WM_QUERYOPEN             0x0013
        // WM_ERASEBKGND            0x0014
        // WM_SYSCOLORCHANGE        0x0015
        // WM_ENDSESSION            0x0016
        // WM_SYSTEMERROR           0x0017
        // WM_SHOWWINDOW            0x0018
        // WM_CTLCOLOR              0x0019
        // WM_WININICHANGE          0x001A
        // WM_DEVMODECHANGE         0x001B
        // WM_ACTIVATEAPP           0x001C
        // WM_FONTCHANGE            0x001D
        // WM_TIMECHANGE            0x001E
        // WM_CANCELMODE            0x001F

        // WM_SETCURSOR             0x0020
        // WM_MOUSEACTIVATE         0x0021
        // WM_CHILDACTIVATE         0x0022
        // WM_QUEUESYNC             0x0023
        // WM_GETMINMAXINFO         0x0024
        // empty                    0x0025
        // WM_PAINTICON             0x0026
        // WM_ICONERASEBKGND        0x0027
        // WM_NEXTDLGCTL            0x0028
        // WM_ALTTABACTIVE          0x0029
        // WM_SPOOLERSTATUS         0x002A
        // WM_DRAWITEM              0x002B
        // WM_MEASUREITEM           0x002C
        // WM_DELETEITEM            0x002D
        // WM_VKEYTOITEM            0x002E
        // WM_CHARTOITEM            0x002F

        // WM_SETFONT               0x0030
        // WM_GETFONT               0x0031
        // WM_SETHOTKEY             0x0032
        // WM_GETHOTKEY             0x0033
        // WM_FILESYSCHANGE         0x0034
        // WM_ISACTIVEICON          0x0035
        // WM_QUERYPARKICON         0x0036
        // WM_QUERYDRAGICON         0x0037
        // WM_WINHELP               0x0038
        // WM_COMPAREITEM           0x0039
        // WM_FULLSCREEN            0x003A
        // WM_CLIENTSHUTDOWN        0x003B
        // WM_DDEMLEVENT            0x003C
        // empty                    0x003D
        // empty                    0x003E
        // MM_CALCSCROLL            0x003F

        // WM_TESTING               0x0040
        // WM_COMPACTING            0x0041

        // WM_OTHERWINDOWCREATED    0x0042
        // WM_OTHERWINDOWDESTROYED  0x0043
        // WM_COMMNOTIFY            0x0044
        // WM_MEDIASTATUSCHANGE     0x0045
        // WM_WINDOWPOSCHANGING     0x0046
        // WM_WINDOWPOSCHANGED      0x0047

        // WM_POWER                 0x0048
        // WM_COPYGLOBALDATA        0x0049
        // WM_COPYDATA              0x004A
        // WM_CANCELJOURNAL         0x004B
        // WM_LOGONNOTIFY           0x004C
        // WM_KEYF1                 0x004D
        // WM_NOTIFY                0x004E
        // WM_ACCESS_WINDOW         0x004f

        // WM_INPUTLANGCHANGEREQUEST 0x0050
        // WM_INPUTLANGCHANGE       0x0051
        // WM_TCARD                 0x0052
        // WM_HELP                  0x0053 WINHELP4
        // WM_USERCHANGED           0x0054
        // WM_NOTIFYFORMAT          0x0055

        // 0x0059-0x005F

        // 0x0060-0x0067

        // 0x0068-0x006F

        // WM_FINALDESTROY          0x0070

        // WM_TASKACTIVATED         0x0072
        // WM_TASKDEACTIVATED       0x0073
        // WM_TASKCREATED           0x0074
        // WM_TASKDESTROYED         0x0075
        // WM_TASKUICHANGED         0x0076
        // WM_TASKVISIBLE           0x0077
        // WM_TASKNOTVISIBLE        0x0078
        // WM_SETCURSORINFO         0x0079
        //                          0x007A
        // WM_CONTEXTMENU           0x007B
        // WM_STYLECHANGING         0x007C
        // WM_STYLECHANGED          0x007D
        //                          0x007E
        // WM_GETICON               0x007f

        // WM_SETICON               0x0080
        // WM_NCCREATE              0x0081
        // WM_NCDESTROY             0x0082
        // WM_NCCALCSIZE            0x0083

        // WM_NCHITTEST             0x0084
        // WM_NCPAINT               0x0085
        // WM_NCACTIVATE            0x0086
        // WM_GETDLGCODE            0x0087

        // WM_SYNCPAINT             0x0088
        // WM_SYNCTASK              0x0089


        // WM_KLUDGEMINRECT         0x008B
        // WM_LPKDRAWSWITCHWND      0x008C
        // 0x008D-0x008F


        // 0x0090-0x0097


        // 0x0098-0x009F


        // WM_NCMOUSEMOVE           0x00A0
        // WM_NCLBUTTONDOWN         0x00A1
        // WM_NCLBUTTONUP           0x00A2
        // WM_NCLBUTTONDBLCLK       0x00A3
        // WM_NCRBUTTONDOWN         0x00A4
        // WM_NCRBUTTONUP           0x00A5
        // WM_NCRBUTTONDBLCLK       0x00A6
        // WM_NCMBUTTONDOWN         0x00A7
        // WM_NCMBUTTONUP           0x00A8
        // WM_NCMBUTTONDBLCLK       0x00A9

        // 0x00AA-0x00AF


        // EM_GETSEL                0x00B0
        // EM_SETSEL                0x00B1
        // EM_GETRECT               0x00B2
        // EM_SETRECT               0x00B3
        // EM_SETRECTNP             0x00B4
        // EM_SCROLL                0x00B5
        // EM_LINESCROLL            0x00B6
        // empty                    0x00B7
        // EM_GETMODIFY             0x00B8
        // EM_SETMODIFY             0x00B9
        // EM_GETLINECOUNT          0x00BA
        // EM_LINEINDEX             0x00BB
        // EM_SETHANDLE             0x00BC
        // EM_GETHANDLE             0x00BD
        // EM_GETTHUMB              0x00BE
        // empty                    0x00BF

        // empty                    0x00C0
        // EM_LINELENGTH            0x00C1
        // EM_REPLACESEL            0x00C2
        // EM_SETFONT               0x00C3
        // EM_GETLINE               0x00C4
        // EM_LIMITTEXT             0x00C5
        // EM_CANUNDO               0x00C6
        // EM_UNDO                  0x00C7
        // EM_FMTLINES              0x00C8
        // EM_LINEFROMCHAR          0x00C9
        // EM_SETWORDBREAK          0x00CA
        // EM_SETTABSTOPS           0x00CB
        // EM_SETPASSWORDCHAR       0x00CC
        // EM_EMPTYUNDOBUFFER       0x00CD
        // EM_GETFIRSTVISIBLELINE   0x00CE
        // EM_SETREADONLY           0x00CF

        // EM_SETWORDBREAKPROC      0x00D0
        // EM_GETWORDBREAKPROC      0x00D1
        // EM_GETPASSWORDCHAR       0x00D2
        // EM_SETMARGINS            0x00D3
        // EM_GETMARGINS            0x00D4
        // EM_GETLIMITTEXT          0x00D5
        // EM_POSFROMCHAR           0x00D6
        // EM_CHARFROMPOS           0x00D7
        // EM_SETIMESTATUS          0x00D8

        // EM_GETIMESTATUS          0x00D9
        // EM_MSGMAX                0x00DA
        // 0x00DB-0x00DF


        // SBM_SETPOS               0x00E0
        // SBM_GETPOS               0x00E1
        // SBM_SETRANGE             0x00E2
        // // SBM_GETRANGE          0x00E3
        // SBM_ENABLE_ARROWS        0x00E4

        // SBM_SETRANGEREDRAW       0x00E6


        // SBM_SETSCROLLINFO        0x00E9
        // SBM_GETSCROLLINFO        0x00EA


        // BM_GETCHECK              0x00F0
        // BM_SETCHECK              0x00F1
        // BM_GETSTATE              0x00F2
        // BM_SETSTATE              0x00F3
        // BM_SETSTYLE              0x00F4
        // BM_CLICK                 0x00F5
        // BM_GETIMAGE              0x00F6
        // BM_SETIMAGE              0x00F7

        // 0x00F8-0x00FF

        //WM_KEYDOWN               0x0100
        // WM_KEYUP                 0x0101
        // WM_CHAR                  0x0102
        // WM_DEADCHAR              0x0103
        // WM_SYSKEYDOWN            0x0104
        // WM_SYSKEYUP              0x0105
        // WM_SYSCHAR               0x0106
        // WM_SYSDEADCHAR           0x0107
        // WM_YOMICHAR              0x0108
        // empty                    0x0109
        // WM_CONVERTREQUEST        0x010A
        // WM_CONVERTRESULT         0x010B
        // empty                    0x010C
        // empty                    0x010D
        // empty                    0x010E
        // WM_IME_COMPOSITION       0x010F

        // WM_INITDIALOG            0x0110
        // WM_COMMAND               0x0111
        // WM_SYSCOMMAND            0x0112
        // WM_TIMER                 0x0113
        // WM_HSCROLL               0x0114
        // WM_VSCROLL               0x0115
        // WM_INITMENU              0x0116
        // WM_INITMENUPOPUP         0x0117
        // WM_SYSTIMER              0x0118
        // empty                    0x0119
        // empty                    0x011A
        // empty                    0x011B
        // empty                    0x011C
        // empty                    0x011D
        // empty                    0x011E
        // WM_MENUSELECT            0x011F

        // WM_MENUCHAR              0x0120
        // WM_ENTERIDLE             0x0121
        // WM_MENURBUTTONUP         0x0122
        // WM_MENUDRAG              0x0123
        // WM_MENUGETOBJECT         0x0124
        // WM_UNINITMENUPOPUP       0x0125
        // WM_MENUCOMMAND           0x0126
        // WM_CHANGEUISTATE         0x0127
        // WM_UPDATEUISTATE         0x0128
        // WM_QUERYUISTATE          0x0129

        // 0x012A-0x012F


        // empty                    0x0130
        // WM_LBTRACKPOINT          0x0131
        // WM_CTLCOLORMSGBOX        0x0132
        // WM_CTLCOLOREDIT          0x0133
        // WM_CTLCOLORLISTBOX       0x0134
        // WM_CTLCOLORBTN           0x0135
        // WM_CTLCOLORDLG           0x0136
        // WM_CTLCOLORSCROLLBAR     0x0137
        // WM_CTLCOLORSTATIC        0x0138
        //                          0x0139

        // 0x013A-0x013F


        // CB_GETEDITSEL            0x0140
        // CB_LIMITTEXT             0x0141
        // CB_SETEDITSEL            0x0142
        // CB_ADDSTRING             0x0143
        // CB_DELETESTRING          0x0144
        // CB_DIR                   0x0145
        // CB_GETCOUNT              0x0146
        // CB_GETCURSEL             0x0147
        // CB_GETLBTEXT             0x0148
        // CB_GETLBTEXTLEN          0x0149
        // CB_INSERTSTRING          0x014A
        // CB_RESETCONTENT          0x014B
        // CB_FINDSTRING            0x014C
        // CB_SELECTSTRING          0x014D
        // CB_SETCURSEL             0x014E
        // CB_SHOWDROPDOWN          0x014F

        // CB_GETITEMDATA           0x0150
        // CB_SETITEMDATA           0x0151
        // CB_GETDROPPEDCONTROLRECT 0x0152
        // CB_SETITEMHEIGHT         0x0153
        // CB_GETITEMHEIGHT         0x0154
        // CB_SETEXTENDEDUI         0x0155
        // CB_GETEXTENDEDUI         0x0156
        // CB_GETDROPPEDSTATE       0x0157
        // CB_FINDSTRINGEXACT       0x0158
        // CB_SETLOCALE             0x0159
        // CB_GETLOCALE             0x015A
        // CB_GETTOPINDEX           0x015b

        // CB_SETTOPINDEX           0x015c
        // CB_GETHORIZONTALEXTENT   0x015d
        // CB_SETHORIZONTALEXTENT   0x015e
        // CB_GETDROPPEDWIDTH       0x015F

        // CB_SETDROPPEDWIDTH       0x0160
        // CB_INITSTORAGE           0x0161
        // CB_MSGMAX                0x0162
        // 0x0163-0x0167



        // 0x0168-0x016F


        // STM_SETICON              0x0170
        // STM_GETICON              0x0171
        // STM_SETIMAGE             0x0172
        // STM_GETIMAGE             0x0173
        // STM_MSGMAX               0x0174
        // 0x0175-0x0177


        // 0x0178-0x017F

        // LB_ADDSTRING             0x0180
        // LB_INSERTSTRING          0x0181
        // LB_DELETESTRING          0x0182
        // empty                    0x0183
        // LB_RESETCONTENT          0x0184
        // LB_SETSEL                0x0185
        // LB_SETCURSEL             0x0186
        // LB_GETSEL                0x0187
        // LB_GETCURSEL             0x0188
        // LB_GETTEXT               0x0189
        // LB_GETTEXTLEN            0x018A
        // LB_GETCOUNT              0x018B
        // LB_SELECTSTRING          0x018C
        // LB_DIR                   0x018D
        // LB_GETTOPINDEX           0x018E
        // LB_FINDSTRING            0x018F

        // LB_GETSELCOUNT           0x0190
        // LB_GETSELITEMS           0x0191
        // LB_SETTABSTOPS           0x0192
        // LB_GETHORIZONTALEXTENT   0x0193
        // LB_SETHORIZONTALEXTENT   0x0194
        // LB_SETCOLUMNWIDTH        0x0195
        // LB_ADDFILE               0x0196
        // LB_SETTOPINDEX           0x0197
        // LB_GETITEMRECT           0x0198
        // LB_GETITEMDATA           0x0199
        // LB_SETITEMDATA           0x019A
        // LB_SELITEMRANGE          0x019B
        // LB_SETANCHORINDEX        0x019C
        // LB_GETANCHORINDEX        0x019D
        // LB_SETCARETINDEX         0x019E
        // LB_GETCARETINDEX         0x019F

        // LB_SETITEMHEIGHT         0x01A0
        // LB_GETITEMHEIGHT         0x01A1
        // LB_FINDSTRINGEXACT       0x01A2
        // LBCB_CARETON             0x01A3
        // LBCB_CARETOFF            0x01A4
        // LB_SETLOCALE             0x01A5
        // LB_GETLOCALE             0x01A6
        // LB_SETCOUNT              0x01A7

        // LB_INITSTORAGE           0x01A8

        // LB_ITEMFROMPOINT         0x01A9
        // LB_INSERTSTRINGUPPER     0x01AA
        // LB_INSERTSTRINGLOWER     0x01AB
        // LB_ADDSTRINGUPPER        0x01AC
        // LB_ADDSTRINGLOWER        0x01AD
        // LBCB_STARTTRACK          0x01AE
        // LBCB_ENDTRACK            0x01AF

        // LB_MSGMAX                0x01B0
        // 0x01B1-0x01B7

        // 0x01B8-0x01BF

        // 0x01C0-0x01C7

        // 0x01C8-0x01CF

        // 0x01D0-0x01D7

        // 0x01D8-0x01DF

        // MN_SETHMENU              0x01E0
        // MN_GETHMENU              0x01E1
        // MN_SIZEWINDOW            0x01E2
        // MN_OPENHIERARCHY         0x01E3
        // MN_CLOSEHIERARCHY        0x01E4
        // MN_SELECTITEM            0x01E5
        // MN_CANCELMENUS           0x01E6
        // MN_SELECTFIRSTVALIDITEM  0x01E7

        // 0x1E8 - 0x1E9

        // MN_GETPPOPUPMENU(obsolete) 0x01EA
        // MN_FINDMENUWINDOWFROMPOINT 0x01EB
        // MN_SHOWPOPUPWINDOW         0x01EC
        // MN_BUTTONDOWN              0x01ED
        // MN_MOUSEMOVE               0x01EE
        // MN_BUTTONUP                0x01EF
        // MN_SETTIMERTOOPENHIERARCHY 0x01F0

        // MN_DBLCLK                  0x01F1
        // MN_ENDMENU                 0x01F2
        // MN_DODRAGDROP              0x01F3
        // MN_ENDMENU                 0x01F4

        // 0x01F5-0x01F7

        // 0x01F8-0x01FF

        //WM_MOUSEMOVE             0x0200
        // WM_LBUTTONDOWN           0x0201
        // WM_LBUTTONUP             0x0202
        // WM_LBUTTONDBLCLK         0x0203
        // WM_RBUTTONDOWN           0x0204
        // WM_RBUTTONUP             0x0205
        // WM_RBUTTONDBLCLK         0x0206
        // WM_MBUTTONDOWN           0x0207
        // WM_MBUTTONUP             0x0208
        // WM_MBUTTONDBLCLK         0x0209
        // WM_MOUSEWHEEL            0x020A
        // WM_XBUTTONDOWN           0x020B
        // WM_XBUTTONUP             0x020C
        // WM_XBUTTONDBLCLK         0x020D
        // empty                    0x020E
        // empty                    0x020F

        // WM_PARENTNOTIFY          0x0210
        // WM_ENTERMENULOOP         0x0211
        // WM_EXITMENULOOP          0x0212
        // WM_NEXTMENU              0x0213

        // WM_SIZING                0x0214
        // WM_CAPTURECHANGED        0x0215
        // WM_MOVING                0x0216


        // WM_POWERBROADCAST        0x0218
        // WM_DEVICECHANGE          0x0219
        // 0x021A-0x021F

        // WM_MDICREATE             0x0220
        // WM_MDIDESTROY            0x0221
        // WM_MDIACTIVATE           0x0222
        // WM_MDIRESTORE            0x0223
        // WM_MDINEXT               0x0224
        // WM_MDIMAXIMIZE           0x0225
        // WM_MDITILE               0x0226
        // WM_MDICASCADE            0x0227
        // WM_MDIICONARRANGE        0x0228
        // // WM_MDIGETACTIVE       0x0229
        // WM_DROPOBJECT            0x022A
        // WM_QUERYDROPOBJECT       0x022B
        // WM_BEGINDRAG             0x022C
        // WM_DRAGLOOP              0x022D
        // WM_DRAGSELECT            0x022E
        // WM_DRAGMOVE              0x022F

        // WM_MDISETMENU            0x0230
        // WM_ENTERSIZEMOVE         0x0231
        // WM_EXITSIZEMOVE          0x0232

        // WM_DROPFILES             0x0233
        // WM_MDIREFRESHMENU        0x0234
        // 0x0235-0x0237

        // 0x0238-0x023F

        // 0x0240-0x0247

        // 0x0248-0x024F

        // 0x0250-0x0257

        // 0x0258-0x025F

        // 0x0260-0x0267

        // 0x0268-0x026F

        // 0x0270-0x0277

        // 0x0278-0x027F

        // WM_IME_REPORT            0x0280
        // WM_IME_SETCONTEXT        0x0281
        // WM_IME_NOTIFY            0x0282
        // WM_IME_CONTROL           0x0283
        // WM_IME_COMPOSITIONFULL   0x0284
        // WM_IME_SELECT            0x0285
        // WM_IME_CHAR              0x0286


        // 0x0288

        // 0x0290

        // 0x0298

        // WM_KANJILAST             0x029F

        // WM_NCMOUSEHOVER          0x02Ao
        // WM_MOUSEHOVER            0x02A1
        // WM_NCMOUSELEAVE          0x02A2
        // WM_MOUSELEAVE            0x02A3

        // 0x02A4-0x02A7

        // 0x02A8-0x02AF


        // 0x02B0-0x02B7

        // 0x02B8-0x02BF

        // 0x02C0-0x02C7

        // 0x02C8-0x02CF

        // 0x02D0-0x02D7

        // 0x02D8-0x02DF

        // 0x02E0-0x02E7

        // 0x02E8-0x02EF

        // 0x02F0-0x02F7

        // 0x02F8-0x02FF

        // WM_CUT                   0x0300
        // WM_COPY                  0x0301
        // WM_PASTE                 0x0302
        // WM_CLEAR                 0x0303
        // WM_UNDO                  0x0304
        // WM_RENDERFORMAT          0x0305
        // WM_RENDERALLFORMATS      0x0306
        // WM_DESTROYCLIPBOARD      0x0307
        // WM_DRAWCLIPBOARD         0x0308
        // WM_PAINTCLIPBOARD        0x0309
        // WM_VSCROLLCLIPBOARD      0x030A
        // WM_SIZECLIPBOARD         0x030B
        // WM_ASKCBFORMATNAME       0x030C
        // WM_CHANGECBCHAIN         0x030D
        // WM_HSCROLLCLIPBOARD      0x030E
        // WM_QUERYNEWPALETTE       0x030F

        // WM_PALETTEISCHANGING     0x0310
        // WM_PALETTECHANGED        0x0311
        // WM_HOTKEY                0x0312

        // 0x0313-0x0316
        // WM_HOOKMSG               0x0314
        // WM_EXITPROCESS           0x0315
        // WM_WAKETHREAD            0x0316
        // WM_PRINT                 0x0317

        // WM_PRINTCLIENT           0x0318
        // WM_APPCOMMAND            0x0319

        // 0x0320-0x0327

        // 0x0328-0x032F

        // 0x0330-0x0337

        // 0x0338-0x033F

        // 0x0340-0x0347

        // 0x0348-0x034F

        // 0x0350-0x0357

        // reserved pen windows      0x0358-0x035F

        // 0x0360-0x0367

        // 0x0368-0x036F

        // 0x0370-0x0377

        // 0x0378-0x037F

        // 0x0380-0x0387

        // 0x0388-0x038F

        // 0x0390-0x0397

        // 0x0398-0x039F

        // WM_MM_RESERVED_FIRST      0x03A0

        // 0x03A8

        // 0x03B0

        // 0x03B7

        // 0x03C0

        // 0x03C7

        // 0x03D0

        // 0x03D7

        // WM_MM_RESERVED_LAST      0x03DF

        // WM_DDE_INITIATE          0x03E0
        // WM_DDE_TERMINATE         0x03E1
        // WM_DDE_ADVISE            0x03E2
        // WM_DDE_UNADVISE          0x03E3
        // WM_DDE_ACK               0x03E4
        // WM_DDE_DATA              0x03E5
        // WM_DDE_REQUEST           0x03E6
        // WM_DDE_POKE              0x03E7
        // WM_DDE_EXECUTE           0x03E8

        // 0x03E9-0x03EF

        // WM_CBT_RESERVED_FIRST     0x03F0

        // 0x03F8

        // WM_CBT_RESERVED_LAST      

        #endregion

        [DllImport("user32.dll")]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("User32.dll", EntryPoint = "SendMessage")]
        private static extern int SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, string lParam);

        [DllImport("User32.dll ")]
        public static extern IntPtr FindWindowEx(IntPtr parent, IntPtr childe, string strclass, string FrmText);

        //[DllImport("user32.dll")]
        //public static extern int FindWindowEx(int hwndParent, int hwndChildAfter, string lpszClass, string lpszWindow);
        //[DllImport("user32.dll")]
        //public static extern int FindWindow(string strclassName, string strWindowName);
        //[DllImport("user32.dll")]
        //public static extern int GetLastActivePopup(int hWnd);
        //[DllImport("user32.dll")]
        //public static extern int AnyPopup();


        private void button1_Click(object sender, EventArgs e)
        {
            const int BM_CLICK = 0xF5;
            const int WM_LBUTTONDOWN = 0x0201;
            const int WM_LBUTTONUP = 0x0202;

            #region 测试 User Type
            //这是用于查找操作系统中打开的窗口中标题名为User Type的窗口。
            //第一个参数是此窗口的类型。这两个参数知道一个即可，另一个可以填null。
            //但是如果是用窗口类型查找，则可能只能得到其中的一个窗口。因此通过标题进行查找是非常方便的。
            IntPtr maindHwnd = FindWindow(null, "User Type");
            IntPtr btnOkHwnd = FindWindowEx(maindHwnd, IntPtr.Zero, null, "OK");   //获得按钮的句柄 
            MessageBox.Show(btnOkHwnd.ToString("X8"));
            if (btnOkHwnd != IntPtr.Zero)
            {
                //SendMessage(btnOkHwnd, WM_LBUTTONUP, IntPtr.Zero, null);
                //SendMessage(btnOkHwnd, WM_LBUTTONDOWN, IntPtr.Zero, null);
                SendMessage(btnOkHwnd, BM_CLICK, IntPtr.Zero, null);     //发送点击按钮的消息 
            }
            else
            {
                MessageBox.Show("没有找到OK子窗口");
            }

            IntPtr radioHwnd = FindWindowEx(maindHwnd, btnOkHwnd, null, null);   //获得按钮的句柄 
            MessageBox.Show(radioHwnd.ToString("X8"));
            if (btnOkHwnd != IntPtr.Zero)
            {
                SendMessage(btnOkHwnd, WM_LBUTTONDOWN, IntPtr.Zero, null);
                SendMessage(btnOkHwnd, WM_LBUTTONUP, IntPtr.Zero, null);
                SendMessage(radioHwnd, BM_CLICK, IntPtr.Zero, null);     //发送点击按钮的消息 
            }
            else
            {
                MessageBox.Show("没有找到子窗口");
            }
            #endregion

            #region 测试用例
            //这个函数用于获得窗口中子窗口的句柄，子窗口指的其实就是窗口中的各种控件。
            //第一个参数是父窗口的句柄，
            //第二个参数指示获得的是同一类型中的第几个子窗口。填IntPtr.Zero则表示获得第一个子窗口。
            //第三个参数表示你需要找的子窗口的类型，第四个参数一般为null。如果一个窗口中有两个文本框，那么可以用如下操作获得第二个文本框的句柄。
            //IntPtr btnhwnd = FindWindowEx(hwnd, new IntPtr(0), "BUTTON", null);
            //MessageBox.Show(btnhwnd.ToString());

            //IntPtr btnhwnd2 = FindWindowEx(hwnd, btnhwnd, "BUTTON", "Cancel");
            //MessageBox.Show(btnhwnd2.ToString());

            //IntPtr btnhwnd3 = FindWindowEx(hwnd, btnhwnd2, "BUTTON", null);//填上次获得的句柄，可以得到下一个的句柄。 
            //MessageBox.Show(btnhwnd3.ToString());
            //SendMessage(btnhwnd3, BM_CLICK, new IntPtr(0), null);//按下按钮。 

            //这里只是先将第二个参数填为IntPtr.Zero，获取第一个EDIT类型的文本框，然后第二次调用时，再将第二参数填为第一个文本框的句柄，
            //那么执行返回的就是下一个文本框的句柄了。因此htextbox2得到的就是第二文本框的句柄。
            //在可以自由获得各种窗口及其上控件的句柄后，我们就可以向其发送各种消息进行鼠标和键盘的模拟了。比如：
            //SendMessage(htextbox, WM_SETTEXT, IntPtr.Zero, name); 

            //这句是为文本框填写相应的字符串name。
            //IntPtr hbutton = FindWindowEx(hwnd, IntPtr.Zero, "BUTTON", null);
            //SendMessage(hbutton, WM_LBUTTONDOWN, IntPtr.Zero, null);
            //SendMessage(hbutton, WM_LBUTTONUP, IntPtr.Zero, null); 

            //这三句是获得了窗口的一个button，然后发送按下，弹起消息给它，模拟了点击鼠标的动作。
            //SendMessage函数的第一个参数是窗口句柄，或者窗口中控件的句柄，第二个参数是消息的类型Flag，这些值是在API的一些头文件中定义好的。你要是在C#中用，就自己去定义他们，比如

            //const int WM_SETTEXT = 0x000C;
            //const int WM_LBUTTONDOWN = 0x0201;
            //const int WM_LBUTTONUP = 0x0202;
            //const int WM_CLOSE = 0x0010;

            //还有其他的类型Flag，可以参考上一篇Blog查询，也可以去查MSDN。第三个参数和第四个参数都是消息的具体内容。一般我们用的是最后一个参数。第三个参数填为IntPtr.Zero。
            //当然如果是鼠标的动作，那么最后一个参数就是null。
            //SendMessage(htextbox, WM_SETTEXT, IntPtr.Zero, name);//填写文本框。
            //SendMessage(hbutton, WM_LBUTTONDOWN, IntPtr.Zero, null);//鼠标按下按钮。 
            #endregion

        }

        private void btnFrmTest_Click(object sender, EventArgs e)
        {
            const int BM_CLICK = 0xF5;
            IntPtr maindHwnd = FindWindow(null, "frmTest"); //获得窗口句柄 

            if (maindHwnd != IntPtr.Zero)
            {

                IntPtr btn1Hwnd = FindWindowEx(maindHwnd, IntPtr.Zero, null, "button1");   //获得按钮的句柄   
                if (btn1Hwnd != IntPtr.Zero)
                {
                    SendMessage(btn1Hwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息  
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }

                IntPtr comboBoxHwnd2 = FindWindowEx(maindHwnd, IntPtr.Zero, null, "");   // 
                //MessageBox.Show(comboBoxHwnd2.ToString("X8"));
                if (comboBoxHwnd2 != IntPtr.Zero)
                {
                    //SendMessage(btnHwnd, 0x0201, new IntPtr(0), null);     //发送点击按钮的消息 
                    //SendMessage(btn1Hwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息 
                    SendMessage(comboBoxHwnd2, 0x000C, new IntPtr(0), "comboBox Write test2");     //发送点击按钮的消息   
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }

                IntPtr txtBoxHwnd1 = FindWindowEx(maindHwnd, comboBoxHwnd2, null, "");   // 
                //MessageBox.Show(txtBoxHwnd1.ToString("X8"));
                if (txtBoxHwnd1 != IntPtr.Zero)
                {
                    //SendMessage(btnHwnd, 0x0201, new IntPtr(0), null);     //发送点击按钮的消息 
                    //SendMessage(btn1Hwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息 
                    SendMessage(txtBoxHwnd1, 0x000C, new IntPtr(0), "txtBox Write test1");     //发送点击按钮的消息   
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }

                IntPtr comboBoxHwnd1 = FindWindowEx(maindHwnd, txtBoxHwnd1, null, "");   // 
                //MessageBox.Show(comboBoxHwnd1.ToString("X8"));
                if (comboBoxHwnd1 != IntPtr.Zero)
                {
                    //SendMessage(btnHwnd, 0x0201, new IntPtr(0), null);     //发送点击按钮的消息 
                    //SendMessage(btn1Hwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息 
                    SendMessage(comboBoxHwnd1, 0x000C, new IntPtr(0), "comboBox Write test1");     //发送点击按钮的消息   
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }

                IntPtr txtBoxHwnd2 = FindWindowEx(maindHwnd, comboBoxHwnd1, null, null);   // 
                //MessageBox.Show(txtBoxHwnd2.ToString("X8"));
                if (txtBoxHwnd2 != IntPtr.Zero)
                {
                    //SendMessage(btnHwnd, 0x0201, new IntPtr(0), null);     //发送点击按钮的消息 
                    //SendMessage(btn1Hwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息 
                    SendMessage(txtBoxHwnd2, 0x000C, new IntPtr(0), "txtBox Write test2");     //发送点击按钮的消息   
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }
                IntPtr btn2Hwnd = FindWindowEx(maindHwnd, IntPtr.Zero, null, "button2");   //获得按钮的句柄   
                if (btn2Hwnd != IntPtr.Zero)
                {
                    //SendMessage(btnHwnd, 0x0201, new IntPtr(0), null);     //发送点击按钮的消息 
                    SendMessage(btn2Hwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息  
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }
                IntPtr btn3Hwnd = FindWindowEx(maindHwnd, IntPtr.Zero, null, "OpenFileDlg");   //获得按钮的句柄   
                if (btn2Hwnd != IntPtr.Zero)
                {
                    //SendMessage(btnHwnd, 0x0201, new IntPtr(0), null);     //发送点击按钮的消息 
                    SendMessage(btn3Hwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息  
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }
            }
            else
            {
                MessageBox.Show("没有找到窗口");
            }
        }

        private void btnTestOpenFileDlg_Click(object sender, EventArgs e)
        {
            const int BM_CLICK = 0xF5;
            const int WM_LBUTTONDOWN = 0x0201;
            const int WM_LBUTTONUP = 0x0202;

            #region 测试 frmTest的OpenFileDlg按钮
            //IntPtr frmTestHwnd = FindWindow(null, "frmTest"); //获得窗口句柄 
            //if (frmTestHwnd != IntPtr.Zero)
            //{
            //    IntPtr btnOpenFileDlgHwnd = FindWindowEx(frmTestHwnd, IntPtr.Zero, null, "OpenFileDlg");   //获得按钮的句柄   
            //    if (btnOpenFileDlgHwnd != IntPtr.Zero)
            //    {
            //        //SendMessage(btnHwnd, 0x0201, new IntPtr(0), null);     //发送点击按钮的消息 
            //        SendMessage(btnOpenFileDlgHwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息  
            //    }
            //    else
            //    {
            //        MessageBox.Show("没有找到子窗口");
            //    }
            //}
            #endregion

            #region 测试 Retrieve
            IntPtr retrieveHwnd = FindWindow(null, "Retrieve"); //获得窗口句柄
            //MessageBox.Show(openHwnd.ToString("X8"));
            if (retrieveHwnd != IntPtr.Zero)
            {
                IntPtr StaticFileNameHwnd = FindWindowEx(retrieveHwnd, IntPtr.Zero, "Static", "File &name:");
                //MessageBox.Show(StaticFileNameHwnd.ToString("X8"));

                IntPtr taticFileNameHwnd2 = FindWindowEx(retrieveHwnd, StaticFileNameHwnd, null, null);   //获得下一个窗体的句柄 
                //MessageBox.Show(taticFileNameHwnd2.ToString("X8"));

                IntPtr taticFileNameHwnd3 = FindWindowEx(taticFileNameHwnd2, new IntPtr(0), null, null);   //获得窗体的子句柄 
                //MessageBox.Show(taticFileNameHwnd3.ToString("X8"));

                IntPtr taticFileNameHwnd4 = FindWindowEx(taticFileNameHwnd3, new IntPtr(0), null, null);   //获得窗体的子句柄 
                //MessageBox.Show(taticFileNameHwnd4.ToString("X8"));

                if (taticFileNameHwnd4 != IntPtr.Zero)
                {
                    SendMessage(taticFileNameHwnd4, 0x000C, new IntPtr(0), "19XR_APO_Advante3c_20170209.E3A");    //发送写路径的消息 
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }


                //IntPtr txtFileTypeHwnd = FindWindowEx(openHwnd, IntPtr.Zero, "ComboBox", "");   //获得按钮的句柄  
                //MessageBox.Show(txtFileTypeHwnd.ToString("X8"));


                IntPtr btnOpenHwnd = FindWindowEx(retrieveHwnd, IntPtr.Zero, "Button", "&Open");   //获得按钮的句柄   
                //MessageBox.Show(btnOpenHwnd.ToString("X8"));
                if (btnOpenHwnd != IntPtr.Zero)
                {
                    SendMessage(btnOpenHwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息  
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }
            }
            #endregion

            Thread.Sleep(1000);
            Application.DoEvents();

            #region 测试 Retrieve2
            IntPtr retrieveHwnd2 = FindWindow(null, "Retrieve"); //获得窗口句柄
            //MessageBox.Show(retrieveHwnd2.ToString("X8"));
            if (retrieveHwnd2 != IntPtr.Zero)
            {
                IntPtr btnRetrieveHwnd = FindWindowEx(retrieveHwnd2, IntPtr.Zero, "ThunderRT6CommandButton", "&Retrieve");   //获得按钮的句柄   
                //MessageBox.Show(btnRetrieveHwnd.ToString("X8"));
                if (btnRetrieveHwnd != IntPtr.Zero)
                {
                    SendMessage(btnRetrieveHwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息  
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }
            }
            #endregion

            Thread.Sleep(1000);
            Application.DoEvents();

            #region 测试 Retrieve3
            IntPtr retrieveHwnd3 = FindWindow(null, "Retrieve"); //获得窗口句柄
            //MessageBox.Show(retrieveHwnd3.ToString("X8"));
            if (retrieveHwnd3 != IntPtr.Zero)
            {
                IntPtr btnOkHwnd = FindWindowEx(retrieveHwnd3, IntPtr.Zero, "Button", "OK");   //获得按钮的句柄   
                //MessageBox.Show(btnOkHwnd.ToString("X8"));
                if (btnOkHwnd != IntPtr.Zero)
                {
                    SendMessage(btnOkHwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息  
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }
            }
            #endregion
        }

        private void btnMyOpenFileDlg_Click(object sender, EventArgs e)
        {
            #region 测试 testMyOpenFileDlg 测试ok
            IntPtr openHwnd = FindWindow(null, "Open"); //获得窗口句柄
            //MessageBox.Show(openHwnd.ToString("X8"));
            if (openHwnd != IntPtr.Zero)
            {
                IntPtr StaticFileNameHwnd = FindWindowEx(openHwnd, IntPtr.Zero, "Static", "File &name:");
                //MessageBox.Show(StaticFileNameHwnd.ToString("X8"));

                IntPtr taticFileNameHwnd2 = FindWindowEx(openHwnd, StaticFileNameHwnd, null, null);   //获得下一个窗体的句柄 
                //MessageBox.Show(taticFileNameHwnd2.ToString("X8"));

                IntPtr taticFileNameHwnd3 = FindWindowEx(taticFileNameHwnd2, new IntPtr(0), null, null);   //获得窗体的子句柄 
                //MessageBox.Show(taticFileNameHwnd3.ToString("X8"));

                IntPtr taticFileNameHwnd4 = FindWindowEx(taticFileNameHwnd3, new IntPtr(0), null, null);   //获得窗体的子句柄 
                //MessageBox.Show(taticFileNameHwnd4.ToString("X8"));

                if (taticFileNameHwnd4 != IntPtr.Zero)
                {
                    SendMessage(taticFileNameHwnd4, 0x000C, new IntPtr(0), "test.txt");     //发送写路径的消息 
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }

                //IntPtr txtFileTypeHwnd = FindWindowEx(openHwnd, IntPtr.Zero, "ComboBox", "");   //获得按钮的句柄  
                //MessageBox.Show(txtFileTypeHwnd.ToString("X8"));


                IntPtr btnOpenHwnd = FindWindowEx(openHwnd, IntPtr.Zero, "Button", "&Open");   //获得按钮的句柄   
                //MessageBox.Show(btnOpenHwnd.ToString("X8"));
                if (btnOpenHwnd != IntPtr.Zero)
                {
                    //SendMessage(btnHwnd, 0x0201, new IntPtr(0), null);     //发送点击按钮的消息 
                    SendMessage(btnOpenHwnd, 0xF5, new IntPtr(0), null);     //发送点击按钮的消息  
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }
            }
            #endregion
        }

        [DllImport("user32.dll")]
        public static extern int GetWindowText(int hWnd, StringBuilder lpString, int nMaxCount);

        private void btnGetMsg_Click(object sender, EventArgs e)
        {
            StringBuilder str = new StringBuilder(200);
            int len;

            IntPtr maindHwnd = FindWindow(null, "frmMsg"); //获得窗口句柄 

            if (maindHwnd != IntPtr.Zero)
            {
                IntPtr msgHwnd = FindWindowEx(maindHwnd, IntPtr.Zero, "Static", null);   //获得按钮的句柄   
                if (msgHwnd != IntPtr.Zero)
                {
                    len = msgHwnd.ToInt32();
                    GetWindowText(len, str, 200);

                    //MessageBox.Show(str.ToString());

                    using (FileStream fs = new FileStream(@"D:\msg.txt", FileMode.Create))
                    {
                        StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                        //开始写入
                        sw.WriteLine(str.ToString());
                        //清空缓冲区
                        sw.Flush();
                        //关闭流
                        sw.Close();
                        fs.Close();
                        System.Diagnostics.Process.Start(@"D:\msg.txt"); //打开此文件
                    }
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }
            }
            else
            {
                MessageBox.Show("没有找到窗口");
            }
        }

        private void btnTxtCompare_Click(object sender, EventArgs e)
        {
            bool bResult;
            txtCompare(@"D:\GitHub\test\PerfOut1 - Copy.txt", @"D:\GitHub\test\PerfOut1.txt", @"D:\GitHub\test\out.txt");
            //txtCompare2(@"D:\GitHub\test\read.txt", @"D:\GitHub\test\read2.txt", @"D:\GitHub\test\out.txt");
            //bResult = CompareFile(@"D:\GitHub\test\PerfOut1 - Copy.txt", @"D:\GitHub\test\PerfOut1.txt");
            //MessageBox.Show(bResult.ToString());
        }

        #region 方法一
        private void txtCompare(string filePath1, string filePath2, string fileOutpath)
        {
            //用Linq语法处理： 
            string[] txt1 = System.IO.File.ReadAllLines(filePath1, Encoding.Default);
            string[] txt2 = System.IO.File.ReadAllLines(filePath2, Encoding.Default); //读取文件，并返回数组 

            var items1 = from item in txt1 select item.Split(' ');
            var items2 = from item in txt2 select item.Split(' '); //对每行再以空格分隔为数组 

            var strList = from str in txt1  where str != "" && str != " " && str != "  " select str;
            var strList2 = from str in txt2 where str != "" && str != " " && str != "  " select str;

            var result = from item1 in strList
                         join item2 in strList2 on item1[2] equals item2[1]
                         select string.Format("{0} {1} {2}", item2[0], item2[1], item1[1]);

            //var result = from item2 in items2
            //             join item1 in items1 on item2[1] equals item1[2]
            //                 into onegroup
            //             from item in onegroup.DefaultIfEmpty(new string[3])
            //             select string.Format("{0} {1} {2}", item2[0], item2[1], item[1]);

            System.IO.File.WriteAllLines(fileOutpath, result, Encoding.Default);//写入文件 
            foreach (var item in result)
            {
                //Console.WriteLine(item);
            }

            //数组1中不包含数组2的数据
            //var v_temp = txt1.Except(txt2).ToArray();

            //var diff1 = txt1.Intersect(txt2);// 交集
            //var diff2 = txt1.Union(txt2);// 并集，返回两个序列的并集，去掉重复元素
            //var diff2 = txt1.Concat(txt2);// 并集，返回两个序列的并集
            //var diff3 = txt1.Except(txt2);// a有b没有的
            //var diff4 = txt2.Except(txt1);// b有a没有的

            //var max = txt1.Max();
            //var min = txt1.Min();
            //var avg = txt1.Average();
            //var dis = txt1.Distinct();

            //List<string> ListA = new List<string>();  
            //List<string> ListB = new List<string>();  
            //List<string> ListResult = new List<string>();  
  
            //ListResult = ListA.Distinct().ToList();//去重  
            //ListResult = ListA.Except(ListB).ToList();//差集  
            //ListResult= ListA.Union(ListB).ToList();  //并集  
            //ListResult = ListA.Intersect(ListB).ToList();//交集  

        }
        #endregion

        #region 方法二
        class myCompare : IEqualityComparer<string>
        {
            #region IEqualityComparer<string> 成员

            public bool Equals(string x, string y)
            {
                string[] splitStrs1 = x.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                string[] splitStrs2 = y.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                return string.CompareOrdinal(splitStrs1[splitStrs1.Length - 1], splitStrs2[splitStrs2.Length - 1]) == 0;
            }
            public int GetHashCode(string obj)
            {
                return 0;
            }
            #endregion
        }
        private void txtCompare2(string filePath1, string filePath2, string fileOutpath)
        {
            string[] values1 = File.ReadAllLines(filePath1);

            string[] values2 = File.ReadAllLines(filePath2);

            string[] values3 = values1.Intersect(values2, new myCompare()).ToArray();

            for (int i = 0; i < values3.Length; i++)
            {
                string[] splitStrs = values3[i].Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                string temp = splitStrs[splitStrs.Length - 2];

                splitStrs[splitStrs.Length - 2] = splitStrs[splitStrs.Length - 1];
                splitStrs[splitStrs.Length - 1] = temp;
                values3[i] = string.Join(" ", splitStrs);
            }
            File.WriteAllLines(fileOutpath, values3);
        }
        #endregion

        #region 利用哈希值比较两个文件是否相同

        //哈希算法将任意长度的二进制值映射为固定长度的较小二进制值，这个小的二进制值称为哈希值。
        //该算法为一个文件生成一个小的（通常约为20字节）二进制“指纹”（binary fingerprint）。
        //从统计学角度看，不同的文件不可能生成相同的哈希码。事实上，即使是一个很小的改动（比如，修改了源文件中的一个bit），
        //也会有50％的几率来改变哈希码中的每一个bit。因此，哈希码常常用于数据安全方面。要生成一个哈希码，你必须首先创建一个HashAlgorithm对象，
        //而这通常是调用HashAlgorithm.Create方法来完成的；然后调用HashAlgorithm.ComputeHash方法，它会返回一个存储哈希码的字节数组。

        public bool CompareFile()
        {
            string p_1 = @"E:\readme_1.txt";
            string p_2 = @"E:\readme_2.txt";

            //使用System.security.Cryptography.HashAlgorithm类为每个文件生成一个哈希码，然后比较两个哈希码是否一致
            var hash = System.Security.Cryptography.HashAlgorithm.Create();

            //计算第一个文件的哈希值
            var stream_1 = new System.IO.FileStream(p_1, System.IO.FileMode.Open);
            byte[] hashByte_1 = hash.ComputeHash(stream_1);
            stream_1.Close();

            //计算第二个文件的哈希值
            var stream_2 = new System.IO.FileStream(p_2, System.IO.FileMode.Open);
            byte[] hashByte_2 = hash.ComputeHash(stream_2);
            stream_2.Close();

            //比较两个哈希值
            if (BitConverter.ToString(hashByte_1) == BitConverter.ToString(hashByte_2))
            {
                MessageBox.Show("两个文件相等");
                return true;
            }
            else
            {
                MessageBox.Show("两个文件不等");
                return false;
            }
        }

        public bool CompareFile(string filePath1, string filePath2)
        {
            //创建一个哈希算法对象
            using (HashAlgorithm hash = HashAlgorithm.Create())
            {
                using (FileStream file1 = new FileStream(filePath1, FileMode.Open), file2 = new FileStream(filePath2, FileMode.Open))
                {
                    byte[] hashByte1 = hash.ComputeHash(file1);//哈希算法根据文本得到哈希码的字节数组
                    byte[] hashByte2 = hash.ComputeHash(file2);
                    string str1 = BitConverter.ToString(hashByte1);//将字节数组装换为字符串
                    string str2 = BitConverter.ToString(hashByte2);
                    return (str1 == str2);
                }
            }
        }
        #endregion 
    }
}
