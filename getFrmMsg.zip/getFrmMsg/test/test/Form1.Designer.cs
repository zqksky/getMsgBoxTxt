﻿namespace test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btnFrmTest = new System.Windows.Forms.Button();
            this.btnTestOpenFileDlg = new System.Windows.Forms.Button();
            this.btnMyOpenFileDlg = new System.Windows.Forms.Button();
            this.btnGetMsg = new System.Windows.Forms.Button();
            this.btnTxtCompare = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(152, 55);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 38);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnFrmTest
            // 
            this.btnFrmTest.Location = new System.Drawing.Point(152, 110);
            this.btnFrmTest.Name = "btnFrmTest";
            this.btnFrmTest.Size = new System.Drawing.Size(119, 38);
            this.btnFrmTest.TabIndex = 1;
            this.btnFrmTest.Text = "testFrmTest";
            this.btnFrmTest.UseVisualStyleBackColor = true;
            this.btnFrmTest.Click += new System.EventHandler(this.btnFrmTest_Click);
            // 
            // btnTestOpenFileDlg
            // 
            this.btnTestOpenFileDlg.Location = new System.Drawing.Point(152, 161);
            this.btnTestOpenFileDlg.Name = "btnTestOpenFileDlg";
            this.btnTestOpenFileDlg.Size = new System.Drawing.Size(119, 38);
            this.btnTestOpenFileDlg.TabIndex = 2;
            this.btnTestOpenFileDlg.Text = "testOpenFileDlg";
            this.btnTestOpenFileDlg.UseVisualStyleBackColor = true;
            this.btnTestOpenFileDlg.Click += new System.EventHandler(this.btnTestOpenFileDlg_Click);
            // 
            // btnMyOpenFileDlg
            // 
            this.btnMyOpenFileDlg.Location = new System.Drawing.Point(152, 219);
            this.btnMyOpenFileDlg.Name = "btnMyOpenFileDlg";
            this.btnMyOpenFileDlg.Size = new System.Drawing.Size(119, 38);
            this.btnMyOpenFileDlg.TabIndex = 3;
            this.btnMyOpenFileDlg.Text = "testMyOpenFileDlg";
            this.btnMyOpenFileDlg.UseVisualStyleBackColor = true;
            this.btnMyOpenFileDlg.Click += new System.EventHandler(this.btnMyOpenFileDlg_Click);
            // 
            // btnGetMsg
            // 
            this.btnGetMsg.Location = new System.Drawing.Point(301, 55);
            this.btnGetMsg.Name = "btnGetMsg";
            this.btnGetMsg.Size = new System.Drawing.Size(119, 38);
            this.btnGetMsg.TabIndex = 4;
            this.btnGetMsg.Text = "testMsgBox";
            this.btnGetMsg.UseVisualStyleBackColor = true;
            this.btnGetMsg.Click += new System.EventHandler(this.btnGetMsg_Click);
            // 
            // btnTxtCompare
            // 
            this.btnTxtCompare.Location = new System.Drawing.Point(301, 110);
            this.btnTxtCompare.Name = "btnTxtCompare";
            this.btnTxtCompare.Size = new System.Drawing.Size(119, 38);
            this.btnTxtCompare.TabIndex = 5;
            this.btnTxtCompare.Text = "txtCompare";
            this.btnTxtCompare.UseVisualStyleBackColor = true;
            this.btnTxtCompare.Click += new System.EventHandler(this.btnTxtCompare_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(596, 315);
            this.Controls.Add(this.btnTxtCompare);
            this.Controls.Add(this.btnGetMsg);
            this.Controls.Add(this.btnMyOpenFileDlg);
            this.Controls.Add(this.btnTestOpenFileDlg);
            this.Controls.Add(this.btnFrmTest);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnFrmTest;
        private System.Windows.Forms.Button btnTestOpenFileDlg;
        private System.Windows.Forms.Button btnMyOpenFileDlg;
        private System.Windows.Forms.Button btnGetMsg;
        private System.Windows.Forms.Button btnTxtCompare;
    }
}

