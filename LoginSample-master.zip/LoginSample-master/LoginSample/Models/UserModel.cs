﻿
namespace LoginSample.Models
{
    public class UserModel
    {
        public uint UserId { get; set; }

        public string UserName { get; set; }

        public string UserPwd { get; set; }
    }
}
