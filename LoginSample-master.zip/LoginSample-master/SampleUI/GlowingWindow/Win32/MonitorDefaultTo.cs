﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GlowingWindow.Win32
{
	public enum MonitorDefaultTo
	{
		// ReSharper disable InconsistentNaming
		MONITOR_DEFAULTTONULL = 0,
		MONITOR_DEFAULTTOPRIMARY = 1,
		MONITOR_DEFAULTTONEAREST = 2,
		// ReSharper restore InconsistentNaming
	}
}
