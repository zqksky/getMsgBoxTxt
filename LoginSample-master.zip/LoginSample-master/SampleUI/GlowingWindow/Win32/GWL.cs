﻿
namespace GlowingWindow.Win32
{
	// ReSharper disable InconsistentNaming
	public enum GWL
	{
		STYLE = -16,
		EXSTYLE = -20,
	}
	// ReSharper restore InconsistentNaming
}
