﻿using System;

namespace GlowingWindow.Models
{
	public enum ChromeMode
	{
		VisualStudio2013,
		Office2013,
	}
}
