## WPF MVVM Login Sample ##

![](http://i.imgur.com/TVDnDLk.jpg)

## Window Style

Special Thanks

[https://github.com/Grabacr07/MetroRadiance](https://github.com/Grabacr07/MetroRadiance)


## WPF MVVM
[https://github.com/WELL-E/MVVMSample](https://github.com/WELL-E/MVVMSample "WPF MVVM Sample")