﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;

namespace getMsgBoxTxt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [DllImport("user32.dll")]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("User32.dll", EntryPoint = "SendMessage")]
        private static extern int SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, string lParam);

        [DllImport("User32.dll ")]
        public static extern IntPtr FindWindowEx(IntPtr parent, IntPtr childe, string strclass, string FrmText);

        [DllImport("user32.dll")]
        public static extern int GetWindowText(int hWnd, StringBuilder lpString, int nMaxCount);

        private void btnRun_Click(object sender, EventArgs e)
        {
            string strTemp;
            StringBuilder strBuilder = new StringBuilder(200);
            int len;

            IntPtr maindHwnd = FindWindow(null, txtTitle.Text.ToString()); //获得窗口句柄 

            if (maindHwnd != IntPtr.Zero)
            {
                IntPtr msgHwnd = FindWindowEx(maindHwnd, IntPtr.Zero, "Static", null);   //获得按钮的句柄   
                if (msgHwnd != IntPtr.Zero)
                {
                    len = msgHwnd.ToInt32();
                    GetWindowText(len, strBuilder, 200);

                    //MessageBox.Show(strBuilder.ToString());

                    //复制字符串到剪贴板
                    if (strBuilder.ToString() != "")
                    {
                        Clipboard.SetDataObject(strBuilder.ToString());
                        //Clipboard.SetText(strBuilder.ToString()); 
                    }

                    //粘贴
                    //IDataObject iData = Clipboard.GetDataObject();

                    //if (iData.GetDataPresent(DataFormats.Text))
                    //{
                    //    strTemp = (String)iData.GetData(DataFormats.Text);
                    //    MessageBox.Show(strTemp);
                    //}

                    using (FileStream fs = new FileStream(@"D:\msg.txt", FileMode.Create))
                    {
                        StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                        //开始写入
                        sw.WriteLine(strBuilder.ToString());
                        //清空缓冲区
                        sw.Flush();
                        //关闭流
                        sw.Close();
                        fs.Close();
                        System.Diagnostics.Process.Start(@"D:\msg.txt"); //打开此文件
                    }
                }
                else
                {
                    MessageBox.Show("没有找到子窗口");
                }
            }
            else
            {
                MessageBox.Show("没有找到窗口");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public String SwapClipboardHtmlText(String replacementHtmlText)
        {
            String returnHtmlText = null;
            if (Clipboard.ContainsText(TextDataFormat.Html))
            {
                returnHtmlText = Clipboard.GetText(TextDataFormat.Html);
                Clipboard.SetText(replacementHtmlText, TextDataFormat.Html);
            }
            return returnHtmlText;
        }
    }
}
