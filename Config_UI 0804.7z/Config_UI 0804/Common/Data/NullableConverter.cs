﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class NullableConverter
    {
        #region Define Datetime format for converting datetime

        #endregion

        #region definition for private members & properties

        // delegate
        delegate Nullable<int> convertToInt(object source);
        delegate Nullable<long> convertToLong(object source);
        delegate Nullable<double> convertToDouble(object source);
        delegate Nullable<bool> convertToBool(object source);
        delegate Nullable<DateTime> convertToDateTime(object source, string format);

        // default converter
        delegate string convertToString(object source);

        // for containing Mapping
        protected static Dictionary<Type, Delegate> mapper = new Dictionary<Type, Delegate>();

        #endregion

        #region Constructor : registering delegate method
        /// <summary>
        /// Default Constructor
        /// </summary>
        public NullableConverter()
        {
            // don't initialize more than once.
            if (mapper.Count <= 0)
            {
                //Register converting method
                convertToInt delInt = TryConvertToInt;
                mapper.Add(typeof(Nullable<int>), delInt);
                mapper.Add(typeof(int), delInt);

                convertToLong delLong = TryConvertToLong;
                mapper.Add(typeof(Nullable<long>), delLong);
                mapper.Add(typeof(long), delLong);

                convertToDouble delDouble = TryConvertToDouble;
                mapper.Add(typeof(Nullable<double>), delDouble);
                mapper.Add(typeof(double), delDouble);

                convertToDateTime delDateTime = TryConvertToDateTime;
                mapper.Add(typeof(Nullable<DateTime>), delDateTime);
                mapper.Add(typeof(DateTime), delDateTime);

                convertToBool delBool = TryConvertToBool;
                mapper.Add(typeof(Nullable<bool>), delBool);
                mapper.Add(typeof(bool), delBool);

                // Add default converter for string.
                convertToString delString = TryConvertToString;
                mapper.Add(typeof(string), delString);
            }
        }
        #endregion

        #region Definition for indexer
        // Indexer to get convert method
        /// <summary>
        /// indexer to find ot correspoing converting delegate
        /// </summary>
        /// <param name="type">source type</param>
        /// <returns>Delegated method which provide convert.</returns>
        public Delegate this[Type type]
        {
            get
            {
                Delegate returnVal = null;
                if (mapper.ContainsKey(type))
                {
                    returnVal = mapper[type];
                }
                else
                {
                    // by default, use stringConverter.
                    returnVal = mapper[typeof(string)];
                }
                return returnVal;
            }
        }
        #endregion

        #region Definition for Convert

        /// <summary>
        /// Supports conversion of object.ToString() to Nullable bool, int, long, double, string, DateTime.
        /// </summary>
        /// <typeparam name="T"> bool, int, long, double, string or DateTime</typeparam>
        /// <param name="source">object to be converted.</param>
        /// <returns>Convert result of a Nullable generic type for specified value type.</returns>
        public Nullable<T> Convert<T>(object source) where T : struct
        {
            return this.Convert<T>(source, null);
        }


        /// <summary>
        /// Supports conversion of object.ToString() to Nullable bool, int, long, double, string, DateTime.
        /// </summary>
        /// <typeparam name="T"> bool, int, long, double, string or DateTime</typeparam>
        /// <param name="source">object to be converted.</param>
        /// <param name="format">format specifically for DateTime format</param>
        /// <returns>Convert result of a Nullable generic type for specified value type.</returns>
        public Nullable<T> Convert<T>(object source, string format) where T : struct
        {
            // find delegate
            Delegate converter = null;

            var type = typeof(T);

            converter = this[type];
            Debug.Assert(converter != null);

            if (String.IsNullOrEmpty(format))
            {
                // for debugging
                //Debug.Print("No format string is passed.");
                return converter.DynamicInvoke(source) as Nullable<T>;
            }
            else
            {
                //Debug.Print("Format string {" + format + "} is passed.");
                return converter.DynamicInvoke(new object[] { source, format }) as Nullable<T>;
            }
        }

        #endregion

        #region Define Convert Methods

        /// <summary>
        /// DefaultConverter
        /// </summary>
        /// <returns>Converted value from source.</returns>
        protected virtual string TryConvertToString(object source)
        {
            if (source == null) return null;

            return source.ToString();
        }

        /// <summary>
        /// Converts passed object to Nullable
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        protected virtual Nullable<long> TryConvertToLong(object source)
        {
            if (source == null) return null;

            Nullable<long> result = null;

            try
            {
                long longValue = 0;
                if (long.TryParse(source.ToString(), out longValue))
                {
                    result = longValue;
                }
            }
            catch (ArgumentException ex)
            {
                Debug.Assert(false, ex.Message);
            }

            return result;
        }

        /// <summary>
        /// Converted passed object to Nullable&lt;int&gt;
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        protected virtual Nullable<int> TryConvertToInt(object source)
        {
            if (source == null) return null;

            Nullable<int> result = null;

            try
            {
                int intValue = 0;
                if (int.TryParse(source.ToString(), out intValue))
                {
                    result = intValue;
                }
            }
            catch (ArgumentException ex)
            {
                Debug.Assert(false, ex.Message);
            }

            return result;
        }


        /// <summary>
        /// Converted passed object to Nullable&lt;double&gt;
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        protected virtual Nullable<double> TryConvertToDouble(object source)
        {
            if (source == null) return null;

            Nullable<double> result = null;

            try
            {
                double doubleValue = 0;
                if (double.TryParse(source.ToString(), out doubleValue))
                {
                    result = doubleValue;
                }
            }
            catch (ArgumentException ex)
            {
                Debug.Assert(false, ex.Message);
            }

            return result;
        }


        /// <summary>
        /// Converted passed object to Nullable&lt;bool&gt; 
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        protected virtual Nullable<bool> TryConvertToBool(object source)
        {
            if (source == null) return null;

            Nullable<bool> result = null;

            // currently TryParse function does not allow "T", "F" value for converting target.
            // only String.falseValue, String.trueValue are accepted of target of converting.
            List<string> lowercasedFalseString = new List<string>();
            lowercasedFalseString.Add("f");
            lowercasedFalseString.Add("n");
            lowercasedFalseString.Add("no");

            List<string> lowercasedTrueString = new List<string>();
            lowercasedTrueString.Add("t");
            lowercasedTrueString.Add("y");
            lowercasedTrueString.Add("yes");

            if (lowercasedFalseString.Contains(source.ToString().ToLower()))
            {
                return false;
            }

            if (lowercasedTrueString.Contains(source.ToString().ToLower()))
            {
                return true;
            }

            try
            {
                bool boolValue = false;
                if (bool.TryParse(source.ToString(), out boolValue))
                {
                    result = boolValue;
                }
            }
            catch (ArgumentException ex)
            {
                Debug.Assert(false, ex.Message);
            }

            return result;
        }

        /// <summary>
        /// Converted passed object to Nullable&lt;DateTime&gt; 
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <param name="propertyFormat">Format string for passed source.</param> 
        /// <returns>Converted value from source.</returns>
        protected virtual Nullable<DateTime> TryConvertToDateTime(object source, string propertyFormat)
        {
            if (source == null) return null;

            Nullable<DateTime> result = null;
            try
            {
                // by deafult set current time
                DateTime dateTimeValue;

                if (DateTime.TryParseExact(source.ToString(), propertyFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTimeValue))
                {
                    result = dateTimeValue;
                }
            }
            catch (ArgumentException ex)
            {
                Debug.Assert(false, ex.Message);
            }

            return result;
        }
        #endregion
    }
}
