﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class OVLContextRow
    {
        public string Chuck { get; set; }
        public string ToolId { get; set; }
        public string ProductId { get; set; }
        public string LayerId { get; set; }
        public string ReticleId { get; set; }
        public string RecipeId { get; set; }
        public string PreTool { get; set; }
        public string PreReticle { get; set; }
        public string Mode { get; set; }
        public string CtlFlag { get; set; }
        public List<ParameterEntity> Parameters { get; set; }
        public string LastEstiTime { get; set; }
    }
}