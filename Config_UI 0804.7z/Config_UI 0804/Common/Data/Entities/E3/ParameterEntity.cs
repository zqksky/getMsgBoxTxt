﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class ParameterEntity
    {
        public string ParameterName { get; set; }
        public string ParameterVaue { get; set; }
    }
}
