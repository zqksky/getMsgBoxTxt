﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class ToolEntity
    {
        public string ToolId { get; set; }
        public string ToolType { get; set; }
        public string Vendor { get; set; }
        public string Mode { get; set; }
    }
}
