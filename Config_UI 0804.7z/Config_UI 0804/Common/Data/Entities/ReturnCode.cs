﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class ReturnCode
    {
        public static int LOGINOK = 0;
        public static int LOGINFAULT = -1;
    }
}
