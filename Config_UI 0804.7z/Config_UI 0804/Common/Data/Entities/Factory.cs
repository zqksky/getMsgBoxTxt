﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class Factory : EntityBase
    {
        public const string TableName = "FACTORY";

        public const string COL_FACTORY_NAME = "FACTORY_NAME";
        [ColumnMapping(COL_FACTORY_NAME)]
        public string Name { get; set; }

        public const string COL_FACTORY_DESC = "FACTORY_DESC";
        [ColumnMapping(COL_FACTORY_DESC)]
        public string Description { get; set; }
    }
}
