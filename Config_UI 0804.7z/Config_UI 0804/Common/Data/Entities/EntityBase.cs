﻿using System;

namespace R2R.Common.Data
{
    public class EntityBase
    {
        public const string COL_IS_ENABLED = "IS_ENABLED";
        [ColumnMapping(COL_IS_ENABLED)]
        public bool IsEnabled { get; set; }

        public const string COL_MODIFIED_DT = "MODIFIED_DT";
        [ColumnMapping(COL_MODIFIED_DT)]
        public DateTime ModifiedDate { get; set; }

        public const string COL_MODIFIED_BY = "MODIFIED_BY";
        [ColumnMapping(COL_MODIFIED_BY)]
        public string ModifiedBy { get; set; }
    }
}