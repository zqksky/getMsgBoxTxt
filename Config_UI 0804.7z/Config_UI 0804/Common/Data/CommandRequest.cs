﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace R2R.Common.Data
{
    public class CommandRequest : MessageRequest
    {
        public Type Interface { get; set; }
        public string MethodName { get; set; }
        public List<object> InputParams { get; set; }
        public bool HasReturn { get; set; }

        public List<Type> ParamTypes { get; set; }

        public CommandRequest()
        {
            InputParams = new List<object>();
            ParamTypes = new List<Type>();
        }

        public override string ToString()
        {
            if(MethodName != null)
            {
                return MethodName;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
