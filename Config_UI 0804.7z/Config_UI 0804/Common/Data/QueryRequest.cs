﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class QueryRequest : MessageRequest
    {
        public QueryRequest()
        {
            Parameters = new List<QueryParameter>();
        }
        public string QueryName { get; set; }
        public PagingSettings Paging { get; set; }
        public OrderSettings Ordering { get; set; }
        public List<QueryParameter> Parameters { get; set; }

        public bool ReturnSingleValue { get; set; }

        public void AddParameter(string name, object value)
        {
            if(value is string && string.Equals(value, ""))
            {
                value = null;
            }
            Parameters.Add(new QueryParameter(name, value));
        }

        public override string ToString()
        {
            if (QueryName != null)
            {
                return QueryName;
            }
            else
            {
                return string.Empty;
            }
        }
    }

    public class PagingSettings
    {
        public uint StartRowNo { get; set; }
        public uint PageSize { get; set; }
    }
    public class OrderSettings
    {
        public string OrderBy { get; set; }
        public OrderDirection Order { get; set; }
    }

    public enum OrderDirection
    {
        ASC,
        DESC
    }
}
