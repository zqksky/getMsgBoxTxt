﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public abstract class MessageRequest
    {
        public string TxnID { get; set; }
        public string ClientID { get; set; }
        public int ClientProcessID { get; set; }
        public int ClientThreadID { get; set; }
        public string UserID { get; set; }
        public DateTime TxnTime { get; set; }
    }
}
