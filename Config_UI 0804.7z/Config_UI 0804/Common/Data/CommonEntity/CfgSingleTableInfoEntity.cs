﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgSingleTableInfoEntity
    {
        public string[] ColumnData;
        public string[] ColumnFormat;
        public string TableName;
        public bool bAllowView;
        public bool bAllowWrite;
        public string AllowWriteColumn_CSV;
    }
}
