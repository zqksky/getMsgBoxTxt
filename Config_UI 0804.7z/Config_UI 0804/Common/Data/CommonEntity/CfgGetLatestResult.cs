﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgGetLatestResult
    {
        string requestId;
        public string RequestId
        {
            get { return requestId; }
            set { requestId = value; }
        }

        string returnCode;
        public string ReturnCode
        {
            get { return returnCode; }
            set { returnCode = value; }
        }

        string returnText;
        public string ReturnText
        {
            get { return returnText; }
            set { returnText = value; }
        }

        string _Latest_Version_Common;
        public string Latest_Version_Common
        {
            get { return _Latest_Version_Common; }
            set { _Latest_Version_Common = value; }
        }

        string _Latest_Version_LIS;
        public string Latest_Version_LIS
        {
            get { return _Latest_Version_LIS; }
            set { _Latest_Version_LIS = value; }
        }

        string _Latest_Version_CD_Init;
        public string Latest_Version_CD_Init
        {
            get { return _Latest_Version_CD_Init; }
            set { _Latest_Version_CD_Init = value; }
        }

        string _Latest_Version_OVL_PC_Init;
        public string Latest_Version_OVL_PC_Init
        {
            get { return _Latest_Version_OVL_PC_Init; }
            set { _Latest_Version_OVL_PC_Init = value; }
        }

        string _Latest_Version_OVL_CPE_Init;
        public string Latest_Version_OVL_CPE_Init
        {
            get { return _Latest_Version_OVL_CPE_Init; }
            set { _Latest_Version_OVL_CPE_Init = value; }
        }

        public CfgGetLatestResult()
        {
            requestId = "";
            returnCode = "0";
            returnText = "";
            _Latest_Version_Common = "";
            _Latest_Version_LIS = "";
            _Latest_Version_CD_Init = "";
            _Latest_Version_OVL_PC_Init = "";
            _Latest_Version_OVL_CPE_Init = "";
        }
    }
}
