﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgGetInitOvlPCResult
    {
        string requestId;
        public string RequestId
        {
            get { return requestId; }
            set { requestId = value; }
        }

        string returnCode;
        public string ReturnCode
        {
            get { return returnCode; }
            set { returnCode = value; }
        }

        string returnText;
        public string ReturnText
        {
            get { return returnText; }
            set { returnText = value; }
        }

        string _Content_R2R_PH_CONFIG_INIT_OVL_PC;
        public string Content_R2R_PH_CONFIG_INIT_OVL_PC
        {
            get { return _Content_R2R_PH_CONFIG_INIT_OVL_PC; }
            set { _Content_R2R_PH_CONFIG_INIT_OVL_PC = value; }
        }

        string _Content_R2R_PH_CONFIG_INIT_OVL_PC_Original;
        public string Content_R2R_PH_CONFIG_INIT_OVL_PC_Original
        {
            get { return _Content_R2R_PH_CONFIG_INIT_OVL_PC_Original; }
            set { _Content_R2R_PH_CONFIG_INIT_OVL_PC_Original = value; }
        }


        List<string> _ToolList;
        public List<string> ToolList
        {
            get { return _ToolList; }
            set { _ToolList = value; }
        }

        public CfgGetInitOvlPCResult()
        {
            requestId = "";
            returnCode = "0";
            returnText = "";
            _Content_R2R_PH_CONFIG_INIT_OVL_PC = "";
            _Content_R2R_PH_CONFIG_INIT_OVL_PC_Original = "";
            _ToolList = new List<string>();
        }
    }
}
