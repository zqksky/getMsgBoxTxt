﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgAccessControlResult
    {
        string requestId;
        public string RequestId
        {
            get { return requestId; }
            set { requestId = value; }
        }

        string returnCode;
        public string ReturnCode
        {
            get { return returnCode; }
            set { returnCode = value; }
        }

        string returnText;
        public string ReturnText
        {
            get { return returnText; }
            set { returnText = value; }
        }

        string initMode;
        public string InitMode
        {
            get { return initMode; }
            set { initMode = value; }
        }

        bool isDataTooOld;
        public bool IsDataTooOld
        {
            get { return isDataTooOld; }
            set { isDataTooOld = value; }
        }

        bool isOccupiedByOther;
        public bool IsOccupiedByOther
        {
            get { return isOccupiedByOther; }
            set { isOccupiedByOther = value; }
        }

        public CfgAccessControlResult()
        {
            requestId = "";
            returnCode = "0";
            returnText = "";
            initMode = "";
            isDataTooOld = false;
            isOccupiedByOther = false;
        }
    }
}
