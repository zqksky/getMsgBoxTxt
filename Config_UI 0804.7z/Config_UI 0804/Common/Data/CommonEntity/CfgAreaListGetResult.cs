﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgAreaListGetResult
    {
        string requestId;
        public string RequestId
        {
            get { return requestId; }
            set { requestId = value; }
        }

        string returnCode;
        public string ReturnCode
        {
            get { return returnCode; }
            set { returnCode = value; }
        }

        string returnText;
        public string ReturnText
        {
            get { return returnText; }
            set { returnText = value; }
        }

        string _Area_Content;
        public string Area_Content
        {
            get { return _Area_Content; }
            set { _Area_Content = value; }
        }

        public CfgAreaListGetResult()
        {
            requestId = "";
            returnCode = "0";
            returnText = "";
            _Area_Content = "";
        }
    }
}
