﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgGetVersionListResult
    {
        string requestId;
        public string RequestId
        {
            get { return requestId; }
            set { requestId = value; }
        }

        string returnCode;
        public string ReturnCode
        {
            get { return returnCode; }
            set { returnCode = value; }
        }

        string returnText;
        public string ReturnText
        {
            get { return returnText; }
            set { returnText = value; }
        }

        string _Latest_Version;
        public string Latest_Version
        {
            get { return _Latest_Version; }
            set { _Latest_Version = value; }
        }

        public CfgGetVersionListResult()
        {
            requestId = "";
            returnCode = "0";
            returnText = "";
            _Latest_Version = "";
        }

    }
}
