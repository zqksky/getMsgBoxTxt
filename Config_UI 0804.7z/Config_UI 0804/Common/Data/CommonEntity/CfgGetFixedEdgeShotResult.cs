﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgGetFixedEdgeShotResult
    {
        string requestId;
        public string RequestId
        {
            get { return requestId; }
            set { requestId = value; }
        }

        string returnCode;
        public string ReturnCode
        {
            get { return returnCode; }
            set { returnCode = value; }
        }

        string returnText;
        public string ReturnText
        {
            get { return returnText; }
            set { returnText = value; }
        }

        string _Fixed_Edge_Shot_Content;
        public string Fixed_Edge_Shot_Content
        {
            get { return _Fixed_Edge_Shot_Content; }
            set { _Fixed_Edge_Shot_Content = value; }
        }

        public CfgGetFixedEdgeShotResult()
        {
            requestId = "";
            returnCode = "-1";
            returnText = "";
            _Fixed_Edge_Shot_Content = "";
        }
    }
}
