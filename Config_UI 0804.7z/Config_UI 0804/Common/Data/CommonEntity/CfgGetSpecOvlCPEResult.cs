﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgGetSpecOvlCPEResult
    {
        string requestId;
        public string RequestId
        {
            get { return requestId; }
            set { requestId = value; }
        }

        string returnCode;
        public string ReturnCode
        {
            get { return returnCode; }
            set { returnCode = value; }
        }

        string returnText;
        public string ReturnText
        {
            get { return returnText; }
            set { returnText = value; }
        }

        List<string> _OVL_CPE_SPEC_VARNAME;
        public List<string> OVL_CPE_SPEC_VARNAME
        {
            get { return _OVL_CPE_SPEC_VARNAME; }
            set { _OVL_CPE_SPEC_VARNAME = value; }
        }


        List<double> _OVL_CPE_SPEC_MAX_DELTA;
        public List<double> OVL_CPE_SPEC_MAX_DELTA
        {
            get { return _OVL_CPE_SPEC_MAX_DELTA; }
            set { _OVL_CPE_SPEC_MAX_DELTA = value; }
        }

        List<double> _OVL_CPE_USL_CALC;
        public List<double> OVL_CPE_USL_CALC
        {
            get { return _OVL_CPE_USL_CALC; }
            set { _OVL_CPE_USL_CALC = value; }
        }

        List<double> _OVL_CPE_LSL_CALC;
        public List<double> OVL_CPE_LSL_CALC
        {
            get { return _OVL_CPE_LSL_CALC; }
            set { _OVL_CPE_LSL_CALC = value; }
        }

        public CfgGetSpecOvlCPEResult()
        {
            requestId = "";
            returnCode = "0";
            returnText = "";
            _OVL_CPE_SPEC_VARNAME = new List<string>();
            _OVL_CPE_SPEC_MAX_DELTA = new List<double>();
            _OVL_CPE_USL_CALC = new List<double>();
            _OVL_CPE_LSL_CALC = new List<double>();
        }
    }
}
