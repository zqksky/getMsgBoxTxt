﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgGetContextValuesResult
    {
        string _RequestId;
        public string RequestId
        {
            get { return _RequestId; }
            set { _RequestId = value; }
        }

        string _ReturnCode;
        public string ReturnCode
        {
            get { return _ReturnCode; }
            set { _ReturnCode = value; }
        }

        string _ReturnText;
        public string ReturnText
        {
            get { return _ReturnText; }
            set { _ReturnText = value; }
        }

        private List<string> _ProductList;
        public List<string> ProductList
        {
            get { return _ProductList; }
            set { _ProductList = value; }
        }

        private List<string> _LayerList;
        public List<string> LayerList
        {
            get { return _LayerList; }
            set { _LayerList = value; }
        }

        private List<string> _ToolGroupList;
        public List<string> ToolGroupList
        {
            get { return _ToolGroupList; }
            set { _ToolGroupList = value; }
        }

        private List<string> _ToolVendorList;
        public List<string> ToolVendorList
        {
            get { return _ToolVendorList; }
            set { _ToolVendorList = value; }
        }

        public CfgGetContextValuesResult()
        {
            _RequestId = "";
            _ReturnCode = "0";
            _ReturnText = "";
            _ProductList = new List<string>();
            _LayerList = new List<string>();
            _ToolGroupList = new List<string>();
            _ToolVendorList = new List<string>();
        }
    }
}
