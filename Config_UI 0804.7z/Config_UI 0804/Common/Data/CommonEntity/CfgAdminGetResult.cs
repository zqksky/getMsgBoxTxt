﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgAdminGetResult
    {
        /// <summary>
        /// 
        /// </summary>
        public List<string> UserID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<string> UserGroup { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<string> Product { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<string> ProductGroup { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<string> UI_Config { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<string> PriorityLevel { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool IsOutputNull { get; set; }
    }
}
