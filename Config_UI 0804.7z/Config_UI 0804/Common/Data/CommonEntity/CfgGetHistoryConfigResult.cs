﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgGetHistoryConfigResult
    {
        string requestId;
        public string RequestId
        {
            get { return requestId; }
            set { requestId = value; }
        }

        string returnCode;
        public string ReturnCode
        {
            get { return returnCode; }
            set { returnCode = value; }
        }

        string returnText;
        public string ReturnText
        {
            get { return returnText; }
            set { returnText = value; }
        }

        string _Version_A_Common_History;
        public string Version_A_Common_History
        {
            get { return _Version_A_Common_History; }
            set { _Version_A_Common_History = value; }
        }

        string _Version_A_LIS_History;
        public string Version_A_LIS_History
        {
            get { return _Version_A_LIS_History; }
            set { _Version_A_LIS_History = value; }
        }

        string _Version_A_CD_Init_History;
        public string Version_A_CD_Init_History
        {
            get { return _Version_A_CD_Init_History; }
            set { _Version_A_CD_Init_History = value; }
        }

        string _Version_A_OVL_CPE_Init_History;
        public string Version_A_OVL_CPE_Init_History
        {
            get { return _Version_A_OVL_CPE_Init_History; }
            set { _Version_A_OVL_CPE_Init_History = value; }
        }

        string _Version_A_OVL_PC_Init_History;
        public string Version_A_OVL_PC_Init_History
        {
            get { return _Version_A_OVL_PC_Init_History; }
            set { _Version_A_OVL_PC_Init_History = value; }
        }

        string _Version_B_Common_History;
        public string Version_B_Common_History
        {
            get { return _Version_B_Common_History; }
            set { _Version_B_Common_History = value; }
        }

        string _Version_B_LIS_History;
        public string Version_B_LIS_History
        {
            get { return _Version_B_LIS_History; }
            set { _Version_B_LIS_History = value; }
        }

        string _Version_B_CD_Init_History;
        public string Version_B_CD_Init_History
        {
            get { return _Version_B_CD_Init_History; }
            set { _Version_B_CD_Init_History = value; }
        }

        string _Version_B_OVL_CPE_Init_History;
        public string Version_B_OVL_CPE_Init_History
        {
            get { return _Version_B_OVL_CPE_Init_History; }
            set { _Version_B_OVL_CPE_Init_History = value; }
        }

        string _Version_B_OVL_PC_Init_History;
        public string Version_B_OVL_PC_Init_History
        {
            get { return _Version_B_OVL_PC_Init_History; }
            set { _Version_B_OVL_PC_Init_History = value; }
        }

        public CfgGetHistoryConfigResult()
        {
            requestId = "";
            returnCode = "0";
            returnText = "";
            _Version_A_Common_History = "";
            _Version_A_LIS_History = "";
            _Version_A_CD_Init_History = "";
            _Version_A_OVL_CPE_Init_History = "";
            _Version_A_OVL_PC_Init_History = "";
            _Version_B_Common_History = "";
            _Version_B_LIS_History = "";
            _Version_B_CD_Init_History = "";
            _Version_B_OVL_CPE_Init_History = "";
            _Version_B_OVL_PC_Init_History = "";
        }
    }
}
