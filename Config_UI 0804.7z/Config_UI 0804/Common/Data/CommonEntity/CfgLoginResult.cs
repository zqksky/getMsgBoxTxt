﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgLoginResult
    {
        string requestId;
        public string RequestId
        {
            get { return requestId; }
            set { requestId = value; }
        }

        string returnCode;
        public string ReturnCode
        {
            get { return returnCode; }
            set { returnCode = value; }
        }

        string returnText;
        public string ReturnText
        {
            get { return returnText; }
            set { returnText = value; }
        }

        bool isAdminConfig;
        public bool IsAdminConfig
        {
            get { return isAdminConfig; }
            set { isAdminConfig = value; }
        }

        public CfgLoginResult()
        {
            requestId = "";
            returnCode = "0";
            returnText = "";
            isAdminConfig = false;
        }
    }
}
