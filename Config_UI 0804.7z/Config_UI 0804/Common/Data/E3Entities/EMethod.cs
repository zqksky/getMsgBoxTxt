﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    /// <summary>
    /// 方法枚举
    /// </summary>
    public enum EMethod
    {
        R2R_UI_Config_Login,
        R2R_UI_Config_AreaListGet,
        R2R_UI_Config_AdminConfigGet,
        R2R_UI_Config_UserGroupSave,
        R2R_UI_Config_ProductGroupSave,
        R2R_UI_Config_PriorityLevelSave,
        R2R_UI_Config_AccessControlCheck,
        R2R_UI_Config_Get,
        R2R_UI_Config_GetVersionList,
        R2R_UI_Config_GetLatestConfig,
        R2R_UI_Config_GetHistoryConfig,
        R2R_UI_Config_Get_TableList,
        R2R_UI_Config_PH_CopyProduct,
        R2R_UI_Config_Update,
        R2R_UI_Config_PH_Get_CONFIG_COMMON,
        R2R_UI_Config_PH_Get_CONFIG_INIT_CD,
        R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_CPE,
        R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_PC,
        R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_CPE,
        R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_PC,
        R2R_UI_Config_PH_Get_ContextValues,
        R2R_UI_Config_PH_Migration,
        R2R_UI_Config_PH_Update_CONFIG,
        R2R_UI_GetModules,
        R2R_UI_Config_EditStatusCheck,
        R2R_UI_Config_ClearEditOccupy,
        R2R_UI_Config_ClearAdminOccupy,
        R2R_UI_Config_UpdateValidation,

        R2R_UI_Config_GetFixedEdgeShot,
        R2R_UI_Config_FixedEdgeShotSave
    }
}