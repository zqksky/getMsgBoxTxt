﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public enum EProperty
    {
        // Login Property
        UserName,
        DomainName,
        Password,
        AppType,
        AutoLogin,

        //Config
        ClientMachine,
        RequestId,
        Layer,
        Module,
        Product,
        ToolGroup,
        TOOL_VENDOR,
        OVL_CPE_R2R_MODE,
        OVL_CPE_OVL_MODE,
        CONTROL_BY_CHUCK,
        OVL_PC_OVL_MODE,
        OVL_PC_CPE_MODE,
        Recipe,
        ClienetVersion,
        TableName,
        QueryContexts,
        GetTableStructureOnly,
        Reticle,
        Content_Add,
        Content_Modify,
        Content_Delete,
        Content,
        Enter_first_element_here,

        //Access Control
        TableIndex,
        UserID,
        UserGroup,
        ProductGroup,
        UI_Config,
        Priority_Level,
        Opt_Action,
        Query_Time,
        PriorityLevel,

        UserID_Add,
        UserID_Delete,
        Product_Add,
        Product_Modify,
        Product_Delete,
        UserGroup_Add,
        ProductGroup_Add,
        UI_Config_Add,
        PriorityLevel_Add,
        UserGroup_Modify,
        ProductGroup_Modify,
        UI_Config_Modify,
        PriorityLevel_Modify,
        UserGroup_Delete,
        ProductGroup_Delete,
        UI_Config_Delete,
        PriorityLevel_Delete,

        //Version Control
        Tool_Group,
        Version_Number_A,
        Version_Number_B,
        CatchFlag,
        CatchReason,

        // Litho Property
        FromProduct,
        ToProduct,
        FromLayer,
        ToLayer,
        IsCheckOnly,
        QueryTime,
        Action,
        CurrentMode,

        ClientVersion,
        ProductId,
        LayerId,
        ToolId,
        ToolType,

        Content_R2R_PH_CONFIG_COMMON_Delete,
        Content_R2R_PH_CONFIG_COMMON_Add,
        Content_R2R_PH_CONFIG_COMMON_Modify,
        Content_R2R_PH_CONFIG_LIS_Delete,
        Content_R2R_PH_CONFIG_LIS_Add,
        Content_R2R_PH_CONFIG_LIS_Modify,
        Content_R2R_PH_CONFIG_INIT_CD_Delete,
        Content_R2R_PH_CONFIG_INIT_CD_Add,
        Content_R2R_PH_CONFIG_INIT_CD_Modify,
        Content_R2R_PH_CONFIG_INIT_OVL_PC_Delete,
        Content_R2R_PH_CONFIG_INIT_OVL_PC_Add,
        Content_R2R_PH_CONFIG_INIT_OVL_PC_Modify,
        Content_R2R_PH_CONFIG_INIT_OVL_CPE_Delete,
        Content_R2R_PH_CONFIG_INIT_OVL_CPE_Add,
        Content_R2R_PH_CONFIG_INIT_OVL_CPE_Modify,

        //
        Content_R2R_PH_CONFIG_INIT_CD,
        Content_R2R_PH_CONFIG_INIT_CD_Original,
        Content_R2R_PH_CONFIG_INIT_OVL_PC,
        Content_R2R_PH_CONFIG_INIT_OVL_PC_Original,
        Content_R2R_PH_CONFIG_INIT_OVL_CPE,
        Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original,

        OVL_CPE_SPEC_VARNAME,
        OVL_CPE_LSL_CALC,
        OVL_CPE_USL_CALC,
        OVL_CPE_SPEC_MAX_DELTA,

        OVL_PC_SPEC_VARNAME,
        OVL_PC_SPEC_VAR_SELECT,
        OVL_PC_LSL_METRO,
        OVL_PC_USL_METRO,
        OVL_PC_LSL_CALC,
        OVL_PC_USL_CALC,
        OVL_PC_DEADBAND,
        OVL_PC_SPEC_MAX_DELTA,
        Fixed_Edge_Shot_Content_Add,
        Fixed_Edge_Shot_Content_Modify,
        Fixed_Edge_Shot_Content_Delete
    }
}
