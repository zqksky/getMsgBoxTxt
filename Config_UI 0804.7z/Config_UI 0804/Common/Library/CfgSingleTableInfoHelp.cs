﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using R2R.Common.Data.CommonEntity;

namespace R2R.Common.Library
{
    public class CfgSingleTableInfoHelp
    {
        #region
        /// <summary>
        /// Get Column Format
        /// </summary>
        /// <param name="arry">Coulumn Array</param>
        /// <returns></returns>
        static List<StructColumnInfo> GetColumnFormat(string[] arry)
        {
            List<StructColumnInfo> structData = new List<StructColumnInfo>();
            try
            {
                foreach (var str in arry)
                {
                    string[] sArray = System.Text.RegularExpressions.Regex.Split(str, ":", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                    StructColumnInfo column = new StructColumnInfo();
                    column.columnName = sArray[0];
                    column.columnType = GetTypeByString(sArray[1]);
                    column.columnAttribute = sArray[2];
                    structData.Add(column);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return structData;
        }
        /// <summary>
        /// String To Type
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        static Type GetTypeByString(string type)
        {
            //string sType = "System." + type.Substring(0, 1).ToUpper() + type.Substring(1);
            switch (type.ToLower())
            {
                case "boolean":
                    return Type.GetType("System.Boolean", true, true);
                case "bool":
                    return Type.GetType("System.Boolean", true, true);
                case "byte":
                    return Type.GetType("System.Byte", true, true);
                case "sbyte":
                    return Type.GetType("System.SByte", true, true);
                case "char":
                    return Type.GetType("System.Char", true, true);
                case "decimal":
                    return Type.GetType("System.Decimal", true, true);
                case "double":
                    return Type.GetType("System.Double", true, true);
                case "float":
                    return Type.GetType("System.Single", true, true);
                case "int":
                    return Type.GetType("System.Int32", true, true);
                case "uint":
                    return Type.GetType("System.UInt32", true, true);
                case "long":
                    return Type.GetType("System.Int64", true, true);
                case "ulong":
                    return Type.GetType("System.UInt64", true, true);
                case "object":
                    return Type.GetType("System.Object", true, true);
                case "short":
                    return Type.GetType("System.Int16", true, true);
                case "ushort":
                    return Type.GetType("System.UInt16", true, true);
                case "string":
                    return Type.GetType("System.String", true, true);
                case "date":
                case "datetime":
                    return Type.GetType("System.DateTime", true, true);
                case "guid":
                    return Type.GetType("System.Guid", true, true);
                default:
                    return Type.GetType(type, true, true);
            }
        }
        /// <summary>
        /// Get Column Data
        /// </summary>
        /// <param name="arry"></param>
        /// <returns></returns>
        static List<List<string>> GetColumnData(string[] arry)
        {
            List<List<string>> columnData = new List<List<string>>();
            try
            {
                foreach (var str in arry)
                {
                    string[] sArray = System.Text.RegularExpressions.Regex.Split(str, ":", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                    columnData.Add(sArray.ToList());
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return columnData;
        }
        /// <summary>
        /// Get Row Data
        /// </summary>
        /// <param name="columnData"></param>
        /// <returns></returns>
        static List<List<string>> GetRowData(List<List<string>> columnData)
        {
            List<List<string>> rowData = new List<List<string>>();
            try
            {
                for (int n = 0; n < columnData[0].Count; n++)
                {
                    List<string> strList = new List<string>();
                    for (int i = 0; i < columnData.Count; i++)
                    {
                        strList.Add(columnData[i][n]);
                    }
                    rowData.Add(strList);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return rowData;
        }
        /// <summary>
        /// Get Column key Name 
        /// </summary>
        /// <param name="arry"></param>
        /// <returns></returns>
        public static List<string> GetColumnKeyName(string[] arry)
        {
            List<string> strList = new List<string>();
            try
            {
                List<StructColumnInfo> structColumn = new List<StructColumnInfo>();

                structColumn = GetColumnFormat(arry);

                foreach (var st in structColumn)
                {
                    if (st.columnAttribute.ToUpper().Equals("KEY"))
                    {
                        strList.Add(st.columnName);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList;
        }
        /// <summary>
        /// Get Column Name
        /// </summary>
        /// <param name="arry"></param>
        /// <returns></returns>
        public static List<string> GetColumnName(string[] arry)
        {

            List<string> strList = new List<string>();
            try
            {
                List<StructColumnInfo> structColumn = new List<StructColumnInfo>();
                structColumn = GetColumnFormat(arry);


                foreach (var st in structColumn)
                {
                    strList.Add(st.columnName);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList;
        }

        /// <summary>
        /// Get Column Type
        /// </summary>
        /// <param name="arry"></param>
        /// <returns></returns>
        public static List<Type> GetColumnType(string[] arry)
        {
            List<Type> strList = new List<Type>();
            try
            {
                List<StructColumnInfo> structColumn = new List<StructColumnInfo>();
                structColumn = GetColumnFormat(arry);

                foreach (var st in structColumn)
                {
                    strList.Add(st.columnType);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList;
        }

        ///// <summary>
        ///// Create Db by CfgSingleTableInfoEntity
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <param name="rowData"></param>
        ///// <returns></returns>
        //public static DataTable CreateDataTable(CfgSingleTableInfoEntity entity, List<List<string>> rowData)
        //{
        //    DataTable db = new DataTable(entity.TableName);
        //    try
        //    {
        //        List<StructColumnInfo> structData = new List<StructColumnInfo>();
        //        structData = GetColumnFormat(entity.ColumnFormat);
        //        foreach (var st in structData)
        //        {
        //            //string strType = "System.String";
        //            db.Columns.Add(st.columnName, st.columnType);
        //        }

        //        for (int i = 0; i < rowData.Count; i++)
        //        {
        //            db.Rows.Add();
        //            for (int n = 0; n < rowData[0].Count; n++)
        //            {
        //                db.Rows[i][n] = rowData[i][n];
        //            }
        //        }
        //    }
        //    catch (Exception ee)
        //    {
        //        MessageBox.Show(ee.Message);
        //    }
        //    return db;
        //}

        /// <summary>
        /// Create Db by CfgSingleTableInfoEntity
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public static DataTable CreateDataTable(CfgSingleTableInfoEntity entity)
        {
            DataTable db = new DataTable(entity.TableName);
            try
            {
                List<StructColumnInfo> structData = new List<StructColumnInfo>();
                structData = GetColumnFormat(entity.ColumnFormat);
                foreach (var st in structData)
                {
                    //strType = "System.String";
                    db.Columns.Add(st.columnName, Type.GetType("System.String"));
                    //db.Columns.Add(st.columnName, st.columnType);
                }

                List<List<string>> columnData = new List<List<string>>();
                columnData = GetColumnData(entity.ColumnData);

                List<List<string>> rowData = new List<List<string>>();
                rowData = GetRowData(columnData);

                for (int i = 0; i < rowData.Count; i++)
                {
                    db.Rows.Add();
                    for (int n = 0; n < rowData[0].Count; n++)
                    {
                        db.Rows[i][n] = rowData[i][n];
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        /// <summary>
        /// Db To Array
        /// </summary>
        /// <param name="db"></param>
        /// <param name="ColumnNameList"></param>
        /// <returns></returns>
        public static string[] DataTableConvert(DataTable db, List<string> ColumnNameList)
        {
            List<string> strList = new List<string>();
            try
            {
                foreach (var str in ColumnNameList)
                {
                    string strTmp = string.Empty;

                    foreach (DataRow dr in db.Rows)
                    {
                        strTmp += dr[str].ToString() + ":";
                    }

                    //List<string> strListColumn = new List<string>();
                    //strListColumn = (from d in dv.ToTable().AsEnumerable() select d.Field<string>(str)).ToList();
                    strTmp = RemoveLastChar(strTmp,":");
                    strList.Add(strTmp);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList.ToArray();
        }

        /// <summary>
        /// 移除字符串末尾指定字符
        /// </summary>
        /// <param name="str">需要移除的字符串</param>
        /// <param name="value">指定字符</param>
        /// <returns>移除后的字符串</returns>
        public static string RemoveLastChar(string str, string value)
        {
            int _finded = str.LastIndexOf(value);
            if (_finded != -1)
            {
                return str.Substring(0, _finded);
            }
            return str;
        }
        /// <summary>
        /// CfgSingleTableInfoEntity List To Array
        /// </summary>
        /// <param name="entityList"></param>
        /// <returns></returns>
        public static string[] EntityListConvert(List<CfgSingleTableInfoEntity> entityList)
        {
            List<string> strList = new List<string>();
            try
            {
                if (entityList.Count > 0)
                {
                    for (int i = 0; i < entityList[0].ColumnData.Count(); i++)
                    {
                        string strTmp = string.Empty;
                        foreach (var obj in entityList)
                        {
                            strTmp += obj.ColumnData[i] + ":";
                        }
                        strTmp = RemoveLastChar(strTmp, ":");
                        strList.Add(strTmp);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList.ToArray();
        }

        ///// <summary>
        ///// Db to Array
        ///// </summary>
        ///// <param name="db"></param>
        ///// <returns></returns>
        //public static string[] DataTableConvert(DataTable db)
        //{
        //    List<string> strList = new List<string>();
        //    try
        //    {
        //        foreach (DataColumn col in db.Columns)
        //        {
        //            string strTmp = string.Empty;

        //            foreach (DataRow dr in db.Rows)
        //            {
        //                strTmp += dr[col.ColumnName].ToString() + ":";
        //            }
        //            strTmp = RemoveLastChar(strTmp, ":");
        //            strList.Add(strTmp);
        //        }
        //    }
        //    catch (Exception ee)
        //    {
        //        MessageBox.Show(ee.Message);
        //    }
        //    return strList.ToArray();
        //}

        //public static string DataTableConvertToJson(CfgSingleTableInfoEntity cfgInitUpdateEntity,DataTable db,string strColumn)
        //{
        //    string strJsonResult = string.Empty;
        //    try
        //    {
        //        if (db.Rows.Count > 0)
        //        {
        //            List<CfgSingleTableInfoEntity> entityList = new List<CfgSingleTableInfoEntity>();
        //            for (int i = 0; i < db.Rows.Count; i++)
        //            {
        //                string strJson = db.Rows[i][strColumn].ToString();
        //                CfgSingleTableInfoEntity entity = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strJson);
        //                entityList.Add(entity);
        //            }
        //            cfgInitUpdateEntity.ColumnData = EntityListConvert(entityList);
        //            strJsonResult = JsonHelp.SerializeObject(cfgInitUpdateEntity);
        //        }
        //    }
        //    catch (Exception ee)
        //    {
        //        MessageBox.Show(ee.Message);
        //    }
        //    return strJsonResult;
        //}

        public static DataTable SingleTableInfoEntityToInitDataTable(CfgSingleTableInfoEntity cfgInitEntity, DataTable dbInit, string strColumn)
        {
            DataTable db = new DataTable("dbName");
            try
            {
                if (dbInit.Rows.Count > 0)
                {
                    List<CfgSingleTableInfoEntity> entityList = new List<CfgSingleTableInfoEntity>();
                    foreach (DataRow row in dbInit.Rows)
                    {
                        CfgSingleTableInfoEntity entityTmp = new CfgSingleTableInfoEntity();
                        entityTmp = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(row[strColumn].ToString());
                        if (entityTmp != null)
                        {
                            entityList.Add(entityTmp);
                        }
                    }
                    if (entityList.Count > 0)
                    {
                        cfgInitEntity.ColumnData = EntityListConvert(entityList);
                    }
                }

                db = CreateDataTable(cfgInitEntity);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        public static CfgSingleTableInfoEntity GetUpdateSingleTableInfo(CfgSingleTableInfoEntity entity, ref DataTable dbSource, ref DataTable dbUpdate, ref List<string> ColumnNameList, ref List<string> ColumnKeyList)
        {
            CfgSingleTableInfoEntity entityUpdate = new CfgSingleTableInfoEntity();
            dbSource = CreateDataTable(entity);
            dbUpdate = dbSource.Copy();

            ColumnNameList = GetColumnName(entity.ColumnFormat);
            ColumnKeyList = GetColumnKeyName(entity.ColumnFormat);

            string strSource = JsonHelp.SerializeObject(entity);
            entityUpdate = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strSource);

            return entityUpdate;
        }
        #endregion

        #region Init Content Sort
        public static int GetParameterNameItemIndex(string[] columnFormat, string strParameterNameItem)
        {
            int index = 0;
            bool IsHave = false;
            try
            {
                foreach (var str in columnFormat)
                {
                    if (str.Contains(strParameterNameItem))
                    {
                        IsHave = true;
                        break;
                    }
                    index++;
                }
                if (!IsHave || index == columnFormat.Length)
                {
                    index = -1;
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }

            return index;
        }

        public static string GetParameterNameItem(string strParameterName)
        {
            string strResult = "";
            try
            {
                if (!string.IsNullOrEmpty(strParameterName))
                {
                    if (strParameterName.Contains(":"))
                    {
                        strResult = strParameterName.Substring(0, strParameterName.IndexOf(':'));
                    }
                    else
                    {
                        strResult = strParameterName;
                    }
                }
            }

            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }
            return strResult;
        }
        static List<int> GetParameterNameItemIndex(string originalParameterNameItem, string updateParameterNameItem)
        {
            List<int> indexList = new List<int>();
            try
            {
                if (!string.IsNullOrEmpty(originalParameterNameItem) && !string.IsNullOrEmpty(updateParameterNameItem))
                {
                    List<string> originalNameList = new List<string>(originalParameterNameItem.Split(','));
                    List<string> updateNameList = new List<string>(updateParameterNameItem.Split(','));
                    foreach (var str in updateNameList)
                    {
                        int index = originalNameList.IndexOf(str);
                        indexList.Add(index);
                    }
                }
            }

            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }
            return indexList;
        }
        static string GetOriginalParameterNameSort(int originalParameterNameItemCount, string updateParameterNameItem)
        {
            string strResult = "";
            try
            {
                if (!string.IsNullOrEmpty(updateParameterNameItem))
                {
                    for (int n = 0; n < originalParameterNameItemCount; n++)
                    {
                        strResult += updateParameterNameItem + ":";
                    }
                    strResult = CfgSingleTableInfoHelp.RemoveLastChar(strResult, ":");
                }
            }

            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }
            return strResult;
        }
        static string GetOriginalParameterValueSort(string originalParameterValue, List<int> indexList)
        {
            string strResult = "";
            try
            {
                List<string> OriginalParameterValueList = new List<string>(originalParameterValue.Split(':'));
                for (int n = 0; n < OriginalParameterValueList.Count; n++)
                {
                    if (OriginalParameterValueList[n].Contains(";"))
                    {
                        string strDoubleChuckValue = "";
                        List<string> DoubleChuckValueList = new List<string>(OriginalParameterValueList[n].Split(';'));

                        for (int d = 0; d < DoubleChuckValueList.Count; d++)
                        {
                            string strDoubleChuckValueItem = "";
                            List<string> originalDoubleChuckValueList = new List<string>(DoubleChuckValueList[d].Split(','));
                            for (int i = 0; i < indexList.Count; i++)
                            {
                                strDoubleChuckValueItem += originalDoubleChuckValueList[indexList[i]] + ",";
                            }
                            strDoubleChuckValueItem = CfgSingleTableInfoHelp.RemoveLastChar(strDoubleChuckValueItem, ",");
                            strDoubleChuckValue += strDoubleChuckValueItem + ";";
                        }
                        strDoubleChuckValue = CfgSingleTableInfoHelp.RemoveLastChar(strDoubleChuckValue, ";");
                        strResult += strDoubleChuckValue + ":";
                    }
                    else
                    {
                        string strValueItem = "";
                        List<string> originalValueList = new List<string>(OriginalParameterValueList[n].Split(','));
                        for (int i = 0; i < indexList.Count; i++)
                        {
                            strValueItem += originalValueList[indexList[i]] + ",";
                        }
                        strValueItem = CfgSingleTableInfoHelp.RemoveLastChar(strValueItem, ",");
                        strResult += strValueItem + ":";
                    }

                }
                strResult = CfgSingleTableInfoHelp.RemoveLastChar(strResult, ":");
            }

            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }
            return strResult;
        }
        public static string SortInitOriginalContent(string originalContent, string updateParameterNameItem, int parameterIndex)
        {
            string strSortResult = "";

            try
            {
                int OriginalItemCount = 0;
                string originalParameterNameItem = "";


                CfgSingleTableInfoEntity SourceEntity = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(originalContent);
                if (SourceEntity == null)
                {
                    return "";
                }

                string originalParameterValue = SourceEntity.ColumnData[parameterIndex + 1];
                List<string> OriginalParameterNameList = new List<string>(SourceEntity.ColumnData[parameterIndex].Split(':'));

                if (OriginalParameterNameList.Count > 0 && !string.IsNullOrEmpty(updateParameterNameItem))
                {
                    OriginalItemCount = OriginalParameterNameList.Count;
                    originalParameterNameItem = OriginalParameterNameList[0];

                    if (originalParameterNameItem.Equals(updateParameterNameItem))
                    {
                        return originalContent;
                    }
                    else
                    {
                        string strParameterName = GetOriginalParameterNameSort(OriginalItemCount, updateParameterNameItem);

                        List<int> nameItemIndex = new List<int>(GetParameterNameItemIndex(originalParameterNameItem, updateParameterNameItem));
                        string strParameterValue = GetOriginalParameterValueSort(originalParameterValue, nameItemIndex);

                        SourceEntity.ColumnData[parameterIndex] = strParameterName;
                        SourceEntity.ColumnData[parameterIndex + 1] = strParameterValue;

                        strSortResult = JsonHelp.SerializeObject(SourceEntity);
                    }
                }
            }

            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }
            return strSortResult;
        }
        #endregion
    }
}
