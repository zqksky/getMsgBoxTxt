﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Library
{
    public class CommonHelp
    {
        public static string MidStrEx(string sourse, string startstr, string endstr)
        {
            string result = string.Empty;
            int startindex, endindex;
            try
            {
                startindex = sourse.IndexOf(startstr);
                if (startindex == -1)
                    return result;
                string tmpstr = sourse.Substring(startindex + startstr.Length);
                endindex = tmpstr.IndexOf(endstr);
                if (endindex == -1)
                    return result;
                result = tmpstr.Remove(endindex);
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
            }
            return result;
        }
        public static bool StringIsNull(string strData)
        {
            bool flag = false;
            try
            {
                strData = strData.Replace("\"\"", "");
                strData = strData.TrimEnd(',');
                if (string.IsNullOrEmpty(strData))
                {
                    flag = true;
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
            }
            return flag;
        }

        /// <summary>
        /// Get Query Time
        /// </summary>
        /// <returns></returns>
        public static string GetQueryTime()
        {
            string strQueryTime = string.Empty;
            try
            {
                DateTime dt = DateTime.Now;
                strQueryTime = dt.ToString("yyyy-MM-dd'T'HH:mm:ss.ffffffzzz");

                MyLogger.Trace("Return :: " +
                           string.Format("QueryTime<{0}>", strQueryTime));
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                System.Windows.MessageBox.Show(ex.Message);
            }
            return strQueryTime;
        }

        /// <summary>
        /// Argument Is Null
        /// </summary>
        /// <param name="dic"></param>
        /// <returns></returns>
        public static bool ArgumentIsNull(Dictionary<string, object> dic)
        {

            foreach (string key in dic.Keys)
            {
                if (dic[key] == null)
                {
                    MyLogger.Error(string.Format("Argument <{0}> Is Null", key));
                    throw new ArgumentNullException(key);
                }
                else if (dic[key].GetType().ToString().Equals("System.String"))
                {
                    if ((string)dic[key] == "")
                    {
                        MyLogger.Error(string.Format("Argument <{0}> Is Null", key));
                        throw new ArgumentNullException(key);
                    }
                }
                if (dic[key].GetType().ToString().Equals("System.String[]"))
                {

                }

                //if ((string)dic[key] == "" || dic[key] == null)
                //{
                //    MyLogger.Error(string.Format("Argument <{0}> Is Null", key));
                //    throw new ArgumentNullException(key);
                //}

            }
            return false;
        }
        public static string GetModelValue(string FieldName, object obj)
        {
            try
            {
                Type Ts = obj.GetType();
                object o = Ts.GetProperty(FieldName).GetValue(obj, null);
                string Value = Convert.ToString(o);
                if (string.IsNullOrEmpty(Value)) return null;
                return Value;
            }
            catch
            {
                return null;
            }
        }
    }
}
