﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace R2R.Common.Library
{
    public class DataTableHelp
    {
        #region Compare Version
        public static DataTable RemoveBlankRow(DataTable dbSource,List<string> ListKey)
        {
            DataTable db = dbSource.Copy();
            try
            {
                int count = db.Rows.Count;
                for (int i = count - 1; i >= 0; i--)
                {
                    bool flag = false;
                    foreach (var str in ListKey)
                    {
                        if (string.IsNullOrEmpty(db.Rows[i][str].ToString()))
                        {
                            flag = true;
                            break;
                        }
                    }
                    if (flag)
                    {
                        db.Rows.RemoveAt(i);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        public static DataTable CreateCommonCompareVersionTable()
        {
            DataTable db = new DataTable();
            try
            {
                db.Columns.Add("Context", Type.GetType("System.String"));
                db.Columns.Add("CurrentVersion", Type.GetType("System.String"));
                db.Columns.Add("HistoryVersion", Type.GetType("System.String"));
                db.Columns.Add("Result", Type.GetType("System.String"));

                db.PrimaryKey = new DataColumn[] { db.Columns["Context"] };
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        public static DataTable CreateCommonVersionTable(string strColumnNames,string strColumnValues)
        {
            DataTable db = new DataTable();
            try
            {
                db.Columns.Add("Context", Type.GetType("System.String"));
                db.Columns.Add("Values", Type.GetType("System.String"));
                db.PrimaryKey = new DataColumn[] { db.Columns["Context"] };

                List<string> ColumnNameList = new List<string>(strColumnNames.Split(','));
                List<string> ColumnValueList = new List<string>(strColumnValues.Split(','));
                if (ColumnNameList.Count > 0 && ColumnNameList.Count == ColumnValueList.Count)
                {
                    for (int i = 0; i < ColumnNameList.Count; i++)
                    {
                        db.Rows.Add();
                        db.Rows[i][0] = ColumnNameList[i];
                        db.Rows[i][1] = ColumnValueList[i];
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        public static DataTable CompareCommonVersion(DataTable dbCurrent, DataTable dbHistory)
        {
            DataTable dbResult = new DataTable();
            try
            {
                dbResult = dbCurrent.Clone();
                dbResult.Columns.Add("Result", Type.GetType("System.String"));

                //dbCurrent.DefaultView.Sort = "Context DESC";//按Context倒序
                //dbCurrent = dbCurrent.DefaultView.ToTable();//返回一个新的DataTable

                //dbHistory.DefaultView.Sort = "Context DESC";//按Context倒序
                //dbHistory = dbHistory.DefaultView.ToTable();//返回一个新的DataTable

                if (dbCurrent.Rows.Count == dbHistory.Rows.Count)
                {
                    for (int i = 0; i < dbCurrent.Rows.Count; i++)
                    {
                        dbResult.Rows.Add();
                        dbResult.Rows[i][0] = dbCurrent.Rows[i][0];
                        dbResult.Rows[i][1] = dbCurrent.Rows[i][1];
                        dbResult.Rows[i][2] = dbHistory.Rows[i][1];

                        if (dbCurrent.Rows[i][1].Equals(dbHistory.Rows[i][1]))
                        {
                            dbResult.Rows[i][3] = "NoChanged";
                        }
                        else
                        {
                            dbResult.Rows[i][3] = "Changed";
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }
        public static DataTable CreateCDCompareVersionTable()
        {
            DataTable db = new DataTable();
            try
            {
                db.Columns.Add("Context", Type.GetType("System.String"));
                db.Columns.Add("ParameterName", Type.GetType("System.String"));
                db.Columns.Add("Version1", Type.GetType("System.String"));
                db.Columns.Add("Version2", Type.GetType("System.String"));
                db.Columns.Add("Result", Type.GetType("System.String"));

                db.PrimaryKey = new DataColumn[] { db.Columns["Context"] };
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        public static DataTable CompareCDVersion(DataTable dbCurrent, DataTable dbHistory)
        {
            DataTable dbResult = new DataTable();
            try
            {
                dbResult = dbCurrent.Clone();
                dbResult.Columns.Add("Result", Type.GetType("System.String"));

                //dbCurrent.DefaultView.Sort = "Context DESC";//按Context倒序
                //dbCurrent = dbCurrent.DefaultView.ToTable();//返回一个新的DataTable

                //dbHistory.DefaultView.Sort = "Context DESC";//按Context倒序
                //dbHistory = dbHistory.DefaultView.ToTable();//返回一个新的DataTable

                if (dbCurrent.Rows.Count == dbHistory.Rows.Count)
                {
                    for (int i = 0; i < dbCurrent.Rows.Count; i++)
                    {
                        dbResult.Rows.Add();
                        dbResult.Rows[i][0] = dbCurrent.Rows[i][0];
                        dbResult.Rows[i][1] = dbCurrent.Rows[i][1];
                        dbResult.Rows[i][2] = dbCurrent.Rows[i][2];
                        dbResult.Rows[i][3] = dbHistory.Rows[i][2];

                        if (dbCurrent.Rows[i][2].Equals(dbHistory.Rows[i][2]))
                        {
                            dbResult.Rows[i][4] = "NoChanged";
                        }
                        else if (dbCurrent.Rows[i][2].Equals(""))
                        {
                            dbResult.Rows[i][4] = "Miss";
                        }
                        else if (dbHistory.Rows[i][2].Equals(""))
                        {
                            dbResult.Rows[i][4] = "New";
                        }
                        else
                        {
                            dbResult.Rows[i][4] = "Edit";
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }

        public static DataTable CreateCDDetailCompareVersionTable()
        {
            DataTable db = new DataTable();
            try
            {
                db.Columns.Add("ParameterName", Type.GetType("System.String"));
                db.Columns.Add("Version1", Type.GetType("System.String"));
                db.Columns.Add("Version2", Type.GetType("System.String"));
                db.Columns.Add("Result", Type.GetType("System.String"));

                db.PrimaryKey = new DataColumn[] { db.Columns["ParameterName"] };
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        public static DataTable CompareCDDetailVersion(DataTable dbCurrent, DataTable dbHistory)
        {
            DataTable dbResult = new DataTable();
            try
            {
                dbResult = dbCurrent.Clone();
                dbResult.Columns.Add("Result", Type.GetType("System.String"));

                //dbCurrent.DefaultView.Sort = "Context DESC";//按Context倒序
                //dbCurrent = dbCurrent.DefaultView.ToTable();//返回一个新的DataTable

                //dbHistory.DefaultView.Sort = "Context DESC";//按Context倒序
                //dbHistory = dbHistory.DefaultView.ToTable();//返回一个新的DataTable

                if (dbCurrent.Rows.Count == dbHistory.Rows.Count)
                {
                    for (int i = 0; i < dbCurrent.Rows.Count; i++)
                    {
                        dbResult.Rows.Add();
                        dbResult.Rows[i][0] = dbCurrent.Rows[i][0];
                        dbResult.Rows[i][1] = dbCurrent.Rows[i][1];
                        dbResult.Rows[i][2] = dbHistory.Rows[i][1];

                        if (dbCurrent.Rows[i][1].Equals(dbHistory.Rows[i][1]))
                        {
                            dbResult.Rows[i][3] = "NoChanged";
                        }
                        else
                        {
                            dbResult.Rows[i][3] = "Changed";
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }
        #endregion

        #region
        /// <summary>
        /// Get column record to list
        /// </summary>
        /// <param name="db"></param>
        /// <param name="strColumnName"></param>
        /// <returns></returns>
        public static List<string> GetColumnRecordToList(DataTable db, string strColumnName)
        {
            List<string> strList = new List<string>();
            try
            {
                strList = db.AsEnumerable().Select(c => c.Field<string>(strColumnName)).Distinct().ToList();
                strList.Remove("");
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return strList;
        }
        /// <summary>
        /// Get all rows by select string 
        /// </summary>
        /// <param name="db"></param>
        /// <param name="strSelect"></param>
        /// <returns></returns>
        public static DataRow[] Query(DataTable db, string strSelect)
        {
            DataRow[] rows = db.Select(strSelect);
            return rows;
        }

        /// <summary>
        /// Get Change record to DataTable
        /// </summary>
        /// <param name="dbChanged"></param>
        /// <param name="strStatusColumnName"></param>
        /// <param name="strStatus"></param>
        /// <returns></returns>
        public static DataTable GetChangedRecordDataTable(DataTable dbChanged, string strStatusColumnName, string strStatus)
        {
            DataTable dbResult = dbChanged.Clone();

            try
            {
                DataRow[] drArr = dbChanged.Select(strStatusColumnName + "= '" + strStatus + "'");

                for (int i = 0; i < drArr.Length; i++)
                {
                    dbResult.ImportRow(drArr[i]);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }

        /// <summary>
        /// Get Change record to db
        /// </summary>
        /// <param name="dbChanged"></param>
        /// <param name="strStatusColumnName"></param>
        /// <param name="strStatus"></param>
        /// <returns></returns>
        public static DataTable GetChangedRecord(DataTable dbChanged, string strStatusColumnName, string strStatus)
        {
            DataTable dbResult = dbChanged.Clone();

            try
            {
                DataRow[] drArr = dbChanged.Select(strStatusColumnName + "= '" + strStatus + "'");

                for (int i = 0; i < drArr.Length; i++)
                {
                    dbResult.ImportRow(drArr[i]);
                }
                dbResult.Columns.Remove(strStatusColumnName);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }

        /// <summary>
        /// Compare two tables by key
        /// </summary>
        /// <param name="dbOld"></param>
        /// <param name="dbNew"></param>
        /// <param name="ColumnKeyList"></param>
        /// <returns></returns>
        public static DataTable CompareDataTable(DataTable dbOld, DataTable dbNew, List<string> ColumnKeyList)
        {
            DataTable dbResult = new DataTable("dbResult");
            DataTable dbOldExcept = new DataTable("dbOldExcept");
            DataTable dbNewExcept = new DataTable("dbNewExcept");
            try
            {
                if (dbOld != null || dbNew != null)
                {
                    dbResult = dbOld.Clone();
                    if (dbResult.Columns.Contains("Status"))
                    {
                    }
                    else
                    {
                        dbResult.Columns.Add("Status", Type.GetType("System.String")).SetOrdinal(0);
                    }

                    //获取两个数据源的差集
                    IEnumerable<DataRow> queryOld = dbOld.AsEnumerable().Except(dbNew.AsEnumerable(), DataRowComparer.Default);
                    if (queryOld.Count() > 0)
                    {
                        dbOldExcept = queryOld.CopyToDataTable();
                    }

                    //获取两个数据源的差集
                    IEnumerable<DataRow> queryNew = dbNew.AsEnumerable().Except(dbOld.AsEnumerable(), DataRowComparer.Default);
                    if (queryNew.Count() > 0)
                    {
                        dbNewExcept = queryNew.CopyToDataTable();
                    }

                    foreach (DataRow row in dbOldExcept.Rows)
                    {
                        string str = GetSelectKey(row, ColumnKeyList);
                        if (dbNewExcept.Rows.Count > 0)
                        {
                            DataRow[] rows = dbNewExcept.Select(str);
                            if (rows.Length > 0)
                            {
                                //bool flag = CompareRowValue(row, rows[0]);

                                dbResult.ImportRow(row);
                                dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Old";

                                dbResult.ImportRow(rows[0]);
                                dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Edit";
                            }
                            else
                            {
                                dbResult.ImportRow(row);
                                dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Delete";
                            }
                        }
                        else
                        {
                            dbResult.ImportRow(row);
                            dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Delete";
                        }
                    }

                    foreach (DataRow row in dbNewExcept.Rows)
                    {
                        string str = GetSelectKey(row, ColumnKeyList);
                        if (dbOldExcept.Rows.Count > 0)
                        {
                            DataRow[] rows = dbOldExcept.Select(str);
                            if (rows.Length > 0)
                            {

                            }
                            else
                            {
                                dbResult.ImportRow(row);
                                dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Add";
                            }
                        }
                        else
                        {
                            dbResult.ImportRow(row);
                            dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Add";
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }
        #endregion

        #region
        public static DataTable GetCommonDataTable()
        {
            DataTable db = new DataTable("dbCommon");
            try
            {
                db.Columns.Add("PRODUCT", Type.GetType("System.String"));
                db.Columns.Add("LAYER", Type.GetType("System.String"));
                db.Columns.Add("TOOL_GROUP", Type.GetType("System.String"));
                db.Columns.Add("ALIGMENT_LAYER", Type.GetType("System.String"));
                db.Columns.Add("ALIAMENT_METHOD", Type.GetType("System.String"));
                db.Columns.Add("OVERLAY_LAYER", Type.GetType("System.String"));
                db.Columns.Add("CONTROL_BY_CHUCK", Type.GetType("System.String"));
                db.Columns.Add("CHUCK_DEDICATION", Type.GetType("System.String"));
                db.Columns.Add("CHUCK_DEDICATION_LAYER", Type.GetType("System.String"));
                db.Columns.Add("CASCADE_PC_LAYER", Type.GetType("System.String"));
                db.Columns.Add("CASCADE_CPE_LAYER", Type.GetType("System.String"));
                db.Columns.Add("PRELAYER_2", Type.GetType("System.String"));
                db.Columns.Add("CD_R2R_MODE", Type.GetType("System.String"));
                db.Columns.Add("CD_TARGET", Type.GetType("System.String"));
                db.Columns.Add("DOSE_SENSITIVITY", Type.GetType("System.String"));
                db.Columns.Add("CD_EXPIRE_TIME", Type.GetType("System.String"));
                db.Columns.Add("DOSE_MAX_DELTA", Type.GetType("System.String"));
                db.Columns.Add("DOSE_USL", Type.GetType("System.String"));
                db.Columns.Add("DOSE_LSL", Type.GetType("System.String"));
                db.Columns.Add("CD_LUMDA", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_R2R_MODE", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_OVL_MODE", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_SPEC_VARNAME", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_SPEC_MAX_DELTA", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_DEADBAND", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_USL_CALC", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_LSL_CALC", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_USL_METRO", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_LSL_METRO", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_EXPIRE_TIME", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_LUMDA", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_UPDATE_TIME", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_UPDATE_LOT", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_R2R_MODE", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_OVL_MODE", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_SPEC_VARNAME", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_SPEC_MAX_DELTA", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_USL_CALC", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_LSL_CALC", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_EXPIRE_TIME", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_LUMDA", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_UPDATE_TIME", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_UPDATE_LOT", Type.GetType("System.String"));
                db.Columns.Add("LIST_TOOL", Type.GetType("System.String"));
                db.Columns.Add("LIST_RETICLE", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_FEEDFOREWARD", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_FEEDFOREWARD", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_FIX_EDGE", Type.GetType("System.String"));
                db.Columns.Add("LIST_PRE_TOOL", Type.GetType("System.String"));
                db.Columns.Add("LIST_PRE_RETICLE", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_SPEC_VAR_SELECT", Type.GetType("System.String"));
                db.Columns.Add("TOOL_VENDOR", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_DYNAMIC_CONTEXT", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_DYNAMIC_CONTEXT", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_OOC_COUNT", Type.GetType("System.String"));
                db.Columns.Add("OVL_PC_OOS_COUNT", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_OOC_COUNT", Type.GetType("System.String"));
                db.Columns.Add("OVL_CPE_OOS_COUNT", Type.GetType("System.String"));

                db.PrimaryKey = new DataColumn[] { db.Columns["PRODUCT"], db.Columns["LAYER"], db.Columns["TOOL_GROUP"] };

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        /// <summary>
        /// Get Init Db
        /// </summary>
        /// <param name="dbInit"></param>
        /// <param name="strColumn"></param>
        /// <param name="strColumnRemove1"></param>
        /// <param name="strColumnRemove2"></param>
        /// <returns></returns>
        public static DataTable GetInitDataTable(DataTable dbInit, string strColumn, string strColumnRemove1, string strColumnRemove2)
        {
            DataTable dbResult=new DataTable("dbResult");
            DataTable db = dbInit.Copy();
            try
            {
                if (db.Rows.Count>0)
                {
                    db.Columns.Remove(strColumnRemove1);
                    db.Columns.Remove(strColumnRemove2);

                    var query1 =
                        from dt in db.AsEnumerable()
                        where dt.Field<string>(strColumn) != null
                        select dt;
                    if (query1.Count() > 0)
                    {
                        dbResult = query1.CopyToDataTable<DataRow>();
                    }

                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }
        /// <summary>
        /// Create Init Db
        /// </summary>
        /// <returns></returns>
        public static DataTable CreateInitDataTable()
        {
            DataTable db = new DataTable("dbInit");
            try
            {
                db.Columns.Add("PRODUCT", Type.GetType("System.String"));
                db.Columns.Add("LAYER", Type.GetType("System.String"));
                db.Columns.Add("TOOL_GROUP", Type.GetType("System.String"));
                db.Columns.Add("CdInitContent", Type.GetType("System.String"));
                db.Columns.Add("PcInitContent", Type.GetType("System.String"));
                db.Columns.Add("CpeInitContent", Type.GetType("System.String"));

                db.PrimaryKey = new DataColumn[] { db.Columns["PRODUCT"], db.Columns["LAYER"], db.Columns["TOOL_GROUP"] };
                
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }
        /// <summary>
        /// Create Init Db
        /// </summary>
        /// <returns></returns>
        public static DataTable CreatePCInitDataTable(bool IsHaveChuck2)
        {
            DataTable db = new DataTable("dbPCInit");
            try
            {
                db.Columns.Add("TOOL", Type.GetType("System.String"));
                db.Columns.Add("RETICLE", Type.GetType("System.String"));
                db.Columns.Add("PRE_TOOL", Type.GetType("System.String"));
                db.Columns.Add("PRE_RETICLE", Type.GetType("System.String"));
                db.Columns.Add("TOOL_LIST", Type.GetType("System.String"));
                db.Columns.Add("RETICLE_LIST", Type.GetType("System.String"));
                db.Columns.Add("PARAMETER", Type.GetType("System.String"));
                db.Columns.Add("MODE", Type.GetType("System.String"));
                if (IsHaveChuck2)
                {
                    db.Columns.Add("CHUCK1", Type.GetType("System.String"));
                    db.Columns.Add("CHUCK2", Type.GetType("System.String"));
                }
                else
                {
                    db.Columns.Add("CHUCKNA", Type.GetType("System.String"));
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }
        /// <summary>
        /// Create Tool Type Db
        /// </summary>
        /// <param name="ToolGroupList"></param>
        /// <param name="ToolVendorList"></param>
        /// <returns></returns>
        public static DataTable CreateToolTypeDataTable(List<string> ToolGroupList, List<string> ToolVendorList)
        {
            DataTable db = new DataTable("dbTypeValue");
            try
            {
                db.Columns.Add("ToolGroup", Type.GetType("System.String"));
                db.Columns.Add("ToolVendor", Type.GetType("System.String"));
                for (int i = 0; i < ToolGroupList.Count; i++)
                {
                    db.Rows.Add();
                    db.Rows[i][0] = ToolGroupList[i];
                    db.Rows[i][1] = ToolVendorList[i];
                }

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        ///// <summary>
        ///// Create ContextValue Db
        ///// </summary>
        ///// <param name="ProductList"></param>
        ///// <param name="LayerList"></param>
        ///// <param name="ToolGroupList"></param>
        ///// <param name="ToolVendorList"></param>
        ///// <returns></returns>
        //public static DataTable CreateContextValueDataTable(List<string> ProductList, List<string> LayerList, List<string> ToolGroupList, List<string> ToolVendorList)
        //{
        //    DataTable db = new DataTable("dbContextValue");
        //    try
        //    {
        //        db.Columns.Add("Product", Type.GetType("System.String"));
        //        db.Columns.Add("Layer", Type.GetType("System.String"));
        //        db.Columns.Add("ToolGroup", Type.GetType("System.String"));
        //        db.Columns.Add("ToolVendor", Type.GetType("System.String"));
        //        for (int i = 0; i < ProductList.Count; i++)
        //        {
        //            db.Rows.Add();
        //            db.Rows[i][0] = ProductList[i];
        //            db.Rows[i][1] = LayerList[i];
        //            db.Rows[i][2] = ToolGroupList[i];
        //            db.Rows[i][3] = ToolVendorList[i];
        //        }

        //    }
        //    catch (Exception ee)
        //    {
        //        MessageBox.Show(ee.Message);
        //    }
        //    return db;
        //}

        /// <summary>
        /// Create Db by column list
        /// </summary>
        /// <param name="ColumnList"></param>
        /// <returns></returns>
        public static DataTable CreateDataTable(List<string> ColumnList)
        {
            DataTable db = new DataTable("dbName");
            try
            {
                foreach (var str in ColumnList)
                {
                    db.Columns.Add(str, Type.GetType("System.String"));
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }
        /// <summary>
        /// Create Db by column list and type list
        /// </summary>
        /// <param name="ColumnList"></param>
        /// <param name="TypeList"></param>
        /// <returns></returns>
        public static DataTable CreateDataTable(List<string> ColumnList,List<Type> TypeList)
        {
            DataTable db = new DataTable("dbName");
            try
            {
                for (int i = 0; i < ColumnList.Count; i++)
                {
                    db.Columns.Add(ColumnList[i], TypeList[i]);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        /// <summary>
        /// Create Db
        /// </summary>
        /// <param name="dbStructure"></param>
        /// <param name="rowData"></param>
        /// <returns></returns>
        public static DataTable CreateDataTable(DataTable dbStructure, List<List<string>> rowData)
        {
            DataTable db = dbStructure.Clone();
            try
            {
                for (int i = 0; i < rowData.Count; i++)
                {
                    db.Rows.Add();
                    for (int n = 0; n < rowData[0].Count; n++)
                    {
                        db.Rows[i][n] = rowData[i][n];
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        /// <summary>
        /// Set Column Value
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="ColumnName"></param>
        /// <param name="ColumnValue"></param>
        /// <param name="rowStartIndex"></param>
        public static void SetColumnValue(DataTable dt, string ColumnName, string ColumnValue, int rowStartIndex)
        {
            try
            {
                for (int i = rowStartIndex; i < dt.Rows.Count; i++)
                {
                    //为新添加的列进行赋值
                    dt.Rows[i][ColumnName] = ColumnValue;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Get select string
        /// </summary>
        /// <param name="row"></param>
        /// <param name="strListColumnKey"></param>
        /// <returns></returns>
        static string GetSelectKey(DataRow row, List<string> strListColumnKey)
        {
            string str = string.Empty;
            try
            {
                foreach (var s in strListColumnKey)
                {
                    str += s + "= '" + row[s] + "' " + "and ";
                }
                str = str.Trim();
                str = str.TrimEnd(new char[] { 'a', 'n', 'd' });
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return str;
        }
        /// <summary>
        /// Compare two row
        /// </summary>
        /// <param name="row1"></param>
        /// <param name="row2"></param>
        /// <returns></returns>
        static bool CompareRowValue(DataRow row1, DataRow row2)
        {
            bool flag = false;
            string str1 = string.Empty;
            string str2 = string.Empty;

            try
            {
                str1 = JsonHelp.SerializeObject(row1.ItemArray);
                str2 = JsonHelp.SerializeObject(row2.ItemArray);

                if (str1.Equals(str2))
                {
                    flag = true;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            //flag = CompareObject(row1.ItemArray, row2.ItemArray);
            return flag;
        }
        /// <summary>
        /// Get column name
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static List<string> GetColumnName(DataTable dt)
        {
            List<string> strList = new List<string>();
            try
            {
                foreach (DataColumn column in dt.Columns)
                {
                    strList.Add(column.ColumnName);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList;
        }
        /// <summary>
        /// Two datatable merge
        /// </summary>
        /// <param name="db1"></param>
        /// <param name="db2"></param>
        /// <param name="strListColumnKey"></param>
        /// <param name="strListRowEdit"></param>
        /// <param name="strListRowChanged"></param>
        /// <param name="strListRowAdded"></param>
        /// <returns></returns>
        public static DataTable DataTableMerge(DataTable db1, DataTable db2, List<string> strListColumnKey, ref List<DataRow> strListRowEdit, ref List<DataRow> strListRowChanged, ref List<DataRow> strListRowAdded)
        {
            DataTable dbResult = db1.Copy();
            strListRowEdit = new List<DataRow>();
            strListRowChanged = new List<DataRow>();
            strListRowAdded = new List<DataRow>();
            try
            {
                foreach (DataRow row in db2.Rows)
                {
                    string str = GetSelectKey(row, strListColumnKey);
                    DataRow[] rows = dbResult.Select(str);
                    if (rows.Length > 0)
                    {
                        bool flag = CompareRowValue(row, rows[0]);
                        if (flag)
                        {

                        }
                        else
                        {
                            DataTable dbTmp = db1.Clone();
                            DataRow rowEdit = dbTmp.NewRow();
                            rowEdit.ItemArray = rows[0].ItemArray;

                            strListRowEdit.Add(rowEdit);
                            strListRowChanged.Add(row);
                            dbResult.Rows.Remove(rows[0]);
                            dbResult.ImportRow(row);
                        }
                    }
                    else
                    {
                        strListRowAdded.Add(row);
                        dbResult.ImportRow(row);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }

        #endregion

        #region Test
        /// <summary>
        /// 比较两个字段集合是否名称,数据类型一致 
        /// </summary>
        /// <param name="dcA"></param>
        /// <param name="dcB"></param>
        /// <returns></returns>
        private bool CompareColumn(DataColumnCollection dcA, DataColumnCollection dcB)
        {
            bool flag = false;
            try
            {
                if (dcA.Count == dcB.Count)
                {
                    foreach (DataColumn dc in dcA)
                    {
                        //找相同字段名称 
                        if (dcB.IndexOf(dc.ColumnName) > -1)
                        {
                            //测试数据类型 
                            if (dc.DataType != dcB[dcB.IndexOf(dc.ColumnName)].DataType)
                            {
                                return false;
                            }
                        }
                        else
                        {
                            return false;
                        }
                    }
                    flag = true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return flag;
        }

        /// <summary>
        /// Get the first record 
        /// </summary>
        /// <param name="db"></param>
        /// <param name="strQuery"></param>
        /// <param name="strColumn"></param>
        /// <returns></returns>
        public static string GetTheFirstRecord(DataTable db, string strQuery, string strColumn)
        {
            string strResult = string.Empty;
            try
            {
                DataRow[] rows = Query(db, strQuery);
                if (rows.Count() > 0)
                {
                    strResult = rows[0][strColumn].ToString();
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return strResult;
        }
        /// <summary>
        /// Get the record to List
        /// </summary>
        /// <param name="db"></param>
        /// <param name="strQuery"></param>
        /// <param name="strColumn"></param>
        /// <returns></returns>
        public static List<string> GetQueryRecordToList(DataTable db, string strQuery, string strColumn)
        {
            List<string> strList = new List<string>();
            try
            {
                DataRow[] rows = Query(db, strQuery);
                if (rows.Count() > 0)
                {
                    for (int i = 0; i < rows.Count(); i++)
                    {
                        strList.Add(rows[i][strColumn].ToString());
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return strList;
        }


        /// <summary>
        /// 按照数组中列名顺序排序
        /// </summary>
        /// <param name="drA"></param>
        /// <param name="columnNames">按照数组中列名顺序排序</param>
        private static void ColumnSort(DataRow drA, string[] columnNames)
        {
            try
            {
                //drA 排序
                int i = 0;
                foreach (string columnName in columnNames)
                {
                    if (drA.Table.Columns.Contains(columnName))
                    {
                        drA.Table.Columns[columnName].SetOrdinal(i);
                        i++;
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Compare two datarow
        /// </summary>
        /// <param name="drA"></param>
        /// <param name="drB"></param>
        /// <param name="columnNames">需要比较的列名称</param>
        /// <returns></returns>
        public static bool DataRowCompare(DataRow drA, DataRow drB, string[] columnNames)
        {
            bool flag = false;
            try
            {
                //DataRow 中需要比较的列排序
                ColumnSort(drA, columnNames);
                ColumnSort(drB, columnNames);
                foreach (DataColumn dcA in drA.Table.Columns)
                {
                    if (columnNames.Contains(dcA.ColumnName))
                    {
                        foreach (DataColumn dcB in drB.Table.Columns)
                        {
                            if (columnNames.Contains(dcB.ColumnName))
                            {
                                if (dcB.ColumnName == dcA.ColumnName)//列名比较
                                {
                                    //类型比较
                                    if (dcB.DataType != dcA.DataType)
                                    {
                                        flag = false;
                                        break;
                                    }
                                    //值比较
                                    else if (CompareObject(drA[dcB.ColumnName], drB[dcB.ColumnName]))
                                    {
                                        flag = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return flag;
        }

        /// <summary>
        /// 引用对象比较
        /// </summary>
        /// <param name="objA"></param>
        /// <param name="objB"></param>
        /// <returns></returns>
        public static bool CompareObject(object objA, object objB)
        {
            bool flag = false;
            try
            {
                if (objA == null || objB == null)
                {
                    flag = false;
                }
                else if (objA == DBNull.Value && objB != DBNull.Value)
                {
                    flag = false;
                }
                else if (objA != DBNull.Value && objB == DBNull.Value)
                {
                    flag = false;
                }
                else if (objA == DBNull.Value && objB == DBNull.Value)
                {
                    //objA objB 对应的列类型已经比较过 类型已判断 值一致
                    flag = true;
                }
                else if (objA.GetType() != objB.GetType())
                {
                    flag = false;
                }
                else if (objA is int || objA is short || objA is long || objA is float || objA is double || objA is decimal)
                {
                    //int 01与1      
                    if (objA is int)
                    {
                        if ((int)objA == (int)objB)
                        {
                            flag = true;
                        }
                    }
                    else if (objA is short)
                    {
                        if ((short)objA == (short)objB)
                        {
                            flag = true;
                        }
                    }
                    else if (objA is long)
                    {
                        if ((long)objA == (long)objB)
                        {
                            flag = true;
                        }
                    }
                    else if (objA is float)
                    {
                        if ((float)objA == (float)objB)
                        {
                            flag = true;
                        }
                    }
                    else if (objA is double)
                    {
                        if ((double)objA == (double)objB)
                        {
                            flag = true;
                        }
                    }
                    else if (objA is decimal)
                    {
                        if ((decimal)objA == (decimal)objB)
                        {
                            flag = true;
                        }
                    }
                }
                else
                {
                    string strA = JsonHelp.SerializeObject(objA);
                    string strB = JsonHelp.SerializeObject(objB);

                    if (strA.Equals(strB))
                    {
                        flag = true;
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return flag;
        }

        /// <summary>
        /// Get rows that exist in both tables
        /// </summary>
        /// <param name="dbOne"></param>
        /// <param name="dbTwo"></param>
        /// <returns></returns>
        public static DataTable GetAllExistRecords(DataTable dbOne, DataTable dbTwo)
        {
            DataTable dbResult = dbTwo.Clone();
            try
            {
                bool flag = false;
                foreach (DataRow row in dbTwo.Rows)
                {
                    flag = IsExistRow(dbOne, row);
                    if (flag)
                    {
                        dbResult.ImportRow(row);
                    }
                }

                ////获取两个数据源的交集
                //IEnumerable<DataRow> query = dbOne.AsEnumerable().Intersect(dbTwo.AsEnumerable(), DataRowComparer.Default);
                //dbResult = query.CopyToDataTable();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return dbResult;
        }
        /// <summary>
        /// Judge whether the table contains a record
        /// </summary>
        /// <param name="db"></param>
        /// <param name="row"></param>
        /// <returns></returns>
        public static bool IsExistRow(DataTable db, DataRow row)
        {
            bool flag = false;
            try
            {
                foreach (DataRow r in db.Rows)
                {
                    if (CompareRowValue(r, row))
                    {
                        flag = true;
                        break;
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return flag;
        }

        void test(DataTable dt1, DataTable dt2)
        {
            //比较两个数据源的交集
            IEnumerable<DataRow> query1 = dt1.AsEnumerable().Intersect(dt2.AsEnumerable(), DataRowComparer.Default);
            DataTable dt3 = query1.CopyToDataTable();

            //获取两个数据源的并集
            IEnumerable<DataRow> query2 = dt1.AsEnumerable().Union(dt2.AsEnumerable(), DataRowComparer.Default);
            DataTable dt4 = query2.CopyToDataTable();

            //获取两个数据源的差集
            IEnumerable<DataRow> query3 = dt1.AsEnumerable().Except(dt2.AsEnumerable(), DataRowComparer.Default);
            DataTable dt5 = query3.CopyToDataTable();
        }

        public struct StructCompareRow
        {
            public string columnNmae;
            public string oldValue;
            public string newValue;
        };

        public static List<StructCompareRow> CompareRowValue(string strOldRow, string strNewRow, List<string> columnName)
        {
            List<StructCompareRow> structList = new List<StructCompareRow>();

            List<string> oldRowList = new List<string>();
            List<string> newRowList = new List<string>();

            oldRowList = JsonHelp.DeserializeJsonToObject<List<string>>(strOldRow);
            newRowList = JsonHelp.DeserializeJsonToObject<List<string>>(strNewRow);

            for (int i = 0; i < columnName.Count; i++)
            {
                if (oldRowList[i].Equals(newRowList[i]))
                {
                    continue;
                }
                else
                {
                    StructCompareRow structData = new StructCompareRow();
                    structData.columnNmae = columnName[i];
                    structData.oldValue = oldRowList[i];
                    structData.newValue = newRowList[i];

                    structList.Add(structData);
                }
            }

            return structList;
        }
        #endregion
    }
}
