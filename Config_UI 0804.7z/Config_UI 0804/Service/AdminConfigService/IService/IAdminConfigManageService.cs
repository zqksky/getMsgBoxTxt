﻿using R2R.Common.Data.CommonEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminConfigService.IService
{
    public interface IAdminConfigManageService
    {
        CfgAreaListGetResult R2R_UI_Config_AreaListGet(string strServerAddress, string requestId, string userId, string clientVersion);
        CfgAdminGetResult R2R_UI_Config_AdminConfigGet(string strServerAddress, string requestId, string userId, string clientVersion, double tableIndex,  string userGroup, string Product, string ProductGroup, string UIConfig, string PriorityLevel);
        //CfgAdminGetResult R2R_UI_Config_AdminConfigGet(string strServerAddress, string requestId, string userName, string clientVersion, double tableIndex, string userId, string userGroup, string Product, string ProductGroup, string UIConfig, string PriorityLevel);
        CfgUpdateResult R2R_UI_Config_UserGroupSave(string strServerAddress, string requestId, string userName, string clientVersion, string cfgArea, string[] addUserId, string[] addUserGroup, string[] deleteUserId, string[] deleteUserGroup);
        CfgUpdateResult R2R_UI_Config_ProductGroupSave(string strServerAddress, string requestId, string userName, string clientVersion, string cfgArea, string[] addProduct, string[] addProductGroup, string[] modifyProduct, string[] modifyProductGroup, string[] deleteProduct, string[] deleteProductGroup);
        CfgUpdateResult R2R_UI_Config_PriorityLevelSave(string strServerAddress, string requestId, string userName, string clientVersion, string cfgArea, string[] addUserGroup, string[] addProductGroup, string[] addUIConfig, string[] addPriorityLevel, string[] modifyUserGroup, string[] modifyProductGroup, string[] modifyUIConfig, string[] modifyPriorityLevel, string[] deleteUserGroup, string[] deleteProductGroup, string[] deleteUIConfig, string[] deletePriorityLevel);
        CfgAccessControlResult R2R_UI_Config_AccessControlCheck(string strServerAddress, string requestId, string userName, string clientVersion, double tableIndex, string userId, string userGroup, string Product, string ProductGroup, string UIConfig, string PriorityLevel, string OptAction, string QueryTime, bool isCheckOnly);
        bool R2R_UI_Config_ClearAdminOccupy(string strServerAddress, string requestId, string userId, string clientVersion, string uiConfig);
    }
}
