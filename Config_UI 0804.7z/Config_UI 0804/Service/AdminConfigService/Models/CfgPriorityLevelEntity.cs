﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminConfigService.Models
{
    public class CfgPriorityLevelEntity
    {
        public string UserGroup { get; set; }
        public string ProductGroup { get; set; }
        public string UIConfig { get; set; }
        public string PriorityLevel { get; set; }
        public string Action { get; set; }
        //public List<string> UIConfigList { get; set; } = new List<string>() { "LITHO" };
        //public List<string> PriorityLevelList { get; set; } = new List<string>() {"Edit","View" };
        //public string LastSaveBy { get; set; }
        //public string LastSaveTime { get; set; }
        //public string OccupiedBy { get; set; }
        //public string OccupyTime { get; set; }
    }
}
