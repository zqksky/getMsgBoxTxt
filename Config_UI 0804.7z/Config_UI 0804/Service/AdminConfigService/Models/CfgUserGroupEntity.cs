﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminConfigService.Models
{
    public class CfgUserGroupEntity
    {
        public string UserId { get; set; }
        public string UserGroup { get; set; }
        public string Action { get; set; }
        //public string LastSaveBy { get; set; }
        //public string LastSaveTime { get; set; }
        //public string OccupiedBy { get; set; }
        //public string OccupyTime { get; set; }
    }
}
