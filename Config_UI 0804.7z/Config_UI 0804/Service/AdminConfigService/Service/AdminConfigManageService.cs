﻿using AdminConfigService.IService;
using R2R.Common.Data;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdminConfigService.Service
{
    public class AdminConfigManageService : IAdminConfigManageService
    {
        public CfgAreaListGetResult R2R_UI_Config_AreaListGet(string strServerAddress, string requestId, string userId, string clientVersion)
        {
            CfgAreaListGetResult result = new CfgAreaListGetResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion));

            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserName", userId);
            arguDic.Add("ClientVersion", clientVersion);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                //{
                string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_AreaListGet, arguDic, strServerAddress);
                if (strResult.Equals("error"))
                {
                    return null;
                }
                result = JsonHelp.DeserializeJsonToObject<CfgAreaListGetResult>(strResult);
                if (result == null)
                {
                    return null;
                }

                MyLogger.Trace("Reply :: " +
                               string.Format("RequestId<{0}>", result.RequestId) +
                               string.Format("ReturnCode<{0}>", result.ReturnCode) +
                               string.Format("ReturnText<{0}>", result.ReturnText) +
                               string.Format("Area_Content<{0}>", result.Area_Content));
                //if (!result.ReturnCode.Equals("-1"))
                //{
                return result;
                //}
                //}
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }

        public CfgAdminGetResult R2R_UI_Config_AdminConfigGet(string strServerAddress, string requestId, string userId, string clientVersion, double tableIndex, string userGroup, string Product, string ProductGroup, string UIConfig, string PriorityLevel)
        {
            CfgAdminGetResult result = new CfgAdminGetResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("TableIndex<{0}>", tableIndex) +
                           string.Format("UserGroup<{0}>", userGroup) +
                           string.Format("Product<{0}>", Product) +
                           string.Format("ProductGroup<{0}>", ProductGroup) +
                           string.Format("UI_Config<{0}>", UIConfig) +
                           string.Format("PriorityLevel<{0}>", PriorityLevel));

            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("TableIndex", tableIndex);
            arguDic.Add("UserGroup", userGroup);
            arguDic.Add("Product", Product);
            arguDic.Add("ProductGroup", ProductGroup);
            arguDic.Add("UI_Config", UIConfig);
            arguDic.Add("PriorityLevel", PriorityLevel);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                //{
                string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_AdminConfigGet, arguDic, strServerAddress);
                if (strResult.Equals("error"))
                {
                    return null;
                }
                result = JsonHelp.DeserializeJsonToObject<CfgAdminGetResult>(strResult);
                if (result == null)
                {
                    return null;
                }

                MyLogger.Trace("Reply :: " +
                               string.Format("Result<{0}>", strResult));
                //string.Format("IsOutputNull<{0}>", result.IsOutputNull) +
                //string.Format("PriorityLevel<{0}>", result.PriorityLevel) +
                //string.Format("Product<{0}>", result.Product) +
                //string.Format("ProductGroup<{0}>", result.ProductGroup) +
                //string.Format("UI_Config<{0}>", result.UI_Config) +
                //string.Format("UserGroup<{0}>", result.UserGroup) +
                //string.Format("UserID<{0}>", result.UserID));
                //if (!result.ReturnCode.Equals("-1"))
                //{
                return result;
                //}
                //}
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }

        public CfgUpdateResult R2R_UI_Config_UserGroupSave(string strServerAddress, string requestId, string userName, string clientVersion,string cfgArea, string[] addUserId, string[] addUserGroup, string[] deleteUserId, string[] deleteUserGroup)
        {
            CfgUpdateResult result = new CfgUpdateResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("userName<{0}>", userName) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Area<{0}>", cfgArea) +
                           string.Format("UserID_Add<{0}>", JsonHelp.SerializeObject(addUserId)) +
                           string.Format("UserGroup_Add<{0}>", JsonHelp.SerializeObject(addUserGroup)) +
                           string.Format("UserID_Delete<{0}>", JsonHelp.SerializeObject(deleteUserId)) +
                           string.Format("UserGroup_Delete<{0}>", JsonHelp.SerializeObject(deleteUserGroup)));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserName", userName);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("UI_Config", cfgArea);
            arguDic.Add("UserID_Add", addUserId);
            arguDic.Add("UserGroup_Add", addUserGroup);
            arguDic.Add("UserID_Delete", deleteUserId);
            arguDic.Add("UserGroup_Delete", deleteUserGroup);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                //{
                string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_UserGroupSave, arguDic, strServerAddress);
                if (strResult.Equals("error"))
                {
                    return null;
                }
                result = JsonHelp.DeserializeJsonToObject<CfgUpdateResult>(strResult);
                if (result == null)
                {
                    return null;
                }

                MyLogger.Trace("Reply :: " +
                                string.Format("RequestId<{0}>", result.RequestId) +
                                string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                string.Format("ReturnText<{0}>", result.ReturnText));
                if (!result.ReturnCode.Equals("-1"))
                {
                    return result;
                }
                //}
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }

        public CfgUpdateResult R2R_UI_Config_ProductGroupSave(string strServerAddress, string requestId, string userName, string clientVersion, string cfgArea, string[] addProduct, string[] addProductGroup, string[] modifyProduct, string[] modifyProductGroup, string[] deleteProduct, string[] deleteProductGroup)
        {
            CfgUpdateResult result = new CfgUpdateResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("userName<{0}>", userName) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Area<{0}>", cfgArea) +
                           string.Format("Product_Add<{0}>", JsonHelp.SerializeObject(addProduct)) +
                           string.Format("ProductGroup_Add<{0}>", JsonHelp.SerializeObject(addProductGroup)) +
                           string.Format("Product_Modify<{0}>", JsonHelp.SerializeObject(modifyProduct)) +
                           string.Format("ProductGroup_Modify<{0}>", JsonHelp.SerializeObject(modifyProductGroup)) +
                           string.Format("Product_Delete<{0}>", JsonHelp.SerializeObject(deleteProduct)) +
                           string.Format("ProductGroup_Delete<{0}>", JsonHelp.SerializeObject(deleteProductGroup)));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserName", userName);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("UI_Config", cfgArea);
            arguDic.Add("Product_Add", addProduct);
            arguDic.Add("ProductGroup_Add", addProductGroup);
            arguDic.Add("Product_Modify", modifyProduct);
            arguDic.Add("ProductGroup_Modify", modifyProductGroup);
            arguDic.Add("Product_Delete", deleteProduct);
            arguDic.Add("ProductGroup_Delete", deleteProductGroup);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                //{
                string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_ProductGroupSave, arguDic, strServerAddress);
                if (strResult.Equals("error"))
                {
                    return null;
                }
                result = JsonHelp.DeserializeJsonToObject<CfgUpdateResult>(strResult);
                if (result == null)
                {
                    return null;
                }

                MyLogger.Trace("Reply :: " +
                                string.Format("RequestId<{0}>", result.RequestId) +
                                string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                string.Format("ReturnText<{0}>", result.ReturnText));
                if (!result.ReturnCode.Equals("-1"))
                {
                    return result;
                }
                //}
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }

        public CfgUpdateResult R2R_UI_Config_PriorityLevelSave(string strServerAddress, string requestId, string userName, string clientVersion, string cfgArea, string[] addUserGroup, string[] addProductGroup, string[] addUIConfig, string[] addPriorityLevel, string[] modifyUserGroup, string[] modifyProductGroup, string[] modifyUIConfig, string[] modifyPriorityLevel, string[] deleteUserGroup, string[] deleteProductGroup, string[] deleteUIConfig, string[] deletePriorityLevel)
        {
            CfgUpdateResult result = new CfgUpdateResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("userName<{0}>", userName) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Area<{0}>", cfgArea) +
                           string.Format("UserGroup_Add<{0}>", JsonHelp.SerializeObject(addUserGroup)) +
                           string.Format("ProductGroup_Add<{0}>", JsonHelp.SerializeObject(addProductGroup)) +
                           string.Format("UI_Config_Add<{0}>", JsonHelp.SerializeObject(addUIConfig)) +
                           string.Format("PriorityLevel_Add<{0}>", JsonHelp.SerializeObject(addPriorityLevel)) +
                           string.Format("UserGroup_Modify<{0}>", JsonHelp.SerializeObject(modifyUserGroup)) +
                           string.Format("ProductGroup_Modify<{0}>", JsonHelp.SerializeObject(modifyProductGroup)) +
                           string.Format("UI_Config_Modify<{0}>", JsonHelp.SerializeObject(modifyUIConfig)) +
                           string.Format("PriorityLevel_Modify<{0}>", JsonHelp.SerializeObject(modifyPriorityLevel)) +
                           string.Format("UserGroup_Delete<{0}>", JsonHelp.SerializeObject(deleteUserGroup)) +
                           string.Format("ProductGroup_Delete<{0}>", JsonHelp.SerializeObject(deleteProductGroup)) +
                           string.Format("UI_Config_Delete<{0}>", JsonHelp.SerializeObject(deleteUIConfig)) +
                           string.Format("PriorityLevel_Delete<{0}>", JsonHelp.SerializeObject(deletePriorityLevel)));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserName", userName);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("UI_Config", cfgArea);
            arguDic.Add("UserGroup_Add", addUserGroup);
            arguDic.Add("ProductGroup_Add", addProductGroup);
            arguDic.Add("UI_Config_Add", addUIConfig);
            arguDic.Add("PriorityLevel_Add", addPriorityLevel);
            arguDic.Add("UserGroup_Modify", modifyUserGroup);
            arguDic.Add("ProductGroup_Modify", modifyProductGroup);
            arguDic.Add("UI_Config_Modify", modifyUIConfig);
            arguDic.Add("PriorityLevel_Modify", modifyPriorityLevel);
            arguDic.Add("UserGroup_Delete", deleteUserGroup);
            arguDic.Add("ProductGroup_Delete", deleteProductGroup);
            arguDic.Add("UI_Config_Delete", deleteUIConfig);
            arguDic.Add("PriorityLevel_Delete", deletePriorityLevel);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                //{
                string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_PriorityLevelSave, arguDic, strServerAddress);
                if (strResult.Equals("error"))
                {
                    return null;
                }
                result = JsonHelp.DeserializeJsonToObject<CfgUpdateResult>(strResult);
                if (result == null)
                {
                    return null;
                }

                MyLogger.Trace("Reply :: " +
                                string.Format("RequestId<{0}>", result.RequestId) +
                                string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                string.Format("ReturnText<{0}>", result.ReturnText));
                if (!result.ReturnCode.Equals("-1"))
                {
                    return result;
                }
                //}
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }

        public CfgAccessControlResult R2R_UI_Config_AccessControlCheck(string strServerAddress, string requestId, string userName, string clientVersion, double tableIndex, string userId, string userGroup, string Product, string ProductGroup, string UIConfig, string PriorityLevel, string OptAction, string QueryTime, bool isCheckOnly)
        {
            CfgAccessControlResult result = new CfgAccessControlResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClienetVersion<{0}>", clientVersion) +
                           string.Format("TableIndex<{0}>", tableIndex) +
                           string.Format("UserID<{0}>", userId) +
                           string.Format("UserGroup<{0}>", userGroup) +
                           string.Format("Product<{0}>", Product) +
                           string.Format("ProductGroup<{0}>", ProductGroup) +
                           string.Format("UI_Config<{0}>", UIConfig) +
                           string.Format("Priority_Level<{0}>", PriorityLevel) +
                           string.Format("Opt_Action<{0}>", OptAction) +
                           string.Format("Query_Time<{0}>", QueryTime) +
                           string.Format("IsCheckOnly<{0}>", isCheckOnly));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserName", userName);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("TableIndex", tableIndex);
            arguDic.Add("UserID", userId);
            arguDic.Add("UserGroup", userGroup);
            arguDic.Add("Product", Product);
            arguDic.Add("ProductGroup", ProductGroup);
            arguDic.Add("UI_Config", UIConfig);
            arguDic.Add("Priority_Level", PriorityLevel);
            arguDic.Add("Opt_Action", OptAction);
            arguDic.Add("Query_Time", QueryTime);
            arguDic.Add("IsCheckOnly", isCheckOnly);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                //{
                string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_AccessControlCheck, arguDic, strServerAddress);
                if (strResult.Equals("error"))
                {
                    return null;
                }
                result = JsonHelp.DeserializeJsonToObject<CfgAccessControlResult>(strResult);
                if (result == null)
                {
                    return null;
                }

                MyLogger.Trace("Reply :: " +
                                string.Format("RequestId<{0}>", result.RequestId) +
                                string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                string.Format("ReturnText<{0}>", result.ReturnText));
                if (!result.ReturnCode.Equals("-1"))
                {
                    return result;
                }
                //}
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }
        // <summary>
        /// Invoke R2R_UI_Config_ClearAdminOccupy webservice Fun
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="uiConfig"></param>
        /// <returns></returns>
        public bool R2R_UI_Config_ClearAdminOccupy(string strServerAddress, string requestId, string userId, string clientVersion, string uiConfig)
        {
            bool flag = false;
            CfgUpdateResult result = new CfgUpdateResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("UI_Config", uiConfig);
            try
            {
                //WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_ClearAdminOccupy, arguDic, strServerAddress);

                ////if (!CommonHelp.ArgumentIsNull(arguDic))
                string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_ClearAdminOccupy, arguDic, strServerAddress);
                if (strResult.Equals("error"))
                {
                    string strMsg = "Invoke R2R_UI_Config_ClearAdminOccupy Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return false;
                }
                result = JsonHelp.DeserializeJsonToObject<CfgUpdateResult>(strResult);
                if (result == null)
                {
                    return false;
                }

                MyLogger.Trace("Reply :: " +
                                string.Format("RequestId<{0}>", result.RequestId) +
                                string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                string.Format("ReturnText<{0}>", result.ReturnText));
                if (result.ReturnCode.Equals("0"))
                {
                    flag = true;
                }
                else if (result.ReturnCode.Equals("-1"))
                {
                    System.Windows.Forms.MessageBox.Show(result.ReturnText);
                    flag = false;
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return flag;
        }
    }
}
