﻿using LoginService.IService;
using LoginService.Models;
using R2R.Common.Data;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Linq;

namespace LoginService.Service
{
    public class LoginManageService : ILoginManageService
    {
        /// <summary>
        /// Invoke Login webservice Fun
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <param name="domainName"></param>
        /// <returns></returns>
        public CfgLoginResult R2R_UI_Config_Login(string requestId, string clientVersion, string userId, string password, string domainName, string strServerAddress)
        {
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId)+
                           string.Format("ClientVersion<{0}>", clientVersion)+
                           string.Format("UserID<{0}>", userId)+
                           string.Format("Password<{0}>", password)+
                           string.Format("DomainName<{0}>", domainName)+
                           string.Format("AppType<{0}>", "R2R_ModelConfig")+
                           string.Format("AutoLogin<{0}>", false));
            CfgLoginResult result = new CfgLoginResult();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("UserID", userId);
            arguDic.Add("Password", password);
            arguDic.Add("DomainName", domainName);
            arguDic.Add("AppType", "R2R_ModelConfig");
            arguDic.Add("AutoLogin", false);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_Login, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgLoginResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText)+
                                    string.Format("IsAdminConfig<{0}>", result.IsAdminConfig));
                    if (!result.ReturnCode.Equals("-1"))
                    {
                        return result;
                    }
                    else
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }

        #region 获取xml文件中的数据
        /// <summary>
        /// Get ClientInfo from config file
        /// </summary>
        /// <param name="xmlPath"></param>
        /// <returns></returns>
        public ClientInfoValue GetClientInfoConfig(string xmlPath)
        {
            MyLogger.Trace("Input:: " +
                           string.Format("XmlPath<{0}>", xmlPath));

            ClientInfoValue clientInfo = new ClientInfoValue();
            try
            {
                XElement xe = XElement.Load(xmlPath);

                IEnumerable<XElement> elements = from ele in xe.Elements("Config").Elements("ClientInfoConfig").Elements("ClientInfo")
                                                 select ele;

                foreach (var ele in elements)
                {
                    string strKey;
                    string strValue;
                    strKey = ele.Attribute("Key").Value;
                    strValue = ele.Attribute("Value").Value;

                    if (strKey.Equals("ClientVersion"))
                    {
                        clientInfo.ClientVersion = strValue;
                    }
                    //else if (strKey.Equals("UserId"))
                    //{
                    //    clientInfo.UesrId = strValue;
                    //}
                    else if (strKey.Equals("RequestId"))
                    {
                        clientInfo.RequestId = strValue;
                    }
                }
                string strJson = JsonHelp.SerializeObject(clientInfo);
                MyLogger.Trace("Return:: " +
                           string.Format("ClientInfo<{0}>", strJson));
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }

            return clientInfo;
        }
        /// <summary>
        /// Get Resend Xml Value from config file
        /// </summary>
        /// <param name="xmlPath"></param>
        /// <returns></returns>
        public List<string> GetResendXmlConfig(string xmlPath)
        {
            MyLogger.Trace("Input:: " +
                           string.Format("XmlPath<{0}>", xmlPath));

            List<string> strList = new List<string>();
            try
            {
                XElement xe = XElement.Load(xmlPath);

                IEnumerable<XElement> elements = from ele in xe.Elements("Config").Elements("ResendConfig").Elements("StrConfig")
                                                 select ele;

                foreach (var ele in elements)
                {
                    string strKey;
                    string strValue;

                    strKey = ele.Attribute("Key").Value;
                    strValue = ele.Attribute("Value").Value;

                    strList.Add(strValue);
                }
                string strJson = JsonHelp.SerializeObject(strList);
                MyLogger.Trace("Return:: " +
                           string.Format("ResendConfig<{0}>", strJson));
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }

            return strList;
        }
        /// <summary>
        /// Get Domain Name from config file
        /// </summary>
        /// <param name="xmlPath"></param>
        /// <returns></returns>
        public List<string> GetDomainName(string xmlPath)
        {
            MyLogger.Trace("Input:: " +
                          string.Format("XmlPath<{0}>", xmlPath));

            List<string> strList = new List<string>();

            try
            {
                XElement xe = XElement.Load(xmlPath);

                IEnumerable<XElement> elements = from ele in xe.Elements("Config").Elements("DomainConfig").Elements("DomainName")
                                                 select ele;

                foreach (var ele in elements)
                {
                    string strKey;
                    string strValue;

                    strKey = ele.Attribute("Key").Value;
                    //strValue = ele.Attribute("Value").Value;

                    //if (ele.LastAttribute.Name == "VALUE_TXT")
                    //{
                    //    strValue += ";" + ele.Attribute("VALUE_TXT").Value;
                    //}
                    //MessageBox.Show("strKey=" + strKey + "; strValue=" + strValue);

                    strList.Add(strKey);
                }
                string strJson = JsonHelp.SerializeObject(strList);
                MyLogger.Trace("Return:: " +
                           string.Format("DomainName<{0}>", strJson));
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }

            return strList;
        }
        /// <summary>
        /// Get ServerAddress from config file
        /// </summary>
        /// <param name="xmlPath"></param>
        /// <returns></returns>
        public List<ServerAddressInfo> GetServerAddress(string xmlPath)
        {
            MyLogger.Trace("Input:: " +
                          string.Format("XmlPath<{0}>", xmlPath));

            List<ServerAddressInfo> infoList = new List<ServerAddressInfo>();
            try
            {
                XElement xe = XElement.Load(xmlPath);

                IEnumerable<XElement> elements = from ele in xe.Elements("Config").Elements("ServerConfig").Elements("ServerAddress")
                                                 select ele;

                foreach (var ele in elements)
                {
                    ServerAddressInfo info = new ServerAddressInfo();

                    info.Name = ele.Attribute("Key").Value;
                    info.Server = ele.Attribute("Value").Value;
                    info.Value = info.Server.Substring(0,info.Server.LastIndexOf(":"));

                    //if (ele.LastAttribute.Name == "VALUE_TXT")
                    //{
                    //    info.Name += ";" + ele.Attribute("VALUE_TXT").Value;
                    //}
                    //MessageBox.Show("strKey=" + info.Name + "; strValue=" + info.Value);

                    infoList.Add(info);
                }
                string strJson = JsonHelp.SerializeObject(infoList);
                MyLogger.Trace("Return:: " +
                           string.Format("ServerAddress<{0}>", strJson));
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }

            return infoList;
        }
        #endregion
    }
}
