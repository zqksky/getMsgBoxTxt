﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginService.Models
{
    public class ServerAddressInfo
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public string Server { get; set; }
    }
}
