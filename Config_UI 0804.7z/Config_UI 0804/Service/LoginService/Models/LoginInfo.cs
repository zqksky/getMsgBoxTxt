﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginService.Models
{
    public class LoginInfo
    {
        public int LoginState;
        public bool IsAdminConfig;
        public string DomainName;
        public string Password;
        public string ServerAddress;
        public string ServerName;
        public string UserId;
        public string RequestId;
        public string ClientVersion;
    }
}
