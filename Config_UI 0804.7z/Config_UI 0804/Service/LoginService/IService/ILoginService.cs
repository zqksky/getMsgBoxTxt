﻿using LoginService.Models;
using R2R.Common.Data.CommonEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginService.IService
{
    public interface ILoginManageService
    {
        CfgLoginResult R2R_UI_Config_Login(string requestId, string clientVersion, string userId, string password, string domainName, string strServerAddress);
        ClientInfoValue GetClientInfoConfig(string xmlPath);
        List<string> GetResendXmlConfig(string xmlPath);
        List<string> GetDomainName(string xmlPath);
        List<ServerAddressInfo> GetServerAddress(string xmlPath);
    }
}
