﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class CompareInitEntity
    {
        public string Context { get; set; }
        public string ParameterName { get; set; }
        public string VersionA_Add { get; set; }
        public string VersionA_Modify { get; set; }
        public string VersionA_Delete { get; set; }
        public string VersionB_Add { get; set; }
        public string VersionB_Modify { get; set; }
        public string VersionB_Delete { get; set; }
        public string Result { get; set; }

        public string VersionA_NoChange { get; set; }
        public string VersionB_NoChange { get; set; }
    }
}
