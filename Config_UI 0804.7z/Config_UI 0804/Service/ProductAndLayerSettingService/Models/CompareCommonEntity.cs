﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class CompareCommonEntity
    {
        public string Context { get; set; }
        public string VersionA { get; set; }
        public string VersionB { get; set; }
        public string Result { get; set; }
    }
}
