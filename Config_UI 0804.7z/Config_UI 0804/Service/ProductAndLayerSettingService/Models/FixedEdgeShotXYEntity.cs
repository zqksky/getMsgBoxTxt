﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class FixedEdgeShotXYEntity : INotifyPropertyChanged
    {
        #region Properties
        private bool _IsClickEnable;
        public bool IsClickEnable
        {
            get { return _IsClickEnable; }
            set
            {
                _IsClickEnable = value;
                OnPropertyChanged();
            }
        }

        private string _BtnName;
        public string BtnName
        {
            get { return _BtnName; }
            set
            {
                _BtnName = value;
                OnPropertyChanged();
            }
        }

        private string _BtnTag;
        public string BtnTag
        {
            get { return _BtnTag; }
            set
            {
                _BtnTag = value;
                OnPropertyChanged();
            }
        }

        private string _BtnValue;
        public string BtnValue
        {
            get { return _BtnValue; }
            set
            {
                _BtnValue = value;
                OnPropertyChanged();
            }
        }

        private string _BtnHeight;
        public string BtnHeight
        {
            get { return _BtnHeight; }
            set
            {
                _BtnHeight = value;
                OnPropertyChanged();
            }
        }

        private string _BtnWidth;
        public string BtnWidth
        {
            get { return _BtnWidth; }
            set
            {
                _BtnWidth = value;
                OnPropertyChanged();
            }
        }

        private string _BtnOpacity;
        public string BtnOpacity
        {
            get { return _BtnOpacity; }
            set
            {
                _BtnOpacity = value;
                OnPropertyChanged();
            }
        }

        private string _BtnColor;
        public string BtnColor
        {
            get { return _BtnColor; }
            set
            {
                _BtnColor = value;
                OnPropertyChanged();
            }
        }
        #endregion //Properties

        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName]string propertyname = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }

        #endregion //INotifyPropertyChanged
    }
}
