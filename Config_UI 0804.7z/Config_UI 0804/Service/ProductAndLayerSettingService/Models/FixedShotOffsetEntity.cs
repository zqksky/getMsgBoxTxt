﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class FixedShotOffsetEntity
    {
        public string PRODUCT { get; set; }
        public string LAYER { get; set; }
        public string TOOL_GROUP { get; set; }
        public string TOOL { get; set; }
        public string PRE_TOOL { get; set; }
        public string RETICLE { get; set; }
        public string PRE_RETICLE { get; set; }
        public string CPE_MODE { get; set; }
        public string STEP_SIZE_X { get; set; }
        public string STEP_SIZE_Y { get; set; }
        public string SHOT_OFFSET_X { get; set; }
        public string SHOT_OFFSET_Y { get; set; }
        public string SHOT_POSITION_X { get; set; }
        public string SHOT_POSITION_Y { get; set; }
        public string TRANSLATION_X { get; set; }
        public string TRANSLATION_Y { get; set; }
        public string ROTATION { get; set; }
        public string MAGNIFICATION { get; set; }
        public string ASYM_ROTATION { get; set; }
        public string ASYM_MAGNIFICATION { get; set; }
        public string SECOND_ORDER_EXPANSION_X { get; set; }
        public string SECOND_ORDER_EXPANSION_Y { get; set; }
        public string TRAPEZOID_X { get; set; }
        public string TRAPEZOID_Y { get; set; }
        public string BOW_X { get; set; }
        public string BOW_Y { get; set; }
        public string THIRD_ORDER_EXPANSION_X { get; set; }
        public string THIRD_ORDER_EXPANSION_Y { get; set; }
        public string ACCORDION_X { get; set; }
        public string ACCORDION_Y { get; set; }
        public string CSHAPE_DISTORTION_X { get; set; }
        public string CSHAPE_DISTORTION_Y { get; set; }
        public string HIRD_ORDER_FLOW_X { get; set; }

    }
}
