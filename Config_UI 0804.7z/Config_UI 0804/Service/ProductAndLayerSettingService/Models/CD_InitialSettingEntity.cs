﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class CD_InitialSettingEntity
    {
        public string Product { get; set; }
        public string Layer { get; set; }
        public string ToolGroup { get; set; }
        public string Tool { get; set; }
        public string Reticle { get; set; }
        public string Parameter { get; set; }
        public string R2RMode { get; set; }
        public string FocusValue { get; set; }
        public string DoseValue { get; set; }
        public string DoseSensitivity { get; set; }
        public List<string> R2RModeList { get; set; }
        public List<string> ToolList { get; set; }
    }
}
