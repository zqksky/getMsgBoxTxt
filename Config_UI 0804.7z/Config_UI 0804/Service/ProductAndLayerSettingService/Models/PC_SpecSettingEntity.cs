﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class PC_SpecSettingEntity
    {
        public string Type { get; set; }
        public string Parameter { get; set; }
        public string Select { get; set; }
        public string Max_Delta { get; set; }
        public string Deadband { get; set; }
        public string USL_Calc { get; set; }
        public string LSL_Calc { get; set; }
        public string USL_Metro { get; set; }
        public string LSL_Metro { get; set; }
        public List<string> SelectList { get; set; }
    }
}
