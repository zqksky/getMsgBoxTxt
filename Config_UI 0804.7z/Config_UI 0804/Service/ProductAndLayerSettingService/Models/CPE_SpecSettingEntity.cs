﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class CPE_SpecSettingEntity
    {
        public string CPE_Type { get; set; }
        public string Parameter { get; set; }
        public string Max_Delta { get; set; }
        public string USL { get; set; }
        public string LSL { get; set; }
    }
}
