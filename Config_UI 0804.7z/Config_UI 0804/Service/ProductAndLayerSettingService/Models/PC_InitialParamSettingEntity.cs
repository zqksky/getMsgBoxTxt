﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class PC_InitialParamSettingEntity
    {
        public string Mode { get; set; }
        public string Parameter { get; set; }
        public string Chuck1 { get; set; }
        public string Chuck2 { get; set; }
    }
}
