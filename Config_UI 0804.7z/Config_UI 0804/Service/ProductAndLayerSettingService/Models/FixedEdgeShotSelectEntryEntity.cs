﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class FixedEdgeShotSelectEntryEntity
    {
        public bool IsSelect { get; set; }
        public string EntryName { get; set; }
    }
}
