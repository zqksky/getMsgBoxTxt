﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class ProductSettingEntity
    {
        public string Product { get; set; }
        public string Layer { get; set; }
        public string ToolGroup { get; set; }
        //public string ToolVendor{ get; set; }
        public string AlignmentLayer { get; set; }
        public string AlignmentMethod { get; set; }
        public string PreLayer1 { get; set; }
        public string PreLayer2 { get; set; }
        public string ControlByChuck { get; set; }
        public string ChuckDedication { get; set; }
        public string ChuckDedicationLayer { get; set; }
        public string CascadePCLayer { get; set; }
        public string CascadeCPELayer { get; set; }
    }
}
