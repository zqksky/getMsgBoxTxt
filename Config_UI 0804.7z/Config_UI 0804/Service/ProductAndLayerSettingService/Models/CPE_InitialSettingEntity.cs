﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class CPE_InitialSettingEntity
    {
        public string PRODUCT { get; set; }
        public string LAYER { get; set; }
        public string TOOL_GROUP { get; set; }
        public string TOOL { get; set; }
        public string RETICLE { get; set; }
        public string PRE_TOOL { get; set; }
        public string PRE_RETICLE { get; set; }
        public string INIT_PARAMETER_NAME { get; set; }
        public string CPESubRecipe { get; set; }
        public string CPEModelTimeStamp { get; set; }

        public List<string> ToolList { get; set; }
        public List<string> ReticleList { get; set; }
        public List<string> PreToolList { get; set; }
        public List<string> PreReticleList { get; set; }
    }
}
