﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class SendWaferModeParam
    {
        public string ScannerGrop { get; set; }
        public string Mode { get; set; }

        #region LIS
        public string LIS_UPDATE_TIME { get; set; }
        public string LIS_UPDATE_LOT { get; set; }
        public string SPARSE_SAMPLING { get; set; }
        public string DENSE_SAMPLING { get; set; }
        public string EST_SPARSE_RECIPE { get; set; }
        public string EST_DENSE_RECIPE { get; set; }
        public string OPTIMIZE_RECIPE { get; set; }
        public string SAMPLING_TOOLTYPE { get; set; }
        public string ESTI_KPI_OCAP { get; set; }
        public string EXCEPTION_CNT { get; set; }
        public string EXCEPTION_THRESHOLD { get; set; }
        #endregion

        #region OVL PC
        public string OVLPCSpecVarName { get; set; }
        public string OVLPCSpecMaxDelta { get; set; }
        public string OVLPCDeadband { get; set; }
        public string OVLPCUslCalc { get; set; }
        public string OVLPCLslCalc { get; set; }
        public string OVLPCUslMetro { get; set; }
        public string OVLPCLslMetro { get; set; }
        public string OVLPCExpireTime { get; set; }
        public string OVLPCLumda { get; set; }
        public string OVLPCUpdateTime { get; set; }
        public string OVLPCUpdateLot { get; set; }
        public string OVLPCFeedforeward { get; set; }
        #endregion

        #region OVL CPE
        public string OVLCPESpecVarName { get; set; }
        public string OVLCPESpecMaxDelta { get; set; }
        public string OVLCPEUslCalc { get; set; }
        public string OVLCPELslCalc { get; set; }
        public string OVLCPEExpireTime { get; set; }
        public string OVLCPELumda { get; set; }
        public string OVLCPEUpdateTime { get; set; }
        public string OVLCPEUpdateLot { get; set; }
        public string OVLCPEFeedforeward { get; set; }
        public string OVLCPEFixEdge { get; set; }
        #endregion
    }
}
