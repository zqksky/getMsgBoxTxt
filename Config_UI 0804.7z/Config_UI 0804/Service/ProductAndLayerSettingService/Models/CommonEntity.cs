﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class CommonEntity
    {
        public string PRODUCT { get; set; }
        public string LAYER { get; set; }
        public string TOOL_GROUP { get; set; }
        public string ALIGMENT_LAYER { get; set; }
        public string ALIAMENT_METHOD { get; set; }
        public string OVERLAY_LAYER { get; set; }
        public string CONTROL_BY_CHUCK { get; set; }
        public string CHUCK_DEDICATION { get; set; }
        public string CHUCK_DEDICATION_LAYER { get; set; }
        public string CASCADE_PC_LAYER { get; set; }
        public string CASCADE_CPE_LAYER { get; set; }
        public string PRELAYER_2 { get; set; }
        public string CD_R2R_MODE { get; set; }
        public string CD_TARGET { get; set; }
        public string DOSE_SENSITIVITY { get; set; }
        public string CD_EXPIRE_TIME { get; set; }
        public string DOSE_MAX_DELTA { get; set; }
        public string DOSE_USL { get; set; }
        public string DOSE_LSL { get; set; }
        public string CD_LUMDA { get; set; }
        public string OVL_PC_R2R_MODE { get; set; }
        public string OVL_PC_OVL_MODE { get; set; }
        public string OVL_PC_SPEC_VARNAME { get; set; }
        public string OVL_PC_SPEC_MAX_DELTA { get; set; }
        public string OVL_PC_DEADBAND { get; set; }
        public string OVL_PC_USL_CALC { get; set; }
        public string OVL_PC_LSL_CALC { get; set; }
        public string OVL_PC_USL_METRO { get; set; }
        public string OVL_PC_LSL_METRO { get; set; }
        public string OVL_PC_EXPIRE_TIME { get; set; }
        public string OVL_PC_LUMDA { get; set; }
        public string OVL_PC_UPDATE_TIME { get; set; }
        public string OVL_PC_UPDATE_LOT { get; set; }
        public string OVL_CPE_R2R_MODE { get; set; }
        public string OVL_CPE_OVL_MODE { get; set; }
        public string OVL_CPE_SPEC_VARNAME { get; set; }
        public string OVL_CPE_SPEC_MAX_DELTA { get; set; }
        public string OVL_CPE_USL_CALC { get; set; }
        public string OVL_CPE_LSL_CALC { get; set; }
        public string OVL_CPE_EXPIRE_TIME { get; set; }
        public string OVL_CPE_LUMDA { get; set; }
        public string OVL_CPE_UPDATE_TIME { get; set; }
        public string OVL_CPE_UPDATE_LOT { get; set; }
        public string LIST_TOOL { get; set; }
        public string LIST_RETICLE { get; set; }
        public string OVL_PC_FEEDFOREWARD { get; set; }
        public string OVL_CPE_FEEDFOREWARD { get; set; }
        public string OVL_CPE_FIX_EDGE { get; set; }
        public string LIST_PRE_TOOL { get; set; }
        public string LIST_PRE_RETICLE { get; set; }
        public string OVL_PC_SPEC_VAR_SELECT { get; set; }
        public string TOOL_VENDOR { get; set; }
        public string OVL_PC_DYNAMIC_CONTEXT { get; set; }
        public string OVL_CPE_DYNAMIC_CONTEXT { get; set; }
        public string OVL_PC_OOC_COUNT { get; set; }
        public string OVL_PC_OOS_COUNT { get; set; }
        public string OVL_CPE_OOC_COUNT { get; set; }
        public string OVL_CPE_OOS_COUNT { get; set; }
    }
}
