﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.Models
{
    public class FixedEdgeShotSettingEntity
    {
        public string Field_Index_X { get; set; }
        public string Field_Index_Y { get; set; }
        public string TermName { get; set; }
        public string TermValue { get; set; }
    }
}
