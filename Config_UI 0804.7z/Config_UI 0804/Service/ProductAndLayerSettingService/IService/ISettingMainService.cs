﻿using R2R.Common.Data.CommonEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSettingService.IService
{
    public interface ISettingMainService
    {
        CfgGetFixedEdgeShotResult R2R_UI_Config_GetFixedEdgeShot(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup);
        CfgUpdateResult R2R_UI_Config_FixedEdgeShotSave(string strServerAddress, string requestId, string userId, string clientVersion, string Fixed_Edge_Shot_Content_Add, string Fixed_Edge_Shot_Content_Modify, string Fixed_Edge_Shot_Content_Delete);
        CfgUpdateResult R2R_UI_Config_UpdateValidation(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string UIConfig, string catchFlag, string catchReason);
        CfgGetVersionListResult R2R_UI_Config_GetVersionList(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string UIConfig);
        CfgGetLatestResult R2R_UI_Config_GetLatestConfig(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string UIConfig);
        CfgGetHistoryConfigResult R2R_UI_Config_GetHistoryConfig(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string versionA, string versionB);
        CfgEditStatusCheckResult R2R_UI_Config_EditStatusCheck(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string queryTime, bool isCheckOnly, string uiConfig, string action, string currentMode);
        bool R2R_UI_Config_ClearEditOccupy(string strServerAddress, string requestId, string userId, string clientVersion, string uiConfig);
        CfgGetContextValuesResult R2R_UI_Config_PH_Get_ContextValues(string strServerAddress, string requestId, string userId, string clienetVersion);
        CfgUpdateResult R2R_UI_Config_PH_CopyProduct(string strServerAddress, string requestId, string userId, string clientVersion, string fromProduct, string toProduct, string fromLayer, string toLayer, bool isCheckOnly);
        CfgGetCommonResult R2R_UI_Config_PH_Get_CONFIG_COMMON(string strServerAddress, string requestId, string userId, string clienetVersion, string product, string layer, string toolGroup);
        CfgGetInitCDResult R2R_UI_Config_PH_Get_CONFIG_INIT_CD(string strServerAddress, string requestId, string userId, string clienetVersion, string product, string layer, string toolGroup, string toolVendor, string Content_R2R_PH_CONFIG_INIT_CD, string Content_R2R_PH_CONFIG_INIT_CD_Original);
        CfgGetInitOvlPCResult R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_PC(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string toolVendor, string controlByChuck, string ovlPcOvlMode, string OVL_PC_SPEC_VARNAME, string OVL_PC_SPEC_VAR_SELECT, string Content_R2R_PH_CONFIG_INIT_OVL_PC, string Content_R2R_PH_CONFIG_INIT_OVL_PC_Original);
        CfgGetInitOvlCPEResult R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_CPE(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string toolVendor, string ovlCpeR2RMode, string ovlCpeOvlMode, string Content_R2R_PH_CONFIG_INIT_OVL_CPE, string Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original);
        CfgGetSpecOvlCPEResult R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_CPE(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string toolVendor, string ovlPcCpeMode, string OVL_CPE_SPEC_VARNAME, string OVL_CPE_LSL_CALC, string OVL_CPE_USL_CALC, string OVL_CPE_SPEC_MAX_DELTA);
        CfgGetSpecOvlPCResult R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_PC(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string toolVendor, string ovlPcOvlMode, string OVL_PC_SPEC_VARNAME, string OVL_PC_SPEC_VAR_SELECT, string OVL_PC_LSL_METRO, string OVL_PC_USL_METRO, string OVL_PC_LSL_CALC, string OVL_PC_USL_CALC, string OVL_PC_DEADBAND, string OVL_PC_SPEC_MAX_DELTA);
        bool R2R_UI_Config_PH_Update_CONFIG(string strServerAddress, string requestId, string userId, string clientVersion, string strCommonDelete, string strCommonAdd, string strCommonModify, string strLisDelete, string strLisAdd, string strLisModify, string strInitCdDelete,
                                                                    string strInitCdAdd, string strInitCdModify, string strInitOvlPcDelete, string strInitOvlPcAdd, string strInitOvlPcModify, string strInitOvlCpeDelete, string strInitOvlCpeAdd, string strInitOvlCpeModify,string queryTime);
    }
}
