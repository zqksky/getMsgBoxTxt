﻿using ProductAndLayerSettingService.IService;
using R2R.Common.Data;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductAndLayerSettingService.Service
{
    public class SettingMainService : ISettingMainService
    {
        #region Fixed Shot CPE Offset Webservice
        /// <summary>
        /// Invoke R2R_UI_Config_GetFixedEdgeShot webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <returns></returns>
        public CfgGetFixedEdgeShotResult R2R_UI_Config_GetFixedEdgeShot(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup)
        {
            CfgGetFixedEdgeShotResult result = new CfgGetFixedEdgeShotResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClienetVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("Tool_Group", toolGroup);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_GetFixedEdgeShot, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgGetFixedEdgeShotResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("Fixed_Edge_Shot_Content<{0}>", result.Fixed_Edge_Shot_Content));
                    if (!result.ReturnCode.Equals("-1"))
                    {
                        //entity = JsonHelp.DeserializeJsonToObject<CfgGetContextValuesResult>(result);
                        return result;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }

        public CfgUpdateResult R2R_UI_Config_FixedEdgeShotSave(string strServerAddress, string requestId, string userId, string clientVersion,  string Fixed_Edge_Shot_Content_Add, string Fixed_Edge_Shot_Content_Modify, string Fixed_Edge_Shot_Content_Delete)
        {
            string strJson = string.Empty;
            CfgUpdateResult result = new CfgUpdateResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Fixed_Edge_Shot_Content_Add<{0}>", Fixed_Edge_Shot_Content_Add) +
                           string.Format("Fixed_Edge_Shot_Content_Modify<{0}>", Fixed_Edge_Shot_Content_Modify) +
                           string.Format("Fixed_Edge_Shot_Content_Delete<{0}>", Fixed_Edge_Shot_Content_Delete));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Fixed_Edge_Shot_Content_Add", Fixed_Edge_Shot_Content_Add);
            arguDic.Add("Fixed_Edge_Shot_Content_Modify", Fixed_Edge_Shot_Content_Modify);
            arguDic.Add("Fixed_Edge_Shot_Content_Delete", Fixed_Edge_Shot_Content_Delete);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_FixedEdgeShotSave, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgUpdateResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText));
                    if (result.ReturnCode.Equals("0"))
                    {
                        return result;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        return result;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }

        #endregion

        #region Version Control Webservice 
        public CfgUpdateResult R2R_UI_Config_UpdateValidation(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string UIConfig,string catchFlag, string catchReason)
        {
            string strJson = string.Empty;
            CfgUpdateResult result = new CfgUpdateResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup) +
                           string.Format("UI_Config<{0}>", UIConfig) +
                           string.Format("CatchFlag<{0}>", catchFlag) +
                           string.Format("CatchReason<{0}>", catchReason));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("ToolGroup", toolGroup);
            arguDic.Add("UI_Config", UIConfig);
            arguDic.Add("CatchFlag", catchFlag);
            arguDic.Add("CatchReason", catchReason);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_UpdateValidation, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgUpdateResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText));
                    if (result.ReturnCode.Equals("0"))
                    {
                        return result;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        return result;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }

        /// <summary>
        /// Invoke R2R_UI_Config_GetHistoryConfig webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="product"></param>
        /// <param name="layer"></param>
        /// <param name="toolGroup"></param>
        /// <returns></returns>
        public CfgGetHistoryConfigResult R2R_UI_Config_GetHistoryConfig(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string versionA, string versionB)
        {
            string strJson = string.Empty;
            CfgGetHistoryConfigResult result = new CfgGetHistoryConfigResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup) +
                           string.Format("Version_Number_A<{0}>", versionA) +
                           string.Format("Version_Number_B<{0}>", versionB));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("ToolGroup", toolGroup);
            arguDic.Add("Version_Number_A", versionA);
            arguDic.Add("Version_Number_B", versionB);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_GetHistoryConfig, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgGetHistoryConfigResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("Version_A_Common_History<{0}>", result.Version_A_Common_History) +
                                    string.Format("Version_A_LIS_History<{0}>", result.Version_A_LIS_History) +
                                    string.Format("Version_A_CD_Init_History<{0}>", result.Version_A_CD_Init_History) +
                                    string.Format("Version_A_OVL_CPE_Init_History<{0}>", result.Version_A_OVL_CPE_Init_History) +
                                    string.Format("Version_A_OVL_PC_Init_History<{0}>", result.Version_A_OVL_PC_Init_History) +
                                    string.Format("Version_B_Common_History<{0}>", result.Version_B_Common_History) +
                                    string.Format("Version_B_LIS_History<{0}>", result.Version_B_LIS_History) +
                                    string.Format("Version_B_CD_Init_History<{0}>", result.Version_B_CD_Init_History) +
                                    string.Format("Version_B_OVL_CPE_Init_History<{0}>", result.Version_B_OVL_CPE_Init_History) +
                                    string.Format("Version_B_OVL_PC_Init_History<{0}>", result.Version_B_OVL_PC_Init_History));
                    if (result.ReturnCode.Equals("0"))
                    {
                        return result;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        return result;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }

        /// <summary>
        /// Invoke R2R_UI_Config_GetVersionList webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="product"></param>
        /// <param name="layer"></param>
        /// <param name="toolGroup"></param>
        /// <returns></returns>
        public CfgGetLatestResult R2R_UI_Config_GetLatestConfig(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string UIConfig)
        {
            string strJson = string.Empty;
            CfgGetLatestResult result = new CfgGetLatestResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup) +
                           string.Format("UI_Config<{0}>", UIConfig));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("Tool_Group", toolGroup);
            arguDic.Add("UI_Config", UIConfig);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_GetLatestConfig, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgGetLatestResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("Latest_Version_Common<{0}>", result.Latest_Version_Common) +
                                    string.Format("Latest_Version_LIS<{0}>", result.Latest_Version_LIS) +
                                    string.Format("Latest_Version_CD_Init<{0}>", result.Latest_Version_CD_Init) +
                                    string.Format("Latest_Version_OVL_PC_Init<{0}>", result.Latest_Version_OVL_PC_Init) +
                                    string.Format("Latest_Version_OVL_CPE_Init<{0}>", result.Latest_Version_OVL_CPE_Init));
                    if (result.ReturnCode.Equals("0"))
                    {
                        return result;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        return result;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }

        /// <summary>
        /// Invoke R2R_UI_Config_GetVersionList webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="product"></param>
        /// <param name="layer"></param>
        /// <param name="toolGroup"></param>
        /// <returns></returns>
        public CfgGetVersionListResult R2R_UI_Config_GetVersionList(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string UIConfig)
        {
            string strJson = string.Empty;
            CfgGetVersionListResult result = new CfgGetVersionListResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup) +
                           string.Format("UI_Config<{0}>", UIConfig));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("Tool_Group", toolGroup);
            arguDic.Add("UI_Config", UIConfig);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_GetVersionList, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgGetVersionListResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("Latest_Version_No<{0}>", result.Latest_Version));
                    if (result.ReturnCode.Equals("0"))
                    {
                        return result;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        //MessageBox.Show(result.ReturnText);
                        return result;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }
        #endregion

        #region CopyProduct Webservice 
        /// <summary>
        /// Invoke R2R_UI_Config_PH_CopyProduct webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="fromProduct"></param>
        /// <param name="toProduct"></param>
        /// <param name="isCheckOnly"></param>
        /// <returns></returns>
        public CfgUpdateResult R2R_UI_Config_PH_CopyProduct(string strServerAddress, string requestId, string userId, string clientVersion, string fromProduct, string toProduct, string fromLayer, string toLayer, bool isCheckOnly)
        {
            string strJson = string.Empty;
            CfgUpdateResult result = new CfgUpdateResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClienetVersion<{0}>", clientVersion) +
                           string.Format("FromProduct<{0}>", fromProduct) +
                           string.Format("ToProduct<{0}>", toProduct) +
                           string.Format("FromLayer<{0}>", fromLayer) +
                           string.Format("ToLayer<{0}>", toLayer) +
                           string.Format("IsCheckOnly<{0}>", isCheckOnly));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("FromProduct", fromProduct);
            arguDic.Add("ToProduct", toProduct);
            arguDic.Add("FromLayer", fromLayer);
            arguDic.Add("ToLayer", toLayer);
            arguDic.Add("IsCheckOnly", isCheckOnly);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_PH_CopyProduct, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgUpdateResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText));
                    if (!result.ReturnCode.Equals("-1"))
                    {
                        //entity = JsonHelp.DeserializeJsonToObject<CfgGetContextValuesResult>(result);
                        return result;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }
        #endregion

        #region Common Webservice
        /// <summary>
        /// Invoke R2R_UI_Config_PH_Get_ContextValues webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <returns></returns>
        public CfgGetContextValuesResult R2R_UI_Config_PH_Get_ContextValues(string strServerAddress, string requestId, string userId, string clientVersion)
        {
            string strJson = string.Empty;
            CfgGetContextValuesResult result = new CfgGetContextValuesResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClienetVersion<{0}>", clientVersion));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_PH_Get_ContextValues, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgGetContextValuesResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ProductList<{0}>", JsonHelp.SerializeObject(result.ProductList)) +
                                    string.Format("LayerList<{0}>", JsonHelp.SerializeObject(result.LayerList)) +
                                    string.Format("ToolGroupList<{0}>", JsonHelp.SerializeObject(result.ToolGroupList)));
                    if (!result.ReturnCode.Equals("-1"))
                    {
                        //entity = JsonHelp.DeserializeJsonToObject<CfgGetContextValuesResult>(result);
                        return result;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }
        /// <summary>
        /// Invoke R2R_UI_Config_PH_Get_CONFIG_COMMON webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="product"></param>
        /// <param name="layer"></param>
        /// <param name="toolGroup"></param>
        /// <returns></returns>
        public CfgGetCommonResult R2R_UI_Config_PH_Get_CONFIG_COMMON(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup)
        {
            string strJson = string.Empty;
            CfgGetCommonResult result = new CfgGetCommonResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("ToolGroup", toolGroup);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_PH_Get_CONFIG_COMMON, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgGetCommonResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("Content_R2R_PH_CONFIG_COMMON<{0}>", result.Content_R2R_PH_CONFIG_COMMON) +
                                    string.Format("Content_R2R_PH_CONFIG_LIS<{0}>", result.Content_R2R_PH_CONFIG_LIS));
                    if (result.ReturnCode.Equals("0"))
                    {
                        return result;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        return result;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }
        #endregion

        #region Access Control Webservice
        /// <summary>
        /// Invoke R2R_UI_Config_EditStatusCheck webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="product"></param>
        /// <param name="layer"></param>
        /// <param name="toolGroup"></param>
        /// <param name="queryTime"></param>
        /// <param name="isCheckOnly"></param>
        /// <param name="uiConfig"></param>
        /// <param name="action"></param>
        /// <param name="currentMode"></param>
        /// <returns></returns>
        public CfgEditStatusCheckResult R2R_UI_Config_EditStatusCheck(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup,string queryTime,bool isCheckOnly,string uiConfig,string action,string currentMode)
        {
            bool flag = false;
            CfgEditStatusCheckResult result = new CfgEditStatusCheckResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup) +
                           string.Format("QueryTime<{0}>", queryTime) +
                           string.Format("IsCheckOnly<{0}>", isCheckOnly) +
                           string.Format("UI_Config<{0}>", uiConfig) +
                           string.Format("Action<{0}>", action) +
                           string.Format("CurrentMode<{0}>", currentMode));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("ToolGroup", toolGroup);
            arguDic.Add("QueryTime", queryTime);
            arguDic.Add("IsCheckOnly", isCheckOnly);
            arguDic.Add("UI_Config", uiConfig);
            arguDic.Add("Action", action);
            arguDic.Add("CurrentMode", currentMode);

            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_EditStatusCheck, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgEditStatusCheckResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("InitMode<{0}>", result.InitMode));
                    if (result.ReturnCode.Equals("0"))
                    {
                        flag=true;
                    }
                    if (result.ReturnCode.Equals("1"))
                    {
                        //MessageBox.Show(result.ReturnText);
                        flag = true;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        //MessageBox.Show(result.ReturnText);
                        flag = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }
        /// <summary>
        /// Invoke R2R_UI_Config_ClearEditOccupy webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="uiConfig"></param>
        /// <returns></returns>
        public bool R2R_UI_Config_ClearEditOccupy(string strServerAddress, string requestId, string userId, string clientVersion, string uiConfig)
        {
            bool flag = false;
            CfgUpdateResult result = new CfgUpdateResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("UI_Config<{0}>", uiConfig));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("UI_Config", uiConfig);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_ClearEditOccupy, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        string strMsg = "Invoke R2R_UI_Config_ClearEditOccupy Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        MessageBox.Show(strMsg);
                        return false;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgUpdateResult>(strResult);
                    if (result == null)
                    {
                        return false;
                    }
                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText));
                    if (result.ReturnCode.Equals("0"))
                    {
                        flag = true;
                    }
                    if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        flag = true;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        flag = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return flag;
        }
        #endregion

        #region Init Webservice
        /// <summary>
        /// Invoke R2R_UI_Config_PH_Get_CONFIG_INIT_CD webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="product"></param>
        /// <param name="layer"></param>
        /// <param name="toolGroup"></param>
        /// <param name="toolVendor"></param>
        /// <param name="Content_R2R_PH_CONFIG_INIT_CD"></param>
        /// <param name="Content_R2R_PH_CONFIG_INIT_CD_Original"></param>
        /// <returns></returns>
        public CfgGetInitCDResult R2R_UI_Config_PH_Get_CONFIG_INIT_CD(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string toolVendor,string Content_R2R_PH_CONFIG_INIT_CD, string Content_R2R_PH_CONFIG_INIT_CD_Original)
        {
            string strJson = string.Empty;
            CfgGetInitCDResult result = new CfgGetInitCDResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup)+
                           string.Format("TOOL_VENDOR<{0}>", toolVendor)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_CD<{0}>", Content_R2R_PH_CONFIG_INIT_CD)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_CD_Original<{0}>", Content_R2R_PH_CONFIG_INIT_CD_Original));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("ToolGroup", toolGroup);
            arguDic.Add("TOOL_VENDOR", toolVendor);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_CD", Content_R2R_PH_CONFIG_INIT_CD);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_CD_Original", Content_R2R_PH_CONFIG_INIT_CD_Original);

            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_PH_Get_CONFIG_INIT_CD, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgGetInitCDResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("Content_R2R_PH_CONFIG_INIT_CD<{0}>", result.Content_R2R_PH_CONFIG_INIT_CD)  +
                                    string.Format("Content_R2R_PH_CONFIG_INIT_CD_Original<{0}>", result.Content_R2R_PH_CONFIG_INIT_CD_Original) +
                                    string.Format("LIST_TOOL<{0}>", JsonHelp.SerializeObject(result.LIST_TOOL)));
                    if (result.ReturnCode.Equals("0"))
                    {
                        return result;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        return result;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }
        /// <summary>
        /// Invoke R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_PC webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="product"></param>
        /// <param name="layer"></param>
        /// <param name="toolGroup"></param>
        /// <param name="toolVendor"></param>
        /// <param name="controlByChuck"></param>
        /// <param name="ovlPcOvlMode"></param>
        /// <param name="OVL_PC_SPEC_VARNAME"></param>
        /// <param name="OVL_PC_SPEC_VAR_SELECT"></param>
        /// <param name="Content_R2R_PH_CONFIG_INIT_OVL_PC"></param>
        /// <param name="Content_R2R_PH_CONFIG_INIT_OVL_PC_Original"></param>
        /// <returns></returns>
        public CfgGetInitOvlPCResult R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_PC(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string toolVendor, string controlByChuck, string ovlPcOvlMode,
                                     string OVL_PC_SPEC_VARNAME, string OVL_PC_SPEC_VAR_SELECT, string Content_R2R_PH_CONFIG_INIT_OVL_PC, string Content_R2R_PH_CONFIG_INIT_OVL_PC_Original)
        {
            string strJson = string.Empty;
            CfgGetInitOvlPCResult result = new CfgGetInitOvlPCResult();

            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup)+
                           string.Format("TOOL_VENDOR<{0}>", toolVendor)+
                           string.Format("CONTROL_BY_CHUCK<{0}>", controlByChuck)+
                           string.Format("OVL_PC_OVL_MODE<{0}>", ovlPcOvlMode)+
                           string.Format("OVL_PC_SPEC_VARNAME<{0}>", OVL_PC_SPEC_VARNAME)+
                           string.Format("OVL_PC_SPEC_VAR_SELECT<{0}>", OVL_PC_SPEC_VAR_SELECT)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_OVL_PC<{0}>", Content_R2R_PH_CONFIG_INIT_OVL_PC)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_OVL_PC_Original<{0}>", Content_R2R_PH_CONFIG_INIT_OVL_PC_Original));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("ToolGroup", toolGroup);
            arguDic.Add("TOOL_VENDOR", toolVendor);
            arguDic.Add("CONTROL_BY_CHUCK", controlByChuck);
            arguDic.Add("OVL_PC_OVL_MODE", ovlPcOvlMode);
            arguDic.Add("OVL_PC_SPEC_VARNAME", OVL_PC_SPEC_VARNAME);
            arguDic.Add("OVL_PC_SPEC_VAR_SELECT", OVL_PC_SPEC_VAR_SELECT);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_OVL_PC", Content_R2R_PH_CONFIG_INIT_OVL_PC);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_OVL_PC_Original", Content_R2R_PH_CONFIG_INIT_OVL_PC_Original);

            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_PC, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgGetInitOvlPCResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("Content_R2R_PH_CONFIG_INIT_OVL_PC<{0}>", result.Content_R2R_PH_CONFIG_INIT_OVL_PC) +
                                    string.Format("Content_R2R_PH_CONFIG_INIT_OVL_PC_Original<{0}>", result.Content_R2R_PH_CONFIG_INIT_OVL_PC_Original) +
                                    string.Format("ToolList<{0}>", JsonHelp.SerializeObject(result.ToolList)));
                    if (result.ReturnCode.Equals("0"))
                    {
                        return result;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        return result;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }
        /// <summary>
        /// Invoke R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_CPE webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="product"></param>
        /// <param name="layer"></param>
        /// <param name="toolGroup"></param>
        /// <param name="toolVendor"></param>
        /// <param name="ovlCpeR2RMode"></param>
        /// <param name="ovlCpeOvlMode"></param>
        /// <param name="Content_R2R_PH_CONFIG_INIT_OVL_CPE"></param>
        /// <param name="Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original"></param>
        /// <returns></returns>
        public CfgGetInitOvlCPEResult R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_CPE(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string toolVendor, string ovlCpeR2RMode, string ovlCpeOvlMode,string Content_R2R_PH_CONFIG_INIT_OVL_CPE, string Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original)
        {
            string strJson = string.Empty;
            CfgGetInitOvlCPEResult result = new CfgGetInitOvlCPEResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup)+
                           string.Format("TOOL_VENDOR<{0}>", toolVendor)+
                           string.Format("OVL_CPE_R2R_MODE<{0}>", ovlCpeR2RMode)+
                           string.Format("OVL_CPE_OVL_MODE<{0}>", ovlCpeOvlMode)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_OVL_CPE<{0}>", Content_R2R_PH_CONFIG_INIT_OVL_CPE)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original<{0}>", Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("ToolGroup", toolGroup);
            arguDic.Add("TOOL_VENDOR", toolVendor);
            arguDic.Add("OVL_CPE_R2R_MODE", ovlCpeR2RMode);
            arguDic.Add("OVL_CPE_OVL_MODE", ovlCpeOvlMode);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_OVL_CPE", Content_R2R_PH_CONFIG_INIT_OVL_CPE);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original", Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original);

            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_CPE, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgGetInitOvlCPEResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("Content_R2R_PH_CONFIG_INIT_OVL_CPE<{0}>", result.Content_R2R_PH_CONFIG_INIT_OVL_CPE) +
                                    string.Format("Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original<{0}>", result.Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original) +
                                    string.Format("ToolList<{0}>", JsonHelp.SerializeObject(result.ToolList)));
                    if (result.ReturnCode.Equals("0"))
                    {
                        return result;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        return result;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }
        #endregion

        #region Spec Webservice
        /// <summary>
        /// Invoke R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_CPE webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="product"></param>
        /// <param name="layer"></param>
        /// <param name="toolGroup"></param>
        /// <param name="toolVendor"></param>
        /// <param name="ovlPcCpeMode"></param>
        /// <param name="OVL_CPE_SPEC_VARNAME"></param>
        /// <param name="OVL_CPE_LSL_CALC"></param>
        /// <param name="OVL_CPE_USL_CALC"></param>
        /// <param name="OVL_CPE_SPEC_MAX_DELTA"></param>
        /// <returns></returns>
        public CfgGetSpecOvlCPEResult R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_CPE(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string toolVendor, string ovlPcCpeMode,
                                            string OVL_CPE_SPEC_VARNAME, string OVL_CPE_LSL_CALC, string OVL_CPE_USL_CALC, string OVL_CPE_SPEC_MAX_DELTA)
        {
            string strJson = string.Empty;
            CfgGetSpecOvlCPEResult result = new CfgGetSpecOvlCPEResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup)+
                           string.Format("TOOL_VENDOR<{0}>", toolVendor)+
                           string.Format("OVL_PC_CPE_MODE<{0}>", ovlPcCpeMode)+
                           string.Format("OVL_CPE_LSL_CALC<{0}>", OVL_CPE_LSL_CALC)+
                           string.Format("OVL_CPE_USL_CALC<{0}>", OVL_CPE_USL_CALC)+
                           string.Format("OVL_CPE_SPEC_MAX_DELTA<{0}>", OVL_CPE_SPEC_MAX_DELTA)+
                           string.Format("OVL_CPE_SPEC_VARNAME<{0}>", OVL_CPE_SPEC_VARNAME));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("ToolGroup", toolGroup);
            arguDic.Add("TOOL_VENDOR", toolVendor);
            arguDic.Add("OVL_PC_CPE_MODE", ovlPcCpeMode);
            arguDic.Add("OVL_CPE_LSL_CALC", OVL_CPE_LSL_CALC);
            arguDic.Add("OVL_CPE_USL_CALC", OVL_CPE_USL_CALC);
            arguDic.Add("OVL_CPE_SPEC_MAX_DELTA", OVL_CPE_SPEC_MAX_DELTA);
            arguDic.Add("OVL_CPE_SPEC_VARNAME", OVL_CPE_SPEC_VARNAME);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_CPE, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgGetSpecOvlCPEResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("OVL_CPE_LSL_CALC<{0}>", JsonHelp.SerializeObject(result.OVL_CPE_LSL_CALC)) +
                                    string.Format("OVL_CPE_USL_CALC<{0}>", JsonHelp.SerializeObject(result.OVL_CPE_USL_CALC)) +
                                    string.Format("OVL_CPE_SPEC_VARNAME<{0}>", JsonHelp.SerializeObject(result.OVL_CPE_SPEC_VARNAME)) +
                                    string.Format("OVL_CPE_SPEC_MAX_DELTA<{0}>", JsonHelp.SerializeObject(result.OVL_CPE_SPEC_MAX_DELTA)));
                    if (result.ReturnCode.Equals("0"))
                    {
                        return result;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        return result;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }
        /// <summary>
        /// Invoke R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_PC webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="product"></param>
        /// <param name="layer"></param>
        /// <param name="toolGroup"></param>
        /// <param name="toolVendor"></param>
        /// <param name="ovlPcOvlMode"></param>
        /// <param name="OVL_PC_SPEC_VARNAME"></param>
        /// <param name="OVL_PC_SPEC_VAR_SELECT"></param>
        /// <param name="OVL_PC_LSL_METRO"></param>
        /// <param name="OVL_PC_USL_METRO"></param>
        /// <param name="OVL_PC_LSL_CALC"></param>
        /// <param name="OVL_PC_USL_CALC"></param>
        /// <param name="OVL_PC_DEADBAND"></param>
        /// <param name="OVL_PC_SPEC_MAX_DELTA"></param>
        /// <returns></returns>
        public CfgGetSpecOvlPCResult R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_PC(string strServerAddress, string requestId, string userId, string clientVersion, string product, string layer, string toolGroup, string toolVendor, string ovlPcOvlMode,
                                      string OVL_PC_SPEC_VARNAME, string OVL_PC_SPEC_VAR_SELECT, string OVL_PC_LSL_METRO, string OVL_PC_USL_METRO, string OVL_PC_LSL_CALC, string OVL_PC_USL_CALC, string OVL_PC_DEADBAND, string OVL_PC_SPEC_MAX_DELTA)
        {
            string strJson = string.Empty;
            CfgGetSpecOvlPCResult result = new CfgGetSpecOvlPCResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Product<{0}>", product) +
                           string.Format("Layer<{0}>", layer) +
                           string.Format("ToolGroup<{0}>", toolGroup)+
                           string.Format("TOOL_VENDOR<{0}>", toolVendor)+
                           string.Format("OVL_PC_OVL_MODE<{0}>", ovlPcOvlMode)+
                           string.Format("OVL_PC_SPEC_VARNAME<{0}>", OVL_PC_SPEC_VARNAME)+
                           string.Format("OVL_PC_SPEC_VAR_SELECT<{0}>", OVL_PC_SPEC_VAR_SELECT)+
                           string.Format("OVL_PC_LSL_METRO<{0}>", OVL_PC_LSL_METRO)+
                           string.Format("OVL_PC_USL_METRO<{0}>", OVL_PC_USL_METRO)+
                           string.Format("OVL_PC_LSL_CALC<{0}>", OVL_PC_LSL_CALC)+
                           string.Format("OVL_PC_USL_CALC<{0}>", OVL_PC_USL_CALC)+
                           string.Format("OVL_PC_DEADBAND<{0}>", OVL_PC_DEADBAND)+
                           string.Format("OVL_PC_SPEC_MAX_DELTA<{0}>", OVL_PC_SPEC_MAX_DELTA));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", product);
            arguDic.Add("Layer", layer);
            arguDic.Add("ToolGroup", toolGroup);
            arguDic.Add("TOOL_VENDOR", toolVendor);
            arguDic.Add("OVL_PC_OVL_MODE", ovlPcOvlMode);
            arguDic.Add("OVL_PC_SPEC_VARNAME", OVL_PC_SPEC_VARNAME);
            arguDic.Add("OVL_PC_SPEC_VAR_SELECT", OVL_PC_SPEC_VAR_SELECT);
            arguDic.Add("OVL_PC_LSL_METRO", OVL_PC_LSL_METRO);
            arguDic.Add("OVL_PC_USL_METRO", OVL_PC_USL_METRO);
            arguDic.Add("OVL_PC_LSL_CALC", OVL_PC_LSL_CALC);
            arguDic.Add("OVL_PC_USL_CALC", OVL_PC_USL_CALC);
            arguDic.Add("OVL_PC_DEADBAND", OVL_PC_DEADBAND);
            arguDic.Add("OVL_PC_SPEC_MAX_DELTA", OVL_PC_SPEC_MAX_DELTA);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_PC, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        return null;
                    }
                    result = JsonHelp.DeserializeJsonToObject<CfgGetSpecOvlPCResult>(strResult);
                    if (result == null)
                    {
                        return null;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("OVL_PC_LSL_CALC<{0}>", JsonHelp.SerializeObject(result.OVL_PC_LSL_CALC)) +
                                    string.Format("OVL_PC_USL_CALC<{0}>", JsonHelp.SerializeObject(result.OVL_PC_USL_CALC)) +
                                    string.Format("OVL_PC_LSL_METRO<{0}>", JsonHelp.SerializeObject(result.OVL_PC_LSL_METRO)) +
                                    string.Format("OVL_PC_USL_METRO<{0}>", JsonHelp.SerializeObject(result.OVL_PC_USL_METRO)) +
                                    string.Format("OVL_PC_SPEC_VARNAME<{0}>", JsonHelp.SerializeObject(result.OVL_PC_SPEC_VARNAME)) +
                                    string.Format("OVL_PC_SPEC_VAR_SELECT<{0}>", JsonHelp.SerializeObject(result.OVL_PC_SPEC_VAR_SELECT)) +
                                    string.Format("OVL_PC_SPEC_MAX_DELTA<{0}>", JsonHelp.SerializeObject(result.OVL_PC_SPEC_MAX_DELTA)) +
                                    string.Format("LIST_TOOL<{0}>", JsonHelp.SerializeObject(result.LIST_TOOL)));
                    if (result.ReturnCode.Equals("0"))
                    {
                        return result;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                        return result;
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return result;
        }
        #endregion

        #region Save Webservice
        /// <summary>
        /// Invoke R2R_UI_Config_PH_Update_CONFIG webservice
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="strCommonDelete"></param>
        /// <param name="strCommonAdd"></param>
        /// <param name="strCommonModify"></param>
        /// <param name="strLisDelete"></param>
        /// <param name="strLisAdd"></param>
        /// <param name="strLisModify"></param>
        /// <param name="strInitCdDelete"></param>
        /// <param name="strInitCdAdd"></param>
        /// <param name="strInitCdModify"></param>
        /// <param name="strInitOvlPcDelete"></param>
        /// <param name="strInitOvlPcAdd"></param>
        /// <param name="strInitOvlPcModify"></param>
        /// <param name="strInitOvlCpeDelete"></param>
        /// <param name="strInitOvlCpeAdd"></param>
        /// <param name="strInitOvlCpeModify"></param>
        /// <param name="queryTime"></param>
        /// <returns></returns>
        public bool R2R_UI_Config_PH_Update_CONFIG(string strServerAddress, string requestId, string userId, string clientVersion, string strCommonDelete, string strCommonAdd, string strCommonModify, string strLisDelete, string strLisAdd, string strLisModify, string strInitCdDelete,
                                                                    string strInitCdAdd, string strInitCdModify, string strInitOvlPcDelete, string strInitOvlPcAdd, string strInitOvlPcModify, string strInitOvlCpeDelete, string strInitOvlCpeAdd, string strInitOvlCpeModify,string queryTime)
        {
            bool flag = false;
            string strJson = string.Empty;
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("Content_R2R_PH_CONFIG_COMMON_Delete<{0}>", strCommonDelete) +
                           string.Format("Content_R2R_PH_CONFIG_COMMON_Add<{0}>", strCommonAdd) +
                           string.Format("Content_R2R_PH_CONFIG_COMMON_Modify<{0}>", strCommonModify)+
                           string.Format("Content_R2R_PH_CONFIG_LIS_Delete<{0}>", strLisDelete)+
                           string.Format("Content_R2R_PH_CONFIG_LIS_Add<{0}>", strLisAdd)+
                           string.Format("Content_R2R_PH_CONFIG_LIS_Modify<{0}>", strLisModify)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_CD_Delete<{0}>", strInitCdDelete)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_CD_Add<{0}>", strInitCdAdd)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_CD_Modify<{0}>", strInitCdModify)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_OVL_PC_Delete<{0}>", strInitOvlPcDelete)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_OVL_PC_Add<{0}>", strInitOvlPcAdd)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_OVL_PC_Modify<{0}>", strInitOvlPcModify)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_OVL_CPE_Delete<{0}>", strInitOvlCpeDelete)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_OVL_CPE_Add<{0}>", strInitOvlCpeAdd)+
                           string.Format("Content_R2R_PH_CONFIG_INIT_OVL_CPE_Modify<{0}>", strInitOvlCpeModify) +
                           string.Format("QueryTime", queryTime));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Content_R2R_PH_CONFIG_COMMON_Delete", strCommonDelete);
            arguDic.Add("Content_R2R_PH_CONFIG_COMMON_Add", strCommonAdd);
            arguDic.Add("Content_R2R_PH_CONFIG_COMMON_Modify", strCommonModify);
            arguDic.Add("Content_R2R_PH_CONFIG_LIS_Delete", strLisDelete);
            arguDic.Add("Content_R2R_PH_CONFIG_LIS_Add", strLisAdd);
            arguDic.Add("Content_R2R_PH_CONFIG_LIS_Modify", strLisModify);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_CD_Delete", strInitCdDelete);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_CD_Add", strInitCdAdd);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_CD_Modify", strInitCdModify);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_OVL_PC_Delete", strInitOvlPcDelete);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_OVL_PC_Add", strInitOvlPcAdd);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_OVL_PC_Modify", strInitOvlPcModify);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_OVL_CPE_Delete", strInitOvlCpeDelete);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_OVL_CPE_Add", strInitOvlCpeAdd);
            arguDic.Add("Content_R2R_PH_CONFIG_INIT_OVL_CPE_Modify", strInitOvlCpeModify);
            arguDic.Add("QueryTime", queryTime);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if (true)
                {
                    string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_PH_Update_CONFIG, arguDic, strServerAddress);
                    if (strResult.Equals("error"))
                    {
                        string strMsg = "Invoke R2R_UI_Config_PH_Update_CONFIG Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        MessageBox.Show(strMsg);
                        return false;
                    }
                    CfgUpdateResult result = JsonHelp.DeserializeJsonToObject<CfgUpdateResult>(strResult);
                    if (result == null)
                    {
                        string strMsg = "Invoke R2R_UI_Config_PH_Update_CONFIG Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        MessageBox.Show(strMsg);
                        return false;
                    }

                    MyLogger.Trace("Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText));
                    if (result.ReturnCode.Equals("0"))
                    {
                        flag = true;
                    }
                    else if (result.ReturnCode.Equals("1"))
                    {
                        flag = false;
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                    else if (result.ReturnCode.Equals("-1"))
                    {
                        flag = false;
                        MyLogger.Trace("Message :: " + result.ReturnText);
                        MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return flag;
        }
        #endregion
    }
}
