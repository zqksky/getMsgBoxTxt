﻿using Prism.Commands;
using Prism.Events;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProductAndLayerSetting.ViewModels
{
    class CPE_SpecSettingViewModel : ViewModelBase
    {
        public CPE_SpecSettingViewModel()
        {

        }

        public ISettingMainService _SettingMainService { get; set; }
        public CPE_SpecSettingViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "CPE Spec Setting";
        }

        /// <summary>
        /// Init Event Fun
        /// </summary>
        void OnInit()
        {
            try
            {
                if (IsCPESpecEnable)
                {
                    IsGrdReadOnly = false;
                    IsBtnConfirmEnable = true;
                }
                else
                {
                    IsGrdReadOnly = true;
                    IsBtnConfirmEnable = false;
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }


        #region Filed
        private bool _IsCPESpecEnable = true;
        public bool IsCPESpecEnable
        {
            get { return this._IsCPESpecEnable; }
            set { SetProperty(ref this._IsCPESpecEnable, value); }
        }

        private bool _IsGrdReadOnly = false;
        public bool IsGrdReadOnly
        {
            get { return this._IsGrdReadOnly; }
            set { SetProperty(ref this._IsGrdReadOnly, value); }
        }

        private bool _IsBtnConfirmEnable = true;
        public bool IsBtnConfirmEnable
        {
            get { return this._IsBtnConfirmEnable; }
            set { SetProperty(ref this._IsBtnConfirmEnable, value); }
        }

        private bool _IsBtnOkClick = false;
        public bool IsBtnOkClick
        {
            get { return this._IsBtnOkClick; }
            set { SetProperty(ref this._IsBtnOkClick, value); }
        }

        private string _Product;
        public string Product
        {
            get { return this._Product; }
            set { SetProperty(ref this._Product, value); }
        }

        private string _Layer;
        public string Layer
        {
            get { return this._Layer; }
            set { SetProperty(ref this._Layer, value); }
        }

        private string _ToolGroup;
        public string ToolGroup
        {
            get { return this._ToolGroup; }
            set { SetProperty(ref this._ToolGroup, value); }
        }

        private string _OOCCount;
        public string OOCCount
        {
            get { return this._OOCCount; }
            set { SetProperty(ref this._OOCCount, value); }
        }

        private string _OOSCount;
        public string OOSCount
        {
            get { return this._OOSCount; }
            set { SetProperty(ref this._OOSCount, value); }
        }

        private CPE_SpecSettingEntity _SelectedSetting;
        public CPE_SpecSettingEntity SelectedSetting
        {
            get { return this._SelectedSetting; }
            set { SetProperty(ref this._SelectedSetting, value); }
        }

        private ObservableCollection<CPE_SpecSettingEntity> _SettingList;
        public ObservableCollection<CPE_SpecSettingEntity> SettingList
        {
            get { return _SettingList; }
            set { SetProperty(ref _SettingList, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnInit));

        private DelegateCommand _OOCCountKeyUpCommand;
        public DelegateCommand OOCCountKeyUpCommand =>
            _OOCCountKeyUpCommand ?? (_OOCCountKeyUpCommand = new DelegateCommand(OnOOCCountKeyUp));

        private DelegateCommand _SelectRowClickCommand;
        public DelegateCommand SelectRowClickCommand =>
            _SelectRowClickCommand ?? (_SelectRowClickCommand = new DelegateCommand(OnSelectRowClick));

        private DelegateCommand _BeginningEditCommand;
        public DelegateCommand BeginningEditCommand =>
            _BeginningEditCommand ?? (_BeginningEditCommand = new DelegateCommand(OnBeginningEdit));

        private DelegateCommand _CellEditEndingCommand;
        public DelegateCommand CellEditEndingCommand =>
            _CellEditEndingCommand ?? (_CellEditEndingCommand = new DelegateCommand(OnCellEditEnding));

        private DelegateCommand _LostFocusCommand;
        public DelegateCommand LostFocusCommand =>
            _LostFocusCommand ?? (_LostFocusCommand = new DelegateCommand(OnLostFocus));

        private DelegateCommand _BtnConfirmCommand;
        public DelegateCommand BtnConfirmCommand =>
            _BtnConfirmCommand ?? (_BtnConfirmCommand = new DelegateCommand(OnConfirmClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));
        #endregion

        #region Event Fun
        /// <summary>
        /// SelectRow Event Fun
        /// </summary>
        void OnOOCCountKeyUp()
        {
            try
            {
                uint tmp;
                if (!uint.TryParse(OOCCount, out tmp))
                {
                    OOCCount = "";
                    System.Windows.Forms.MessageBox.Show("OOCCount must be an integer!");
                    return;
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// SelectRow Event Fun
        /// </summary>
        void OnSelectRowClick()
        {
            try
            {
                //currentMax_Delta = string.Empty;
                //currentLSL = string.Empty;
                //currentUSL = string.Empty;
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        string currentMax_Delta = string.Empty;
        string currentLSL = string.Empty;
        string currentUSL = string.Empty;
        /// <summary>
        /// BeginningEdit Event Fun
        /// </summary>
        void OnBeginningEdit()
        {
            try
            {
                if (SelectedSetting != null)
                {

                    currentMax_Delta = SelectedSetting.Max_Delta;
                    currentLSL = SelectedSetting.LSL;
                    currentUSL= SelectedSetting.USL;
                }

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CellEditEnding Event Fun
        /// </summary>
        void OnCellEditEnding()
        {
            try
            {
                if (SelectedSetting != null)
                {
                    double tmp = double.NaN;
                    if (double.TryParse(SelectedSetting.Max_Delta, out tmp))
                    {

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input Max_Delta was not in a correct format!");
                        SelectedSetting.Max_Delta = currentMax_Delta;
                        return;
                    }
                    if (double.TryParse(SelectedSetting.LSL, out tmp))
                    {

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input LSL was not in a correct format!");
                        SelectedSetting.LSL = currentLSL;
                        return;
                    }
                    if (double.TryParse(SelectedSetting.USL, out tmp))
                    {

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input USL was not in a correct format!");
                        SelectedSetting.USL = currentUSL;
                        return;
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// LostFocus Event Fun
        /// </summary>
        void OnLostFocus()
        {
            try
            {


            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }

        }
        /// <summary>
        /// Confirm Button Click Event Fun
        /// </summary>
        void OnConfirmClick()
        {
            try
            {
                uint tmp;
                if (string.IsNullOrEmpty(OOCCount))
                {
                    System.Windows.Forms.MessageBox.Show("OOCCount cannot be empty!");
                    return;
                }
                else if(!uint.TryParse(OOCCount, out tmp))
                {
                    System.Windows.Forms.MessageBox.Show("OOCCount must be an integer!");
                    return;
                }
                double tmpDouble = double.NaN;
                foreach (var obj in SettingList)
                {
                    if (string.IsNullOrEmpty(obj.Max_Delta) || string.IsNullOrEmpty(obj.USL) || string.IsNullOrEmpty(obj.LSL))
                    {
                        System.Windows.Forms.MessageBox.Show("Max_Delta/USL/LSL cannot be empty!");
                        return;
                    }
                    else if (double.TryParse(obj.Max_Delta, out tmpDouble) || double.TryParse(obj.USL, out tmpDouble) && double.TryParse(obj.LSL, out tmpDouble))
                    {

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Max_Delta/USL/LSL must be an double!");
                        return;
                    }
                }

                IsBtnOkClick = true;

                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Cancel Button Click Event Fun
        /// </summary>
        void OnBtnCancelClick()
        {
            IsBtnOkClick = false;
            this.CurrentWindow.Close();
        }
        #endregion
    }
}
