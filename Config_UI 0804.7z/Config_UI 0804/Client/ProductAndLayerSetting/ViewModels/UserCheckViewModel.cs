﻿using Prism.Commands;
using Prism.Events;
using ProductAndLayerSettingService.IService;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProductAndLayerSetting.ViewModels
{
    public class UserCheckViewModel : ViewModelBase
    {
        IEventAggregator _ea;

        public ISettingMainService UserCheckService { get; set; }
        public UserCheckViewModel(ISettingMainService userCheckService, IEventAggregator ea)
        {
            _ea = ea;
            this.UserCheckService = userCheckService;
            Title = "UserVerification";
        }


        #region Filed
        private bool _IsCheckSuccess = false;
        public bool IsCheckSuccess
        {
            get { return this._IsCheckSuccess; }
            set { SetProperty(ref this._IsCheckSuccess, value); }
        }

        private string _CurrentUserName;
        public string CurrentUserName
        {
            get { return this._CurrentUserName; }
            set { SetProperty(ref this._CurrentUserName, value); }
        }

        private string _CurrentPassword;
        public string CurrentPassword
        {
            get { return this._CurrentPassword; }
            set { SetProperty(ref this._CurrentPassword, value); }
        }

        private string _UserName;
        public string UserName
        {
            get { return this._UserName; }
            set { SetProperty(ref this._UserName, value); }
        }

        private string _Password;
        public string Password
        {
            get { return this._Password; }
            set { SetProperty(ref this._Password, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _BtnOkCommand;
        public DelegateCommand BtnOkCommand =>
            _BtnOkCommand ?? (_BtnOkCommand = new DelegateCommand(OnBtnOKClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));
        #endregion

        #region Event Fun
        /// <summary>
        /// Ok Button Click Event Fun
        /// </summary>
        void OnBtnOKClick()
        {
            try
            {
                if (UserName.Equals("") || Password.Equals(""))
                {
                    MessageBox.Show("Please input user name and password!");
                    return;
                }

                if (CurrentUserName.ToUpper().Equals(UserName.ToUpper()) && CurrentPassword.Equals(Password))
                {
                    IsCheckSuccess = true;
                    this.CurrentWindow.Close();
                }
                else
                {
                    MessageBox.Show("Please check user information!");
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Cancel Button Click Event Fun
        /// </summary>
        void OnBtnCancelClick()
        {
            try
            {
                IsCheckSuccess = false;
                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion
    }
}