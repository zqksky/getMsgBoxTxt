﻿using Prism.Commands;
using Prism.Events;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Common.Data.CommonEntity;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProductAndLayerSetting.ViewModels
{
    class PC_SpecSettingViewModel : ViewModelBase
    {
        public PC_SpecSettingViewModel()
        {

        }

        public ISettingMainService _SettingMainService { get; set; }
        public PC_SpecSettingViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "PC Spec Setting";
        }

        /// <summary>
        /// Init Event Fun
        /// </summary>
        void OnInit()
        {
            try
            {
                if (IsPCSpecEnable)
                {
                    IsGrdReadOnly = false;
                    IsBtnConfirmEnable = true;
                }
                else
                {
                    IsGrdReadOnly = true;
                    IsBtnConfirmEnable = false;
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        #region Filed
        private ObservableCollection<PC_InitialSettingEntity> _PCInitialSettingList;
        public ObservableCollection<PC_InitialSettingEntity> PCInitialSettingList
        {
            get { return _PCInitialSettingList; }
            set { SetProperty(ref _PCInitialSettingList, value); }
        }

        private List<ImportExcelCheckEntity> _ChuckCheckList;
        public List<ImportExcelCheckEntity> ChuckCheckList
        {
            get { return _ChuckCheckList; }
            set { SetProperty(ref _ChuckCheckList, value); }
        }

        private bool _IsPCSpecEnable = true;
        public bool IsPCSpecEnable
        {
            get { return this._IsPCSpecEnable; }
            set { SetProperty(ref this._IsPCSpecEnable, value); }
        }

        private bool _IsGrdReadOnly = false;
        public bool IsGrdReadOnly
        {
            get { return this._IsGrdReadOnly; }
            set { SetProperty(ref this._IsGrdReadOnly, value); }
        }

        private bool _IsBtnConfirmEnable = true;
        public bool IsBtnConfirmEnable
        {
            get { return this._IsBtnConfirmEnable; }
            set { SetProperty(ref this._IsBtnConfirmEnable, value); }
        }

        private string _Status="N";
        public string Status
        {
            get { return this._Status; }
            set { SetProperty(ref this._Status, value); }
        }

        private bool _IsBtnOkClick = false;
        public bool IsBtnOkClick
        {
            get { return this._IsBtnOkClick; }
            set { SetProperty(ref this._IsBtnOkClick, value); }
        }

        private string _Product;
        public string Product
        {
            get { return this._Product; }
            set { SetProperty(ref this._Product, value); }
        }

        private string _Layer;
        public string Layer
        {
            get { return this._Layer; }
            set { SetProperty(ref this._Layer, value); }
        }

        private string _ToolGroup;
        public string ToolGroup
        {
            get { return this._ToolGroup; }
            set { SetProperty(ref this._ToolGroup, value); }
        }

        private string _OOCCount;
        public string OOCCount
        {
            get { return this._OOCCount; }
            set { SetProperty(ref this._OOCCount, value); }
        }

        private string _OOSCount;
        public string OOSCount
        {
            get { return this._OOSCount; }
            set { SetProperty(ref this._OOSCount, value); }
        }

        private PC_SpecSettingEntity _SelectedSetting;
        public PC_SpecSettingEntity SelectedSetting
        {
            get { return this._SelectedSetting; }
            set { SetProperty(ref this._SelectedSetting, value); }
        }

        private ObservableCollection<PC_SpecSettingEntity> _SettingList;
        public ObservableCollection<PC_SpecSettingEntity> SettingList
        {
            get { return _SettingList; }
            set { SetProperty(ref _SettingList, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnInit));

        private DelegateCommand _SelectRowClickCommand;
        public DelegateCommand SelectRowClickCommand =>
            _SelectRowClickCommand ?? (_SelectRowClickCommand = new DelegateCommand(OnSelectRowClick));

        private DelegateCommand _BeginningEditCommand;
        public DelegateCommand BeginningEditCommand =>
            _BeginningEditCommand ?? (_BeginningEditCommand = new DelegateCommand(OnBeginningEdit));

        private DelegateCommand _CellEditEndingCommand;
        public DelegateCommand CellEditEndingCommand =>
            _CellEditEndingCommand ?? (_CellEditEndingCommand = new DelegateCommand(OnCellEditEnding));

        private DelegateCommand _LostFocusCommand;
        public DelegateCommand LostFocusCommand =>
            _LostFocusCommand ?? (_LostFocusCommand = new DelegateCommand(OnLostFocus));

        private DelegateCommand _BtnConfirmCommand;
        public DelegateCommand BtnConfirmCommand =>
            _BtnConfirmCommand ?? (_BtnConfirmCommand = new DelegateCommand(OnConfirmClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));
        #endregion

        #region Event Fun
        /// <summary>
        /// SelectRow Event Fun
        /// </summary>
        void OnSelectRowClick()
        {
            try
            {
                //currentMax_Delta = string.Empty;
                //currentDeadband = string.Empty;
                //currentLSL_Calc = string.Empty;
                //currentUSL_Calc = string.Empty;
                //currentLSL_Metro = string.Empty;
                //currentUSL_Metro = string.Empty;
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        string currentMax_Delta = string.Empty;
        string currentDeadband = string.Empty;
        string currentLSL_Calc = string.Empty;
        string currentUSL_Calc = string.Empty;
        string currentLSL_Metro = string.Empty;
        string currentUSL_Metro = string.Empty;
        /// <summary>
        /// BeginningEdit Event Fun
        /// </summary>
        void OnBeginningEdit()
        {
            try
            {
                if (SelectedSetting != null)
                {

                    currentMax_Delta = SelectedSetting.Max_Delta;
                    currentDeadband = SelectedSetting.Deadband;
                    currentLSL_Calc = SelectedSetting.LSL_Calc;
                    currentUSL_Calc = SelectedSetting.USL_Calc;
                    currentLSL_Metro = SelectedSetting.LSL_Metro;
                    currentUSL_Metro = SelectedSetting.USL_Metro;
                }

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CellEditEnding Event Fun
        /// </summary>
        void OnCellEditEnding()
        {
            try
            {
                if (SelectedSetting != null)
                {
                   
                    double tmp = double.NaN;
                    if (double.TryParse(SelectedSetting.Max_Delta, out tmp))
                    {

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input Max_Delta was not in a correct format!");
                        SelectedSetting.Max_Delta = currentMax_Delta;
                        return;
                    }
                    if (double.TryParse(SelectedSetting.Deadband, out tmp))
                    {

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input Deadband was not in a correct format!");
                        SelectedSetting.Deadband = currentDeadband;
                        return;
                    }
                    if (double.TryParse(SelectedSetting.LSL_Calc, out tmp))
                    {
                        #region
                        //bool IsHaveChuck2 = false;
                        //if (PCInitialSettingList.Count > 0)
                        //{
                        //    string strChuck = PCInitialSettingList[0].INIT_PARAMETER_VALUE;
                        //    if (strChuck.Contains(";"))
                        //    {
                        //        IsHaveChuck2 = true;
                        //    }
                        //}

                        //foreach (var obj in PCInitialSettingList)
                        //{
                        //    List<string> strChuckList1 = new List<string>();
                        //    List<string> strChuckList2 = new List<string>();
                        //    if (IsHaveChuck2)
                        //    {
                        //        string[] strArrayChuck = obj.INIT_PARAMETER_VALUE.Split(';');
                        //        strChuckList1 = new List<string>(strArrayChuck[0].Split(','));
                        //        strChuckList2 = new List<string>(strArrayChuck[1].Split(','));
                        //    }
                        //    else
                        //    {
                        //        strChuckList1 = new List<string>(obj.INIT_PARAMETER_VALUE.Split(','));
                        //    }
                        //    for (int i = 0; i < ChuckCheckList.Count; i++)
                        //    {
                        //        if (ChuckCheckList[i].Parameter.Equals(SelectedSetting.Parameter))
                        //        {
                        //            ChuckCheckList[i].Max = double.Parse(SelectedSetting.USL_Calc);
                        //            ChuckCheckList[i].Min = double.Parse(SelectedSetting.LSL_Calc);
                        //        }

                        //        string strMsg = obj.TOOL + "/" + obj.RETICLE + "/" + ChuckCheckList[i].Parameter + " out of range!";
                                
                        //        bool ChuckValueFlag = CheckChuckValue(ChuckCheckList[i].Max, ChuckCheckList[i].Min, strChuckList1[i], strMsg);
                        //        if (!ChuckValueFlag)
                        //        {
                        //            //SelectedSetting.USL_Calc = currentUSL_Calc;
                        //            //SelectedSetting.LSL_Calc = currentLSL_Calc;
                        //            return;
                        //        }
                        //        if (IsHaveChuck2)
                        //        {
                        //            ChuckValueFlag = CheckChuckValue(ChuckCheckList[i].Max, ChuckCheckList[i].Min, strChuckList2[i], strMsg);
                        //            if (!ChuckValueFlag)
                        //            {
                        //                //SelectedSetting.USL_Calc = currentUSL_Calc;
                        //                //SelectedSetting.LSL_Calc = currentLSL_Calc;
                        //                return;
                        //            }
                        //        }

                        //    }

                        //}
                        #endregion
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input LSL_Calc was not in a correct format!");
                        SelectedSetting.LSL_Calc = currentLSL_Calc;
                        return;
                    }
                    if (double.TryParse(SelectedSetting.USL_Calc, out tmp))
                    {
                        #region
                        //bool IsHaveChuck2 = false;
                        //if (PCInitialSettingList.Count > 0)
                        //{
                        //    string strChuck = PCInitialSettingList[0].INIT_PARAMETER_VALUE;
                        //    if (strChuck.Contains(";"))
                        //    {
                        //        IsHaveChuck2 = true;
                        //    }
                        //}

                        //foreach (var obj in PCInitialSettingList)
                        //{
                        //    List<string> strChuckList1 = new List<string>();
                        //    List<string> strChuckList2 = new List<string>();
                        //    if (IsHaveChuck2)
                        //    {
                        //        string[] strArrayChuck = obj.INIT_PARAMETER_VALUE.Split(';');
                        //        strChuckList1 = new List<string>(strArrayChuck[0].Split(','));
                        //        strChuckList2 = new List<string>(strArrayChuck[1].Split(','));
                        //    }
                        //    else
                        //    {
                        //        strChuckList1 = new List<string>(obj.INIT_PARAMETER_VALUE.Split(','));
                        //    }
                        //    for (int i = 0; i < ChuckCheckList.Count; i++)
                        //    {
                        //        if (ChuckCheckList[i].Parameter.Equals(SelectedSetting.Parameter))
                        //        {
                        //            ChuckCheckList[i].Max = double.Parse(SelectedSetting.USL_Calc);
                        //            ChuckCheckList[i].Min = double.Parse(SelectedSetting.LSL_Calc);
                        //        }
                        //        string strMsg = obj.TOOL + "/" + obj.RETICLE + "/" + ChuckCheckList[i].Parameter + " out of range!";

                        //        bool ChuckValueFlag = CheckChuckValue(ChuckCheckList[i].Max, ChuckCheckList[i].Min, strChuckList1[i], strMsg);
                        //        if (!ChuckValueFlag)
                        //        {
                        //            //SelectedSetting.USL_Calc = currentUSL_Calc;
                        //            //SelectedSetting.LSL_Calc = currentLSL_Calc;
                        //            return;
                        //        }
                        //        if (IsHaveChuck2)
                        //        {
                        //            ChuckValueFlag = CheckChuckValue(ChuckCheckList[i].Max, ChuckCheckList[i].Min, strChuckList2[i], strMsg);
                        //            if (!ChuckValueFlag)
                        //            {
                        //                //SelectedSetting.USL_Calc = currentUSL_Calc;
                        //                //SelectedSetting.LSL_Calc = currentLSL_Calc;
                        //                return;
                        //            }
                        //        }

                        //    }

                        //}
                        #endregion
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input USL_Calc was not in a correct format!");
                        SelectedSetting.USL_Calc = currentUSL_Calc;
                        return;
                    }
                    if (double.TryParse(SelectedSetting.LSL_Metro, out tmp))
                    {

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input LSL_Metro was not in a correct format!");
                        SelectedSetting.LSL_Metro = currentLSL_Metro;
                        return;
                    }
                    if (double.TryParse(SelectedSetting.USL_Metro, out tmp))
                    {

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input USL_Metro was not in a correct format!");
                        SelectedSetting.USL_Metro = currentUSL_Metro;
                        return;
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// LostFocus Event Fun
        /// </summary>
        void OnLostFocus()
        {
            try
            {


            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }

        }
        /// <summary>
        /// Confirm Button Click Event Fun
        /// </summary>
        void OnConfirmClick()
        {
            try
            {
                foreach (var obj in SettingList)
                {
                    double tmp = double.NaN;
                    if (!double.TryParse(obj.Max_Delta, out tmp))
                    {
                        System.Windows.Forms.MessageBox.Show("Input Max_Delta was not in a correct format!");
                        return;
                    }
                    if (!double.TryParse(obj.Deadband, out tmp))
                    {
                        System.Windows.Forms.MessageBox.Show("Input Deadband was not in a correct format!");
                        return;
                    }
                    if (!double.TryParse(obj.LSL_Calc, out tmp))
                    {
                        System.Windows.Forms.MessageBox.Show("Input LSL_Calc was not in a correct format!");
                        return;
                    }
                    if (!double.TryParse(obj.USL_Calc, out tmp))
                    {
                        System.Windows.Forms.MessageBox.Show("Input USL_Calc was not in a correct format!");
                        return;
                    }
                    if (!double.TryParse(obj.LSL_Metro, out tmp))
                    {
                        System.Windows.Forms.MessageBox.Show("Input LSL_Metro was not in a correct format!");
                        return;
                    }
                    if (!double.TryParse(obj.USL_Metro, out tmp))
                    {
                        System.Windows.Forms.MessageBox.Show("Input USL_Metro was not in a correct format!");
                        return;
                    }
                    foreach (var check in ChuckCheckList)
                    {
                        if (obj.Parameter.Equals(check.Parameter))
                        {
                            check.Max = double.Parse(obj.USL_Calc);
                            check.Min = double.Parse(obj.LSL_Calc);
                            if (check.Max < check.Min)
                            {
                                System.Windows.Forms.MessageBox.Show("The value of USL_Calc cannot be less than the value of LSL_Calc!");
                                return;
                            }
                            break;
                        }
                    }
                }

                IsBtnOkClick = true;

                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Cancel Button Click Event Fun
        /// </summary>
        void OnBtnCancelClick()
        {
            IsBtnOkClick = false;
            this.CurrentWindow.Close();
        }
        #endregion

        #region Fun
        bool CheckChuckValue(double dChuckMax, double dChuckMin, string strChuck, string strMsg)
        {
            bool flag = false;
            try
            {
                if (string.IsNullOrEmpty(strChuck))
                {
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return false;
                }

                double chuck = double.NaN;
                if (double.TryParse(strChuck, out chuck))
                {
                    if (chuck > dChuckMax || chuck < dChuckMin)
                    {
                        flag = false;
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }
                    else
                    {
                        flag = true;
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return flag;
        }
        #endregion
    }
}
