﻿using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProductAndLayerSetting.ViewModels
{
    class CPE_LISViewModel : ViewModelBase
    {
        public CPE_LISViewModel()
        {

        }

        public ISettingMainService _SettingMainService { get; set; }
        public CPE_LISViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "Single Lot";
        }

        IRegionNavigationJournal _journal;
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            try
            {
                _journal = navigationContext.NavigationService.Journal;

                var msg = navigationContext.Parameters["Message"] as SendWaferModeParam;
                if (msg != null)
                {
                    SendWaferParam = msg;
                    LISUpdateTime = SendWaferParam.LIS_UPDATE_TIME;
                    LISUpdateLot = SendWaferParam.LIS_UPDATE_LOT;
                    SparseSampling = SendWaferParam.SPARSE_SAMPLING;
                    DenseSampling = SendWaferParam.DENSE_SAMPLING;
                    ESTSparseRecipe = SendWaferParam.EST_SPARSE_RECIPE;
                    ESTDenseRecipe = SendWaferParam.EST_DENSE_RECIPE;
                    OptimizeRecipe = SendWaferParam.OPTIMIZE_RECIPE;
                    SamplingToolType = SendWaferParam.SAMPLING_TOOLTYPE;
                    //SendWaferParam.ESTI_KPI_OCAP;
                    //SendWaferParam.EXCEPTION_CNT;
                    //SendWaferParam.EXCEPTION_THRESHOLD;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        SendWaferModeParam SendWaferParam = new SendWaferModeParam();

        public override bool IsNavigationTarget(NavigationContext navigationContext)
        {
            var msg = navigationContext.Parameters["Message"] as SendWaferModeParam;
            return true;
        }

        #region
        private List<string> _ChangeList = new List<string>();
        public List<string> ChangeList
        {
            get { return this._ChangeList; }
            set { SetProperty(ref this._ChangeList, value); }
        }

        private bool _IsEditClick = false;
        public bool IsEditClick
        {
            get { return this._IsEditClick; }
            set { SetProperty(ref this._IsEditClick, value); }
        }

        private string _LISUpdateTime;
        public string LISUpdateTime
        {
            get { return this._LISUpdateTime; }
            set { SetProperty(ref this._LISUpdateTime, value); }
        }
        
        private string _LISUpdateLot;
        public string LISUpdateLot
        {
            get { return this._LISUpdateLot; }
            set { SetProperty(ref this._LISUpdateLot, value); }
        }

        private string _SparseSampling;
        public string SparseSampling
        {
            get { return this._SparseSampling; }
            set { SetProperty(ref this._SparseSampling, value); }
        }

        private string _DenseSampling;
        public string DenseSampling
        {
            get { return this._DenseSampling; }
            set { SetProperty(ref this._DenseSampling, value); }
        }

        private string _ESTSparseRecipe;
        public string ESTSparseRecipe
        {
            get { return this._ESTSparseRecipe; }
            set { SetProperty(ref this._ESTSparseRecipe, value); }
        }

        private string _ESTDenseRecipe;
        public string ESTDenseRecipe
        {
            get { return this._ESTDenseRecipe; }
            set { SetProperty(ref this._ESTDenseRecipe, value); }
        }

        private string _OptimizeRecipe;
        public string OptimizeRecipe
        {
            get { return this._OptimizeRecipe; }
            set { SetProperty(ref this._OptimizeRecipe, value); }
        }

        private string _SamplingToolType;
        public string SamplingToolType
        {
            get { return this._SamplingToolType; }
            set { SetProperty(ref this._SamplingToolType, value); }
        }

        private List<string> _SamplingToolTypeList =new List<string>() { "KT","YS"};
        public List<string> SamplingToolTypeList
        {
            get { return this._SamplingToolTypeList; }
            set { SetProperty(ref this._SamplingToolTypeList, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnInit));

        private DelegateCommand _LayoutUpdatedCommand;
        public DelegateCommand LayoutUpdatedCommand =>
            _LayoutUpdatedCommand ?? (_LayoutUpdatedCommand = new DelegateCommand(OnLayoutUpdated));

        #endregion

        #region Event Fun
        /// <summary>
        /// Init Event Fun
        /// </summary>
        void OnInit()
        {
            try
            {
                //if (!SamplingToolTypeList.Contains(SamplingToolType))
                //{
                //    SamplingToolTypeList.Add(SamplingToolType);
                //}
                //SamplingToolType = SamplingToolTypeList[SamplingToolTypeList.Count-1];
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// TextChanged Event Fun
        /// </summary>
        void OnLayoutUpdated()
        {
            ChangeList = new List<string>();
            double num1 = double.NaN;
            if (!double.TryParse(LISUpdateTime, out num1))
            {
                LISUpdateTime = "";
            }
            if (!double.TryParse(LISUpdateLot, out num1))
            {
                LISUpdateLot = "";
            }

            ChangeList.Add(LISUpdateTime);
            ChangeList.Add(LISUpdateLot);
            ChangeList.Add(SparseSampling);
            ChangeList.Add(DenseSampling);
            ChangeList.Add(ESTSparseRecipe);
            ChangeList.Add(ESTDenseRecipe);
            ChangeList.Add(OptimizeRecipe);
            ChangeList.Add(SamplingToolType);
            EventAggregator.GetEvent<CPELISChangedEvent>().Publish(ChangeList);
        }
        #endregion
    }
}
