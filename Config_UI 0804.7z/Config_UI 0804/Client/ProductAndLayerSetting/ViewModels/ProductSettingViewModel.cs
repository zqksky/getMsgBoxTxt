﻿using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;

namespace ProductAndLayerSetting.ViewModels
{
    class ProductSettingViewModel : ViewModelBase
    {
        public ProductSettingViewModel()
        {

        }

        public ISettingMainService _SettingMainService { get; set; }
        public ProductSettingViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "Product Setting";
        }

        #region ProductSetting Field
        private bool _IsProductSettingEnable = true;
        public bool IsProductSettingEnable
        {
            get { return this._IsProductSettingEnable; }
            set { SetProperty(ref this._IsProductSettingEnable, value); }
        }
        
        private List<string> _CanonToolGroupList = new List<string>();
        public List<string> CanonToolGroupList
        {
            get { return this._CanonToolGroupList; }
            set { SetProperty(ref this._CanonToolGroupList, value); }
        }

        private bool _IsChuckDedicationLayerEnable = false;
        public bool IsChuckDedicationLayerEnable
        {
            get { return this._IsChuckDedicationLayerEnable; }
            set { SetProperty(ref this._IsChuckDedicationLayerEnable, value); }
        }

        private bool _IsBtnOkClick = false;
        public bool IsBtnOkClick
        {
            get { return this._IsBtnOkClick; }
            set { SetProperty(ref this._IsBtnOkClick, value); }
        }

        private bool _IsBtnCancelClick = false;
        public bool IsBtnCancelClick
        {
            get { return this._IsBtnCancelClick; }
            set { SetProperty(ref this._IsBtnCancelClick, value); }
        }

        private bool _IsProductEditable;
        public bool IsProductEditable
        {
            get { return this._IsProductEditable; }
            set { SetProperty(ref this._IsProductEditable, value); }
        }
        private bool _IsLayerEditable;
        public bool IsLayerEditable
        {
            get { return this._IsLayerEditable; }
            set { SetProperty(ref this._IsLayerEditable, value); }
        }

        private bool _IsProductEnable;
        public bool IsProductEnable
        {
            get { return this._IsProductEnable; }
            set { SetProperty(ref this._IsProductEnable, value); }
        }
        private bool _IsLayerEnable;
        public bool IsLayerEnable
        {
            get { return this._IsLayerEnable; }
            set { SetProperty(ref this._IsLayerEnable, value); }
        }
        private bool _IsToolGroupEnable;
        public bool IsToolGroupEnable
        {
            get { return this._IsToolGroupEnable; }
            set { SetProperty(ref this._IsToolGroupEnable, value); }
        }

        private string _Product;
        public string Product
        {
            get { return this._Product; }
            set { SetProperty(ref this._Product, value); }
        }

        private List<string> _ProductList;
        public List<string> ProductList
        {
            get { return this._ProductList; }
            set { SetProperty(ref this._ProductList, value); }
        }

        private string _Layer;
        public string Layer
        {
            get { return this._Layer; }
            set { SetProperty(ref this._Layer, value); }
        }

        private List<string> _LayerList;
        public List<string> LayerList
        {
            get { return this._LayerList; }
            set { SetProperty(ref this._LayerList, value); }
        }

        private string _ToolGroup;
        public string ToolGroup
        {
            get { return this._ToolGroup; }
            set { SetProperty(ref this._ToolGroup, value); }
        }

        private List<string> _ToolGroupList;
        public List<string> ToolGroupList
        {
            get { return this._ToolGroupList; }
            set { SetProperty(ref this._ToolGroupList, value); }
        }

        private bool _IsAlignmentLayerEnable;
        public bool IsAlignmentLayerEnable
        {
            get { return this._IsAlignmentLayerEnable; }
            set { SetProperty(ref this._IsAlignmentLayerEnable, value); }
        }

        private bool _IsAlignmentMethodEnable=true;
        public bool IsAlignmentMethodEnable
        {
            get { return this._IsAlignmentMethodEnable; }
            set { SetProperty(ref this._IsAlignmentMethodEnable, value); }
        }

        private string _AlignmentLayer;
        public string AlignmentLayer
        {
            get { return this._AlignmentLayer; }
            set { SetProperty(ref this._AlignmentLayer, value); }
        }

        private List<string> _AlignmentLayerList;
        public List<string> AlignmentLayerList
        {
            get { return this._AlignmentLayerList; }
            set { SetProperty(ref this._AlignmentLayerList, value); }
        }

        private string _AlignmentMethod;
        public string AlignmentMethod
        {
            get { return this._AlignmentMethod; }
            set { SetProperty(ref this._AlignmentMethod, value); }
        }

        private List<string> _AlignmentMethodList;
        public List<string> AlignmentMethodList
        {
            get { return this._AlignmentMethodList; }
            set { SetProperty(ref this._AlignmentMethodList, value); }
        }

        private string _OverlayLayer;
        public string OverlayLayer
        {
            get { return this._OverlayLayer; }
            set { SetProperty(ref this._OverlayLayer, value); }
        }

        private List<string> _OverlayLayerList;
        public List<string> OverlayLayerList
        {
            get { return this._OverlayLayerList; }
            set { SetProperty(ref this._OverlayLayerList, value); }
        }

        private string _PreOverlayLayer;
        public string PreOverlayLayer
        {
            get { return this._PreOverlayLayer; }
            set { SetProperty(ref this._PreOverlayLayer, value); }
        }

        private List<string> _PreOverlayLayerList;
        public List<string> PreOverlayLayerList
        {
            get { return this._PreOverlayLayerList; }
            set { SetProperty(ref this._PreOverlayLayerList, value); }
        }

        private string _PControlByChuck;
        public string ControlByChuck
        {
            get { return this._PControlByChuck; }
            set { SetProperty(ref this._PControlByChuck, value); }
        }

        private string _ChuckDedication;
        public string ChuckDedication
        {
            get { return this._ChuckDedication; }
            set { SetProperty(ref this._ChuckDedication, value); }
        }

        private string _CascadePCLayer;
        public string CascadePCLayer
        {
            get { return this._CascadePCLayer; }
            set { SetProperty(ref this._CascadePCLayer, value); }
        }

        private List<string> _CascadePCLayerList;
        public List<string> CascadePCLayerList
        {
            get { return this._CascadePCLayerList; }
            set { SetProperty(ref this._CascadePCLayerList, value); }
        }

        private string _CascadeCPELayer;
        public string CascadeCPELayer
        {
            get { return this._CascadeCPELayer; }
            set { SetProperty(ref this._CascadeCPELayer, value); }
        }

        private List<string> _CascadeCPELayerList;
        public List<string> CascadeCPELayerList
        {
            get { return this._CascadeCPELayerList; }
            set { SetProperty(ref this._CascadeCPELayerList, value); }
        }

        private string _ChuckDedicationLayer;
        public string ChuckDedicationLayer
        {
            get { return this._ChuckDedicationLayer; }
            set { SetProperty(ref this._ChuckDedicationLayer, value); }
        }

        private List<string> _ChuckDedicationLayerList;
        public List<string> ChuckDedicationLayerList
        {
            get { return this._ChuckDedicationLayerList; }
            set { SetProperty(ref this._ChuckDedicationLayerList, value); }
        }

        private bool _IsControlByChuckChangeFlag=false;
        public bool IsControlByChuckChangeFlag
        {
            get { return this._IsControlByChuckChangeFlag; }
            set { SetProperty(ref this._IsControlByChuckChangeFlag, value); }
        }

        private bool _IsControlByChuckFlag;
        public bool IsControlByChuckFlag
        {
            get { return this._IsControlByChuckFlag; }
            set { SetProperty(ref this._IsControlByChuckFlag, value); }
        }

        private bool _IsControlByChuckYes;
        public bool IsControlByChuckYes
        {
            get { return this._IsControlByChuckYes; }
            set { SetProperty(ref this._IsControlByChuckYes, value); }
        }

        private bool __IsControlByChuckNo;
        public bool IsControlByChuckNo
        {
            get { return this.__IsControlByChuckNo; }
            set { SetProperty(ref this.__IsControlByChuckNo, value); }
        }

        private bool _IsControlByChuckEnable;
        public bool IsControlByChuckEnable
        {
            get { return this._IsControlByChuckEnable; }
            set { SetProperty(ref this._IsControlByChuckEnable, value); }
        }

        private bool _IsChuckDedicationYes;
        public bool IsChuckDedicationYes
        {
            get { return this._IsChuckDedicationYes; }
            set { SetProperty(ref this._IsChuckDedicationYes, value); }
        }

        private bool _IsChuckDedicationNo;
        public bool IsChuckDedicationNo
        {
            get { return this._IsChuckDedicationNo; }
            set { SetProperty(ref this._IsChuckDedicationNo, value); }
        }

        private bool _IsChuckDedicationEnable;
        public bool IsChuckDedicationEnable
        {
            get { return this._IsChuckDedicationEnable; }
            set { SetProperty(ref this._IsChuckDedicationEnable, value); }
        }

        private ProductSettingEntity _SelectedProductSetting;
        public ProductSettingEntity SelectedProductSetting
        {
            get { return this._SelectedProductSetting; }
            set { SetProperty(ref this._SelectedProductSetting, value); }
        }

        private ObservableCollection<ProductSettingEntity> _ProductSettingList;
        public ObservableCollection<ProductSettingEntity> ProductSettingList
        {
            get { return _ProductSettingList; }
            set { SetProperty(ref _ProductSettingList, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region ProductSetting Event Define
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnInit));

        private DelegateCommand _RdoControlByChuckYesCheckedCommand;
        public DelegateCommand RdoControlByChuckYesCheckedCommand =>
            _RdoControlByChuckYesCheckedCommand ?? (_RdoControlByChuckYesCheckedCommand = new DelegateCommand(OnRdoControlByChuckYesChecked));

        private DelegateCommand _RdoControlByChuckNoCheckedCommand;
        public DelegateCommand RdoControlByChuckNoCheckedCommand =>
            _RdoControlByChuckNoCheckedCommand ?? (_RdoControlByChuckNoCheckedCommand = new DelegateCommand(OnRdoControlByChuckNoChecked));

        private DelegateCommand _RdoChuckDedicationYesCheckedCommand;
        public DelegateCommand RdoChuckDedicationYesCheckedCommand =>
            _RdoChuckDedicationYesCheckedCommand ?? (_RdoChuckDedicationYesCheckedCommand = new DelegateCommand(OnRdoChuckDedicationYesChecked));

        private DelegateCommand _RdoChuckDedicationNoCheckedCommand;
        public DelegateCommand RdoChuckDedicationNoCheckedCommand =>
            _RdoChuckDedicationNoCheckedCommand ?? (_RdoChuckDedicationNoCheckedCommand = new DelegateCommand(OnRdoChuckDedicationNoChecked));

        private DelegateCommand _BtnOkCommand;
        public DelegateCommand BtnOkCommand =>
            _BtnOkCommand ?? (_BtnOkCommand = new DelegateCommand(OnBtnOkClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));

        private DelegateCommand _ProductKeyDownCommand;
        public DelegateCommand ProductKeyDownCommand =>
            _ProductKeyDownCommand ?? (_ProductKeyDownCommand = new DelegateCommand(OnProductKeyDown));

        private DelegateCommand _LayerKeyDownCommand;
        public DelegateCommand LayerKeyDownCommand =>
            _LayerKeyDownCommand ?? (_LayerKeyDownCommand = new DelegateCommand(OnLayerKeyDown));

        private DelegateCommand _ProductLostFocusCommand;
        public DelegateCommand ProductLostFocusCommand =>
            _ProductLostFocusCommand ?? (_ProductLostFocusCommand = new DelegateCommand(OnProductLostFocus));

        private DelegateCommand _LayerLostFocusCommand;
        public DelegateCommand LayerLostFocusCommand =>
            _LayerLostFocusCommand ?? (_LayerLostFocusCommand = new DelegateCommand(OnLayerLostFocus));

        private DelegateCommand _ProductSelectionChangedCommand;
        public DelegateCommand ProductSelectionChangedCommand =>
            _ProductSelectionChangedCommand ?? (_ProductSelectionChangedCommand = new DelegateCommand(OnProductSelectionChanged));

        private DelegateCommand _LayerSelectionChangedCommand;
        public DelegateCommand LayerSelectionChangedCommand =>
            _LayerSelectionChangedCommand ?? (_LayerSelectionChangedCommand = new DelegateCommand(OnLayerSelectionChanged));

        private DelegateCommand _ToolGroupSelectionChangedCommand;
        public DelegateCommand ToolGroupSelectionChangedCommand =>
            _ToolGroupSelectionChangedCommand ?? (_ToolGroupSelectionChangedCommand = new DelegateCommand(OnToolGroupSelectionChanged));

        private DelegateCommand _AlignmentLayerSelectionChangedCommand;
        public DelegateCommand AlignmentLayerSelectionChangedCommand =>
            _AlignmentLayerSelectionChangedCommand ?? (_AlignmentLayerSelectionChangedCommand = new DelegateCommand(OnAlignmentLayerSelectionChanged));

        private DelegateCommand _AlignmentMethodSelectionChangedCommand;
        public DelegateCommand AlignmentMethodSelectionChangedCommand =>
            _AlignmentMethodSelectionChangedCommand ?? (_AlignmentMethodSelectionChangedCommand = new DelegateCommand(OnAlignmentMethodSelectionChanged));

        private DelegateCommand _OverlayLayerSelectionChangedCommand;
        public DelegateCommand OverlayLayerSelectionChangedCommand =>
            _OverlayLayerSelectionChangedCommand ?? (_OverlayLayerSelectionChangedCommand = new DelegateCommand(OnOverlayLayerSelectionChanged));

        private DelegateCommand _CascadePcLayerSelectionChangedCommand;
        public DelegateCommand CascadePcLayerSelectionChangedCommand =>
            _CascadePcLayerSelectionChangedCommand ?? (_CascadePcLayerSelectionChangedCommand = new DelegateCommand(OnCascadePcLayerSelectionChanged));

        private DelegateCommand _CascadeCpeLayerSelectionChangedCommand;
        public DelegateCommand CascadeCpeLayerSelectionChangedCommand =>
            _CascadeCpeLayerSelectionChangedCommand ?? (_CascadeCpeLayerSelectionChangedCommand = new DelegateCommand(OnCascadeCpeLayerSelectionChanged));
        #endregion

        #region ProductSetting Event Fun
        /// <summary>
        /// Init Event Fun
        /// </summary>
        void OnInit()
        {
            try
            {
                IsControlByChuckFlag = IsControlByChuckYes;
                if (IsChuckDedicationNo)
                {
                    ChuckDedicationLayer = "NA";
                }

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ControlByChuckYesChecked Event Fun
        /// </summary>
        void OnRdoControlByChuckYesChecked()
        {
            try
            {

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ControlByChuckNoChecked Event Fun
        /// </summary>
        void OnRdoControlByChuckNoChecked()
        {
            try
            {

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ChuckDedicationYesChecked Event Fun
        /// </summary>
        void OnRdoChuckDedicationYesChecked()
        {
            try
            {
                IsChuckDedicationLayerEnable = true;
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ChuckDedicationNoChecked Event Fun
        /// </summary>
        void OnRdoChuckDedicationNoChecked()
        {
            try
            {
                IsChuckDedicationLayerEnable = false;
                if (IsChuckDedicationNo)
                {
                    IsChuckDedicationLayerEnable = false;
                    ChuckDedicationLayer = "NA";
                }

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Ok Button Click Event Fun
        /// </summary>
        void OnBtnOkClick()
        {
            try
            {
                if (string.IsNullOrEmpty(AlignmentLayer))
                {
                    System.Windows.Forms.MessageBox.Show("Alignment Layer cannot null");
                    return;
                }
                if (CanonToolGroupList.Contains(ToolGroup))
                {
                    ChuckDedicationLayer = "NA";
                }
                else
                {
                    if (IsChuckDedicationNo)
                    {
                        ChuckDedicationLayer = "NA";
                    }
                    if (IsChuckDedicationYes)
                    {
                        if (string.IsNullOrEmpty(ChuckDedicationLayer))
                        {
                            System.Windows.Forms.MessageBox.Show("Chuck Dedication Layer cannot null");
                            return;
                        }
                    }
                }
                IsBtnOkClick = true;
                IsBtnCancelClick = false;

                if (!IsControlByChuckYes.ToString().Equals(IsControlByChuckFlag.ToString()))
                {
                    IsControlByChuckChangeFlag = true;
                }

                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Cancel Button Click Event Fun
        /// </summary>
        void OnBtnCancelClick()
        {
            try
            {
                IsBtnOkClick = false;
                IsBtnCancelClick = true;

                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        bool IsProductInput = false;
        /// <summary>
        /// Product Text Input Event Fun
        /// </summary>
        void OnProductKeyDown()
        {
            try
            {
                IsProductInput = true;

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        bool IsLayerInput = false;
        /// <summary>
        /// Layer Text Input Event Fun
        /// </summary>
        void OnLayerKeyDown()
        {
            try
            {
                IsLayerInput = true;

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Product TextChanged Event Fun
        /// </summary>
        void OnProductLostFocus()
        {
            try
            {
                if(IsProductInput)
                {
                    if (ProductList.Contains(Product))
                    {
                    }
                    else
                    {
                        if (System.Windows.Forms.MessageBox.Show("New Add Product: " + Product, "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {

                            

                        }

                    }
                    IsProductInput = false;
                }               
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Layer TextChanged Event Fun
        /// </summary>
        void OnLayerLostFocus()
        {
            try
            {
                if (IsLayerInput)
                {
                    if (LayerList.Contains(Layer))
                    {
                    }
                    else
                    {
                        if (System.Windows.Forms.MessageBox.Show("New Add Layer: " + Layer, "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {


                        }
                    }
                    IsLayerInput = false;
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Product SelectionChanged Event Fun
        /// </summary>
        void OnProductSelectionChanged()
        {
            try
            {

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Layer SelectionChanged Event Fun
        /// </summary>
        void OnLayerSelectionChanged()
        {
            try
            {

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ToolGroup SelectionChanged Event Fun
        /// </summary>
        void OnToolGroupSelectionChanged()
        {
            try
            {
                if (CanonToolGroupList.Contains(ToolGroup))
                {
                    IsControlByChuckEnable = false;
                    IsControlByChuckYes = false;
                    IsControlByChuckNo = true;

                    IsChuckDedicationEnable = false;
                    IsChuckDedicationYes = false;
                    IsChuckDedicationNo = true;

                    IsChuckDedicationLayerEnable = false;
                    if (!ChuckDedicationLayerList.Contains("NA"))
                    {
                        ChuckDedicationLayerList.Add("NA");
                    }
                    ChuckDedicationLayer = "NA";

                }
                else
                {
                    IsControlByChuckEnable = true;
                    IsChuckDedicationEnable = true;

                    if (IsChuckDedicationNo)
                    {
                        IsChuckDedicationLayerEnable = false;
                        if (!ChuckDedicationLayerList.Contains("NA"))
                        {
                            ChuckDedicationLayerList.Add("NA");
                        }
                        ChuckDedicationLayer = "NA";
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// AlignmentLayer SelectionChanged Event Fun
        /// </summary>
        void OnAlignmentLayerSelectionChanged()
        {
            try
            {

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// AlignmentMethod SelectionChanged Event Fun
        /// </summary>
        void OnAlignmentMethodSelectionChanged()
        {
            try
            {

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// OverlayLayer SelectionChanged Event Fun
        /// </summary>
        void OnOverlayLayerSelectionChanged()
        {
            try
            {

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CascadePcLayer SelectionChanged Event Fun
        /// </summary>
        void OnCascadePcLayerSelectionChanged()
        {
            try
            {

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CascadeCpeLayer SelectionChanged Event Fun
        /// </summary>
        void OnCascadeCpeLayerSelectionChanged()
        {
            try
            {

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion
    }
}
