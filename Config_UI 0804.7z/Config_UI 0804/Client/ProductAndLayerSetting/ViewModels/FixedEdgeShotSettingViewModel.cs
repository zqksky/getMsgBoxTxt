﻿using Prism.Commands;
using Prism.Events;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace ProductAndLayerSetting.ViewModels
{
    class FixedEdgeShotSettingViewModel : ViewModelBase
    {
        public ISettingMainService _SettingMainService { get; set; }
        public FixedEdgeShotSettingViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "Fixed Edge Shot Setting";
        }

        #region Loaded Event
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnLoaded));

        void OnLoaded()
        {
            try
            {
                InitBtn();

                if (!string.IsNullOrEmpty(Product) && !string.IsNullOrEmpty(Layer) && !string.IsNullOrEmpty(ToolGroup))
                {
                    CfgSingleTableInfoEntity entity = InvokeR2R_UI_Config_GetFixedEdgeShot();
                    if (entity==null)
                    {
                        //this.currentWindow.Close();
                        return;
                    }
                    else
                    {
                        bool flag = false;
                        for (int i = 0; i < 14; i++)
                        {
                            if (string.IsNullOrEmpty(entity.ColumnData[i]))
                            {
                                flag = true;
                                break;
                            }
                        }
                        if (flag)
                        {
                            entity.ColumnData[0] = Product;
                            entity.ColumnData[1] = Layer;
                            entity.ColumnData[2] = ToolGroup;
                            entity.ColumnData[3] = "NewTool";
                            entity.ColumnData[4] = "NewPreTool";
                            entity.ColumnData[5] = "NewReticle";
                            entity.ColumnData[6] = "NewPreReticle";
                            entity.ColumnData[7] = "CPEMode";
                            entity.ColumnData[8] = "0";
                            entity.ColumnData[9] = "0";
                            entity.ColumnData[10] = "0";
                            entity.ColumnData[11] = "0";
                            entity.ColumnData[12] = "0";
                            entity.ColumnData[13] = "0";
                        }

                        InitFixedEdgeShot(entity);

                        OnBtnOkClick();
                    }
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Invoke webservice
        CfgSingleTableInfoEntity InvokeR2R_UI_Config_GetFixedEdgeShot()
        {
            CfgSingleTableInfoEntity entity = new CfgSingleTableInfoEntity();
            try
            {
                CfgGetFixedEdgeShotResult result = this._SettingMainService.R2R_UI_Config_GetFixedEdgeShot(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, Product, Layer, ToolGroup);
                if (result == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_GetFixedEdgeShot Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return null;
                }
                if (result.ReturnCode.Equals("-1"))
                {
                    MyLogger.Trace("Message :: " + result.ReturnText);
                    System.Windows.Forms.MessageBox.Show(result.ReturnText);
                    return null;
                }
                else if (result.ReturnCode.Equals("1"))
                {
                    MyLogger.Trace("Message :: " + result.ReturnText);
                    System.Windows.Forms.MessageBox.Show(result.ReturnText);
                }
                else if (result.ReturnCode.Equals("0"))
                {
                }

                entity = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(result.Fixed_Edge_Shot_Content);
                if (entity == null)
                {
                    return null;
                }

                return entity;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return entity;
        }

        bool InvokeR2R_UI_Config_FixedEdgeShotSave(string ContentAdd, string ContentModify, string ContentDelete)
        {
            bool flag = false;
            try
            {
                CfgUpdateResult result = this._SettingMainService.R2R_UI_Config_FixedEdgeShotSave(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, ContentAdd, ContentModify, ContentDelete);
                if (result == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_GetFixedEdgeShot Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return false;
                }
                if (result.ReturnCode.Equals("-1"))
                {
                    MyLogger.Trace("Message :: " + result.ReturnText);
                    System.Windows.Forms.MessageBox.Show(result.ReturnText);
                    return false;
                }
                else if (result.ReturnCode.Equals("1"))
                {
                    MyLogger.Trace("Message :: " + result.ReturnText);
                    System.Windows.Forms.MessageBox.Show(result.ReturnText);
                    flag = true;
                }
                else if (result.ReturnCode.Equals("0"))
                {
                    System.Windows.Forms.MessageBox.Show(result.ReturnText);
                    flag = true;
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return flag;
        }

        #endregion

        #region Init
        void InitBtn()
        {
            //IsBtnOkEnable = false;
            IsBtnDeleteEnable = false;
            IsBtnDoneEnable = false;
            //IsBtnSaveEnable = false;
        }
        void InitFixedEdgeShot(CfgSingleTableInfoEntity entity)
        {
            cfgFixedEdgeShotUpdateEntity = CfgSingleTableInfoHelp.GetUpdateSingleTableInfo(entity, ref dbR2R_UI_Config_GetFixedEdgeShot_Source, ref dbR2R_UI_Config_GetFixedEdgeShot_Update, ref cfgFixedEdgeShotColumnNameList, ref cfgFixedEdgeShotColumnKeyList);

            if (dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows.Count > 0)
            {
                Product = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["PRODUCT"].ToString();
                Layer = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["LAYER"].ToString();
                ToolGroup = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["TOOL_GROUP"].ToString();
                Tool = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["TOOL"].ToString();
                PreTool = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["PRE_TOOL"].ToString();
                Reticle = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["RETICLE"].ToString();
                PreReticle = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["PRE_RETICLE"].ToString();
                CPEMode = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["CPE_MODE"].ToString();
                StepSizeX = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["STEP_SIZE_X"].ToString();
                StepSizeY = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["STEP_SIZE_Y"].ToString();
                ShotOffsetX = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["SHOT_OFFSET_X"].ToString();
                ShotOffsetY = dbR2R_UI_Config_GetFixedEdgeShot_Source.Rows[0]["SHOT_OFFSET_Y"].ToString();

                SetCPEModeCheck();
            }
        }
        void SetCPEModeCheck()
        {
            try
            {
                if (string.IsNullOrEmpty(CPEMode))
                {
                    IsCPE6Checked = IsCPE15Checked = IsCPE19Checked = false;
                }
                else
                {
                    if (CPEMode.Equals("CPE-6"))
                    {
                        IsCPE6Checked = true;
                    }
                    else if (CPEMode.Equals("CPE-15"))
                    {
                        IsCPE15Checked = true;
                    }
                    else if (CPEMode.Equals("CPE-19"))
                    {
                        IsCPE19Checked = true;
                    }
                    else
                    {
                        IsCPE6Checked = IsCPE15Checked = IsCPE19Checked = false;
                    }
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Fun
        uint xCount;
        uint yCount;
        uint uStepSizeX;
        uint uStepSizeY;
        uint xRemainder;
        uint yRemainder;

        bool IsStepSizeXYCorrectFormat()
        {
            bool flag = false;
            try
            {
                if (string.IsNullOrEmpty(StepSizeX) || string.IsNullOrEmpty(StepSizeY))
                {
                    MessageBox.Show("StepSizeX/StepSizeY cannot be empty!");
                    return false;
                }
                uint uTemp;
                if (uint.TryParse(StepSizeX, out uTemp) && uint.TryParse(StepSizeY, out uTemp))
                {
                    flag = true;
                    uStepSizeX = uint.Parse(StepSizeX);
                    uStepSizeY = uint.Parse(StepSizeY);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return flag;
        }
        bool IsShotOffsetCorrectFormat()
        {
            bool falg = false;
            try
            {
                if (string.IsNullOrEmpty(ShotOffsetX) && string.IsNullOrEmpty(ShotOffsetY))
                {
                    return true;
                }
                else
                {
                    falg = IsShotOffsetXYCorrectFormat(ShotOffsetX, uStepSizeX);
                    if (falg)
                    {
                        falg = IsShotOffsetXYCorrectFormat(ShotOffsetY, uStepSizeY);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return falg;
        }

        bool IsShotOffsetXYCorrectFormat(string strShotOffset, uint uStepSize)
        {
            bool flag = false;
            try
            {
                if (!string.IsNullOrEmpty(strShotOffset))
                {
                    int uTemp;
                    if (int.TryParse(strShotOffset, out uTemp))
                    {
                        if (uTemp < uStepSize / 2)
                        {
                            flag = true;
                        }
                        else
                        {
                            MessageBox.Show("ShotOffset out of range!");
                        }
                    }
                }
                else
                {
                    flag = true;
                }

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return flag;
        }

        bool IsHaveEmptyKey()
        {
            bool flag = true;
            try
            {
                foreach (var str in cfgFixedEdgeShotColumnKeyList)
                {
                    if (string.IsNullOrEmpty(str))
                    {
                        MessageBox.Show(str + "cannot be empty !");
                        return true;
                    }
                }
                flag = false;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return flag;
        }

        bool CheckKeyFormat()
        {
            bool flag = false;
            try
            {
                if (IsHaveEmptyKey())
                {
                    return false;
                }
                if (!IsStepSizeXYCorrectFormat() || !IsShotOffsetCorrectFormat())
                {
                    return false;
                }
                if (!IsCPE6Checked && !IsCPE15Checked && !IsCPE19Checked)
                {
                    return false;
                }
                flag = true;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return flag;
        }

        void GetFixedEdgeShotCount()
        {
            try
            {
                uStepSizeX = uint.Parse(StepSizeX);
                uStepSizeY = uint.Parse(StepSizeY);
                xRemainder = 300 % uStepSizeX;
                yRemainder = 300 % uStepSizeY;
                if (xRemainder != 0)
                {
                    xCount = 300 / uStepSizeX + 1;
                }
                else
                {
                    xCount = 300 / uStepSizeX;
                }
                if (yRemainder != 0)
                {
                    yCount = 300 / uStepSizeY + 1;
                }
                else
                {
                    yCount = 300 / uStepSizeY;
                }
                StepSizeXCount = xCount.ToString();
                StepSizeYCount = yCount.ToString();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        void GetFixedEdgeShotSize()
        {
            try
            {
                BtnHeight = StepSizeY;
                BtnWidth = StepSizeX;
                FixedEdgeShotWidth = "300";
                FixedEdgeShotHeight = "300";
                if (xRemainder != 0)
                {
                    uStepSizeX = uint.Parse(StepSizeX);
                    FixedEdgeShotWidth = (300 + uStepSizeX - xRemainder).ToString();
                    //BtnWidth = (uint.Parse(FixedEdgeShotWidth) / xCount).ToString();
                }
                if (yRemainder != 0)
                {
                    uStepSizeY = uint.Parse(StepSizeY);
                    FixedEdgeShotHeight = (300 + uStepSizeY - yRemainder).ToString();
                    //BtnHeight = (uint.Parse(FixedEdgeShotHeight) / yCount).ToString();
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        void GetFixedEdgeShotMargin()
        {
            try
            {
                if (!string.IsNullOrEmpty(ShotOffsetX) && !string.IsNullOrEmpty(ShotOffsetY))
                {
                    string tmpShotOffsetX = (int.Parse(ShotOffsetX) * 2).ToString();
                    string tmpShotOffsetY = (int.Parse(ShotOffsetY) * 2).ToString();

                    FixedEdgeShotMargin = "0," + tmpShotOffsetY + "," + tmpShotOffsetX + ",0";
                }
                else if (!string.IsNullOrEmpty(ShotOffsetX))
                {
                    string tmpShotOffsetX = (int.Parse(ShotOffsetX) * 2).ToString();
                    FixedEdgeShotMargin = "0,0," + tmpShotOffsetX + ",0";
                }
                else if (!string.IsNullOrEmpty(ShotOffsetY))
                {
                    string tmpShotOffsetY = (int.Parse(ShotOffsetY) * 2).ToString();
                    FixedEdgeShotMargin = "0," + tmpShotOffsetY + ",0,0";
                }
                else
                {
                    FixedEdgeShotMargin = "0";
                }

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        uint GetFixedEdgeXStartIndex(uint count)
        {
            uint iStart = 0;
            try
            {
                uint iRemainder = 0;
                iStart = count / 2;
                iRemainder = count % 2;
                if (iRemainder == 0)
                {
                    iStart = iStart - 1;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return iStart;
        }

        uint GetFixedEdgeYStartIndex(uint count)
        {
            uint iStart = 0;
            try
            {
                iStart = count / 2;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return iStart;
        }

        void InitFixedEdgeXIndex()
        {
            try
            {
                uint iStart = GetFixedEdgeXStartIndex(xCount);
                FixedEdgeXIndexHeight = StepSizeY;

                FixedEdgeShotXList = new ObservableCollection<FixedEdgeShotXYEntity>();
                for (int x = 0; x < xCount; x++)
                {
                    FixedEdgeShotXYEntity xyTextTmp = new FixedEdgeShotXYEntity();
                    xyTextTmp.BtnName = "btnX" + x.ToString();
                    xyTextTmp.BtnTag = x.ToString();
                    xyTextTmp.IsClickEnable = false;
                    xyTextTmp.BtnValue = (x - iStart).ToString();
                    xyTextTmp.BtnHeight = StepSizeY;
                    xyTextTmp.BtnWidth = StepSizeX;
                    xyTextTmp.BtnColor = "White";
                    FixedEdgeShotXList.Add(xyTextTmp);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void InitFixedEdgeYIndex()
        {
            try
            {
                uint iStart = GetFixedEdgeYStartIndex(yCount);
                FixedEdgeYIndexWidth = StepSizeX;

                FixedEdgeShotYList = new ObservableCollection<FixedEdgeShotXYEntity>();
                for (int y = 0; y < yCount; y++)
                {
                    FixedEdgeShotXYEntity xyTextTmp = new FixedEdgeShotXYEntity();
                    xyTextTmp.BtnName = "btnY" + y.ToString();
                    xyTextTmp.BtnTag = y.ToString();
                    xyTextTmp.IsClickEnable = false;
                    xyTextTmp.BtnValue = (iStart - y).ToString();
                    xyTextTmp.BtnHeight = StepSizeY;
                    xyTextTmp.BtnWidth = StepSizeX;
                    xyTextTmp.BtnColor = "White";
                    FixedEdgeShotYList.Add(xyTextTmp);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void InitFixedEdgeXY()
        {
            try
            {
                FixedEdgeXYOpacity = "0.7";
                FixedEdgeXYIndexVisibility = "Visible";
                GetFixedEdgeShotCount();
                xCount = uint.Parse(StepSizeXCount);
                yCount = uint.Parse(StepSizeYCount);

                GetFixedEdgeShotSize();
                GetFixedEdgeShotMargin();

                InitFixedEdgeXIndex();
                InitFixedEdgeYIndex();

                uint iStartX = GetFixedEdgeXStartIndex(xCount);
                uint iStartY = GetFixedEdgeYStartIndex(yCount);

                FixedEdgeShotXYList = new ObservableCollection<FixedEdgeShotXYEntity>();
                for (int y = 0; y < yCount; y++)
                {
                    for (int x = 0; x < xCount; x++)
                    {
                        FixedEdgeShotXYEntity xyTextTmp = new FixedEdgeShotXYEntity();
                        xyTextTmp.BtnName = "btnXY" + (y * 1 + x).ToString();
                        xyTextTmp.BtnTag = (x - iStartX).ToString() + "," + (iStartY - y).ToString();
                        xyTextTmp.IsClickEnable = true;
                        xyTextTmp.BtnValue = "";
                        xyTextTmp.BtnHeight = StepSizeY;
                        xyTextTmp.BtnWidth = StepSizeX;
                        xyTextTmp.BtnColor = "White";
                        FixedEdgeShotXYList.Add(xyTextTmp);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        bool GetShotPositionXYDetail(string ShotXYSelectedIndex)
        {
            bool flag = false;
            try
            {
                string shotPositionX = string.Empty;
                string shotPositionY = string.Empty;
                string[] array = ShotXYSelectedIndex.Split(',');
                ShotPositionX = array[0].ToString();
                ShotPositionY = array[1].ToString();

                #region Query 
                if (dbR2R_UI_Config_GetFixedEdgeShot_Update != null && dbR2R_UI_Config_GetFixedEdgeShot_Update.Rows.Count > 0)
                {
                    string strSelect = "PRODUCT = '" + Product + "' and LAYER = '" + Layer + "' and TOOL = '" + Tool + "' and TOOL_GROUP = '" + ToolGroup +
                    "' and PRE_TOOL = '" + PreTool + "' and PRE_RETICLE = '" + PreReticle + "' and RETICLE = '" + Reticle + "' and CPE_MODE = '" + CPEMode +
                    "' and STEP_SIZE_X = '" + StepSizeX + "' and STEP_SIZE_Y = '" + StepSizeY + "' and SHOT_OFFSET_X = '" + ShotOffsetX +
                    "' and SHOT_OFFSET_Y = '" + ShotOffsetY + "' and SHOT_POSITION_X = '" + ShotPositionX + "' and SHOT_POSITION_Y = '" + ShotPositionY + "'";
                    DataRow[] rows = DataTableHelp.Query(dbR2R_UI_Config_GetFixedEdgeShot_Update, strSelect);
                    if (rows.Count() > 0)
                    {
                        #region 
                        TranslationX = rows[0]["TRANSLATION_X"].ToString();
                        TranslationY = rows[0]["TRANSLATION_Y"].ToString();
                        Rotation = rows[0]["ROTATION"].ToString();
                        Magnification = rows[0]["MAGNIFICATION"].ToString();
                        AsymRotation = rows[0]["ASYM_ROTATION"].ToString();
                        AsymMagnification = rows[0]["ASYM_MAGNIFICATION"].ToString();
                        SecondOrderExpansionX = rows[0]["SECOND_ORDER_EXPANSION_X"].ToString();
                        SecondOrderExpansionY = rows[0]["SECOND_ORDER_EXPANSION_Y"].ToString();
                        TrapezoidX = rows[0]["TRAPEZOID_X"].ToString();
                        TrapezoidY = rows[0]["TRAPEZOID_Y"].ToString();
                        BowX = rows[0]["BOW_X"].ToString();
                        BowY = rows[0]["BOW_Y"].ToString();
                        ThirdOrderExpansionX = rows[0]["THIRD_ORDER_EXPANSION_X"].ToString();
                        ThirdOrderExpansionY = rows[0]["THIRD_ORDER_EXPANSION_Y"].ToString();
                        AccordionX = rows[0]["ACCORDION_X"].ToString();
                        AccordionY = rows[0]["ACCORDION_Y"].ToString();
                        CShapeDistortionX = rows[0]["CSHAPE_DISTORTION_X"].ToString();
                        CShapeDistortionY = rows[0]["CSHAPE_DISTORTION_Y"].ToString();
                        HirdOrderFlowX = rows[0]["HIRD_ORDER_FLOW_X"].ToString();
                        #endregion
                        flag = true;
                    }
                }
                if (!flag)
                {
                    ClearShotPositionXYDetail();
                }
                #endregion
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return flag;
        }

        void ClearShotPositionXY()
        {
            try
            {
                ShotPositionX = "";
                ShotPositionY = "";
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        void ClearShotPositionXYDetail()
        {
            try
            {
                TranslationX = "";
                TranslationY = "";
                Rotation = "";
                Magnification = "";
                AsymRotation = "";
                AsymMagnification = "";
                SecondOrderExpansionX = "";
                SecondOrderExpansionY = "";
                TrapezoidX = "";
                TrapezoidY = "";
                BowX = "";
                BowY = "";
                ThirdOrderExpansionX = "";
                ThirdOrderExpansionY = "";
                AccordionX = "";
                AccordionY = "";
                CShapeDistortionX = "";
                CShapeDistortionY = "";
                HirdOrderFlowX = "";
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Parameter
        CfgSingleTableInfoEntity cfgFixedEdgeShotUpdateEntity = new CfgSingleTableInfoEntity();
        List<string> cfgFixedEdgeShotColumnNameList = new List<string>();
        List<string> cfgFixedEdgeShotColumnKeyList = new List<string>();
        DataTable dbR2R_UI_Config_GetFixedEdgeShot_Source = new DataTable();
        DataTable dbR2R_UI_Config_GetFixedEdgeShot_Update = new DataTable();
        #endregion

        #region Compare Fun old
        List<FixedShotOffsetEntity> SourceEntityList = new List<FixedShotOffsetEntity>();
        List<FixedShotOffsetEntity> UpdateEntityList = new List<FixedShotOffsetEntity>();
        string GetFixedShotOffsetAdd(List<FixedShotOffsetEntity> sourceEntityList, List<FixedShotOffsetEntity> updateEntityList)
        {
            string strResult = "";
            try
            {
                List<FixedShotOffsetEntity> EntityList = new List<FixedShotOffsetEntity>();
                foreach (var updateEntity in updateEntityList)
                {
                    bool bIsHave = false;
                    foreach (var sourceEntity in sourceEntityList)
                    {
                        if (sourceEntity.PRODUCT.Equals(updateEntity.PRODUCT) && sourceEntity.LAYER.Equals(updateEntity.TOOL) && sourceEntity.LAYER.Equals(updateEntity.TOOL))
                        {
                            bIsHave = true;
                            break;
                        }
                    }
                    if (!bIsHave)
                    {
                        EntityList.Add(updateEntity);

                        strResult = JsonHelp.SerializeObject(EntityList);
                    }
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return strResult;
        }
        string GetFixedShotOffsetDelete(List<FixedShotOffsetEntity> sourceEntityList, List<FixedShotOffsetEntity> updateEntityList)
        {
            string strResult = "";
            try
            {
                List<FixedShotOffsetEntity> EntityList = new List<FixedShotOffsetEntity>();
                foreach (var sourceEntity in sourceEntityList)
                {
                    bool bIsHave = false;
                    foreach (var updateEntity in updateEntityList)
                    {
                        if (sourceEntity.PRODUCT.Equals(updateEntity.PRODUCT) && sourceEntity.LAYER.Equals(updateEntity.TOOL) && sourceEntity.LAYER.Equals(updateEntity.TOOL))
                        {
                            bIsHave = true;
                            break;
                        }
                    }
                    if (!bIsHave)
                    {
                        EntityList.Add(sourceEntity);

                        strResult = JsonHelp.SerializeObject(EntityList);
                    }
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return strResult;
        }
        string GetFixedShotOffsetModify(List<FixedShotOffsetEntity> sourceEntityList, List<FixedShotOffsetEntity> updateEntityList)
        {
            string strResult = "";
            try
            {
                List<FixedShotOffsetEntity> EntityList = new List<FixedShotOffsetEntity>();

                foreach (var updateEntity in updateEntityList)
                {
                    bool bIsEdit = false;
                    foreach (var sourceEntity in sourceEntityList)
                    {
                        if (sourceEntity.PRODUCT.Equals(updateEntity.PRODUCT) && sourceEntity.LAYER.Equals(updateEntity.TOOL) && sourceEntity.LAYER.Equals(updateEntity.TOOL))
                        {
                            string strSource = JsonHelp.SerializeObject(sourceEntity);
                            string strUpdate = JsonHelp.SerializeObject(updateEntity);
                            if (!strSource.Equals(strUpdate))
                            {
                                bIsEdit = true;
                            }
                            break;
                        }
                    }
                    if (bIsEdit)
                    {
                        EntityList.Add(updateEntity);

                        strResult = JsonHelp.SerializeObject(EntityList);
                    }
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return strResult;
        }
        #endregion

        #region Filed
        private string _Product;
        public string Product
        {
            get { return this._Product; }
            set { SetProperty(ref this._Product, value); }
        }

        private string _Layer;
        public string Layer
        {
            get { return this._Layer; }
            set { SetProperty(ref this._Layer, value); }
        }

        private string _ToolGroup;
        public string ToolGroup
        {
            get { return this._ToolGroup; }
            set { SetProperty(ref this._ToolGroup, value); }
        }

        private string _Tool;
        public string Tool
        {
            get { return this._Tool; }
            set { SetProperty(ref this._Tool, value); }
        }

        private string _Reticle;
        public string Reticle
        {
            get { return this._Reticle; }
            set { SetProperty(ref this._Reticle, value); }
        }

        private string _PreTool;
        public string PreTool
        {
            get { return this._PreTool; }
            set { SetProperty(ref this._PreTool, value); }
        }

        private string _PreReticle;
        public string PreReticle
        {
            get { return this._PreReticle; }
            set { SetProperty(ref this._PreReticle, value); }
        }
        private string _CPEMode;
        public string CPEMode
        {
            get { return this._CPEMode; }
            set { SetProperty(ref this._CPEMode, value); }
        }
        private bool _IsCPE6Checked;
        public bool IsCPE6Checked
        {
            get { return this._IsCPE6Checked; }
            set { SetProperty(ref this._IsCPE6Checked, value); }
        }
        private bool _IsCPE15Checked;
        public bool IsCPE15Checked
        {
            get { return this._IsCPE15Checked; }
            set { SetProperty(ref this._IsCPE15Checked, value); }
        }
        private bool _IsCPE19Checked;
        public bool IsCPE19Checked
        {
            get { return this._IsCPE19Checked; }
            set { SetProperty(ref this._IsCPE19Checked, value); }
        }
        //private bool _IsBtnOkEnable = false;
        //public bool IsBtnOkEnable
        //{
        //    get { return this._IsBtnOkEnable; }
        //    set { SetProperty(ref this._IsBtnOkEnable, value); }
        //}

        private bool _IsBtnDeleteEnable =false;
        public bool IsBtnDeleteEnable
        {
            get { return this._IsBtnDeleteEnable; }
            set { SetProperty(ref this._IsBtnDeleteEnable, value); }
        }

        private bool _IsBtnDoneEnable=false;
        public bool IsBtnDoneEnable
        {
            get { return this._IsBtnDoneEnable; }
            set { SetProperty(ref this._IsBtnDoneEnable, value); }
        }
        private bool _IsBtnSaveEnable=true;
        public bool IsBtnSaveEnable
        {
            get { return this._IsBtnSaveEnable; }
            set { SetProperty(ref this._IsBtnSaveEnable, value); }
        }
        
        private string _TranslationX;
        public string TranslationX
        {
            get { return this._TranslationX; }
            set { SetProperty(ref this._TranslationX, value); }
        }

        private string _TranslationY;
        public string TranslationY
        {
            get { return this._TranslationY; }
            set { SetProperty(ref this._TranslationY, value); }
        }
        private string _Rotation;
        public string Rotation
        {
            get { return this._Rotation; }
            set { SetProperty(ref this._Rotation, value); }
        }
        private string _Magnification;
        public string Magnification
        {
            get { return this._Magnification; }
            set { SetProperty(ref this._Magnification, value); }
        }
        private string _AsymMagnification;
        public string AsymMagnification
        {
            get { return this._AsymMagnification; }
            set { SetProperty(ref this._AsymMagnification, value); }
        }

        private string _AsymRotation;
        public string AsymRotation
        {
            get { return this._AsymRotation; }
            set { SetProperty(ref this._AsymRotation, value); }
        }

        private string _SecondOrderExpansionX;
        public string SecondOrderExpansionX
        {
            get { return this._SecondOrderExpansionX; }
            set { SetProperty(ref this._SecondOrderExpansionX, value); }
        }
        private string _SecondOrderExpansionY;
        public string SecondOrderExpansionY
        {
            get { return this._SecondOrderExpansionY; }
            set { SetProperty(ref this._SecondOrderExpansionY, value); }
        }

        private string _TrapezoidX;
        public string TrapezoidX
        {
            get { return this._TrapezoidX; }
            set { SetProperty(ref this._TrapezoidX, value); }
        }
        private string _TrapezoidY;
        public string TrapezoidY
        {
            get { return this._TrapezoidY; }
            set { SetProperty(ref this._TrapezoidY, value); }
        }

        private string _BowX;
        public string BowX
        {
            get { return this._BowX; }
            set { SetProperty(ref this._BowX, value); }
        }
        private string _BowY;
        public string BowY
        {
            get { return this._BowY; }
            set { SetProperty(ref this._BowY, value); }
        }

        private string _ThirdOrderExpansionX;
        public string ThirdOrderExpansionX
        {
            get { return this._ThirdOrderExpansionX; }
            set { SetProperty(ref this._ThirdOrderExpansionX, value); }
        }
        private string _ThirdOrderExpansionY;
        public string ThirdOrderExpansionY
        {
            get { return this._ThirdOrderExpansionY; }
            set { SetProperty(ref this._ThirdOrderExpansionY, value); }
        }

        private string _AccordionX;
        public string AccordionX
        {
            get { return this._AccordionX; }
            set { SetProperty(ref this._AccordionX, value); }
        }
        private string _AccordionY;
        public string AccordionY
        {
            get { return this._AccordionY; }
            set { SetProperty(ref this._AccordionY, value); }
        }

        private string _CShapeDistortionX;
        public string CShapeDistortionX
        {
            get { return this._CShapeDistortionX; }
            set { SetProperty(ref this._CShapeDistortionX, value); }
        }
        private string _CShapeDistortionY;
        public string CShapeDistortionY
        {
            get { return this._CShapeDistortionY; }
            set { SetProperty(ref this._CShapeDistortionY, value); }
        }

        private string _HirdOrderFlowX;
        public string HirdOrderFlowX
        {
            get { return this._HirdOrderFlowX; }
            set { SetProperty(ref this._HirdOrderFlowX, value); }
        }
        private string _HirdOrderFlowY;
        public string HirdOrderFlowY
        {
            get { return this._HirdOrderFlowY; }
            set { SetProperty(ref this._HirdOrderFlowY, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }

        //private string _ToolGroup;
        //public string ToolGroup
        //{
        //    get { return this._ToolGroup; }
        //    set { SetProperty(ref this._ToolGroup, value); }
        //}
        #endregion

        #region FixedEdgeX Filed
        private string _FixedEdgeXIndexHeight;
        public string FixedEdgeXIndexHeight
        {
            get { return this._FixedEdgeXIndexHeight; }
            set { SetProperty(ref this._FixedEdgeXIndexHeight, value); }
        }

        private FixedEdgeShotXYEntity _FixedEdgeShotXSelected;
        public FixedEdgeShotXYEntity FixedEdgeShotXSelected
        {
            get { return this._FixedEdgeShotXSelected; }
            set { SetProperty(ref this._FixedEdgeShotXSelected, value); }
        }

        private ObservableCollection<FixedEdgeShotXYEntity> _FixedEdgeShotXList;
        public ObservableCollection<FixedEdgeShotXYEntity> FixedEdgeShotXList
        {
            get { return _FixedEdgeShotXList; }
            set { SetProperty(ref _FixedEdgeShotXList, value); }
        }
        #endregion

        #region FixedEdgeY Filed
        private string _FixedEdgeYIndexWidth;
        public string FixedEdgeYIndexWidth
        {
            get { return this._FixedEdgeYIndexWidth; }
            set { SetProperty(ref this._FixedEdgeYIndexWidth, value); }
        }

        private FixedEdgeShotXYEntity _FixedEdgeShotYSelected;
        public FixedEdgeShotXYEntity FixedEdgeShotYSelected
        {
            get { return this._FixedEdgeShotYSelected; }
            set { SetProperty(ref this._FixedEdgeShotYSelected, value); }
        }

        private ObservableCollection<FixedEdgeShotXYEntity> _FixedEdgeShotYList;
        public ObservableCollection<FixedEdgeShotXYEntity> FixedEdgeShotYList
        {
            get { return _FixedEdgeShotYList; }
            set { SetProperty(ref _FixedEdgeShotYList, value); }
        }
        #endregion

        #region FixedEdge Filed
        private string _BtnHeight;
        public string BtnHeight
        {
            get { return this._BtnHeight; }
            set { SetProperty(ref this._BtnHeight, value); }
        }
        private string _BtnWidth;
        public string BtnWidth
        {
            get { return this._BtnWidth; }
            set { SetProperty(ref this._BtnWidth, value); }
        }
        private string _BtnSingleValue;
        public string BtnSingleValue
        {
            get { return this._BtnSingleValue; }
            set { SetProperty(ref this._BtnSingleValue, value); }
        }

        private string _FixedEdgeXYOpacity = "0.7";
        public string FixedEdgeXYOpacity
        {
            get { return this._FixedEdgeXYOpacity; }
            set { SetProperty(ref this._FixedEdgeXYOpacity, value); }
        }

        private string _FixedEdgeXYIndexVisibility = "Hidden";
        public string FixedEdgeXYIndexVisibility
        {
            get { return this._FixedEdgeXYIndexVisibility; }
            set { SetProperty(ref this._FixedEdgeXYIndexVisibility, value); }
        }

        private string _StepSizeX;
        public string StepSizeX
        {
            get { return this._StepSizeX; }
            set { SetProperty(ref this._StepSizeX, value); }
        }

        private string _StepSizeY;
        public string StepSizeY
        {
            get { return this._StepSizeY; }
            set { SetProperty(ref this._StepSizeY, value); }
        }

        private string _ShotOffsetX;
        public string ShotOffsetX
        {
            get { return this._ShotOffsetX; }
            set { SetProperty(ref this._ShotOffsetX, value); }
        }

        private string _ShotOffsetY;
        public string ShotOffsetY
        {
            get { return this._ShotOffsetY; }
            set { SetProperty(ref this._ShotOffsetY, value); }
        }

        private string _ShotPositionX;
        public string ShotPositionX
        {
            get { return this._ShotPositionX; }
            set { SetProperty(ref this._ShotPositionX, value); }
        }

        private string _ShotPositionY;
        public string ShotPositionY
        {
            get { return this._ShotPositionY; }
            set { SetProperty(ref this._ShotPositionY, value); }
        }

        private string _FixedEdgeShotHeight = "300";
        public string FixedEdgeShotHeight
        {
            get { return this._FixedEdgeShotHeight; }
            set { SetProperty(ref this._FixedEdgeShotHeight, value); }
        }

        private string _FixedEdgeShotWidth = "300";
        public string FixedEdgeShotWidth
        {
            get { return this._FixedEdgeShotWidth; }
            set { SetProperty(ref this._FixedEdgeShotWidth, value); }
        }

        private string _FixedEdgeShotMargin = "0";
        public string FixedEdgeShotMargin
        {
            get { return this._FixedEdgeShotMargin; }
            set { SetProperty(ref this._FixedEdgeShotMargin, value); }
        }

        private string _FixedEdgeXYMargin = "0";
        public string FixedEdgeXYMargin
        {
            get { return this._FixedEdgeXYMargin; }
            set { SetProperty(ref this._FixedEdgeXYMargin, value); }
        }

        private string _StepSizeXCount;
        public string StepSizeXCount
        {
            get { return this._StepSizeXCount; }
            set { SetProperty(ref this._StepSizeXCount, value); }
        }

        private string _StepSizeYCount;
        public string StepSizeYCount
        {
            get { return this._StepSizeYCount; }
            set { SetProperty(ref this._StepSizeYCount, value); }
        }

        private FixedEdgeShotSelectEntryEntity _SelectedTermSetting;
        public FixedEdgeShotSelectEntryEntity SelectedTermSetting
        {
            get { return this._SelectedTermSetting; }
            set { SetProperty(ref this._SelectedTermSetting, value); }
        }

        private ObservableCollection<FixedEdgeShotSelectEntryEntity> _SettingTermList;
        public ObservableCollection<FixedEdgeShotSelectEntryEntity> SettingTermList
        {
            get { return _SettingTermList; }
            set { SetProperty(ref _SettingTermList, value); }
        }

        private FixedEdgeShotXYEntity _FixedEdgeShotXYSelected;
        public FixedEdgeShotXYEntity FixedEdgeShotXYSelected
        {
            get { return this._FixedEdgeShotXYSelected; }
            set { SetProperty(ref this._FixedEdgeShotXYSelected, value); }
        }

        private ObservableCollection<FixedEdgeShotXYEntity> _FixedEdgeShotXYList;
        public ObservableCollection<FixedEdgeShotXYEntity> FixedEdgeShotXYList
        {
            get { return _FixedEdgeShotXYList; }
            set { SetProperty(ref _FixedEdgeShotXYList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _BtnOkCommand;
        public DelegateCommand BtnOkCommand =>
            _BtnOkCommand ?? (_BtnOkCommand = new DelegateCommand(OnBtnOkClick));

        private DelegateCommand _BtnSaveCommand;
        public DelegateCommand BtnSaveCommand =>
            _BtnSaveCommand ?? (_BtnSaveCommand = new DelegateCommand(OnBtnSaveClick));

        private DelegateCommand _BtnDoneCommand;
        public DelegateCommand BtnDoneCommand =>
            _BtnDoneCommand ?? (_BtnDoneCommand = new DelegateCommand(OnBtnDoneClick));

        private DelegateCommand _BtnDeleteCommand;
        public DelegateCommand BtnDeleteCommand =>
            _BtnDeleteCommand ?? (_BtnDeleteCommand = new DelegateCommand(OnBtnDeleteClick));

        private DelegateCommand<Object> _BtnXYCommand;
        public DelegateCommand<Object> BtnXYCommand =>
            _BtnXYCommand ?? (_BtnXYCommand = new DelegateCommand<Object>(OnBtnXYClick));

        private DelegateCommand _CPEModeCheckedCommand;
        public DelegateCommand CPEModeCheckedCommand =>
            _CPEModeCheckedCommand ?? (_CPEModeCheckedCommand = new DelegateCommand(OnCPEModeChecked));

        #endregion

        #region Event Fun
        void OnBtnOkClick()
        {
            try
            {
                InitBtn();
                ClearShotPositionXY();
                ClearShotPositionXYDetail();
                bool flagStepSizeXY = IsStepSizeXYCorrectFormat();
                bool flagShotOffsetXY = IsShotOffsetCorrectFormat();
                if (flagStepSizeXY && flagShotOffsetXY)
                {
                    InitFixedEdgeXY();

                }

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        void OnBtnSaveClick()
        {
            try
            {
                if (!CheckKeyFormat())
                {
                    //MessageBox.Show("Please click the Done button first!");
                    return;
                }

                #region Compare
                DataTable dbCfgChanged = DataTableHelp.CompareDataTable(dbR2R_UI_Config_GetFixedEdgeShot_Source, dbR2R_UI_Config_GetFixedEdgeShot_Update, cfgFixedEdgeShotColumnKeyList);
                DataTable dbOld = DataTableHelp.GetChangedRecord(dbCfgChanged, "Status", "Old");
                DataTable dbModify = DataTableHelp.GetChangedRecord(dbCfgChanged, "Status", "Edit");
                DataTable dbAdd = DataTableHelp.GetChangedRecord(dbCfgChanged, "Status", "Add");
                DataTable dbDelete = DataTableHelp.GetChangedRecord(dbCfgChanged, "Status", "Delete");

                string ContentAdd = "";
                string ContentModify = "";
                string ContentDelete = "";
                if (dbAdd.Rows.Count > 0)
                {
                    cfgFixedEdgeShotUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbAdd, cfgFixedEdgeShotColumnNameList);
                    ContentAdd = JsonHelp.SerializeObject(cfgFixedEdgeShotUpdateEntity);
                }

                if (dbModify.Rows.Count > 0)
                {
                    cfgFixedEdgeShotUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbModify, cfgFixedEdgeShotColumnNameList);
                    ContentModify = JsonHelp.SerializeObject(cfgFixedEdgeShotUpdateEntity);
                }

                if (dbDelete.Rows.Count > 0)
                {
                    cfgFixedEdgeShotUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbDelete, cfgFixedEdgeShotColumnNameList);
                    ContentDelete = JsonHelp.SerializeObject(cfgFixedEdgeShotUpdateEntity);
                }
                #endregion

                if (!string.IsNullOrEmpty(ContentAdd) || !string.IsNullOrEmpty(ContentModify) || !string.IsNullOrEmpty(ContentDelete))
                {
                    bool falg = InvokeR2R_UI_Config_FixedEdgeShotSave(ContentAdd, ContentModify, ContentDelete);

                    if (falg)
                    {
                        CfgSingleTableInfoEntity entity = InvokeR2R_UI_Config_GetFixedEdgeShot();
                        InitFixedEdgeShot(entity);
                        OnBtnOkClick();
                    }
                }

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        void OnBtnDoneClick()
        {
            try
            {
                if (!CheckKeyFormat())
                {
                    return;
                }

                #region Edit 
                string strSelect = "PRODUCT = '" + Product + "' and LAYER = '" + Layer + "' and TOOL = '" + Tool + "' and TOOL_GROUP = '" + ToolGroup +
                    "' and PRE_TOOL = '" + PreTool + "' and PRE_RETICLE = '" + PreReticle + "' and RETICLE = '" + Reticle + "' and CPE_MODE = '" + CPEMode +
                    "' and STEP_SIZE_X = '" + StepSizeX + "' and STEP_SIZE_Y = '" + StepSizeY + "' and SHOT_OFFSET_X = '" + ShotOffsetX +
                    "' and SHOT_OFFSET_Y = '" + ShotOffsetY + "' and SHOT_POSITION_X = '" + ShotPositionX + "' and SHOT_POSITION_Y = '" + ShotPositionY + "'";
                DataRow[] rows = DataTableHelp.Query(dbR2R_UI_Config_GetFixedEdgeShot_Update, strSelect);
                if (rows.Count() > 0)
                {
                    #region 
                    rows[0]["TRANSLATION_X"] = TranslationX;
                    rows[0]["TRANSLATION_Y"] = TranslationY;
                    rows[0]["ROTATION"] = Rotation;
                    rows[0]["MAGNIFICATION"] = Magnification;
                    rows[0]["ASYM_ROTATION"] = AsymRotation;
                    rows[0]["ASYM_MAGNIFICATION"] = AsymMagnification;
                    rows[0]["SECOND_ORDER_EXPANSION_X"] = SecondOrderExpansionX;
                    rows[0]["SECOND_ORDER_EXPANSION_Y"] = SecondOrderExpansionY;
                    rows[0]["TRAPEZOID_X"] = TrapezoidX;
                    rows[0]["TRAPEZOID_Y"] = TrapezoidY;
                    rows[0]["BOW_X"] = BowX;
                    rows[0]["BOW_Y"] = BowY;
                    rows[0]["THIRD_ORDER_EXPANSION_X"] = ThirdOrderExpansionX;
                    rows[0]["THIRD_ORDER_EXPANSION_Y"] = ThirdOrderExpansionY;
                    rows[0]["ACCORDION_X"] = AccordionX;
                    rows[0]["ACCORDION_Y"] = AccordionY;
                    rows[0]["CSHAPE_DISTORTION_X"] = CShapeDistortionX;
                    rows[0]["CSHAPE_DISTORTION_Y"] = CShapeDistortionY;
                    rows[0]["HIRD_ORDER_FLOW_X"] = HirdOrderFlowX;
                    #endregion
                }
                else
                {
                    DataRow row = dbR2R_UI_Config_GetFixedEdgeShot_Update.NewRow();
                    row["PRODUCT"] = Product;
                    row["LAYER"] = Layer;
                    row["TOOL_GROUP"] = ToolGroup;
                    row["TOOL"] = Tool;
                    row["PRE_TOOL"] = PreTool;
                    row["RETICLE"] = Reticle;
                    row["PRE_RETICLE"] = PreReticle;
                    row["CPE_MODE"] = CPEMode;
                    row["STEP_SIZE_X"] = StepSizeX;
                    row["STEP_SIZE_Y"] = StepSizeY;
                    row["SHOT_OFFSET_X"] = ShotOffsetX;
                    row["SHOT_OFFSET_Y"] = ShotOffsetY;
                    row["SHOT_POSITION_X"] = ShotPositionX;
                    row["SHOT_POSITION_Y"] = ShotPositionY;
                    row["TRANSLATION_X"] = TranslationX;
                    row["TRANSLATION_Y"] = TranslationY;
                    row["ROTATION"] = Rotation;
                    row["MAGNIFICATION"] = Magnification;
                    row["ASYM_ROTATION"] = AsymRotation;
                    row["ASYM_MAGNIFICATION"] = AsymMagnification;
                    row["SECOND_ORDER_EXPANSION_X"] = SecondOrderExpansionX;
                    row["SECOND_ORDER_EXPANSION_Y"] = SecondOrderExpansionY;
                    row["TRAPEZOID_X"] = TrapezoidX;
                    row["TRAPEZOID_Y"] = TrapezoidY;
                    row["BOW_X"] = BowX;
                    row["BOW_Y"] = BowY;
                    row["THIRD_ORDER_EXPANSION_X"] = ThirdOrderExpansionX;
                    row["THIRD_ORDER_EXPANSION_Y"] = ThirdOrderExpansionY;
                    row["ACCORDION_X"] = AccordionX;
                    row["ACCORDION_Y"] = AccordionY;
                    row["CSHAPE_DISTORTION_X"] = CShapeDistortionX;
                    row["CSHAPE_DISTORTION_Y"] = CShapeDistortionY;
                    row["HIRD_ORDER_FLOW_X"] = HirdOrderFlowX;

                    dbR2R_UI_Config_GetFixedEdgeShot_Update.Rows.Add(row);
                }
                IsBtnSaveEnable = true;
                #endregion
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        void OnBtnDeleteClick()
        {
            try
            {
                if (string.IsNullOrEmpty(ShotPositionX) || string.IsNullOrEmpty(ShotPositionY))
                {
                    return;
                }

                #region Delete 
                string strSelect = "PRODUCT = '" + Product + "' and LAYER = '" + Layer + "' and TOOL = '" + Tool + "' and TOOL_GROUP = '" + ToolGroup +
                    "' and PRE_TOOL = '" + PreTool + "' and PRE_RETICLE = '" + PreReticle + "' and RETICLE = '" + Reticle + "' and CPE_MODE = '" + CPEMode +
                    "' and STEP_SIZE_X = '" + StepSizeX + "' and STEP_SIZE_Y = '" + StepSizeY + "' and SHOT_OFFSET_X = '" + ShotOffsetX +
                    "' and SHOT_OFFSET_Y = '" + ShotOffsetY + "' and SHOT_POSITION_X = '" + ShotPositionX + "' and SHOT_POSITION_Y = '" + ShotPositionY + "'";
                DataRow[] rows = DataTableHelp.Query(dbR2R_UI_Config_GetFixedEdgeShot_Update, strSelect);
                if (rows.Count() > 0)
                {
                    #region 
                    for (int i = 0; i < rows.Count(); i++)
                    {
                        dbR2R_UI_Config_GetFixedEdgeShot_Update.Rows.Remove(rows[i]);
                    }
                    #endregion
                }

                ClearShotPositionXY();
                ClearShotPositionXYDetail();
                IsBtnDoneEnable = false;
                IsBtnSaveEnable = true;
                #endregion
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnBtnXYClick(Object obj)
        {
            try
            {
                FixedEdgeShotXYSelected = obj as FixedEdgeShotXYEntity;
                if (FixedEdgeShotXYSelected != null)
                {
                    if(!CheckKeyFormat())
                    {
                        MessageBox.Show("Key cannot be empty!");
                    }
                    IsBtnDeleteEnable = false;
                    IsBtnDoneEnable = true;
                    ClearShotPositionXY();
                    bool flag = GetShotPositionXYDetail(FixedEdgeShotXYSelected.BtnTag);
                    if (flag)
                    {
                        FixedEdgeShotXYSelected.BtnColor = "Blue";
                        IsBtnDeleteEnable = true;
                    }
                    else
                    {
                        FixedEdgeShotXYSelected.BtnColor = "Red";
                    }
                    FixedEdgeShotXYSelected.BtnOpacity = "1";
                }

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnCPEModeChecked()
        {
            try
            {
                if (IsCPE6Checked)
                {
                    CPEMode = "CPE-6";
                }
                else if (IsCPE15Checked)
                {
                    CPEMode = "CPE-15";
                }
                else if (IsCPE19Checked)
                {
                    CPEMode = "CPE-19";
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion

    }
}
