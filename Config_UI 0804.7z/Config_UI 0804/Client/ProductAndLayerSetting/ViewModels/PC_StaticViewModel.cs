﻿using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProductAndLayerSetting.ViewModels
{
    class PC_StaticViewModel : ViewModelBase
    {
        public ISettingMainService _SettingMainService { get; set; }
        public PC_StaticViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
        }

        IRegionNavigationJournal _journal;
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            try
            {
                _journal = navigationContext.NavigationService.Journal;

                var msg = navigationContext.Parameters["Message"] as SendWaferModeParam;
                if (msg != null)
                {
                    SendWaferParam = msg;

                    IsWaferFeedForewardYes = bool.Parse(SendWaferParam.OVLPCFeedforeward);
                    IsWaferFeedForewardNo = !IsWaferFeedForewardYes;
                    WaferLumda = SendWaferParam.OVLPCLumda;
                    PCUpdateTime = SendWaferParam.OVLPCUpdateTime;
                    PCUpdateLot = SendWaferParam.OVLPCUpdateLot;
                    PCExpireTime = SendWaferParam.OVLPCExpireTime;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        SendWaferModeParam SendWaferParam = new SendWaferModeParam();

        public override bool IsNavigationTarget(NavigationContext navigationContext)
        {
            var msg = navigationContext.Parameters["Message"] as SendWaferModeParam;
            return true;
        }

        #region Init
        /// <summary>
        /// Init ControlByChuck
        /// </summary>
        /// <param name="strScannerGroup"></param>
        void InitControlByChuck(string strScannerGroup)
        {
            if (strScannerGroup.ToUpper().Equals("CANON"))
            {

            }
        }
        /// <summary>
        /// Init WaferFeedForeward
        /// </summary>
        void InitWaferFeedForeward()
        {
            IsWaferFeedForewardEnable = true;
        }
        #endregion

        #region Filed
        private List<string> _ChangeList = new List<string>();
        public List<string> ChangeList
        {
            get { return this._ChangeList; }
            set { SetProperty(ref this._ChangeList, value); }
        }

        private bool _IsWaferFeedForewardYes=false;
        public bool IsWaferFeedForewardYes
        {
            get { return this._IsWaferFeedForewardYes; }
            set { SetProperty(ref this._IsWaferFeedForewardYes, value); }
        }

        private bool __IsWaferFeedForewardNo=true;
        public bool IsWaferFeedForewardNo
        {
            get { return this.__IsWaferFeedForewardNo; }
            set { SetProperty(ref this.__IsWaferFeedForewardNo, value); }
        }

        private bool _IsWaferFeedForewardEnable=true;
        public bool IsWaferFeedForewardEnable
        {
            get { return this._IsWaferFeedForewardEnable; }
            set { SetProperty(ref this._IsWaferFeedForewardEnable, value); }
        }

        private string _WaferLumda;
        public string WaferLumda
        {
            get { return this._WaferLumda; }
            set { SetProperty(ref this._WaferLumda, value); }
        }

        private string _PCUpdateTime;
        public string PCUpdateTime
        {
            get { return this._PCUpdateTime; }
            set { SetProperty(ref this._PCUpdateTime, value); }
        }

        private string _PCUpdateLot;
        public string PCUpdateLot
        {
            get { return this._PCUpdateLot; }
            set { SetProperty(ref this._PCUpdateLot, value); }
        }

        private string _PCExpireTime;
        public string PCExpireTime
        {
            get { return this._PCExpireTime; }
            set { SetProperty(ref this._PCExpireTime, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _LayoutUpdatedCommand;
        public DelegateCommand LayoutUpdatedCommand =>
            _LayoutUpdatedCommand ?? (_LayoutUpdatedCommand = new DelegateCommand(OnLayoutUpdated));

        #endregion

        #region Event Fun
        /// <summary>
        /// TextChanged Event Fun
        /// </summary>
        void OnLayoutUpdated()
        {
            ChangeList = new List<string>();
            ChangeList.Add(IsWaferFeedForewardYes.ToString().ToLower());
            double num1 = double.NaN;
            if (double.TryParse(WaferLumda, out num1))
            {
                if (num1 < 0 || num1 > 1)
                {
                    WaferLumda = "";
                }
            }
            else
            {
                WaferLumda = "";
            }
            if (!double.TryParse(PCUpdateTime, out num1))
            {
                PCUpdateTime = "";
            }
            if (!double.TryParse(PCUpdateLot, out num1))
            {
                PCUpdateLot = "";
            }
            uint tmp = 0;
            if (!uint.TryParse(PCExpireTime, out tmp))
            {
                PCExpireTime = "";
            }
            ChangeList.Add(WaferLumda);
            ChangeList.Add(PCUpdateTime);
            ChangeList.Add(PCUpdateLot);
            ChangeList.Add(PCExpireTime);
            EventAggregator.GetEvent<PCStaticChangedEvent>().Publish(ChangeList);
        }
        #endregion
    }
}
