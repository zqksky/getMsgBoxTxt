﻿using Prism.Commands;
using Prism.Events;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProductAndLayerSetting.ViewModels
{
    class CD_InitialSettingViewModel : ViewModelBase
    {
        public CD_InitialSettingViewModel()
        {

        }

        public ISettingMainService _SettingMainService { get; set; }
        public CD_InitialSettingViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "CD Initial Setting";

        }
        /// <summary>
        /// Init Event fun
        /// </summary>
        void OnInit()
        {
            try
            {
                if (IsCDInitialEnable)
                {
                    IsGrdReadOnly = false;
                    IsBtnEnable = true;
                }
                else
                {
                    IsGrdReadOnly = true;
                    IsBtnEnable = false;
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        #region Filed
        private bool _IsCDInitialEnable = true;
        public bool IsCDInitialEnable
        {
            get { return this._IsCDInitialEnable; }
            set { SetProperty(ref this._IsCDInitialEnable, value); }
        }

        private bool _IsGrdReadOnly = false;
        public bool IsGrdReadOnly
        {
            get { return this._IsGrdReadOnly; }
            set { SetProperty(ref this._IsGrdReadOnly, value); }
        }

        private bool _IsBtnEnable = true;
        public bool IsBtnEnable
        {
            get { return this._IsBtnEnable; }
            set { SetProperty(ref this._IsBtnEnable, value); }
        }

        private bool _IsBtnOkClick = false;
        public bool IsBtnOkClick
        {
            get { return this._IsBtnOkClick; }
            set { SetProperty(ref this._IsBtnOkClick, value); }
        }

        private string _Product;
        public string Product
        {
            get { return this._Product; }
            set { SetProperty(ref this._Product, value); }
        }

        private string _Layer;
        public string Layer
        {
            get { return this._Layer; }
            set { SetProperty(ref this._Layer, value); }
        }

        private string _ToolGroup;
        public string ToolGroup
        {
            get { return this._ToolGroup; }
            set { SetProperty(ref this._ToolGroup, value); }
        }

        private string _DoseUSL;
        public string DoseUSL
        {
            get { return this._DoseUSL; }
            set { SetProperty(ref this._DoseUSL, value); }
        }

        private string _DoseLSL;
        public string DoseLSL
        {
            get { return this._DoseLSL; }
            set { SetProperty(ref this._DoseLSL, value); }
        }

        private CD_InitialSettingEntity _SelectedSetting;
        public CD_InitialSettingEntity SelectedSetting
        {
            get { return this._SelectedSetting; }
            set { SetProperty(ref this._SelectedSetting, value); }
        }

        private ObservableCollection<CD_InitialSettingEntity> _SettingList =new ObservableCollection<CD_InitialSettingEntity>();
        public ObservableCollection<CD_InitialSettingEntity> SettingList
        {
            get { return _SettingList; }
            set { SetProperty(ref _SettingList, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnInit));

        private DelegateCommand _SelectRowClickCommand;
        public DelegateCommand SelectRowClickCommand =>
            _SelectRowClickCommand ?? (_SelectRowClickCommand = new DelegateCommand(OnSelectRowClick));

        private DelegateCommand _BeginningEditCommand;
        public DelegateCommand BeginningEditCommand =>
            _BeginningEditCommand ?? (_BeginningEditCommand = new DelegateCommand(OnBeginningEdit));

        private DelegateCommand _CellEditEndingCommand;
        public DelegateCommand CellEditEndingCommand =>
            _CellEditEndingCommand ?? (_CellEditEndingCommand = new DelegateCommand(OnCellEditEnding));

        private DelegateCommand _LostFocusCommand;
        public DelegateCommand LostFocusCommand =>
            _LostFocusCommand ?? (_LostFocusCommand = new DelegateCommand(OnLostFocus));

        private DelegateCommand _BtnAddCommand;
        public DelegateCommand BtnAddCommand =>
            _BtnAddCommand ?? (_BtnAddCommand = new DelegateCommand(OnAddClick));

        private DelegateCommand _BtnDeleteCommand;
        public DelegateCommand BtnDeleteCommand =>
            _BtnDeleteCommand ?? (_BtnDeleteCommand = new DelegateCommand(OnDeleteClick));

        private DelegateCommand _BtnConfirmCommand;
        public DelegateCommand BtnConfirmCommand =>
            _BtnConfirmCommand ?? (_BtnConfirmCommand = new DelegateCommand(OnBtnConfirmClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));
        #endregion

        #region Event Fun
        /// <summary>
        /// Add Button Click Event Fun
        /// </summary>
        void OnAddClick()
        {
            try
            {
                IsDeleteRow = false;
                SelectedSetting = new CD_InitialSettingEntity();
                SelectedSetting.Product = Product;
                SelectedSetting.Layer = Layer;
                SelectedSetting.ToolGroup = ToolGroup;
                SelectedSetting.Parameter = SettingList[0].Parameter;
                SelectedSetting.R2RMode = SettingList[0].R2RMode;
                SelectedSetting.R2RModeList = new List<string>(SettingList[0].R2RModeList);
                SelectedSetting.ToolList = new List<string>(SettingList[0].ToolList);
                SelectedSetting.Tool = "";
                SelectedSetting.Reticle= "";
                SelectedSetting.DoseValue = "0";
                SelectedSetting.FocusValue = "0";
                SelectedSetting.DoseSensitivity = "0";
                SettingList.Add(SelectedSetting);
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        bool IsDeleteRow = false;
        /// <summary>
        /// Delete Button Click Event Fun
        /// </summary>
        void OnDeleteClick()
        {
            try
            {
                if (SelectedSetting == null)
                {
                    System.Windows.Forms.MessageBox.Show("Please select a row!");
                }
                if (SettingList.Count == 1)
                {
                    System.Windows.Forms.MessageBox.Show("Only one record!");
                    return;
                }
                IsDeleteRow = true;
                SettingList.Remove(SelectedSetting);
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Confirm Button Click Event fun
        /// </summary>
        void OnBtnConfirmClick()
        {
            try
            {
                List<string> ReticleValueList = new List<string>();
                List<string> DoseSensitivityValueList = new List<string>();
                foreach (var obj in SettingList)
                {
                    if (string.IsNullOrEmpty(obj.Tool) || string.IsNullOrEmpty(obj.Reticle))
                    {
                        System.Windows.Forms.MessageBox.Show("Tool/Reticle cannot be empty!");
                        return;
                    }

                    #region Check DoseSensitivity
                    string strReticleValue = obj.Reticle;
                    string strDoseSensitivityValue = obj.DoseSensitivity;
                    if (ReticleValueList.Contains(strReticleValue))
                    {
                        int index = ReticleValueList.IndexOf(strReticleValue);
                        if (!DoseSensitivityValueList[index].Equals(strDoseSensitivityValue))
                        {
                            System.Windows.Forms.MessageBox.Show("Same Reticle, DoseSensitivity must have the same value!");
                            return;
                        }
                    }
                    else
                    {
                        ReticleValueList.Add(strReticleValue);
                        DoseSensitivityValueList.Add(strDoseSensitivityValue);
                    }
                    #endregion

                    double tmp = double.NaN;
                    if (double.TryParse(obj.DoseValue, out tmp))
                    {
                        if (tmp < double.Parse(DoseLSL) || tmp > double.Parse(DoseUSL))
                        {

                            System.Windows.Forms.MessageBox.Show(obj.Tool+"/"+obj.Reticle+" --- DoseValue out of range!");
                            if (SelectedSetting != null)
                            {
                                SelectedSetting.DoseValue = currentDoseValue;
                            }
                            return;
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input DoseValue was not in a correct format!");
                        return;
                    }

                    if (!double.TryParse(obj.FocusValue, out tmp))
                    {
                        System.Windows.Forms.MessageBox.Show("Input FocusValue was not in a correct format!");
                        return;
                    }
                    if (!double.TryParse(obj.DoseSensitivity, out tmp))
                    {
                        System.Windows.Forms.MessageBox.Show("Input DoseSensitivity was not in a correct format!");
                        return;
                    }
                }

                IsBtnOkClick = true;

                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Cancel Button Click Event Fun
        /// </summary>
        void OnBtnCancelClick()
        {
            IsBtnOkClick = false;
            this.CurrentWindow.Close();
        }

        List<CD_InitialSettingEntity> SettingListTmp = new List<CD_InitialSettingEntity>();
        /// <summary>
        /// SelectRow Event fun
        /// </summary>
        void OnSelectRowClick()
        {
            try
            {
                //currentTool = string.Empty;
                //currentReticle = string.Empty;
                //currentDoseValue = string.Empty;
                //currentFocusValue = string.Empty;
                if (IsDeleteRow)
                {
                    IsDeleteRow = false;
                    return;
                }
                if (SelectedSetting != null)
                {
                    
                }
                string strJson = string.Empty;
                strJson = JsonHelp.SerializeObject(SettingList);
                SettingListTmp = JsonHelp.DeserializeJsonToList<CD_InitialSettingEntity>(strJson);

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        bool IsAddEdit = false;
        string currentTool = string.Empty;
        string currentReticle = string.Empty;
        string currentDoseValue = string.Empty;
        string currentFocusValue = string.Empty;
        /// <summary>
        /// BeginningEdit Event fun
        /// </summary>
        void OnBeginningEdit()
        {
            try
            {
                if (SelectedSetting != null)
                {
                    if (SelectedSetting.Tool.Equals("") && SelectedSetting.Reticle.Equals(""))
                    {
                        IsAddEdit = true;
                    }
                    currentTool = SelectedSetting.Tool;
                    currentReticle = SelectedSetting.Reticle;

                    currentDoseValue = SelectedSetting.DoseValue;
                    currentFocusValue = SelectedSetting.FocusValue;
                }

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CellEditEnding Event fun
        /// </summary>
        void OnCellEditEnding()
        {
            try
            {
                if (SelectedSetting != null)
                {
                    if (IsAddEdit)
                    {
                        IsAddEdit = false;

                        return;
                    }

                    foreach (var obj in SettingListTmp)
                    {
                        if (obj.Tool.Equals(SelectedSetting.Tool) && obj.Reticle.Equals(SelectedSetting.Reticle))
                        {
                            if (SelectedSetting.Tool.Equals(currentTool) && SelectedSetting.Reticle.Equals(currentReticle))
                            {
                                break;
                            }
                            System.Windows.Forms.MessageBox.Show("TOOL and RETICLE already exist!");
                            SelectedSetting.Tool = currentTool;
                            SelectedSetting.Reticle = currentReticle;
                            return;
                        }
                    }
                    double tmp = double.NaN;
                    if (double.TryParse(SelectedSetting.DoseValue, out tmp))
                    {
                        if (tmp < double.Parse(DoseLSL) || tmp > double.Parse(DoseUSL))
                        {
                            System.Windows.Forms.MessageBox.Show(SelectedSetting.Tool + "/" + SelectedSetting.Reticle + " --- DoseValue out of range!");
                            SelectedSetting.DoseValue = currentDoseValue;
                            return;
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input DoseValue was not in a correct format!");
                        SelectedSetting.DoseValue = currentDoseValue;
                        return;
                    }
                    if (double.TryParse(SelectedSetting.FocusValue, out tmp))
                    {

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input FocusValue was not in a correct format!");
                        SelectedSetting.FocusValue = currentFocusValue;
                        return;
                    }
                    if (double.TryParse(SelectedSetting.DoseSensitivity, out tmp))
                    {

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Input DoseSensitivity was not in a correct format!");
                        SelectedSetting.DoseSensitivity = currentFocusValue;
                        return;
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// LostFocus Event Fun
        /// </summary>
        void OnLostFocus()
        {
            try
            {
                

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }

        }

        #endregion

    }
}
