﻿using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProductAndLayerSetting.ViewModels
{
    class CPE_StaticViewModel : ViewModelBase
    {
        public CPE_StaticViewModel()
        {

        }

        public ISettingMainService _SettingMainService { get; set; }
        public CPE_StaticViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "Single Lot";
        }

        IRegionNavigationJournal _journal;
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            try
            {
                _journal = navigationContext.NavigationService.Journal;

                var msg = navigationContext.Parameters["Message"] as SendWaferModeParam;
                if (msg != null)
                {
                    SendWaferParam = msg;

                    IsCPEFeedForewardYes = bool.Parse(SendWaferParam.OVLCPEFeedforeward);
                    IsCPEFeedForewardNo = !IsCPEFeedForewardYes;
                    IsFixedEdgeShotValuesYes = bool.Parse(SendWaferParam.OVLCPEFixEdge);
                    IsFixedEdgeShotValuesNo = !IsFixedEdgeShotValuesYes;
                    CPELumda = SendWaferParam.OVLCPELumda;
                    CPEUpdateTime = SendWaferParam.OVLCPEUpdateTime;
                    CPEUpdateLot = SendWaferParam.OVLCPEUpdateLot;
                    CPEExpireTime = SendWaferParam.OVLCPEExpireTime;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        SendWaferModeParam SendWaferParam = new SendWaferModeParam();

        public override bool IsNavigationTarget(NavigationContext navigationContext)
        {
            var msg = navigationContext.Parameters["Message"] as SendWaferModeParam;
            return true;
        }

        #region Filed
        private List<string> _ChangeList = new List<string>();
        public List<string> ChangeList
        {
            get { return this._ChangeList; }
            set { SetProperty(ref this._ChangeList, value); }
        }

        private bool _IsCPEFeedForewardYes=false;
        public bool IsCPEFeedForewardYes
        {
            get { return this._IsCPEFeedForewardYes; }
            set { SetProperty(ref this._IsCPEFeedForewardYes, value); }
        }

        private bool _IsCPEFeedForewardNo=true;
        public bool IsCPEFeedForewardNo
        {
            get { return this._IsCPEFeedForewardNo; }
            set { SetProperty(ref this._IsCPEFeedForewardNo, value); }
        }

        private bool _IsCPEFeedForewardEnable=true;
        public bool IsCPEFeedForewardEnable
        {
            get { return this._IsCPEFeedForewardEnable; }
            set { SetProperty(ref this._IsCPEFeedForewardEnable, value); }
        }

        private bool _IsFixedEdgeShotValuesYes;
        public bool IsFixedEdgeShotValuesYes
        {
            get { return this._IsFixedEdgeShotValuesYes; }
            set { SetProperty(ref this._IsFixedEdgeShotValuesYes, value); }
        }

        private bool __IsFixedEdgeShotValuesNo;
        public bool IsFixedEdgeShotValuesNo
        {
            get { return this.__IsFixedEdgeShotValuesNo; }
            set { SetProperty(ref this.__IsFixedEdgeShotValuesNo, value); }
        }

        private string _CPELumda;
        public string CPELumda
        {
            get { return this._CPELumda; }
            set { SetProperty(ref this._CPELumda, value); }
        }

        private string _CPEUpdateTime;
        public string CPEUpdateTime
        {
            get { return this._CPEUpdateTime; }
            set { SetProperty(ref this._CPEUpdateTime, value); }
        }

        private string _CPEUpdateLot;
        public string CPEUpdateLot
        {
            get { return this._CPEUpdateLot; }
            set { SetProperty(ref this._CPEUpdateLot, value); }
        }

        private string _CPEExpireTime;
        public string CPEExpireTime
        {
            get { return this._CPEExpireTime; }
            set { SetProperty(ref this._CPEExpireTime, value); }
        }

        private string _IsBtnEditEnable;
        public string IsBtnEditEnable
        {
            get { return this._IsBtnEditEnable; }
            set { SetProperty(ref this._IsBtnEditEnable, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _LayoutUpdatedCommand;
        public DelegateCommand LayoutUpdatedCommand =>
            _LayoutUpdatedCommand ?? (_LayoutUpdatedCommand = new DelegateCommand(LayoutUpdated));

        #endregion

        #region Event Fun
        /// <summary>
        /// TextChanged Event Fun
        /// </summary>
        void LayoutUpdated()
        {
            ChangeList = new List<string>();
            ChangeList.Add(IsCPEFeedForewardYes.ToString().ToLower());
            ChangeList.Add(IsFixedEdgeShotValuesYes.ToString().ToLower());
            double num1 = double.NaN;
            if (double.TryParse(CPELumda, out num1))
            {
                if (num1 < 0 || num1 > 1)
                {
                    CPELumda = "";
                }
            }
            else
            {
                CPELumda = "";
            }
            if (!double.TryParse(CPEUpdateTime, out num1))
            {
                CPEUpdateTime = "";
            }
            if (!double.TryParse(CPEUpdateLot, out num1))
            {
                CPEUpdateLot = "";
            }
            uint tmp = 0;
            if (!uint.TryParse(CPEExpireTime, out tmp))
            {
                CPEExpireTime = "";
            }

            ChangeList.Add(CPELumda);
            ChangeList.Add(CPEUpdateTime);
            ChangeList.Add(CPEUpdateLot);
            ChangeList.Add(CPEExpireTime);
            EventAggregator.GetEvent<CPEStaticChangedEvent>().Publish(ChangeList);
        }
        #endregion
    }
}
