﻿using Microsoft.Win32;
using Prism.Commands;
using Prism.Events;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProductAndLayerSetting.ViewModels
{
    class PC_InitialSettingViewModel : ViewModelBase
    {
        public PC_InitialSettingViewModel()
        {

        }

        public ISettingMainService _SettingMainService { get; set; }
        public PC_InitialSettingViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "PC Initial Setting";
        }
        /// <summary>
        /// Init Event Fun
        /// </summary>
        void OnInit()
        {
            try
            {
                if (IsPCInitialEnable)
                {
                    IsGrdReadOnly = false;
                    IsBtnEnable = true;
                }
                else
                {
                    IsGrdReadOnly = true;
                    IsBtnEnable = false;
                }

                string strSettingSource = JsonHelp.SerializeObject(SettingList);
                SettingListSource = JsonHelp.DeserializeJsonToList<PC_InitialSettingEntity>(strSettingSource);

                if (SettingList.Count > 0)
                {
                    string strChuck = SettingList[0].INIT_PARAMETER_VALUE;
                    if (strChuck.Contains(";"))
                    {
                        IsHaveChuck2 = true;
                    }
                    ChuckTextShow = IsHaveChuck2 ? "Chuck1" : "ChuckNA";
                    Chuck2VisibleStatus = IsHaveChuck2 ? "Visible" : "Hidden";

                    IsChuck2ReadOnly = !IsHaveChuck2;
                }

                SettingParamList = new ObservableCollection<PC_InitialParamSettingEntity>(GetPCInitialParameterSettingInfo());
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        #region Filed
        bool IsHaveChuck2 = false;

        private bool _IsPCInitialEnable = true;
        public bool IsPCInitialEnable
        {
            get { return this._IsPCInitialEnable; }
            set { SetProperty(ref this._IsPCInitialEnable, value); }
        }

        private bool _IsGrdReadOnly = false;
        public bool IsGrdReadOnly
        {
            get { return this._IsGrdReadOnly; }
            set { SetProperty(ref this._IsGrdReadOnly, value); }
        }

        private bool _IsBtnEnable = true;
        public bool IsBtnEnable
        {
            get { return this._IsBtnEnable; }
            set { SetProperty(ref this._IsBtnEnable, value); }
        }

        private int _SelectSettingRowIndex = 0;
        public int SelectSettingRowIndex
        {
            get { return this._SelectSettingRowIndex; }
            set { SetProperty(ref this._SelectSettingRowIndex, value); }
        }

        private int _ColumnIndex;
        public int ColumnIndex
        {
            get { return this._ColumnIndex; }
            set { SetProperty(ref this._ColumnIndex, value); }
        }

        private bool _IsPaste = false;
        public bool IsPaste
        {
            get { return this._IsPaste; }
            set { SetProperty(ref this._IsPaste, value); }
        }

        private bool _IsImport = false;
        public bool IsImport
        {
            get { return this._IsImport; }
            set { SetProperty(ref this._IsImport, value); }
        }

        private bool _IsDeleteRow = false;
        public bool IsDeleteRow
        {
            get { return this._IsDeleteRow; }
            set { SetProperty(ref this._IsDeleteRow, value); }
        }

        private bool _IsBtnOkClick = false;
        public bool IsBtnOkClick
        {
            get { return this._IsBtnOkClick; }
            set { SetProperty(ref this._IsBtnOkClick, value); }
        }
      
        private string _ChuckTextShow = "Chuck1";
        public string ChuckTextShow
        {
            get { return this._ChuckTextShow; }
            set { SetProperty(ref this._ChuckTextShow, value); }
        }

        private bool _IsChuck2ReadOnly = true;
        public bool IsChuck2ReadOnly
        {
            get { return this._IsChuck2ReadOnly; }
            set { SetProperty(ref this._IsChuck2ReadOnly, value); }
        }

        //private string _IsChuck2Visible = "Visible";
        //public string IsChuck2Visible
        //{
        //    get { return this._IsChuck2Visible; }
        //    set { SetProperty(ref this._IsChuck2Visible, value); }
        //}

        private string _Chuck2VisibleStatus = "Hidden";
        public string Chuck2VisibleStatus
        {
            get { return this._Chuck2VisibleStatus; }
            set { SetProperty(ref this._Chuck2VisibleStatus, value); }
        }

        private bool _IsToolFlag;
        public bool IsToolFlag
        {
            get { return this._IsToolFlag; }
            set { SetProperty(ref this._IsToolFlag, value); }
        }

        private bool _IsReticleFlag;
        public bool IsReticleFlag
        {
            get { return this._IsReticleFlag; }
            set { SetProperty(ref this._IsReticleFlag, value); }
        }

        private bool _IsPreToolFlag;
        public bool IsPreToolFlag
        {
            get { return this._IsPreToolFlag; }
            set { SetProperty(ref this._IsPreToolFlag, value); }
        }

        private bool _IsPreReticleFlag;
        public bool IsPreReticleFlag
        {
            get { return this._IsPreReticleFlag; }
            set { SetProperty(ref this._IsPreReticleFlag, value); }
        }

        private string _Product;
        public string Product
        {
            get { return this._Product; }
            set { SetProperty(ref this._Product, value); }
        }

        private string _Layer;
        public string Layer
        {
            get { return this._Layer; }
            set { SetProperty(ref this._Layer, value); }
        }

        private string _ToolGroup;
        public string ToolGroup
        {
            get { return this._ToolGroup; }
            set { SetProperty(ref this._ToolGroup, value); }
        }

        private List<ImportExcelCheckEntity> _ImportCheckList;
        public List<ImportExcelCheckEntity> ImportCheckList
        {
            get { return _ImportCheckList; }
            set { SetProperty(ref _ImportCheckList, value); }
        }

        private List<PCLimitChuckEntity> _PCLimitChuckList;
        public List<PCLimitChuckEntity> PCLimitChuckList
        {
            get { return _PCLimitChuckList; }
            set { SetProperty(ref _PCLimitChuckList, value); }
        }

        private PC_InitialSettingEntity _SelectedSettingCopy;
        public PC_InitialSettingEntity SelectedSettingCopy
        {
            get { return this._SelectedSettingCopy; }
            set { SetProperty(ref this._SelectedSettingCopy, value); }
        }

        private PC_InitialSettingEntity _SelectedSettingPaste;
        public PC_InitialSettingEntity SelectedSettingPaste
        {
            get { return this._SelectedSettingPaste; }
            set { SetProperty(ref this._SelectedSettingPaste, value); }
        }

        private PC_InitialSettingEntity _SelectedSetting;
        public PC_InitialSettingEntity SelectedSetting
        {
            get { return this._SelectedSetting; }
            set { SetProperty(ref this._SelectedSetting, value); }
        }

        private List<PC_InitialSettingEntity> _SettingListSource;
        public List<PC_InitialSettingEntity> SettingListSource
        {
            get { return _SettingListSource; }
            set { SetProperty(ref _SettingListSource, value); }
        }

        private ObservableCollection<PC_InitialSettingEntity> _ImportSettingList;
        public ObservableCollection<PC_InitialSettingEntity> ImportSettingList
        {
            get { return _ImportSettingList; }
            set { SetProperty(ref _ImportSettingList, value); }
        }

        private ObservableCollection<PC_InitialSettingEntity> _SettingList;
        public ObservableCollection<PC_InitialSettingEntity> SettingList
        {
            get { return _SettingList; }
            set { SetProperty(ref _SettingList, value); }
        }

        private PC_InitialParamSettingEntity _SelectedParamSetting;
        public PC_InitialParamSettingEntity SelectedParamSetting
        {
            get { return this._SelectedParamSetting; }
            set { SetProperty(ref this._SelectedParamSetting, value); }
        }

        private ObservableCollection<PC_InitialParamSettingEntity> _SettingParamList;
        public ObservableCollection<PC_InitialParamSettingEntity> SettingParamList
        {
            get { return _SettingParamList; }
            set { SetProperty(ref _SettingParamList, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnInit));

        private DelegateCommand _SelectRowClickCommand;
        public DelegateCommand SelectRowClickCommand =>
            _SelectRowClickCommand ?? (_SelectRowClickCommand = new DelegateCommand(OnSelectRowClick));

        private DelegateCommand _BeginningEditCommand;
        public DelegateCommand BeginningEditCommand =>
            _BeginningEditCommand ?? (_BeginningEditCommand = new DelegateCommand(OnBeginningEdit));

        private DelegateCommand _CellEditEndingCommand;
        public DelegateCommand CellEditEndingCommand =>
            _CellEditEndingCommand ?? (_CellEditEndingCommand = new DelegateCommand(OnCellEditEnding));

        private DelegateCommand _ParamSelectRowClickCommand;
        public DelegateCommand ParamSelectRowClickCommand =>
            _ParamSelectRowClickCommand ?? (_ParamSelectRowClickCommand = new DelegateCommand(OnParameterSelectRowClick));

        private DelegateCommand _ParamBeginningEditCommand;
        public DelegateCommand ParamBeginningEditCommand =>
            _ParamBeginningEditCommand ?? (_ParamBeginningEditCommand = new DelegateCommand(OnParameterBeginningEdit));

        private DelegateCommand _ParamCellEditEndingCommand;
        public DelegateCommand ParamCellEditEndingCommand =>
            _ParamCellEditEndingCommand ?? (_ParamCellEditEndingCommand = new DelegateCommand(OnParameterCellEditEnding));

        private DelegateCommand _ParamLostFocusCommand;
        public DelegateCommand ParamLostFocusCommand =>
            _ParamLostFocusCommand ?? (_ParamLostFocusCommand = new DelegateCommand(OnParameterLostFocus));

        private DelegateCommand _BtnImportCommand;
        public DelegateCommand BtnImportCommand =>
            _BtnImportCommand ?? (_BtnImportCommand = new DelegateCommand(OnImportClick));

        private DelegateCommand _BtnExportCommand;
        public DelegateCommand BtnExportCommand =>
            _BtnExportCommand ?? (_BtnExportCommand = new DelegateCommand(OnExportClick));

        private DelegateCommand _BtnCopyCommand;
        public DelegateCommand BtnCopyCommand =>
            _BtnCopyCommand ?? (_BtnCopyCommand = new DelegateCommand(OnCopyClick));

        private DelegateCommand _BtnPasteCommand;
        public DelegateCommand BtnPasteCommand =>
            _BtnPasteCommand ?? (_BtnPasteCommand = new DelegateCommand(OnPasteClick));

        private DelegateCommand _BtnAddCommand;
        public DelegateCommand BtnAddCommand =>
            _BtnAddCommand ?? (_BtnAddCommand = new DelegateCommand(OnAddClick));

        private DelegateCommand _BtnDeleteCommand;
        public DelegateCommand BtnDeleteCommand =>
            _BtnDeleteCommand ?? (_BtnDeleteCommand = new DelegateCommand(OnDeleteClick));

        private DelegateCommand _BtnConfirmCommand;
        public DelegateCommand BtnConfirmCommand =>
            _BtnConfirmCommand ?? (_BtnConfirmCommand = new DelegateCommand(OnConfirmClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));
        #endregion

        #region Event Fun
        /// <summary>
        /// SelectionRow Event Fun
        /// </summary>
        void OnSelectRowClick()
        {
            try
            {
                //currentTool = string.Empty;
                //currentReticle = string.Empty;
                if (IsDeleteRow)
                {
                    IsDeleteRow = false;
                    return;
                }
                if (IsPaste)
                {
                    IsPaste = false;
                    return;
                }
                if (SelectedSetting == null)
                {
                    string strMsg = "Please select a row!";
                    MyLogger.Trace("Message :: " + strMsg);

                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                SettingParamList = new ObservableCollection<PC_InitialParamSettingEntity>(GetPCInitialParameterSettingInfo());

                string strJson = JsonHelp.SerializeObject(SelectedSetting);
                MyLogger.Trace("EventFun:: " +
                                string.Format("SelecteRow<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(SettingParamList);
                MyLogger.Trace("EventFun:: " +
                                string.Format("SelectParameterInfo<{0}>", strJson));
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        bool IsAddEdit = false;
        string currentTool = string.Empty;
        string currentReticle = string.Empty;
        /// <summary>
        /// BeginningEdit Event Fun
        /// </summary>
        void OnBeginningEdit()
        {
            try
            {
                if (SelectedSetting != null)
                {
                    if (SelectedSetting.TOOL.Equals("") && SelectedSetting.RETICLE.Equals(""))
                    {
                        IsAddEdit = true;
                    }
                    currentTool = SelectedSetting.TOOL;
                    currentReticle = SelectedSetting.RETICLE;
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CellEditEnding Event Fun
        /// </summary>
        void OnCellEditEnding()
        {
            try
            {
                if (SelectedSetting != null)
                {
                    //if (IsAddEdit)
                    //{
                    //    IsAddEdit = false;
                        
                    //    return;
                    //}
                    //foreach (var obj in SettingListSource)
                    //{
                    //    if (obj.TOOL.Equals(SelectedSetting.TOOL) && obj.RETICLE.Equals(SelectedSetting.RETICLE))
                    //    {
                    //        if (SelectedSetting.TOOL.Equals(currentTool) && SelectedSetting.RETICLE.Equals(currentReticle))
                    //        {
                    //            return;
                    //        }
                    //        string strMsg = "TOOL and RETICLE already exist!";
                    //        MyLogger.Trace("Message :: " + strMsg);

                    //        System.Windows.Forms.MessageBox.Show(strMsg);
                    //        SelectedSetting.TOOL = currentTool;
                    //        SelectedSetting.RETICLE = currentReticle;
                    //        return;
                    //    }
                    //    else
                    //    {

                    //    }
                    //}                 
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// SelectionRow Event Fun
        /// </summary>
        void OnParameterSelectRowClick()
        {
            try
            {
               //IsParamAddEdit = false;
               //currentChuck1 = string.Empty;
               //currentChuck2 = string.Empty;
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        bool IsParamAddEdit = false;
        string currentChuck1 = string.Empty;
        string currentChuck2 = string.Empty;
        /// <summary>
        /// BeginningEdit Event Fun
        /// </summary>
        void OnParameterBeginningEdit()
        {
            try
            {
                if (SelectedParamSetting != null)
                {
                    if (IsHaveChuck2)
                    {
                        if (SelectedParamSetting.Chuck1.Equals("") && SelectedParamSetting.Chuck2.Equals(""))
                        {
                            IsParamAddEdit = true;
                        }
                        currentChuck2 = SelectedParamSetting.Chuck2;
                    }
                    else
                    {
                        if (SelectedParamSetting.Chuck1.Equals(""))
                        {
                            IsParamAddEdit = true;
                        }
                    }
                    currentChuck1 = SelectedParamSetting.Chuck1;
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CellEditEnding Event Fun
        /// </summary>
        void OnParameterCellEditEnding()
        {
            try
            {
                if (SelectedParamSetting != null)
                {
                    if (IsParamAddEdit)
                    {
                        IsParamAddEdit = false;

                        //return;
                    }
                    foreach (var obj in PCLimitChuckList)
                    {
                        if (obj.Parameter.Equals(SelectedParamSetting.Parameter))
                        {
                            if (!SelectedParamSetting.Chuck1.Equals("") && !SelectedParamSetting.Chuck1.Equals(currentChuck1))
                            {
                                double chuck1 = double.NaN;
                                if (double.TryParse(SelectedParamSetting.Chuck1, out chuck1))
                                {
                                    if (chuck1 <= obj.Max && chuck1 >= obj.Min)
                                    {

                                    }
                                    else
                                    {
                                        string strMsg = "Chuck1 exceeded the limit!";
                                        MyLogger.Trace("Message :: " + strMsg);

                                        System.Windows.Forms.MessageBox.Show(strMsg);
                                        SelectedParamSetting.Chuck1 = currentChuck1;
                                        return;
                                    }
                                }
                                else
                                {
                                    string strMsg = "Input Chuck1 was not in a correct format!";
                                    MyLogger.Trace("Message :: " + strMsg);

                                    System.Windows.Forms.MessageBox.Show(strMsg);
                                    SelectedParamSetting.Chuck1 = currentChuck1;
                                    return;
                                }
                            }
                            else
                            {
                            }
                            if (Chuck2VisibleStatus.Equals("Visible"))
                            {
                                if (!SelectedParamSetting.Chuck2.Equals("") && !SelectedParamSetting.Chuck2.Equals(currentChuck2))
                                {
                                    double chuck2 = double.NaN;
                                    if (double.TryParse(SelectedParamSetting.Chuck2, out chuck2))
                                    {
                                        if (chuck2 <= obj.Max && chuck2 >= obj.Min)
                                        {

                                        }
                                        else
                                        {
                                            string strMsg = "Chuck2 exceeded the limit!";
                                            MyLogger.Trace("Message :: " + strMsg);

                                            System.Windows.Forms.MessageBox.Show(strMsg);
                                            SelectedParamSetting.Chuck2 = currentChuck2;
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        string strMsg = "Input Chuck2 was not in a correct format!";
                                        MyLogger.Trace("Message :: " + strMsg);

                                        System.Windows.Forms.MessageBox.Show(strMsg);
                                        SelectedParamSetting.Chuck2 = currentChuck2;
                                        return;
                                    }
                                }
                            }
                            return;
                        }
                        else
                        {

                        }
                    }

                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// LostFocus Event Fun
        /// </summary>
        void OnParameterLostFocus()
        {
            try
            {
                if (SelectedSetting != null)
                {
                    if (IsParamAddEdit)
                    {
                        return;
                    }

                    string strChuck1 = string.Empty;
                    string strChuck2 = string.Empty;
                    string strChuck = string.Empty;
                    foreach (PC_InitialParamSettingEntity obj in SettingParamList)
                    {
                        strChuck1 += obj.Chuck1 + ",";
                        if (Chuck2VisibleStatus.Equals("Visible"))
                        {
                            strChuck2 += obj.Chuck2 + ",";
                        }
                    }

                    if (IsChuck2ReadOnly)
                    {
                        strChuck = CfgSingleTableInfoHelp.RemoveLastChar(strChuck1, ",");
                    }
                    else
                    {
                        strChuck1 = CfgSingleTableInfoHelp.RemoveLastChar(strChuck1, ",");
                        strChuck1+= ";"; 
                        strChuck2 = CfgSingleTableInfoHelp.RemoveLastChar(strChuck2, ",");
                        strChuck += strChuck1;
                        strChuck += strChuck2;
                    }
                    SelectedSetting.INIT_PARAMETER_VALUE = strChuck;
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Import Button Click Event Fun
        /// </summary>
        void OnImportClick()
        {
            try
            {
                //string strExcelFile = @"C:\zqk\PCInitialImport.xlsx";
                string strExcelFile = string.Empty;
                OpenFileDialog open = new OpenFileDialog();//定义打开文本框实体
                open.Title = "打开文件";//对话框标题
                open.Filter = "文件（.xlsx）|*.xlsx|所有文件|*.*";//文件扩展名
                if ((bool)open.ShowDialog().GetValueOrDefault())
                {
                    strExcelFile = System.IO.Path.GetFullPath(open.FileName);
                    DataTable dbImport = ExcelHelp.Import(strExcelFile);

                    if (dbImport.Rows.Count > 0)
                    {
                        bool flag = false;
                        flag = CheckColumnName(dbImport,IsHaveChuck2);

                        if (flag)
                        {
                            SetSettingListByImport(dbImport);
                        }
                        else
                        {
                            string strMsg = "Please check the number of columns!";
                            MyLogger.Trace("Message :: " + strMsg);

                            System.Windows.Forms.MessageBox.Show(strMsg);
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Export Button Click Event Fun
        /// </summary>
        void OnExportClick()
        {
            try
            {
                DataTable dbExport = new DataTable("dbExport");
                dbExport = GetExportDataTable();
                //string strExcelFile = @"C:\zqk\PCInitialExport.xlsx";
                string strExcelFile = string.Empty;
                SaveFileDialog save = new SaveFileDialog();//定义打开文本框实体
                save.Title = "打开文件";//对话框标题
                save.Filter = "文件（.xlsx）|*.xlsx|所有文件|*.*";//文件扩展名
                if ((bool)save.ShowDialog().GetValueOrDefault())
                {
                    strExcelFile = System.IO.Path.GetFullPath(save.FileName);
                    ExcelHelp.Export(dbExport, strExcelFile);
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Copy Button Click Event Fun
        /// </summary>
        void OnCopyClick()
        {
            try
            {
                if (SelectedSetting != null)
                {
                    string strJson = JsonHelp.SerializeObject(SelectedSetting);
                    SelectedSettingCopy = JsonHelp.DeserializeJsonToObject<PC_InitialSettingEntity>(strJson);

                    MyLogger.Trace("EventFun:: " +
                                    string.Format("CopyData<{0}>", strJson));
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Copy Button Click Event Fun
        /// </summary>
        void OnPasteClick()
        {
            try
            {
                if (SelectedSetting != null)
                {
                    if (SelectedSettingCopy != null)
                    {
                        string strJson = JsonHelp.SerializeObject(SelectedSettingCopy);
                        SelectedSettingPaste = JsonHelp.DeserializeJsonToObject<PC_InitialSettingEntity>(strJson);

                        IsPaste = true;
                        int index = SettingList.IndexOf(SelectedSetting);
                        SettingList.Insert(index, SelectedSettingPaste);
                        SettingList.Remove(SelectedSetting);
                        SelectedSetting = SelectedSettingPaste;

                        MyLogger.Trace("EventFun:: " +
                                        string.Format("CopyData<{0}>", strJson));
                    }
                    else
                    {
                        string strMsg = "Please Please copy a record first!";
                        MyLogger.Trace("Message :: " + strMsg);

                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }
                    
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Add Button Click Event Fun
        /// </summary>
        void OnAddClick()
        {
            try
            {
                IsDeleteRow = false;

                SelectedSetting = new PC_InitialSettingEntity();
                SelectedSetting.PRODUCT = Product;
                SelectedSetting.LAYER = Layer;
                SelectedSetting.TOOL_GROUP = ToolGroup;
                SelectedSetting.TOOL = "";  // SettingToolList[0].TOOL;
                SelectedSetting.RETICLE = "";   // SettingToolList[0].RETICLE;
                if (SettingList.Count > 0)
                {
                    SelectedSetting.PRE_TOOL = SettingList[0].PRE_TOOL;
                    SelectedSetting.PRE_RETICLE = SettingList[0].PRE_RETICLE;
                    SelectedSetting.OVL_PC_MODE = SettingList[0].OVL_PC_MODE;
                }

                List<string> ListTool = new List<string>();
                List<string> ListReticle = new List<string>();
                foreach (var obj in SettingList)
                {
                    foreach (var str in obj.ToolList)
                    {
                        if (!ListTool.Contains(str))
                        {
                            ListTool.Add(str);
                        }
                    }
                    foreach (var str in obj.ReticleList)
                    {
                        if (!ListReticle.Contains(str))
                        {
                            ListReticle.Add(str);
                        }
                    }
                }

                SelectedSetting.ToolList = new List<string>(ListTool);
                SelectedSetting.ReticleList = new List<string>(ListReticle);

                SelectedSetting.INIT_PARAMETER_NAME = SettingList[0].INIT_PARAMETER_NAME;
                string strParameName = SelectedSetting.INIT_PARAMETER_NAME;
                string strParameValueTmp = SettingList[0].INIT_PARAMETER_VALUE;
                string[] strArray = strParameValueTmp.Split(';');
                string strParameValue = string.Empty;
                for (int n = 0; n < strArray.Count(); n++)
                {
                    string[] strArrayChuck = strArray[n].Split(',');
                    for (int i = 0; i < strArrayChuck.Count(); i++)
                    {
                        strParameValue += "" + ",";
                    }
                    strParameValue = CfgSingleTableInfoHelp.RemoveLastChar(strParameValue, ","); //移除掉","
                    strParameValue += ";";
                }
                strParameValue = CfgSingleTableInfoHelp.RemoveLastChar(strParameValue, ",");  //移除掉","
                SelectedSetting.INIT_PARAMETER_VALUE = strParameValue;

                SettingList.Add(SelectedSetting);

                string strJson = JsonHelp.SerializeObject(SelectedSetting);
                MyLogger.Trace("EventFun:: " +
                                    string.Format("AddRow<{0}>", strJson));

                string strSettingSource = JsonHelp.SerializeObject(SettingList);
                SettingListSource = JsonHelp.DeserializeJsonToList<PC_InitialSettingEntity>(strSettingSource);
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Delete Button Click Event Fun
        /// </summary>
        void OnDeleteClick()
        {
            try
            {
                if (SelectedSetting == null)
                {
                    string strMsg = "Please select a row!";
                    MyLogger.Trace("Message :: " + strMsg);

                    System.Windows.Forms.MessageBox.Show(strMsg);
                }
                if (SettingList.Count == 1)
                {
                    string strMsg = "Only one record!";
                    MyLogger.Trace("Message :: " + strMsg);

                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                IsDeleteRow = true;

                string strJson = JsonHelp.SerializeObject(SelectedSetting);
                MyLogger.Trace("EventFun:: " +
                                    string.Format("DeleteRow<{0}>", strJson));

                SettingList.Remove(SelectedSetting);
                SettingParamList = new ObservableCollection<PC_InitialParamSettingEntity>();

                string strSettingSource = JsonHelp.SerializeObject(SettingList);
                SettingListSource = JsonHelp.DeserializeJsonToList<PC_InitialSettingEntity>(strSettingSource);

                if (SettingList.Count > 0)
                {
                    SelectedSetting = SettingList[SettingList.Count - 1];
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Confirm Button Click Event Fun
        /// </summary>
        void OnConfirmClick()
        {
            try
            {
                string strChuck1 = string.Empty;
                string strChuck2 = string.Empty;
                string strChuck = string.Empty;
                foreach (PC_InitialParamSettingEntity obj in SettingParamList)
                {
                    if (obj.Chuck1.Equals(""))
                    {
                        string strMsg = "Chuck cannot be empty!";
                        MyLogger.Trace("Message :: " + strMsg);

                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }

                    strChuck1 += obj.Chuck1 + ",";
                    if (Chuck2VisibleStatus.Equals("Visible"))
                    {
                        if (obj.Chuck2.Equals(""))
                        {
                            string strMsg = "Chuck cannot be empty!";
                            MyLogger.Trace("Message :: " + strMsg);

                            System.Windows.Forms.MessageBox.Show(strMsg);
                            return;
                        }
                        strChuck2 += obj.Chuck2 + ",";
                    }
                }

                if (IsChuck2ReadOnly)
                {
                    strChuck = CfgSingleTableInfoHelp.RemoveLastChar(strChuck1, ",");
                }
                else
                {
                    strChuck1 = CfgSingleTableInfoHelp.RemoveLastChar(strChuck1, ",");
                    strChuck1 += ";";
                    strChuck2 = CfgSingleTableInfoHelp.RemoveLastChar(strChuck2, ",");
                    strChuck += strChuck1;
                    strChuck += strChuck2;
                }

                if (SelectedSetting != null)
                {
                    SelectedSetting.INIT_PARAMETER_VALUE = strChuck;
                }

                List<string> ToolAndReticleList = new List<string>();
                foreach (var obj in SettingList)
                {
                    if (obj.TOOL.Equals("") || obj.RETICLE.Equals(""))
                    {
                        string strMsg = "Tool and Reticle cannot be empty!";
                        MyLogger.Trace("Message :: " + strMsg);

                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }
                    else
                    {
                        string str = obj.TOOL + "_" + obj.RETICLE;
                        if (ToolAndReticleList.Contains(str))
                        {
                            string strMsg = "Tool and Reticle are not unique!";
                            MyLogger.Trace("Message :: " + strMsg);

                            System.Windows.Forms.MessageBox.Show(strMsg);
                            return;
                        }
                        else
                        {
                            ToolAndReticleList.Add(str);
                        }
                    }

                    List<string> strChuckList1 = new List<string>();
                    List<string> strChuckList2 = new List<string>();
                    if (IsHaveChuck2)
                    {
                        string[] strArrayChuck = obj.INIT_PARAMETER_VALUE.Split(';');
                        strChuckList1 = new List<string>(strArrayChuck[0].Split(','));
                        strChuckList2 = new List<string>(strArrayChuck[1].Split(',')); 
                    }
                    else
                    {
                        strChuckList1= new List<string>(obj.INIT_PARAMETER_VALUE.Split(','));
                    }
                    for (int i = 0; i < ImportCheckList.Count; i++)
                    {
                        string strMsg = obj.TOOL + "/" + obj.RETICLE + "/" + ImportCheckList[i].Parameter + " value  has to be between " + ImportCheckList[i].Min + " and " + ImportCheckList[i].Max;

                        bool ChuckValueFlag = CheckChuckValue(ImportCheckList[i].Max, ImportCheckList[i].Min, strChuckList1[i], strMsg);
                        if (!ChuckValueFlag)
                        {
                            return;
                        }
                        if (IsHaveChuck2)
                        {
                            ChuckValueFlag = CheckChuckValue(ImportCheckList[i].Max, ImportCheckList[i].Min, strChuckList2[i], strMsg);
                            if (!ChuckValueFlag)
                            {
                                return;
                            }
                        }                 
                    }
                }              

                if (SettingList.Count < 1)
                {
                    IsBtnOkClick = false;
                }
                else
                {
                    IsBtnOkClick = true;
                }

                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Cancel Button Click Event Fun
        /// </summary>
        void OnBtnCancelClick()
        {
            IsBtnOkClick = false;
            this.CurrentWindow.Close();
        }
        #endregion

        #region Fun
        bool CheckColumnName(DataTable dbImport, bool IsHaveChuck2)
        {
            bool flag = false;
            try
            {
                List<string> dbColumnList = DataTableHelp.GetColumnName(dbImport);
                List<string> ColumnList = new List<string>();

                string strJson = JsonHelp.SerializeObject(dbColumnList);
                MyLogger.Trace("Input:: " +
                                string.Format("ColumnList<{0}>", strJson) +
                                string.Format("IsHaveChuck2<{0}>", IsHaveChuck2));

                if (IsHaveChuck2)
                {
                    ColumnList = new List<string>() { "TOOL", "RETICLE", "PRE_TOOL", "PRE_RETICLE", "TOOL_LIST", "RETICLE_LIST", "PARAMETER", "MODE", "CHUCK1", "CHUCK2" };
                }
                else
                {
                    ColumnList = new List<string>() { "TOOL", "RETICLE", "PRE_TOOL", "PRE_RETICLE", "TOOL_LIST", "RETICLE_LIST", "PARAMETER", "MODE", "CHUCKNA" };
                }
                if (ColumnList.Count == dbColumnList.Count && ColumnList.Count(t => !dbColumnList.Contains(t)) == 0)
                {
                    flag = true;
                }

                MyLogger.Trace("Return:: " + string.Format("Flag<{0}>", flag));
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }

            return flag;
        }

        #region old
        //bool CheckParameter(string strParameter,string strChuckValue, string strMsg)
        //{
        //    bool flag = false;
        //    try
        //    {
        //        List<string> ParameterList = new List<string>();
        //        ParameterList = new List<string>(strParameter.Split(','));
        //        if (ImportCheckList.Count == ParameterList.Count)
        //        {
        //            for (int i = 0; i < ParameterList.Count; i++)
        //            {
        //                if (ImportCheckList[i].Parameter.Equals(ParameterList[i]))
        //                {
        //                }
        //                else
        //                {
        //                    System.Windows.Forms.MessageBox.Show(strMsg);
        //                    return false;
        //                }
        //            }
        //            flag = true;
        //        }
        //    }
        //    catch (Exception ee)
        //    {
        //        System.Windows.Forms.MessageBox.Show(ee.Message);
        //    }
        //    return flag;
        //}

        //bool CheckParameter(string strSource, string strNew, string strMsg)
        //{
        //    bool flag = false;
        //    try
        //    {
        //        List<string> ListSource = new List<string>();
        //        List<string> ListNew = new List<string>();
        //        ListSource = new List<string>(strSource.Split(','));
        //        ListNew = new List<string>(strNew.Split(','));
        //        if (ListSource.Count == ListNew.Count)
        //        {
        //            foreach (var str in ListNew)
        //            {
        //                if (!ListSource.Contains(str))
        //                {
        //                    System.Windows.Forms.MessageBox.Show(strMsg);
        //                    return false;
        //                }
        //            }
        //            flag = true;
        //        }
        //    }
        //    catch (Exception ee)
        //    {
        //        System.Windows.Forms.MessageBox.Show(ee.Message);
        //    }
        //    return flag;
        //}
        //bool CheckImportData(string strTool, string strReticle, string strParameterName, string strMode)
        //{
        //    bool flag = false;
        //    try
        //    {
        //        foreach (var obj in SettingListSource)
        //        {
        //            if (obj.TOOL.Equals(strTool) && obj.RETICLE.Equals(strReticle))
        //            {
        //                string strMsg = "Please check the ParameterName!";
        //                flag = CheckParameter(obj.INIT_PARAMETER_NAME, strParameterName, strMsg);
        //                if (flag)
        //                {
        //                    strMsg = "Please check the Mode!";
        //                    flag = CheckParameter(obj.OVL_PC_MODE, strMode, strMsg);
        //                    return flag;
        //                }
        //                else
        //                {
        //                    return flag;
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ee)
        //    {
        //        System.Windows.Forms.MessageBox.Show(ee.Message);
        //    }
        //    return flag;
        //}

        //bool CheckChuckValue(string strParameterName, ref string strChuck)
        //{
        //    bool IsChuckOutOfRange = false;
        //    try
        //    {
        //        foreach (var obj in PCLimitChuckList)
        //        {
        //            if (obj.Parameter.Equals(strParameterName))
        //            {
        //                double chuck = double.NaN;
        //                if (double.TryParse(strChuck, out chuck))
        //                {
        //                    if (chuck <= obj.Max && chuck >= obj.Min)
        //                    {

        //                    }
        //                    else
        //                    {
        //                        strChuck = "";
        //                        IsChuckOutOfRange = true;
        //                    }
        //                }
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ee)
        //    {
        //        System.Windows.Forms.MessageBox.Show(ee.Message);
        //    }
        //    return IsChuckOutOfRange;
        //}
        #endregion

        bool CheckChuckValue(double dChuckMax, double dChuckMin, string strChuck,string strMsg)
        {

            bool flag = false;
            try
            {
                MyLogger.Trace("Input:: " +
                            string.Format("ChuckMax<{0}>", dChuckMax) +
                            string.Format("ChuckMin<{0}>", dChuckMin) +
                            string.Format("Chuck<{0}>", strChuck));

                if (string.IsNullOrEmpty(strChuck))
                {
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return false;
                }

                double chuck = double.NaN;
                if ( double.TryParse(strChuck, out chuck))
                {
                    if (chuck > dChuckMax || chuck < dChuckMin)
                    {
                        flag = false;

                        MyLogger.Trace("Message :: " + strMsg);

                        System.Windows.Forms.MessageBox.Show(strMsg );
                    }
                    else
                    {
                        flag = true;
                    }
                }

                MyLogger.Trace("Return:: " +
                    string.Format("Flag<{0}>", flag));
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            
            return flag;
        }


        /// <summary>
        /// Set SettingList By Import
        /// </summary>
        /// <param name="dbImport"></param>
        void SetSettingListByImport(DataTable dbImport)
        {
            try
            {
                string strJson = JsonHelp.SerializeObject(dbImport);
                MyLogger.Trace("Input:: " +
                                string.Format("ImportDataTable<{0}>", strJson));

                if (ImportCheckList.Count < 1)
                {
                    System.Windows.Forms.MessageBox.Show("Please checck PC Spec Setting!");
                    return;
                }

                bool ChuckValueFlag = false;
                ImportSettingList = new ObservableCollection<PC_InitialSettingEntity>();
                var query = from p in dbImport.AsEnumerable()
                             group p by new { t1 = p.Field<string>("TOOL"), t2 = p.Field<string>("RETICLE") } into g
                             select new
                             {
                                 tool = g.Key.t1,
                                 reticle = g.Key.t2,
                                 preTool = g.First().Field<string>("PRE_TOOL"),
                                 preReticle = g.First().Field<string>("PRE_Reticle"),
                                 toolList = g.First().Field<string>("TOOL_LIST"),
                                 reticleList = g.First().Field<string>("RETICLE_LIST"),
                                 parameterCount = g.Count(),
                                 g
                             };

                foreach (var item in query)
                {
                    int i = 0;
                    string strParameterName = string.Empty;
                    string strParameterValue = string.Empty;
                    string strParameterMode = string.Empty;
                    string strParameterChuck1 = string.Empty;
                    string strParameterChuck2 = string.Empty;
                    if (item.parameterCount != ImportCheckList.Count)
                    {
                        System.Windows.Forms.MessageBox.Show("Please check the number of parameters!");
                        return;
                    }
                    if (!ImportCheckList[0].ToolList.Contains(item.tool))
                    {
                        System.Windows.Forms.MessageBox.Show("TOOL is not in ToolList!");
                        return;
                    }
                    foreach (var p in item.g)
                    {
                        if (i < ImportCheckList.Count)
                        {
                            string strParameterChuck1Temp = string.Empty;

                            string strParameterNameTemp = p.Field<string>("PARAMETER");
                            if (!strParameterNameTemp.Equals(ImportCheckList[i].Parameter))
                            {
                                System.Windows.Forms.MessageBox.Show("Please check the " + ImportCheckList[i].Parameter + " name!");
                                return;
                            }
                            if (IsHaveChuck2)
                            {
                                strParameterChuck1Temp = p.Field<string>("CHUCK1");
                            }
                            else
                            {
                                strParameterChuck1Temp = p.Field<string>("CHUCKNA");
                            }
                            string strMsg = item.tool + "/" + item.reticle + "/" + ImportCheckList[i].Parameter + " value  has to be between " + ImportCheckList[i].Min + " and " + ImportCheckList[i].Max;
                 
                            ChuckValueFlag = CheckChuckValue(ImportCheckList[i].Max, ImportCheckList[i].Min, strParameterChuck1Temp, strMsg);
                            if (!ChuckValueFlag)
                            {
                                return;
                            }

                            strParameterName += strParameterNameTemp + ",";
                            strParameterMode += p.Field<string>("MODE") + ",";
                            strParameterChuck1 += strParameterChuck1Temp + ",";
                            if (IsHaveChuck2)
                            {
                                string strParameterChuck2Temp = p.Field<string>("CHUCK2");
                                ChuckValueFlag = CheckChuckValue(ImportCheckList[i].Max, ImportCheckList[i].Min, strParameterChuck2Temp, strMsg);
                                if (!ChuckValueFlag)
                                {
                                    return;
                                }
                                strParameterChuck2 += strParameterChuck2Temp + ",";
                            }
                            i++;
                        }
                        else
                        {
                            ImportSettingList = new ObservableCollection<PC_InitialSettingEntity>();
                            System.Windows.Forms.MessageBox.Show("Please check the number of parameters!");
                            return;
                        }
                    }
                    if (i != ImportCheckList.Count)
                    {
                        ImportSettingList = new ObservableCollection<PC_InitialSettingEntity>();
                        System.Windows.Forms.MessageBox.Show("Please check the number of parameters!");
                        return;
                    }

                    PC_InitialSettingEntity importEntity = new PC_InitialSettingEntity();
                    importEntity.PRODUCT = Product;
                    importEntity.LAYER = Layer;
                    importEntity.TOOL_GROUP = ToolGroup;
                    importEntity.TOOL = item.tool;
                    importEntity.RETICLE = item.reticle;
                    importEntity.PRE_TOOL = item.preTool;
                    importEntity.PRE_RETICLE = item.preReticle;
                    importEntity.ToolList = item.toolList.Split(',').ToList();
                    importEntity.ReticleList = item.reticleList.Split(',').ToList();

                    strParameterValue = CfgSingleTableInfoHelp.RemoveLastChar(strParameterChuck1, ",");
                    if (IsHaveChuck2)
                    {
                        strParameterValue += ";" + CfgSingleTableInfoHelp.RemoveLastChar(strParameterChuck2, ",");
                    }
                    importEntity.OVL_PC_MODE = CfgSingleTableInfoHelp.RemoveLastChar(strParameterMode, ",");
                    importEntity.INIT_PARAMETER_NAME = CfgSingleTableInfoHelp.RemoveLastChar(strParameterName, ",");
                    importEntity.INIT_PARAMETER_VALUE = strParameterValue; // CfgSingleTableInfoHelp.RemoveLastChar(strParameterValue, ",");
                    
                    ImportSettingList.Add(importEntity);                   
                }
                if (ImportSettingList.Count > 0)
                {
                    SelectedSetting = ImportSettingList[0];
                    SettingList = new ObservableCollection<PC_InitialSettingEntity>(ImportSettingList);

                    strJson = JsonHelp.SerializeObject(dbImport);
                    MyLogger.Trace("Input:: " +
                                    string.Format("ImportDataTable<{0}>", strJson));

                    strJson = JsonHelp.SerializeObject(SettingList);
                    MyLogger.Trace("Fun:: " +
                                    string.Format("SettingList<{0}>", strJson));
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Get Export DataTable
        /// </summary>
        /// <returns></returns>
        DataTable GetExportDataTable()
        {
            DataTable dbExport = DataTableHelp.CreatePCInitDataTable(IsHaveChuck2);
            try
            {
                int n = 0;
                foreach (var obj in SettingList)
                {
                    string strToolList = string.Empty;
                    string strReticleList = string.Empty;
                    foreach (var str in obj.ToolList)
                    {
                        strToolList += str + ",";
                    }
                    foreach (var str in obj.ReticleList)
                    {
                        strReticleList += str + ",";
                    }
                    strToolList = CfgSingleTableInfoHelp.RemoveLastChar(strToolList, ",");
                    strReticleList = CfgSingleTableInfoHelp.RemoveLastChar(strReticleList, ",");

                    string strParameName = obj.INIT_PARAMETER_NAME;
                    string strParameMode = obj.OVL_PC_MODE;
                    string strParameValue = obj.INIT_PARAMETER_VALUE;

                    string strParameChuck1 = string.Empty;
                    string strParameChuck2 = string.Empty;
                    if (IsHaveChuck2)
                    {
                        string[] strArray = strParameValue.Split(';');
                        strParameChuck1 = strArray[0];
                        strParameChuck2 = strArray[1];
                    }
                    else
                    {
                        strParameChuck1 = obj.INIT_PARAMETER_VALUE;
                    }

                    string[] arrParameterName = strParameName.Split(',');
                    string[] arrParameterMode = strParameMode.Split(',');
                    string[] arrParameterChuck1 = strParameChuck1.Split(',');
                    string[] arrParameterChuck2 = new string[arrParameterChuck1.Length];
                    if (IsHaveChuck2)
                    {
                        arrParameterChuck2 = strParameChuck2.Split(',');
                    }
                    for (int i = 0; i < arrParameterName.Length; i++)
                    {
                        int row = i + n * arrParameterName.Length;
                        dbExport.Rows.Add();
                        dbExport.Rows[row]["TOOL"] = obj.TOOL;
                        dbExport.Rows[row]["RETICLE"] = obj.RETICLE;
                        dbExport.Rows[row]["PRE_TOOL"] = obj.PRE_TOOL;
                        dbExport.Rows[row]["PRE_RETICLE"] = obj.PRE_RETICLE;
                        dbExport.Rows[row]["TOOL_LIST"] = strToolList;
                        dbExport.Rows[row]["RETICLE_LIST"] = strReticleList;
                        dbExport.Rows[row]["PARAMETER"] = arrParameterName[i];
                        dbExport.Rows[row]["MODE"] = arrParameterMode[i];
                        if (IsHaveChuck2)
                        {
                            dbExport.Rows[row]["CHUCK1"] = arrParameterChuck1[i];
                            dbExport.Rows[row]["CHUCK2"] = arrParameterChuck2[i];
                        }
                        else
                        {
                            dbExport.Rows[row]["CHUCKNA"] = arrParameterChuck1[i];
                        }
                    }
                    n++;
                }

                string strJson = JsonHelp.SerializeObject(dbExport);
                MyLogger.Trace("Return:: " +
                                string.Format("ExportDataTable<{0}>", strJson));
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return dbExport;
        }

        /// <summary>
        /// Get PCinitialParamSettingInfo
        /// </summary>
        /// <returns></returns>
        List<PC_InitialParamSettingEntity> GetPCInitialParameterSettingInfo()
        {
            List<PC_InitialParamSettingEntity> paramList = new List<PC_InitialParamSettingEntity>();
            try
            {
                if (SelectedSetting != null)
                {

                    string strMode = SelectedSetting.OVL_PC_MODE;
                    string[] ModeList = strMode.Split(',');

                    string strParameter = SelectedSetting.INIT_PARAMETER_NAME;
                    string[] ParameterList = strParameter.Split(',');

                    string strChuck = SelectedSetting.INIT_PARAMETER_VALUE;
                    string[] strArrayList = strChuck.Split(';');

                    List<string> chuck1List = new List<string>();
                    List<string> chuck2List = new List<string>();
                    for (int n = 0; n < strArrayList.Length; n++)
                    {
                        string[] strArray = strArrayList[n].Split(',');
                        if (n == 0)
                        {
                            chuck1List = new List<string>(strArray);
                            if (ParameterList.Count() != chuck1List.Count)
                            {
                                if (chuck1List.Count == 0)
                                {
                                    for (int i = 0; i < ParameterList.Length; i++)
                                    {
                                        chuck1List.Add("");
                                    }
                                }
                                else
                                {
                                    int nChuck1 = ParameterList.Count() - chuck1List.Count;
                                    for (int i = 0; i < nChuck1; i++)
                                    {
                                        chuck1List.Add("");
                                    }
                                }

                            }
                        }
                        if (n == 1)
                        {
                            chuck2List = new List<string>(strArray);
                            if (ParameterList.Count() != chuck2List.Count)
                            {
                                if (chuck2List.Count == 0)
                                {
                                    for (int i = 0; i < ParameterList.Length; i++)
                                    {
                                        chuck2List.Add("");
                                    }
                                }
                                else
                                {
                                    int nChuck2 = ParameterList.Count() - chuck2List.Count;
                                    for (int i = 0; i < nChuck2; i++)
                                    {
                                        chuck2List.Add("");
                                    }
                                }

                            }
                        }
                    }
                   
                    for (int i = 0; i < ParameterList.Length; i++)
                    {
                        PC_InitialParamSettingEntity obj = new PC_InitialParamSettingEntity();

                        obj.Mode = ModeList[i];
                        obj.Parameter = ParameterList[i];
                        obj.Chuck1 = chuck1List[i];
                        if (chuck1List.Count>0 && chuck2List.Count == chuck1List.Count())
                        {
                            obj.Chuck2 = chuck2List[i];
                        }
                        else
                        {
                            obj.Chuck2 = "";
                        }
                        paramList.Add(obj);
                    }
                }

                string strJson = JsonHelp.SerializeObject(paramList);
                MyLogger.Trace("Return:: " +
                                string.Format("ParameterList<{0}>", strJson));
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return paramList;
        }
        #endregion
    }
}
