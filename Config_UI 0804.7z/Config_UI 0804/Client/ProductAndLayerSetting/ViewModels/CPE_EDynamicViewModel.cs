﻿using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProductAndLayerSetting.ViewModels
{
    class CPE_EDynamicViewModel : ViewModelBase
    {
        public CPE_EDynamicViewModel()
        {

        }

        public ISettingMainService _SettingMainService { get; set; }
        public CPE_EDynamicViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "Single Lot";
        }

        IRegionNavigationJournal _journal;
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            try
            {
                _journal = navigationContext.NavigationService.Journal;

                var msg = navigationContext.Parameters["Message"] as SendWaferModeParam;
                if (msg != null)
                {
                    SendWaferParam = msg;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        SendWaferModeParam SendWaferParam = new SendWaferModeParam();

        public override bool IsNavigationTarget(NavigationContext navigationContext)
        {
            var msg = navigationContext.Parameters["Message"] as SendWaferModeParam;
            return true;
        }

        #region Filed
        private List<string> _ChangeList = new List<string>();
        public List<string> ChangeList
        {
            get { return this._ChangeList; }
            set { SetProperty(ref this._ChangeList, value); }
        }

        private bool _IsCPEFeedForewardYes=false;
        public bool IsCPEFeedForewardYes
        {
            get { return this._IsCPEFeedForewardYes; }
            set { SetProperty(ref this._IsCPEFeedForewardYes, value); }
        }

        private bool _IsCPEFeedForewardNo=true;
        public bool IsCPEFeedForewardNo
        {
            get { return this._IsCPEFeedForewardNo; }
            set { SetProperty(ref this._IsCPEFeedForewardNo, value); }
        }

        private bool _IsCPEFeedForewardEnable;
        public bool IsCPEFeedForewardEnable
        {
            get { return this._IsCPEFeedForewardEnable; }
            set { SetProperty(ref this._IsCPEFeedForewardEnable, value); }
        }

        private bool _IsFixedEdgeShotValuesYes;
        public bool IsFixedEdgeShotValuesYes
        {
            get { return this._IsFixedEdgeShotValuesYes; }
            set { SetProperty(ref this._IsFixedEdgeShotValuesYes, value); }
        }

        private bool __IsFixedEdgeShotValuesNo;
        public bool IsFixedEdgeShotValuesNo
        {
            get { return this.__IsFixedEdgeShotValuesNo; }
            set { SetProperty(ref this.__IsFixedEdgeShotValuesNo, value); }
        }

        private string _CPELumda;
        public string CPELumda
        {
            get { return this._CPELumda; }
            set { SetProperty(ref this._CPELumda, value); }
        }

        private string _CPEUpdateTime;
        public string CPEUpdateTime
        {
            get { return this._CPEUpdateTime; }
            set { SetProperty(ref this._CPEUpdateTime, value); }
        }

        private string _CPEUpdateLot;
        public string CPEUpdateLot
        {
            get { return this._CPEUpdateLot; }
            set { SetProperty(ref this._CPEUpdateLot, value); }
        }

        private string _LevelOneSampling;
        public string LevelOneSampling
        {
            get { return this._LevelOneSampling; }
            set { SetProperty(ref this._LevelOneSampling, value); }
        }

        private string _LevelTwoSampling;
        public string LevelTwoSampling
        {
            get { return this._LevelTwoSampling; }
            set { SetProperty(ref this._LevelTwoSampling, value); }
        }

        private string _IsBtnEditEnable;
        public string IsBtnEditEnable
        {
            get { return this._IsBtnEditEnable; }
            set { SetProperty(ref this._IsBtnEditEnable, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _TextChangedCommand;
        public DelegateCommand TextChangedCommand =>
            _TextChangedCommand ?? (_TextChangedCommand = new DelegateCommand(OnTextChanged));

        #endregion

        #region Event Fun
        /// <summary>
        /// TextChanged Event Fun
        /// </summary>
        void OnTextChanged()
        {
            ChangeList = new List<string>();
            ChangeList.Add(IsCPEFeedForewardYes.ToString().ToLower());
            ChangeList.Add(IsFixedEdgeShotValuesYes.ToString().ToLower());
            double num1 = double.NaN;
            if (double.TryParse(CPELumda, out num1))
            {
                if (num1 < 0 || num1 > 1)
                {
                    CPELumda = "";
                    //System.Windows.Forms.MessageBox.Show("The Lumda has to be between 0 and 1!");
                }
            }
            else
            {
                CPELumda = "";
                //System.Windows.Forms.MessageBox.Show("The Lumda has to be between 0 and 1!");
            }
            ChangeList.Add(CPELumda);
            ChangeList.Add(CPEUpdateTime);
            ChangeList.Add(CPEUpdateLot);
            ChangeList.Add(LevelOneSampling);
            ChangeList.Add(LevelTwoSampling);
            EventAggregator.GetEvent<CPEEDynamicChangedEvent>().Publish(ChangeList);
        }
        #endregion
    }
}
