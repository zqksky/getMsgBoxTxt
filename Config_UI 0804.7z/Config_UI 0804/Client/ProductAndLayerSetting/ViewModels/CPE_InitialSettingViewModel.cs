﻿using Prism.Commands;
using Prism.Events;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProductAndLayerSetting.ViewModels
{
    class CPE_InitialSettingViewModel : ViewModelBase
    {
        public CPE_InitialSettingViewModel()
        {

        }

        IEventAggregator _ea;
        public ISettingMainService _SettingMainService { get; set; }
        public CPE_InitialSettingViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "CPE Initial Setting";

            _ea = ea;
            EventAggregator.GetEvent<CPEInitialFlagEvent>().Subscribe(CPEInitialMessageReceived);

            //OnInit();
        }

        private void CPEInitialMessageReceived(string str)
        {
            CPER2RMode = str;
        }

        string strSettingSource = string.Empty;
        string strSettingUpdate = string.Empty;
        /// <summary>
        /// Init Event Fun
        /// </summary>
        void OnInit()
        {
            try
            {
                if (IsCPEInitialEnable)
                {
                    IsGrdReadOnly = false;
                    IsConfirmEnableFlag = true;
                }
                else
                {
                    IsGrdReadOnly = true;
                    IsConfirmEnableFlag = false;
                }

                strSettingSource = JsonHelp.SerializeObject(SettingList);
                SettingInitList = JsonHelp.DeserializeJsonToList<CPE_InitialSettingEntity>(strSettingSource);
                GetInitSettingList();

                InitChecked();
                InitCheckedEnable();
                //GetSettingList();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }


        #region Fun
        /// <summary>
        /// Init CheckBox
        /// </summary>
        void InitChecked()
        {
            if (CPER2RMode.Equals("Fixed"))
            {
                CheckedList = new List<string>() { "TOOL" };
            }

            foreach (var str in CheckedList)
            {
                if (str.ToUpper().Equals("TOOL"))
                {
                    IsToolCheckedFlag = true;
                }
                else if (str.ToUpper().Equals("RETICLE"))
                {
                    IsReticleCheckedFlag = true;
                }
                else if (str.ToUpper().Equals("PRE_TOOL"))
                {
                    IsPreToolCheckedFlag = true;
                }
                else if (str.ToUpper().Equals("PRE_RETICLE"))
                {
                    IsPreReticleCheckedFlag = true;
                }
            }
        }

        /// <summary>
        /// Init CheckBox Enable
        /// </summary>
        void InitCheckedEnable()
        {
            if (CPER2RMode.Equals("Fixed"))
            {
                IsAddEnableFlag = false;
                IsDeleteEnableFlag = false;
                IsToolEnableFlag = false;
                IsPreToolEnableFlag = false;
                IsReticleEnableFlag = false;
                IsPreReticleEnableFlag = false;
                IsToolColumnEnableFlag = false;
            }
            else if (CPER2RMode.Equals("Static") || CPER2RMode.Equals("Dynamic") || CPER2RMode.Equals("LIS"))
            {
                IsAddEnableFlag = true;
                IsDeleteEnableFlag = true;
                IsToolEnableFlag = false;
                IsPreToolEnableFlag = true;
                IsReticleEnableFlag = true;
                IsPreReticleEnableFlag = false;

                IsToolCheckedFlag = true;
                IsToolColumnEnableFlag = IsToolCheckedFlag;
                foreach (var obj in SettingList)
                {
                    obj.CPEModelTimeStamp = "";
                }

                ObservableCollection<CPE_InitialSettingEntity> list = new ObservableCollection<CPE_InitialSettingEntity>(SettingList);
                SettingList.Clear();
                SettingList = new ObservableCollection<CPE_InitialSettingEntity>(list);
            }
        }
        /// <summary>
        /// Get Checked list
        /// </summary>
        void GetCheckedList()
        {
            CheckedList = new List<string>();
            if (IsToolCheckedFlag)
            {
                CheckedList.Add("TOOL");
            }
            if (IsReticleCheckedFlag)
            {
                CheckedList.Add("RETICLE");
            }
            if (IsPreToolCheckedFlag)
            {
                CheckedList.Add("PRE_TOOL");
            }
            if (IsPreReticleCheckedFlag)
            {
                CheckedList.Add("PRE_RETICLE");
            }
        }
        /// <summary>
        /// Get InitSettingList
        /// </summary>
        void GetInitSettingList()
        {
            ToolListInit = new List<string>();
            ReticleListInit = new List<string>();
            PreToolListInit = new List<string>();
            PreReticleListInit = new List<string>();

            foreach (var obj in SettingInitList)
            {
                foreach (var str in obj.ToolList)
                {
                    if (!ToolListInit.Contains(str))
                    {
                        ToolListInit.Add(str);
                    }
                }
                foreach (var str in obj.ReticleList)
                {
                    if (!ReticleListInit.Contains(str))
                    {
                        ReticleListInit.Add(str);
                    }
                }
                foreach (var str in obj.PreToolList)
                {
                    if (!PreToolListInit.Contains(str))
                    {
                        PreToolListInit.Add(str);
                    }
                }
                foreach (var str in obj.PreReticleList)
                {
                    if (!PreReticleListInit.Contains(str))
                    {
                        PreReticleListInit.Add(str);
                    }
                }
                if (!ToolListInit.Contains(obj.TOOL))
                {
                    ToolListInit.Add(obj.TOOL);
                }
                if (!ReticleListInit.Contains(obj.RETICLE))
                {
                    ReticleListInit.Add(obj.RETICLE);
                }
                if (!PreToolListInit.Contains(obj.PRE_TOOL))
                {
                    PreToolListInit.Add(obj.PRE_TOOL);
                }
                if (!PreReticleListInit.Contains(obj.PRE_RETICLE))
                {
                    PreReticleListInit.Add(obj.PRE_RETICLE);
                }
            }
        }
        /// <summary>
        /// Get SettingList
        /// </summary>
        void GetSettingList()
        {
            foreach (var obj in SettingList)
            {
                if (!IsToolCheckedFlag)
                {
                    if (!obj.ToolList.Contains("*"))
                    {
                        obj.ToolList.Add("*");
                    }

                    obj.TOOL = "*";
                }
                if (!IsReticleCheckedFlag)
                {
                    if (!obj.ReticleList.Contains("*"))
                    {
                        obj.ReticleList.Add("*");
                    }
                    obj.RETICLE = "*";
                }
                if (!IsPreToolCheckedFlag)
                {
                    if (!obj.PreToolList.Contains("*"))
                    {
                        obj.PreToolList.Add("*");
                    }
                    obj.PRE_TOOL = "*";
                }
                if (!IsPreReticleCheckedFlag)
                {
                    if (!obj.PreReticleList.Contains("*"))
                    {
                        obj.PreReticleList.Add("*");
                    }
                    obj.PRE_RETICLE = "*";
                }
                //ObservableCollection<CPE_InitialSettingEntity> list = new ObservableCollection<CPE_InitialSettingEntity>(SettingList);
                //SettingList.Clear();
                //SettingList = new ObservableCollection<CPE_InitialSettingEntity>(list);
            }
        }
        /// <summary>
        /// Set SettingList
        /// </summary>
        /// <param name="strCheckedType"></param>
        void SetSettingList(string strCheckedType)
        {
            string str = string.Empty;
            if (strCheckedType.Equals("Tool"))
            {
                if (IsToolCheckedFlag)
                {
                    str = "";
                    foreach (var obj in SettingList)
                    {
                        foreach (var strTmp in ToolListInit)
                        {
                            if (!obj.ToolList.Contains(strTmp))
                            {
                                obj.ToolList.Add(strTmp);
                            }
                        }
                        obj.ToolList.Remove("*");
                        obj.TOOL = str;
                    }
                }
                else
                {
                    str = "*";
                    foreach (var obj in SettingList)
                    {
                        foreach (var strTmp in ToolListInit)
                        {
                            if (!obj.ToolList.Contains(strTmp))
                            {
                                obj.ToolList.Add(strTmp);
                            }
                        }
                        obj.ToolList.Add("*");
                        obj.TOOL = str;
                    }
                }
            }

            else if (strCheckedType.Equals("Reticle"))
            {
                if (IsReticleCheckedFlag)
                {
                    str = "";
                    foreach (var obj in SettingList)
                    {
                        foreach (var strTmp in ReticleListInit)
                        {
                            if (!obj.ReticleList.Contains(strTmp))
                            {
                                obj.ReticleList.Add(strTmp);
                            }
                        }
                        obj.ReticleList.Remove("*");
                        obj.RETICLE = str;
                    }
                }
                else
                {
                    str = "*";
                    foreach (var obj in SettingList)
                    {
                        foreach (var strTmp in ReticleListInit)
                        {
                            if (!obj.ReticleList.Contains(strTmp))
                            {
                                obj.ReticleList.Add(strTmp);
                            }
                        }
                        obj.ReticleList.Add("*");
                        obj.RETICLE = str;
                    }
                }
            }
            else if (strCheckedType.Equals("PreTool"))
            {
                if (IsPreToolCheckedFlag)
                {
                    str = "";
                    foreach (var obj in SettingList)
                    {
                        foreach (var strTmp in PreToolListInit)
                        {
                            if (!obj.PreToolList.Contains(strTmp))
                            {
                                obj.PreToolList.Add(strTmp);
                            }
                        }
                        obj.PreToolList.Remove("*");
                        obj.PRE_TOOL = str;
                    }
                }
                else
                {
                    str = "*";
                    foreach (var obj in SettingList)
                    {
                        foreach (var strTmp in PreToolListInit)
                        {
                            if (!obj.PreToolList.Contains(strTmp))
                            {
                                obj.PreToolList.Add(strTmp);
                            }
                        }
                        obj.PreToolList.Add("*");
                        obj.PRE_TOOL = str;
                    }
                }
            }
            else if (strCheckedType.Equals("PreReticle"))
            {
                if (IsPreReticleCheckedFlag)
                {
                    str = "";

                    foreach (var obj in SettingList)
                    {
                        foreach (var strTmp in PreReticleListInit)
                        {
                            if (!obj.PreReticleList.Contains(strTmp))
                            {
                                obj.PreReticleList.Add(strTmp);
                            }
                        }
                        obj.PreReticleList.Remove("*");
                        obj.PRE_RETICLE = str;
                    }

                }
                else
                {
                    str = "*";
                    foreach (var obj in SettingList)
                    {
                        foreach (var strTmp in PreReticleListInit)
                        {
                            if (!obj.PreReticleList.Contains(strTmp))
                            {
                                obj.PreReticleList.Add(strTmp);
                            }
                        }
                        obj.PreReticleList.Add("*");
                        obj.PRE_RETICLE = str;
                    }
                }
            }

            ObservableCollection<CPE_InitialSettingEntity> list = new ObservableCollection<CPE_InitialSettingEntity>(SettingList);
            SettingList.Clear();
            SettingList = new ObservableCollection<CPE_InitialSettingEntity>(list);
        }
        #endregion

        #region Filed
        private bool _IsCPEInitialEnable = true;
        public bool IsCPEInitialEnable
        {
            get { return this._IsCPEInitialEnable; }
            set { SetProperty(ref this._IsCPEInitialEnable, value); }
        }

        private bool _IsGrdReadOnly = false;
        public bool IsGrdReadOnly
        {
            get { return this._IsGrdReadOnly; }
            set { SetProperty(ref this._IsGrdReadOnly, value); }
        }

        private bool _IsConfirmEnableFlag = true;
        public bool IsConfirmEnableFlag
        {
            get { return this._IsConfirmEnableFlag; }
            set { SetProperty(ref this._IsConfirmEnableFlag, value); }
        }

        List<string> ToolListInit = new List<string>();
        List<string> ReticleListInit = new List<string>();
        List<string> PreToolListInit = new List<string>();
        List<string> PreReticleListInit = new List<string>();

        private List<string> _CheckedList = new List<string>();
        public List<string> CheckedList
        {
            get { return this._CheckedList; }
            set { SetProperty(ref this._CheckedList, value); }
        }

        private string _CPER2RMode = "";
        public string CPER2RMode
        {
            get { return this._CPER2RMode; }
            set { SetProperty(ref this._CPER2RMode, value); }
        }


        private bool _IsBtnOkClick = false;
        public bool IsBtnOkClick
        {
            get { return this._IsBtnOkClick; }
            set { SetProperty(ref this._IsBtnOkClick, value); }
        }

        private bool _IsDeleteEnableFlag = false;
        public bool IsDeleteEnableFlag
        {
            get { return this._IsDeleteEnableFlag; }
            set { SetProperty(ref this._IsDeleteEnableFlag, value); }
        }

        private bool _IsAddEnableFlag = false;
        public bool IsAddEnableFlag
        {
            get { return this._IsAddEnableFlag; }
            set { SetProperty(ref this._IsAddEnableFlag, value); }
        }

        private bool _IsToolEnableFlag=false;
        public bool IsToolEnableFlag
        {
            get { return this._IsToolEnableFlag; }
            set { SetProperty(ref this._IsToolEnableFlag, value); }
        }

        private bool _IsToolColumnEnableFlag = true;
        public bool IsToolColumnEnableFlag
        {
            get { return this._IsToolColumnEnableFlag; }
            set { SetProperty(ref this._IsToolColumnEnableFlag, value); }
        }

        private bool _IsReticleEnableFlag = false;
        public bool IsReticleEnableFlag
        {
            get { return this._IsReticleEnableFlag; }
            set { SetProperty(ref this._IsReticleEnableFlag, value); }
        }

        private bool _IsPreToolEnableFlag = false;
        public bool IsPreToolEnableFlag
        {
            get { return this._IsPreToolEnableFlag; }
            set { SetProperty(ref this._IsPreToolEnableFlag, value); }
        }

        private bool _IsPreReticleEnableFlag = false;
        public bool IsPreReticleEnableFlag
        {
            get { return this._IsPreReticleEnableFlag; }
            set { SetProperty(ref this._IsPreReticleEnableFlag, value); }
        }

        private bool _IsToolCheckedFlag = true;
        public bool IsToolCheckedFlag
        {
            get { return this._IsToolCheckedFlag; }
            set { SetProperty(ref this._IsToolCheckedFlag, value); }
        }

        private bool _IsReticleCheckedFlag;
        public bool IsReticleCheckedFlag
        {
            get { return this._IsReticleCheckedFlag; }
            set { SetProperty(ref this._IsReticleCheckedFlag, value); }
        }

        private bool _IsPreToolCheckedFlag;
        public bool IsPreToolCheckedFlag
        {
            get { return this._IsPreToolCheckedFlag; }
            set { SetProperty(ref this._IsPreToolCheckedFlag, value); }
        }

        private bool _IsPreReticleCheckedFlag;
        public bool IsPreReticleCheckedFlag
        {
            get { return this._IsPreReticleCheckedFlag; }
            set { SetProperty(ref this._IsPreReticleCheckedFlag, value); }
        }

        private string _Product;
        public string Product
        {
            get { return this._Product; }
            set { SetProperty(ref this._Product, value); }
        }

        private string _Layer;
        public string Layer
        {
            get { return this._Layer; }
            set { SetProperty(ref this._Layer, value); }
        }

        private string _ToolGroup;
        public string ToolGroup
        {
            get { return this._ToolGroup; }
            set { SetProperty(ref this._ToolGroup, value); }
        }       

        private CPE_InitialSettingEntity _SelectedSetting;
        public CPE_InitialSettingEntity SelectedSetting
        {
            get { return this._SelectedSetting; }
            set { SetProperty(ref this._SelectedSetting, value); }
        }

        private ObservableCollection<CPE_InitialSettingEntity> _SettingList;
        public ObservableCollection<CPE_InitialSettingEntity> SettingList
        {
            get { return _SettingList; }
            set { SetProperty(ref _SettingList, value); }
        }

        private List<CPE_InitialSettingEntity> _SettingInitList;
        public List<CPE_InitialSettingEntity> SettingInitList
        {
            get { return _SettingInitList; }
            set { SetProperty(ref _SettingInitList, value); }
        }


        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnInit));

        private DelegateCommand _ChkToolClickCommand;
        public DelegateCommand ChkToolClickCommand =>
            _ChkToolClickCommand ?? (_ChkToolClickCommand = new DelegateCommand(OnChkToolClick));

        private DelegateCommand _ChkPreToolClickCommand;
        public DelegateCommand ChkPreToolClickCommand =>
            _ChkPreToolClickCommand ?? (_ChkPreToolClickCommand = new DelegateCommand(OnChkPreToolClick));

        private DelegateCommand _ChkReticleClickCommand;
        public DelegateCommand ChkReticleClickCommand =>
            _ChkReticleClickCommand ?? (_ChkReticleClickCommand = new DelegateCommand(OnChkReticleClick));

        private DelegateCommand _ChkPreReticleClickCommand;
        public DelegateCommand ChkPreReticleClickCommand =>
            _ChkPreReticleClickCommand ?? (_ChkPreReticleClickCommand = new DelegateCommand(OnChkPreReticleClick));
        
        private DelegateCommand _SelectionChangedCommand;
        public DelegateCommand SelectionChangedCommand =>
            _SelectionChangedCommand ?? (_SelectionChangedCommand = new DelegateCommand(OnSelectionChanged));

        private DelegateCommand _BeginningEditCommand;
        public DelegateCommand BeginningEditCommand =>
            _BeginningEditCommand ?? (_BeginningEditCommand = new DelegateCommand(OnBeginningEdit));
 
        private DelegateCommand _CellEditEndingCommand;
        public DelegateCommand CellEditEndingCommand =>
            _CellEditEndingCommand ?? (_CellEditEndingCommand = new DelegateCommand(OnCellEditEnding));

        private DelegateCommand _LostFocusCommand;
        public DelegateCommand LostFocusCommand =>
            _LostFocusCommand ?? (_LostFocusCommand = new DelegateCommand(OnLostFocus));
       
        private DelegateCommand _BtnAddCommand;
        public DelegateCommand BtnAddCommand =>
            _BtnAddCommand ?? (_BtnAddCommand = new DelegateCommand(OnAddClick));

        private DelegateCommand _BtnDeleteCommand;
        public DelegateCommand BtnDeleteCommand =>
            _BtnDeleteCommand ?? (_BtnDeleteCommand = new DelegateCommand(OnDeleteClick));

        private DelegateCommand _BtnConfirmCommand;
        public DelegateCommand BtnConfirmCommand =>
            _BtnConfirmCommand ?? (_BtnConfirmCommand = new DelegateCommand(OnConfirmClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));
        #endregion

        #region Event Fun
        /// <summary>
        /// Tool CheckBox Click Event Fun
        /// </summary>
        void OnChkToolClick()
        {
            try
            {
                SetSettingList("Tool");
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// PreTool CheckBox Click Event Fun
        /// </summary>
        void OnChkPreToolClick()
        {
            try
            {
                SetSettingList("PreTool");
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Reticle CheckBox Click Event Fun
        /// </summary>
        void OnChkReticleClick()
        {
            try
            {
                SetSettingList("Reticle");
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// PreReticle CheckBox Click Event Fun
        /// </summary>
        void OnChkPreReticleClick()
        {
            try
            {
                //IsPreReticleEnable = IsPreReticleCheckedFlag;

                SetSettingList("PreReticle");
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// SelectionChanged Event Fun
        /// </summary>
        void OnSelectionChanged()
        {
            try
            {
                //IsBeginning = false;
                //currentTool = string.Empty;
                //currentSubRecipe = string.Empty;
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        bool IsBeginning = false;
        string currentTool = string.Empty;
        string currentSubRecipe = string.Empty;
        /// <summary>
        /// BeginningEdit Event Fun
        /// </summary>
        void OnBeginningEdit()
        {
            try
            {
                if (SelectedSetting != null)
                {
                    if (CPER2RMode.Equals("Fixed"))
                    {
                        currentTool = SelectedSetting.TOOL;
                        currentSubRecipe = SelectedSetting.CPESubRecipe;

                        IsBeginning = true;
                    }
                }

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// LostFocus Event Fun 
        /// </summary>
        void OnLostFocus()
        {
            try
            {

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }

        }
        /// <summary>
        /// CellEditEnding Event Fun
        /// </summary>
        void OnCellEditEnding()
        {
            try
            {
                if (SelectedSetting != null)
                {
                    if (IsBeginning)
                    {
                        if (CPER2RMode.Equals("Fixed"))
                        {
                            if (currentTool.Equals(SelectedSetting.TOOL) && currentSubRecipe.Equals(SelectedSetting.CPESubRecipe))
                            {
                            }
                            else
                            {
                                DateTime dt = DateTime.Now;
                                string str = dt.ToString("yyyy-MM-dd'T'HH:mm:ss.ffffffzzz");
                                str = str.Replace(":", ";");
                                SelectedSetting.CPEModelTimeStamp = str;

                                ObservableCollection<CPE_InitialSettingEntity> list = new ObservableCollection<CPE_InitialSettingEntity>(SettingList);
                                SettingList.Clear();
                                SettingList = new ObservableCollection<CPE_InitialSettingEntity>(list);
                            }
                        }
                        IsBeginning = false;
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Add Button Click Event Fun
        /// </summary>
        void OnAddClick()
        {
            try
            {
                if (SettingList.Count > 0)
                {
                    CPE_InitialSettingEntity SelectedSettingNew = new CPE_InitialSettingEntity();
                    SelectedSettingNew.PRODUCT = Product;
                    SelectedSettingNew.LAYER = Layer;
                    SelectedSettingNew.TOOL_GROUP = ToolGroup;

                    SelectedSettingNew.ToolList = new List<string>();
                    SelectedSettingNew.ReticleList = new List<string>();
                    SelectedSettingNew.PreToolList = new List<string>();
                    SelectedSettingNew.PreReticleList = new List<string>();
                    if (IsToolCheckedFlag)
                    {
                        foreach (var str in ToolListInit)
                        {
                            if (!SelectedSettingNew.ToolList.Contains(str))
                            {
                                SelectedSettingNew.ToolList.Add(str);
                            }  
                        }
                        SelectedSettingNew.ToolList.Remove("*");
                    }
                    else
                    {
                        foreach (var str in ToolListInit)
                        {
                            if (!SelectedSettingNew.ToolList.Contains(str))
                            {
                                SelectedSettingNew.ToolList.Add(str);
                            }
                        }
                        if (!SelectedSettingNew.ToolList.Contains("*"))
                        {
                            SelectedSettingNew.ToolList.Add("*");
                        }
                    }
                    if (IsReticleCheckedFlag)
                    {
                        foreach (var str in ReticleListInit)
                        {
                            if (!SelectedSettingNew.ReticleList.Contains(str))
                            {
                                SelectedSettingNew.ReticleList.Add(str);
                            }
                        }
                        SelectedSettingNew.ReticleList.Remove("*");
                    }
                    else
                    {
                        foreach (var str in ReticleListInit)
                        {
                            if (!SelectedSettingNew.ReticleList.Contains(str))
                            {
                                SelectedSettingNew.ReticleList.Add(str);
                            }
                        }
                        if (!SelectedSettingNew.ReticleList.Contains("*"))
                        {
                            SelectedSettingNew.ReticleList.Add("*");
                        }
                    }
                    if (IsPreToolCheckedFlag)
                    {
                        foreach (var str in PreToolListInit)
                        {
                            if (!SelectedSettingNew.PreToolList.Contains(str))
                            {
                                SelectedSettingNew.PreToolList.Add(str);
                            }
                        }
                        SelectedSettingNew.PreToolList.Remove("*");
                    }
                    else
                    {
                        foreach (var str in PreToolListInit)
                        {
                            if (!SelectedSettingNew.PreToolList.Contains(str))
                            {
                                SelectedSettingNew.PreToolList.Add(str);
                            }
                        }
                        if (!SelectedSettingNew.PreToolList.Contains("*"))
                        {
                            SelectedSettingNew.PreToolList.Add("*");
                        }
                    }
                    if (IsPreReticleCheckedFlag)
                    {
                        foreach (var str in PreReticleListInit)
                        {
                            if (!SelectedSettingNew.PreReticleList.Contains(str))
                            {
                                SelectedSettingNew.PreReticleList.Add(str);
                            }
                        }
                        SelectedSettingNew.PreReticleList.Remove("*");
                    }
                    else
                    {
                        foreach (var str in PreReticleListInit)
                        {
                            if (!SelectedSettingNew.PreReticleList.Contains(str))
                            {
                                SelectedSettingNew.PreReticleList.Add(str);
                            }
                        }
                        if (!SelectedSettingNew.PreReticleList.Contains("*"))
                        {
                            SelectedSettingNew.PreReticleList.Add("*");
                        }
                    }
                    SelectedSettingNew.TOOL = IsToolCheckedFlag ? "" : "*";
                    SelectedSettingNew.RETICLE = IsReticleCheckedFlag ? "" : "*";
                    SelectedSettingNew.PRE_TOOL = IsPreToolCheckedFlag ? "" : "*";
                    SelectedSettingNew.PRE_RETICLE = IsPreReticleCheckedFlag ? "" : "*"; 

                    SelectedSettingNew.INIT_PARAMETER_NAME = SettingList[0].INIT_PARAMETER_NAME;
                    SelectedSettingNew.CPESubRecipe = "";
                    if (CPER2RMode.Equals("Fixed"))
                    {
                        SelectedSettingNew.CPEModelTimeStamp = SettingList[0].CPEModelTimeStamp;
                    }
                    else
                    {
                        SelectedSettingNew.CPEModelTimeStamp = "";
                    }

                    SettingList.Add(SelectedSettingNew);
                }

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Delete Button Click Event Fun
        /// </summary>
        void OnDeleteClick()
        {
            try
            {
                if (SelectedSetting == null)
                {
                    System.Windows.Forms.MessageBox.Show("Please select a row!");
                }
                if (SettingList.Count == 1)
                {
                    System.Windows.Forms.MessageBox.Show("Only one record!");
                    return;
                }
                SettingList.Remove(SelectedSetting);
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Confirm Button Click Event Fun
        /// </summary>
        void OnConfirmClick()
        {
            try
            {
                foreach (var obj in SettingList)
                {
                    if (IsToolCheckedFlag)
                    {
                        if (obj.TOOL.Equals("") || obj.TOOL.Equals("*"))
                        {
                            MessageBox.Show("Tool can not enter * or null!");
                            return;
                        }
                    }

                    if (IsReticleCheckedFlag)
                    {
                        if (obj.RETICLE.Equals("") || obj.RETICLE.Equals("*"))
                        {
                            MessageBox.Show("Reticle can not enter * or null!");
                            return;
                        }
                    }
                    if (IsPreToolCheckedFlag)
                    {
                        if (obj.PRE_TOOL.Equals("") || obj.PRE_TOOL.Equals("*"))
                        {
                            MessageBox.Show("PreTool can not enter * or null!");
                            return;
                        }
                    }
                    if (IsPreReticleCheckedFlag)
                    {
                        if (obj.PRE_RETICLE.Equals("") || obj.PRE_RETICLE.Equals("*"))
                        {
                            MessageBox.Show("PreReticle can not enter * or null!");
                            return;
                        }
                    }

                    if (obj.CPESubRecipe.Equals("") || obj.CPESubRecipe.Equals("*"))
                    {
                        MessageBox.Show("CPE Sub Recipe can not enter * or null!");
                        return;
                    }
                }

                strSettingUpdate = JsonHelp.SerializeObject(SettingList);

                IsBtnOkClick = true;

                GetCheckedList();

                foreach (var obj in SettingList)
                {
                    string str = obj.CPEModelTimeStamp.Replace(":", ";");
                    obj.CPEModelTimeStamp = str;
                }

                List<string> strList = new List<string>();
                foreach (var obj in SettingList)
                {
                    //string strMsg = "Tool/Reticle are not unique!";
                    //string str = obj.TOOL + "-" + obj.RETICLE + "-" + obj.RETICLE;
                    string strMsg = "Tool are not unique!";
                    string str = obj.TOOL;
                    if (IsToolCheckedFlag && IsReticleCheckedFlag && IsPreReticleCheckedFlag && IsPreToolCheckedFlag)
                    {
                        str = obj.TOOL + "-" + obj.RETICLE + "-" + obj.PRE_RETICLE + "-" + obj.PRE_TOOL;
                        strMsg = "Tool/Reticle/PreReticle/PreTool are not unique!";
                    }
                    else if (IsToolCheckedFlag && IsReticleCheckedFlag && IsPreReticleCheckedFlag)
                    {
                        str = obj.TOOL + "-" + obj.RETICLE + "-" + obj.PRE_RETICLE;
                        strMsg = "Tool/Reticle/PreReticle are not unique!";
                    }
                    else if (IsToolCheckedFlag && IsReticleCheckedFlag && IsPreToolCheckedFlag)
                    {
                        str = obj.TOOL + "-" + obj.RETICLE + "-"  + obj.PRE_TOOL;
                        strMsg = "Tool and Reticle and PreTool are not unique!";
                    }
                    else if (IsToolCheckedFlag && IsReticleCheckedFlag)
                    {
                        str = obj.TOOL + "-" + obj.RETICLE;
                        strMsg = "Tool/Reticle are not unique!";
                    }
                    else if (IsToolCheckedFlag && IsPreToolCheckedFlag)
                    {
                        str = obj.TOOL + "-" + obj.PRE_TOOL;
                        strMsg = "Tool/PreTool are not unique!";
                    }
                    else if (IsToolCheckedFlag && IsPreReticleCheckedFlag)
                    {
                        str = obj.TOOL + "-" + obj.PRE_RETICLE;
                        strMsg = "Tool/PreReticle are not unique!";
                    }
                    else if (IsToolCheckedFlag)
                    {
                        str = obj.TOOL;
                        strMsg = "Tool are not unique!";
                    }
                    if (strList.Contains(str))
                    {
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }
                    else
                    {
                        strList.Add(str);
                    }
                }

                if (CPER2RMode.Equals("Fixed"))
                {

                }
                else
                {
                    foreach (var obj in SettingList)
                    {
                        obj.CPEModelTimeStamp = "";
                    }
                }
                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Cancel Button Click Event Fun
        /// </summary>
        void OnBtnCancelClick()
        {
            IsBtnOkClick = false;
            this.CurrentWindow.Close();
        }
        #endregion
    }
}
