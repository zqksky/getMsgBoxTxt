﻿using MahApps.Metro.Controls;
using Prism.Commands;
using Prism.Events;
using ProductAndLayerSetting.Views;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ProductAndLayerSetting.ViewModels
{
    class VersionCompareViewModel : ViewModelBase
    {
        public VersionCompareViewModel()
        {

        }
        public ISettingMainService _SettingMainService { get; set; }
        public VersionCompareViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "Version Compare";

        }

        #region Init Field
        private bool _IsBtnVersionCompareClickFlag;
        public bool IsBtnVersionCompareClickFlag
        {
            get { return this._IsBtnVersionCompareClickFlag; }
            set { SetProperty(ref this._IsBtnVersionCompareClickFlag, value); }
        }

        private bool _IsUpdateValidationFlag=false;
        public bool IsUpdateValidationFlag
        {
            get { return this._IsUpdateValidationFlag; }
            set { SetProperty(ref this._IsUpdateValidationFlag, value); }
        }

        private bool _IsProductListEnable;
        public bool IsProductListEnable
        {
            get { return this._IsProductListEnable; }
            set { SetProperty(ref this._IsProductListEnable, value); }
        }

        private bool _IsVersionAListEnable;
        public bool IsVersionAListEnable
        {
            get { return this._IsVersionAListEnable; }
            set { SetProperty(ref this._IsVersionAListEnable, value); }
        }

        private bool _IsVersionBListEnable;
        public bool IsVersionBListEnable
        {
            get { return this._IsVersionBListEnable; }
            set { SetProperty(ref this._IsVersionBListEnable, value); }
        }

        private bool _IsBtnVersionNumberEnable;
        public bool IsBtnVersionNumberEnable
        {
            get { return this._IsBtnVersionNumberEnable; }
            set { SetProperty(ref this._IsBtnVersionNumberEnable, value); }
        }

        private bool _IsBtnCompareEnable;
        public bool IsBtnCompareEnable
        {
            get { return this._IsBtnCompareEnable; }
            set { SetProperty(ref this._IsBtnCompareEnable, value); }
        }
        private bool _IsBtnSaveEnable;
        public bool IsBtnSaveEnable
        {
            get { return this._IsBtnSaveEnable; }
            set { SetProperty(ref this._IsBtnSaveEnable, value); }
        }

        private bool _IsBtnCancelEnable;
        public bool IsBtnCancelEnable
        {
            get { return this._IsBtnCancelEnable; }
            set { SetProperty(ref this._IsBtnCancelEnable, value); }
        }

        private bool _IsBtnPassEnable;
        public bool IsBtnPassEnable
        {
            get { return this._IsBtnPassEnable; }
            set { SetProperty(ref this._IsBtnPassEnable, value); }
        }

        private bool _IsBtnFailEnable;
        public bool IsBtnFailEnable
        {
            get { return this._IsBtnFailEnable; }
            set { SetProperty(ref this._IsBtnFailEnable, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region Init Event 
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnLoaded));
        #endregion

        #region Init Event Fun
        void OnLoaded()
        {
            try
            {
                if (IsBtnVersionCompareClickFlag)
                {
                    IsProductListEnable = true;
                    IsVersionAListEnable = true;
                    IsVersionBListEnable = true;
                    IsBtnVersionNumberEnable = true;
                    IsBtnCompareEnable = true;
                    IsBtnSaveEnable = false;
                    IsBtnCancelEnable = false;
                    IsBtnPassEnable = false;
                    IsBtnFailEnable = false;

                    OnBtnVersionNumberClick();
                }
                else
                {
                    IsProductListEnable = false;
                    IsVersionAListEnable = false;
                    IsVersionBListEnable = false;
                    IsBtnVersionNumberEnable = false;
                    IsBtnCompareEnable = false;

                    if (IsUpdateValidationFlag)
                    {
                        IsBtnSaveEnable = false;
                        IsBtnCancelEnable = false;
                        IsBtnPassEnable = true;
                        IsBtnFailEnable = true;

                        VersionAList.Add("Previous");
                        VersionBList.Add("Current");
                        VersionA = "Previous";
                        VersionB = "Current";
                        OnBtnCompareClick();
                    }
                    else
                    {
                        IsBtnSaveEnable = true;
                        IsBtnCancelEnable = true;
                        IsBtnPassEnable = false;
                        IsBtnFailEnable = false;

                        VersionAList.Add("Previous");
                        VersionBList.Add("Current");
                        VersionA = "Previous";
                        VersionB = "Current";
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Fun
        void ClearVersionNumber()
        {
            try
            {
                VersionA = "";
                VersionB = "";
                VersionAList = new ObservableCollection<string>();
                VersionBList = new ObservableCollection<string>();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        void ClearLblContext()
        {
            try
            {
                LblProduct = "";
                LblLayer = "";
                LblToolGroup = "";
                LblCdInitGroup = "";
                LblCdResult = "";
                LblPcInitGroup = "";
                LblPcResult = "";
                LblCpeInitGroup = "";
                LblCpeResult = "";
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        void ClearParameter()
        {
            try
            {
                CommonCompareList = new ObservableCollection<CompareCommonEntity>();
                LISCompareList = new ObservableCollection<CompareCommonEntity>();
                CDInitCompareList = new ObservableCollection<CompareInitEntity>();
                PCInitCompareList = new ObservableCollection<CompareInitEntity>();
                CPEInitCompareList = new ObservableCollection<CompareInitEntity>();
                CdDetailCompareList = new ObservableCollection<CompareDetailEntity>();
                PcDetailCompareList = new ObservableCollection<CompareDetailEntity>();
                CpeDetailCompareList = new ObservableCollection<CompareDetailEntity>();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Field
        string catchFlag = "FAIL";
        private string _CatchReason = "";
        public string CatchReason
        {
            get { return this._CatchReason; }
            set { SetProperty(ref this._CatchReason, value); }
        }

        private string _CommonVersionA_Opt="Version A";
        public string CommonVersionA_Opt
        {
            get { return this._CommonVersionA_Opt; }
            set { SetProperty(ref this._CommonVersionA_Opt, value); }
        }

        private string _CommonVersionB_Opt="Version B";
        public string CommonVersionB_Opt
        {
            get { return this._CommonVersionB_Opt; }
            set { SetProperty(ref this._CommonVersionB_Opt, value); }
        }

        private string _LISVersionA_Opt = "Version A";
        public string LISVersionA_Opt
        {
            get { return this._LISVersionA_Opt; }
            set { SetProperty(ref this._LISVersionA_Opt, value); }
        }

        private string _LISVersionB_Opt = "Version B";
        public string LISVersionB_Opt
        {
            get { return this._LISVersionB_Opt; }
            set { SetProperty(ref this._LISVersionB_Opt, value); }
        }

        private bool _FlagSave=false;
        public bool FlagSave
        {
            get { return this._FlagSave; }
            set { SetProperty(ref this._FlagSave, value); }
        }

        private string _Product;
        public string Product
        {
            get { return this._Product; }
            set { SetProperty(ref this._Product, value); }
        }

        private List<string> _ProductList = new List<string>();
        public List<string> ProductList
        {
            get { return this._ProductList; }
            set { SetProperty(ref this._ProductList, value); }
        }

        private string _Layer;
        public string Layer
        {
            get { return this._Layer; }
            set { SetProperty(ref this._Layer, value); }
        }

        private List<string> _LayerList = new List<string>();
        public List<string> LayerList
        {
            get { return this._LayerList; }
            set { SetProperty(ref this._LayerList, value); }
        }

        private string _ToolGroup;
        public string ToolGroup
        {
            get { return this._ToolGroup; }
            set { SetProperty(ref this._ToolGroup, value); }
        }

        private List<string> _ToolGroupList = new List<string>();
        public List<string> ToolGroupList
        {
            get { return this._ToolGroupList; }
            set { SetProperty(ref this._ToolGroupList, value); }
        }

        private string _ConfigUI="LITHO";
        public string ConfigUI
        {
            get { return this._ConfigUI; }
            set { SetProperty(ref this._ConfigUI, value); }
        }

        private string _VersionA;
        public string VersionA
        {
            get { return this._VersionA; }
            set { SetProperty(ref this._VersionA, value); }
        }

        private ObservableCollection<string> _VersionAList = new ObservableCollection<string>();
        public ObservableCollection<string> VersionAList
        {
            get { return this._VersionAList; }
            set { SetProperty(ref this._VersionAList, value); }
        }

        private string _VersionB;
        public string VersionB
        {
            get { return this._VersionB; }
            set { SetProperty(ref this._VersionB, value); }
        }

        private ObservableCollection<string> _VersionBList = new ObservableCollection<string>();
        public ObservableCollection<string> VersionBList
        {
            get { return this._VersionBList; }
            set { SetProperty(ref this._VersionBList, value); }
        }

        private string _LblProduct;
        public string LblProduct
        {
            get { return this._LblProduct; }
            set { SetProperty(ref this._LblProduct, value); }
        }

        private string _LblLayer;
        public string LblLayer
        {
            get { return this._LblLayer; }
            set { SetProperty(ref this._LblLayer, value); }
        }

        private string _LblToolGroup;
        public string LblToolGroup
        {
            get { return this._LblToolGroup; }
            set { SetProperty(ref this._LblToolGroup, value); }
        }

        private string _LblCdInitGroup;
        public string LblCdInitGroup
        {
            get { return this._LblCdInitGroup; }
            set { SetProperty(ref this._LblCdInitGroup, value); }
        }

        private string _LblCdResult;
        public string LblCdResult
        {
            get { return this._LblCdResult; }
            set { SetProperty(ref this._LblCdResult, value); }
        }

        private string _LblPcInitGroup;
        public string LblPcInitGroup
        {
            get { return this._LblPcInitGroup; }
            set { SetProperty(ref this._LblPcInitGroup, value); }
        }

        private string _LblPcResult;
        public string LblPcResult
        {
            get { return this._LblPcResult; }
            set { SetProperty(ref this._LblPcResult, value); }
        }

        private string _LblCpeInitGroup;
        public string LblCpeInitGroup
        {
            get { return this._LblCpeInitGroup; }
            set { SetProperty(ref this._LblCpeInitGroup, value); }
        }

        private string _LblCpeResult;
        public string LblCpeResult
        {
            get { return this._LblCpeResult; }
            set { SetProperty(ref this._LblCpeResult, value); }
        }

        private CompareCommonEntity _SelectedCommonCompare;
        public CompareCommonEntity SelectedCommonCompare
        {
            get { return this._SelectedCommonCompare; }
            set { SetProperty(ref this._SelectedCommonCompare, value); }
        }

        private ObservableCollection<CompareCommonEntity> _CommonCompareList;
        public ObservableCollection<CompareCommonEntity> CommonCompareList
        {
            get { return _CommonCompareList; }
            set { SetProperty(ref _CommonCompareList, value); }
        }

        private CompareCommonEntity _SelectedLISCompare;
        public CompareCommonEntity SelectedLISCompare
        {
            get { return this._SelectedLISCompare; }
            set { SetProperty(ref this._SelectedLISCompare, value); }
        }

        private ObservableCollection<CompareCommonEntity> _LISCompareList;
        public ObservableCollection<CompareCommonEntity> LISCompareList
        {
            get { return _LISCompareList; }
            set { SetProperty(ref _LISCompareList, value); }
        }

        private CompareInitEntity _SelectedCDInitCompare;
        public CompareInitEntity SelectedCDInitCompare
        {
            get { return this._SelectedCDInitCompare; }
            set { SetProperty(ref this._SelectedCDInitCompare, value); }
        }

        private ObservableCollection<CompareInitEntity> _CDInitCompareList;
        public ObservableCollection<CompareInitEntity> CDInitCompareList
        {
            get { return _CDInitCompareList; }
            set { SetProperty(ref _CDInitCompareList, value); }
        }

        private CompareInitEntity _SelectedPCInitCompare;
        public CompareInitEntity SelectedPCInitCompare
        {
            get { return this._SelectedPCInitCompare; }
            set { SetProperty(ref this._SelectedPCInitCompare, value); }
        }

        private ObservableCollection<CompareInitEntity> _PCInitCompareList;
        public ObservableCollection<CompareInitEntity> PCInitCompareList
        {
            get { return _PCInitCompareList; }
            set { SetProperty(ref _PCInitCompareList, value); }
        }

        private CompareInitEntity _SelectedCPEInitCompare;
        public CompareInitEntity SelectedCPEInitCompare
        {
            get { return this._SelectedCPEInitCompare; }
            set { SetProperty(ref this._SelectedCPEInitCompare, value); }
        }

        private ObservableCollection<CompareInitEntity> _CPEInitCompareList;
        public ObservableCollection<CompareInitEntity> CPEInitCompareList
        {
            get { return _CPEInitCompareList; }
            set { SetProperty(ref _CPEInitCompareList, value); }
        }

        private CompareDetailEntity _SelectedDetailCompare;
        public CompareDetailEntity SelectedDetailCompare
        {
            get { return this._SelectedDetailCompare; }
            set { SetProperty(ref this._SelectedDetailCompare, value); }
        }

        private ObservableCollection<CompareDetailEntity> _CdDetailCompareList;
        public ObservableCollection<CompareDetailEntity> CdDetailCompareList
        {
            get { return _CdDetailCompareList; }
            set { SetProperty(ref _CdDetailCompareList, value); }
        }

        private ObservableCollection<CompareDetailEntity> _PcDetailCompareList;
        public ObservableCollection<CompareDetailEntity> PcDetailCompareList
        {
            get { return _PcDetailCompareList; }
            set { SetProperty(ref _PcDetailCompareList, value); }
        }

        private ObservableCollection<CompareDetailEntity> _CpeDetailCompareList;
        public ObservableCollection<CompareDetailEntity> CpeDetailCompareList
        {
            get { return _CpeDetailCompareList; }
            set { SetProperty(ref _CpeDetailCompareList, value); }
        }
        #endregion

        #region Event 
        private DelegateCommand _ContextTextChangedCommand;
        public DelegateCommand ContextTextChangedCommand =>
            _ContextTextChangedCommand ?? (_ContextTextChangedCommand = new DelegateCommand(OnContextTextChanged));

        private DelegateCommand _VersionContextTextChangedCommand;
        public DelegateCommand VersionContextTextChangedCommand =>
            _VersionContextTextChangedCommand ?? (_VersionContextTextChangedCommand = new DelegateCommand(OnVersionContextTextChanged));

        private DelegateCommand<Object> _TabSelectionChangedCommand;
        public DelegateCommand<Object> TabSelectionChangedCommand =>
            _TabSelectionChangedCommand ?? (_TabSelectionChangedCommand = new DelegateCommand<Object>(OnTabSelectionChanged));

        private DelegateCommand _BtnVersionNumberCommand;
        public DelegateCommand BtnVersionNumberCommand =>
            _BtnVersionNumberCommand ?? (_BtnVersionNumberCommand = new DelegateCommand(OnBtnVersionNumberClick));

        private DelegateCommand _BtnCompareCommand;
        public DelegateCommand BtnCompareCommand =>
            _BtnCompareCommand ?? (_BtnCompareCommand = new DelegateCommand(OnBtnCompareClick));

        private DelegateCommand _BtnSaveCommand;
        public DelegateCommand BtnSaveCommand =>
            _BtnSaveCommand ?? (_BtnSaveCommand = new DelegateCommand(OnBtnSaveClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));

        private DelegateCommand _BtnPassCommand;
        public DelegateCommand BtnPassCommand =>
            _BtnPassCommand ?? (_BtnPassCommand = new DelegateCommand(OnBtnPassClick));

        private DelegateCommand _BtnFailCommand;
        public DelegateCommand BtnFailCommand =>
            _BtnFailCommand ?? (_BtnFailCommand = new DelegateCommand(OnBtnFailClick));

        private DelegateCommand _CDInitLeftDoubleClickCommand;
        public DelegateCommand CDInitLeftDoubleClickCommand =>
            _CDInitLeftDoubleClickCommand ?? (_CDInitLeftDoubleClickCommand = new DelegateCommand(OnCDInitLeftDoubleClick));

        private DelegateCommand _PCInitLeftDoubleClickCommand;
        public DelegateCommand PCInitLeftDoubleClickCommand =>
            _PCInitLeftDoubleClickCommand ?? (_PCInitLeftDoubleClickCommand = new DelegateCommand(OnPCInitLeftDoubleClick));

        private DelegateCommand _CPEInitLeftDoubleClickCommand;
        public DelegateCommand CPEInitLeftDoubleClickCommand =>
            _CPEInitLeftDoubleClickCommand ?? (_CPEInitLeftDoubleClickCommand = new DelegateCommand(OnCPEInitLeftDoubleClick));

        #endregion

        #region Event Fun
        void OnContextTextChanged()
        {
            try
            {
                ClearVersionNumber();
                ClearParameter();
                ClearLblContext();

                OnBtnVersionNumberClick();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        void OnVersionContextTextChanged()
        {
            try
            {
                ClearParameter();
                ClearLblContext();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        void OnTabSelectionChanged(object obj)
        {
            try
            {

            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        void OnBtnVersionNumberClick()
        {
            try
            {
                ClearParameter();
                ClearLblContext();

                if (string.IsNullOrEmpty(Product) || string.IsNullOrEmpty(Layer) || string.IsNullOrEmpty(ToolGroup))
                {
                    string strMsg = "Product/Layer/ToolGroup cannot be empty!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
               
                CfgGetVersionListResult VersionList = new CfgGetVersionListResult();
                VersionList = _SettingMainService.R2R_UI_Config_GetVersionList(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, Product, Layer, ToolGroup, ConfigUI);
                if (VersionList == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_GetVersionList Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (VersionList.ReturnCode.Equals("-1"))
                {
                    VersionAList=new ObservableCollection<string>();
                    VersionBList=new ObservableCollection<string>();
                    return;
                }
                else if (VersionList.ReturnCode.Equals("1"))
                {
                    VersionAList=new ObservableCollection<string>();
                    VersionBList=new ObservableCollection<string>();
                    return;
                }
                else
                {
                    VersionAList=new ObservableCollection<string>();
                    VersionBList=new ObservableCollection<string>();
                    int VersionNumber = int.Parse(VersionList.Latest_Version);
                    for (int i = 1; i <= VersionNumber; i++)
                    {
                        VersionAList.Add(i.ToString());
                        VersionBList.Add(i.ToString());
                    }
                    if (VersionNumber < 1)
                    {

                    }
                    else
                    {
                        VersionA = "1";
                        VersionB = VersionNumber > 1 ? "2" : "1";

                    }

                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        void OnBtnCompareClick()
        {
            try
            {
                if (IsUpdateValidationFlag)
                {
                    IsBtnPassEnable = true;
                    IsBtnFailEnable = true;
                }

                ClearParameter();
                ClearLblContext();

                //VersionA = "1";
                //VersionB = "2";
                if (string.IsNullOrEmpty(VersionA) || string.IsNullOrEmpty(VersionB))
                {
                    string strMsg = "Please select VersionA and versionB!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);

                    return;
                }

                if (VersionA.Equals(VersionB))
                {
                    string strMsg = "VersionA and VersionB cannot be the same!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                if (!IsUpdateValidationFlag)
                {
                    if (int.Parse(VersionA) > int.Parse(VersionB))
                    {
                        string strMsg = "VersionB must be greater than VersionA !";

                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }
                }


                CfgGetHistoryConfigResult entityHistory = _SettingMainService.R2R_UI_Config_GetHistoryConfig(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, Product, Layer, ToolGroup, VersionA, VersionB);
                if (entityHistory == null)
                {
                    IsBtnPassEnable = false;
                    IsBtnFailEnable = false;

                    string strMsg = "Invoke R2R_UI_Config_GetHistoryConfig Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (entityHistory.ReturnCode.Equals("-1"))
                {

                    IsBtnPassEnable = false;
                    IsBtnFailEnable = false;

                    return;
                }
                else
                {
                    CommonCompareList = new ObservableCollection<CompareCommonEntity>(GetCommonCompareVersionList(entityHistory.Version_A_Common_History, entityHistory.Version_B_Common_History,true));
                    LISCompareList = new ObservableCollection<CompareCommonEntity>(GetCommonCompareVersionList(entityHistory.Version_A_LIS_History, entityHistory.Version_B_LIS_History, false));
                    CDInitCompareList = new ObservableCollection<CompareInitEntity>(GetInitCompareVersionList(entityHistory.Version_A_CD_Init_History, entityHistory.Version_B_CD_Init_History, InitType.CD));
                    PCInitCompareList = new ObservableCollection<CompareInitEntity>(GetInitCompareVersionList(entityHistory.Version_A_OVL_PC_Init_History, entityHistory.Version_B_OVL_PC_Init_History, InitType.PC));
                    CPEInitCompareList = new ObservableCollection<CompareInitEntity>(GetInitCompareVersionList(entityHistory.Version_A_OVL_CPE_Init_History, entityHistory.Version_B_OVL_CPE_Init_History, InitType.CPE));
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        void OnCDInitLeftDoubleClick()
        {
            try
            {
                CdDetailCompareList = new ObservableCollection<CompareDetailEntity>(GetDetailCompareList(SelectedCDInitCompare,true));
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        void OnPCInitLeftDoubleClick()
        {
            try
            {
                GetPCDetailCompareList(SelectedPCInitCompare);
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        void OnCPEInitLeftDoubleClick()
        {
            try
            {
                CpeDetailCompareList = new ObservableCollection<CompareDetailEntity>(GetDetailCompareList(SelectedCPEInitCompare,false));
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        void OnBtnSaveClick()
        {
            try
            {
                FlagSave = true;
                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        void OnBtnCancelClick()
        {
            try
            {
                FlagSave = false;
                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        void OnBtnPassClick()
        {
            try
            {
                UpdateValidation(true);

                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        void OnBtnFailClick()
        {
            try
            {
                var window = new MetroWindow();//Windows窗体      
                ValidationReason view = new ValidationReason();
                ValidationReasonViewModel viewModel = (ValidationReasonViewModel)view.DataContext;

                viewModel.CurrentWindow = window;
                window.Content = view;
                window.Title = "Validation Reason";
                window.Height = 320;
                window.Width = 480;
                //window.ResizeMode = ResizeMode.NoResize;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();

                if (viewModel.IsCheckSuccess)
                {
                    CatchReason = viewModel.Reason;
                }
                else
                {
                    return;
                }

                UpdateValidation(false);

                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Fun 
        bool UpdateValidation(bool IsPass)
        {
            bool flag = false;
            try
            {
                if (IsPass)
                {
                    catchFlag = "PASS";
                    CatchReason = "";
                }
                else
                {
                    catchFlag = "FAIL";
                }
                CfgUpdateResult ValidationResult = new CfgUpdateResult();
                ValidationResult = _SettingMainService.R2R_UI_Config_UpdateValidation(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, Product, Layer, ToolGroup, ConfigUI, catchFlag, CatchReason);
                if (ValidationResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_UpdateValidation Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return flag;
                }
                if (ValidationResult.ReturnCode.Equals("0"))
                {

                }
                else if (ValidationResult.ReturnCode.Equals("1"))
                {
                    MyLogger.Trace("Message :: " + ValidationResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(ValidationResult.ReturnText);
                }
                else
                {
                    MyLogger.Trace("Message :: " + ValidationResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(ValidationResult.ReturnText);
                    return flag;
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return flag;
        }

        List<CompareCommonEntity> GetCommonCompareVersionList(string strVersionA,string strVersionB,bool IsCommon)
        {
            List<CompareCommonEntity> CompareVersionList = new List<CompareCommonEntity>();
            
            try
            {
                int parameterNameIndex = -1;
                List<string> cfgCommonColumnNameList = new List<string>();
                List<string> cfgCommonColumnKeyList = new List<string>();
                CfgSingleTableInfoEntity entityCommonVersionA = new CfgSingleTableInfoEntity();
                CfgSingleTableInfoEntity entityCommonVersionB = new CfgSingleTableInfoEntity();
                if (string.IsNullOrEmpty(strVersionA))
                {
                    entityCommonVersionB = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strVersionB);
                    cfgCommonColumnNameList = CfgSingleTableInfoHelp.GetColumnName(entityCommonVersionB.ColumnFormat);
                    parameterNameIndex = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entityCommonVersionB.ColumnFormat, "OPT_ACTION:");
                    if (parameterNameIndex == -1)
                    {
                        string strMsg = "Please check ColumnFormat!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }
                    if (!string.IsNullOrEmpty(entityCommonVersionB.ColumnData[parameterNameIndex]))
                    {
                        if (IsCommon)
                        {
                            CommonVersionB_Opt = "Version B (" + entityCommonVersionB.ColumnData[parameterNameIndex] + ")";
                        }
                        else
                        {
                            LISVersionB_Opt = "Version B (" + entityCommonVersionB.ColumnData[parameterNameIndex] + ")";
                        }
                    }
      
                    DataTable dbR2R_PH_CONFIG_COMMON_VersionB = CfgSingleTableInfoHelp.CreateDataTable(entityCommonVersionB);
                    if (dbR2R_PH_CONFIG_COMMON_VersionB.Rows.Count > 0)
                    {
                        string strTimeStamp = "";
                        foreach (var strColumn in cfgCommonColumnNameList)
                        {
                            if (strColumn.Equals("TIMESTAMP"))
                            {
                                strTimeStamp = dbR2R_PH_CONFIG_COMMON_VersionB.Rows[0][strColumn].ToString();
                                if (!string.IsNullOrEmpty(strTimeStamp))
                                {
                                    strTimeStamp = strTimeStamp.Replace(';', ':');
                                }
                            }

                            CompareCommonEntity commonEntity = new CompareCommonEntity();
                            commonEntity.Context = strColumn;
                            if (strColumn.Equals("TIMESTAMP"))
                            {
                                commonEntity.VersionB = strTimeStamp;
                            }
                            else
                            {
                                commonEntity.VersionB = dbR2R_PH_CONFIG_COMMON_VersionB.Rows[0][strColumn].ToString();
                            }

                            commonEntity.VersionA = "";
                            commonEntity.Result = "Add";
                            CompareVersionList.Add(commonEntity);
                        }
                    }
                }
                else if (string.IsNullOrEmpty(strVersionB))
                {
                    entityCommonVersionA = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strVersionA);
                    cfgCommonColumnNameList = CfgSingleTableInfoHelp.GetColumnName(entityCommonVersionA.ColumnFormat);
                    parameterNameIndex = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entityCommonVersionA.ColumnFormat, "OPT_ACTION:");
                    if (parameterNameIndex == -1)
                    {
                        string strMsg = "Please check ColumnFormat!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }
                    if (!string.IsNullOrEmpty(entityCommonVersionA.ColumnData[parameterNameIndex]))
                    {
                        if (IsCommon)
                        {
                            CommonVersionB_Opt = "Version B (" + entityCommonVersionA.ColumnData[parameterNameIndex] + ")";
                        }
                        else
                        {
                            LISVersionB_Opt = "Version B (" + entityCommonVersionA.ColumnData[parameterNameIndex] + ")";
                        }
                    }

                    DataTable dbR2R_PH_CONFIG_COMMON_VersionA = CfgSingleTableInfoHelp.CreateDataTable(entityCommonVersionA);
                    if (dbR2R_PH_CONFIG_COMMON_VersionA.Rows.Count > 0)
                    {
                        string strTimeStamp = "";
                        foreach (var strColumn in cfgCommonColumnNameList)
                        {
                            if (strColumn.Equals("TIMESTAMP"))
                            {
                                strTimeStamp = dbR2R_PH_CONFIG_COMMON_VersionA.Rows[0][strColumn].ToString();
                                if (!string.IsNullOrEmpty(strTimeStamp))
                                {
                                    strTimeStamp = strTimeStamp.Replace(';', ':');
                                }
                            }

                            CompareCommonEntity commonEntity = new CompareCommonEntity();
                            commonEntity.Context = strColumn;
                            if (strColumn.Equals("TIMESTAMP"))
                            {
                                commonEntity.VersionA = strTimeStamp;
                            }
                            else
                            {
                                commonEntity.VersionA = dbR2R_PH_CONFIG_COMMON_VersionA.Rows[0][strColumn].ToString();
                            }

                            commonEntity.VersionB = "";
                            commonEntity.Result = "Delete";
                            CompareVersionList.Add(commonEntity);
                        }
                    }
                }
                else
                {
                    entityCommonVersionA = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strVersionA);

                    parameterNameIndex = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entityCommonVersionA.ColumnFormat, "OPT_ACTION:");
                    if (parameterNameIndex == -1)
                    {
                        string strMsg = "Please check ColumnFormat!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }
                    if (!string.IsNullOrEmpty(entityCommonVersionA.ColumnData[parameterNameIndex]))
                    {
                        if (IsCommon)
                        {
                            CommonVersionA_Opt = "Version A (" + entityCommonVersionA.ColumnData[parameterNameIndex] + ")";
                        }
                        else
                        {
                            LISVersionA_Opt = "Version A (" + entityCommonVersionA.ColumnData[parameterNameIndex] + ")";
                        }
                    }
                    DataTable dbR2R_PH_CONFIG_COMMON_VersionA = CfgSingleTableInfoHelp.CreateDataTable(entityCommonVersionA);


                    entityCommonVersionB = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strVersionB);
                    parameterNameIndex = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entityCommonVersionB.ColumnFormat, "OPT_ACTION:");
                    if (parameterNameIndex == -1)
                    {
                        string strMsg = "Please check ColumnFormat!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }
                    if (!string.IsNullOrEmpty(entityCommonVersionB.ColumnData[parameterNameIndex]))
                    {
                        if (IsCommon)
                        {
                            CommonVersionB_Opt = "Version B (" + entityCommonVersionB.ColumnData[parameterNameIndex] + ")";
                        }
                        else
                        {
                            LISVersionB_Opt = "Version B (" + entityCommonVersionB.ColumnData[parameterNameIndex] + ")";
                        }
                    }
                    DataTable dbR2R_PH_CONFIG_COMMON_VersionB = CfgSingleTableInfoHelp.CreateDataTable(entityCommonVersionB);

                    cfgCommonColumnNameList = CfgSingleTableInfoHelp.GetColumnName(entityCommonVersionA.ColumnFormat);
                    cfgCommonColumnKeyList = CfgSingleTableInfoHelp.GetColumnKeyName(entityCommonVersionA.ColumnFormat);
                    cfgCommonColumnKeyList = new List<string>() { "PRODUCT", "LAYER", "TOOL_GROUP" };

                    dbR2R_PH_CONFIG_COMMON_VersionA = DataTableHelp.RemoveBlankRow(dbR2R_PH_CONFIG_COMMON_VersionA, cfgCommonColumnKeyList);
                    dbR2R_PH_CONFIG_COMMON_VersionB = DataTableHelp.RemoveBlankRow(dbR2R_PH_CONFIG_COMMON_VersionB, cfgCommonColumnKeyList);

                    CompareVersionList = new List<CompareCommonEntity>();

                    bool IsCommonVersionANull = false;
                    bool IsCommonVersionBNull = false;

                    if (dbR2R_PH_CONFIG_COMMON_VersionA.Rows.Count < 1)
                    {
                        IsCommonVersionANull = true;
                    }
                    if (dbR2R_PH_CONFIG_COMMON_VersionB.Rows.Count < 1)
                    {
                        IsCommonVersionBNull = true;
                    }
                    if (IsCommonVersionANull && IsCommonVersionBNull)
                    {
                        foreach (var strColumn in cfgCommonColumnNameList)
                        {
                            CompareCommonEntity commonEntity = new CompareCommonEntity();
                            commonEntity.Context = strColumn;
                            commonEntity.VersionA = "";
                            commonEntity.VersionB = "";
                            commonEntity.Result = "Miss";
                            CompareVersionList.Add(commonEntity);
                        }
                    }

                    #region old
                    //else if (IsCommonVersionANull)
                    //{
                    //    foreach (var strColumn in cfgCommonColumnNameList)
                    //    {
                    //        CompareCommonEntity commonEntity = new CompareCommonEntity();
                    //        commonEntity.Context = strColumn;
                    //        commonEntity.VersionA = "";
                    //        if (strColumn.Equals("TIMESTAMP"))
                    //        {
                    //            string strTimeStamp = "";
                    //            strTimeStamp = dbR2R_PH_CONFIG_COMMON_VersionB.Rows[0][strColumn].ToString();
                    //            if (!string.IsNullOrEmpty(strTimeStamp))
                    //            {
                    //                strTimeStamp = strTimeStamp.Replace(';', ':');
                    //                commonEntity.VersionB = strTimeStamp;
                    //            }
                    //        }
                    //        else
                    //        {
                    //            commonEntity.VersionB = dbR2R_PH_CONFIG_COMMON_VersionB.Rows[0][strColumn].ToString();
                    //        }
                    //        commonEntity.Result = "VersionAMiss";

                    //        CompareVersionList.Add(commonEntity);
                    //    }

                    //}
                    //else if (IsCommonVersionBNull)
                    //{
                    //    foreach (var strColumn in cfgCommonColumnNameList)
                    //    {
                    //        CompareCommonEntity commonEntity = new CompareCommonEntity();
                    //        commonEntity.Context = strColumn;
                    //        string strTimeStamp = "";
                    //        if (strColumn.Equals("TIMESTAMP"))
                    //        {
                    //            strTimeStamp = dbR2R_PH_CONFIG_COMMON_VersionA.Rows[0][strColumn].ToString();
                    //            if (!string.IsNullOrEmpty(strTimeStamp))
                    //            {
                    //                strTimeStamp = strTimeStamp.Replace(';', ':');
                    //                commonEntity.VersionA = strTimeStamp;
                    //            }
                    //        }
                    //        else
                    //        {
                    //            commonEntity.VersionA = dbR2R_PH_CONFIG_COMMON_VersionA.Rows[0][strColumn].ToString();
                    //        }

                    //        commonEntity.VersionB = "";
                    //        commonEntity.Result = "VersionBMiss";
                    //        CompareVersionList.Add(commonEntity);
                    //    }
                    //}
                    #endregion

                    else
                    {
                        DataTable dbCfgCommonChanged = DataTableHelp.CompareDataTable(dbR2R_PH_CONFIG_COMMON_VersionA, dbR2R_PH_CONFIG_COMMON_VersionB, cfgCommonColumnKeyList);
                        DataTable dbR2R_PH_CONFIG_COMMON_Old = DataTableHelp.GetChangedRecord(dbCfgCommonChanged, "Status", "Old");
                        DataTable dbR2R_PH_CONFIG_COMMON_Modify = DataTableHelp.GetChangedRecord(dbCfgCommonChanged, "Status", "Edit");
                        DataTable dbR2R_PH_CONFIG_COMMON_Add = DataTableHelp.GetChangedRecord(dbCfgCommonChanged, "Status", "Add");
                        DataTable dbR2R_PH_CONFIG_COMMON_Delete = DataTableHelp.GetChangedRecord(dbCfgCommonChanged, "Status", "Delete");


                        if (dbR2R_PH_CONFIG_COMMON_Add.Rows.Count > 0)
                        {
                            string strTimeStamp = "";
                            foreach (var strColumn in cfgCommonColumnNameList)
                            {
                                if (strColumn.Equals("TIMESTAMP"))
                                {
                                    strTimeStamp = dbR2R_PH_CONFIG_COMMON_Add.Rows[0][strColumn].ToString();
                                    if (!string.IsNullOrEmpty(strTimeStamp))
                                    {
                                        strTimeStamp = strTimeStamp.Replace(';', ':');
                                    }
                                }

                                CompareCommonEntity commonEntity = new CompareCommonEntity();
                                commonEntity.Context = strColumn;
                                commonEntity.VersionA = "";
                                if (strColumn.Equals("TIMESTAMP"))
                                {
                                    commonEntity.VersionB = strTimeStamp;
                                }
                                else
                                {
                                    commonEntity.VersionB = dbR2R_PH_CONFIG_COMMON_Add.Rows[0][strColumn].ToString();
                                }

                                commonEntity.Result = "Add";
                                CompareVersionList.Add(commonEntity);
                            }
                        }

                        if (dbR2R_PH_CONFIG_COMMON_Modify.Rows.Count > 0)
                        {
                            string strTimeStampA = "";
                            string strTimeStampB = "";
                            foreach (var strColumn in cfgCommonColumnNameList)
                            {
                                if (strColumn.Equals("TIMESTAMP"))
                                {
                                    strTimeStampA = dbR2R_PH_CONFIG_COMMON_Old.Rows[0][strColumn].ToString();
                                    if (!string.IsNullOrEmpty(strTimeStampA))
                                    {
                                        strTimeStampA = strTimeStampA.Replace(';', ':');
                                    }
                                    strTimeStampB = dbR2R_PH_CONFIG_COMMON_Modify.Rows[0][strColumn].ToString();
                                    if (!string.IsNullOrEmpty(strTimeStampB))
                                    {
                                        strTimeStampB = strTimeStampB.Replace(';', ':');
                                    }
                                }

                                CompareCommonEntity commonEntity = new CompareCommonEntity();
                                commonEntity.Context = strColumn;
                                if (strColumn.Equals("TIMESTAMP"))
                                {
                                    commonEntity.VersionA = strTimeStampA;
                                    commonEntity.VersionB = strTimeStampB;
                                }
                                else
                                {
                                    commonEntity.VersionA = dbR2R_PH_CONFIG_COMMON_Old.Rows[0][strColumn].ToString();
                                    commonEntity.VersionB = dbR2R_PH_CONFIG_COMMON_Modify.Rows[0][strColumn].ToString();
                                }

                                if (commonEntity.VersionA.Equals(commonEntity.VersionB))
                                {
                                    commonEntity.Result = "Same";
                                }
                                else
                                {
                                    commonEntity.Result = "Modify";
                                }

                                CompareVersionList.Add(commonEntity);
                            }
                        }

                        if (dbR2R_PH_CONFIG_COMMON_Delete.Rows.Count > 0)
                        {
                            string strTimeStamp = "";
                            foreach (var strColumn in cfgCommonColumnNameList)
                            {
                                if (strColumn.Equals("TIMESTAMP"))
                                {
                                    strTimeStamp = dbR2R_PH_CONFIG_COMMON_Delete.Rows[0][strColumn].ToString();
                                    if (!string.IsNullOrEmpty(strTimeStamp))
                                    {
                                        strTimeStamp = strTimeStamp.Replace(';', ':');
                                    }
                                }

                                CompareCommonEntity commonEntity = new CompareCommonEntity();
                                commonEntity.Context = strColumn;
                                if (strColumn.Equals("TIMESTAMP"))
                                {
                                    commonEntity.VersionA = strTimeStamp;
                                }
                                else
                                {
                                    commonEntity.VersionA = dbR2R_PH_CONFIG_COMMON_Delete.Rows[0][strColumn].ToString();
                                }

                                commonEntity.VersionB = "";
                                commonEntity.Result = "Delete";
                                CompareVersionList.Add(commonEntity);
                            }
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }

            return CompareVersionList;
        }

        List<CompareInitEntity> GetInitCompareVersionList(string strVersionA, string strVersionB, InitType initType)
        {
            List<CompareInitEntity> CompareVersionList = new List<CompareInitEntity>();
            try
            {
                if (string.IsNullOrEmpty(strVersionA))
                {
                    string strVersion = strVersionB;
                    CfgSingleTableInfoEntity entityInitVersion = new CfgSingleTableInfoEntity();
                    entityInitVersion = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strVersion);
                    DataTable dbR2R_PH_CONFIG_Init = CfgSingleTableInfoHelp.CreateDataTable(entityInitVersion);
                    if (dbR2R_PH_CONFIG_Init.Rows.Count > 0)
                    {
                        for (int i = 0; i < dbR2R_PH_CONFIG_Init.Rows.Count; i++)
                        {
                            CompareInitEntity InitEntity = new CompareInitEntity();
                            if (initType.Equals(InitType.CD))
                            {
                                InitEntity.Context = dbR2R_PH_CONFIG_Init.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["FUNCTION"].ToString();
                            }
                            else
                            {
                                InitEntity.Context = dbR2R_PH_CONFIG_Init.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["PRE_TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["PRE_RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["FUNCTION"].ToString();
                            }
                            InitEntity.ParameterName = "";
                            InitEntity.VersionA_Add = "";
                            InitEntity.VersionA_Modify = "";
                            InitEntity.VersionA_Delete = ""; 
                            InitEntity.VersionA_NoChange = "";

                            InitEntity.VersionB_Add = dbR2R_PH_CONFIG_Init.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                            InitEntity.VersionB_Modify = "";
                            InitEntity.VersionB_Delete = "";
                            InitEntity.VersionB_NoChange = "";

                            InitEntity.Result = "Add";
                            CompareVersionList.Add(InitEntity);
                        }
                    }
                }
                else if(string.IsNullOrEmpty(strVersionB))
                {
                    string strVersion = strVersionA;
                    CfgSingleTableInfoEntity entityInitVersion = new CfgSingleTableInfoEntity();
                    entityInitVersion = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strVersion);
                    DataTable dbR2R_PH_CONFIG_Init = CfgSingleTableInfoHelp.CreateDataTable(entityInitVersion);
                    if (dbR2R_PH_CONFIG_Init.Rows.Count > 0)
                    {
                        for (int i = 0; i < dbR2R_PH_CONFIG_Init.Rows.Count; i++)
                        {
                            CompareInitEntity InitEntity = new CompareInitEntity();
                            if (initType.Equals(InitType.CD))
                            {
                                InitEntity.Context = dbR2R_PH_CONFIG_Init.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["FUNCTION"].ToString();
                            }
                            else
                            {
                                InitEntity.Context = dbR2R_PH_CONFIG_Init.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["PRE_TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["PRE_RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_Init.Rows[i]["FUNCTION"].ToString();
                            }
                            InitEntity.ParameterName = dbR2R_PH_CONFIG_Init.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                            InitEntity.VersionA_Add = "";
                            InitEntity.VersionA_Modify = "";
                            InitEntity.VersionA_Delete = dbR2R_PH_CONFIG_Init.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                            InitEntity.VersionA_NoChange = "";

                            InitEntity.VersionB_Add = "";
                            InitEntity.VersionB_Modify = "";
                            InitEntity.VersionB_Delete = "";
                            InitEntity.VersionB_NoChange = "";

                            InitEntity.Result = "Delete";
                            CompareVersionList.Add(InitEntity);
                        }
                    }
                }
                else
                {
                    int parameterNameIndex = -1;
                    List<string> cfgInitColumnNameList = new List<string>();
                    List<string> cfgInitColumnKeyList = new List<string>();
                    CfgSingleTableInfoEntity entityInitVersionA = new CfgSingleTableInfoEntity();
                    CfgSingleTableInfoEntity entityInitVersionB = new CfgSingleTableInfoEntity();
                    entityInitVersionA = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strVersionA);
                    entityInitVersionB = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strVersionB);

                    parameterNameIndex = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entityInitVersionA.ColumnFormat, "INIT_PARAMETER_NAME:");
                    if(parameterNameIndex ==-1)
                    {
                        string strMsg = "Please check ColumnFormat!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }

                    string UpdateParameterNameItem = CfgSingleTableInfoHelp.GetParameterNameItem(entityInitVersionB.ColumnData[parameterNameIndex]);
                    string strVersionASort = CfgSingleTableInfoHelp.SortInitOriginalContent(strVersionA, UpdateParameterNameItem, parameterNameIndex);
                    entityInitVersionA = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strVersionASort);
                    //if (initType.Equals(InitType.CPE))
                    //{
                    //    entityInitVersionA = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(strVersionA);
                    //}

                    DataTable dbR2R_PH_CONFIG_Init_VersionA = CfgSingleTableInfoHelp.CreateDataTable(entityInitVersionA);                  
                    DataTable dbR2R_PH_CONFIG_Init_VersionB = CfgSingleTableInfoHelp.CreateDataTable(entityInitVersionB); 
                    
                    cfgInitColumnNameList = CfgSingleTableInfoHelp.GetColumnName(entityInitVersionA.ColumnFormat);
                    cfgInitColumnKeyList = CfgSingleTableInfoHelp.GetColumnKeyName(entityInitVersionA.ColumnFormat);
                    if (initType.Equals(InitType.CD))
                    {
                        cfgInitColumnKeyList = new List<string>() { "PRODUCT", "LAYER", "TOOL_GROUP", "TOOL", "RETICLE" };
                    }
                    else
                    {
                        cfgInitColumnKeyList = new List<string>() { "PRODUCT", "LAYER", "TOOL_GROUP", "TOOL", "RETICLE", "PRE_TOOL", "PRE_RETICLE" };
                    }

                    dbR2R_PH_CONFIG_Init_VersionA = DataTableHelp.RemoveBlankRow(dbR2R_PH_CONFIG_Init_VersionA, cfgInitColumnKeyList);
                    dbR2R_PH_CONFIG_Init_VersionB = DataTableHelp.RemoveBlankRow(dbR2R_PH_CONFIG_Init_VersionB, cfgInitColumnKeyList);

                    bool IsInitVersionANull = false;
                    bool IsInitVersionBNull = false;

                    if (dbR2R_PH_CONFIG_Init_VersionA.Rows.Count < 1)
                    {
                        IsInitVersionANull = true;
                    }
                    if (dbR2R_PH_CONFIG_Init_VersionB.Rows.Count < 1)
                    {
                        IsInitVersionBNull = true;
                    }
                    if (IsInitVersionANull && IsInitVersionBNull)
                    {
                        CompareVersionList = new List<CompareInitEntity>();

                    }
                    else
                    {
                        CompareVersionList = new List<CompareInitEntity>();
                        DataTable dbCfgInitCdChanged = DataTableHelp.CompareDataTable(dbR2R_PH_CONFIG_Init_VersionA, dbR2R_PH_CONFIG_Init_VersionB, cfgInitColumnKeyList);
                        DataTable dbR2R_PH_CONFIG_INIT_Old = DataTableHelp.GetChangedRecord(dbCfgInitCdChanged, "Status", "Old");
                        DataTable dbR2R_PH_CONFIG_INIT_Modify = DataTableHelp.GetChangedRecord(dbCfgInitCdChanged, "Status", "Edit");
                        DataTable dbR2R_PH_CONFIG_INIT_Add = DataTableHelp.GetChangedRecord(dbCfgInitCdChanged, "Status", "Add");
                        DataTable dbR2R_PH_CONFIG_INIT_Delete = DataTableHelp.GetChangedRecord(dbCfgInitCdChanged, "Status", "Delete");

                        if (dbR2R_PH_CONFIG_INIT_Add.Rows.Count > 0)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_Add.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                if (initType.Equals(InitType.CD))
                                {
                                    InitEntity.Context = dbR2R_PH_CONFIG_INIT_Add.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Add.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Add.Rows[i]["FUNCTION"].ToString();
                                }
                                else
                                {
                                    InitEntity.Context = dbR2R_PH_CONFIG_INIT_Add.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Add.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Add.Rows[i]["PRE_TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Add.Rows[i]["PRE_RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Add.Rows[i]["FUNCTION"].ToString();
                                }
                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_Add.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = "";
                                InitEntity.VersionA_Delete = "";
                                InitEntity.VersionA_NoChange = "";

                                InitEntity.VersionB_Add = dbR2R_PH_CONFIG_INIT_Add.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionB_Modify = "";
                                InitEntity.VersionB_Delete = "";
                                InitEntity.VersionB_NoChange = "";

                                InitEntity.Result = "Add";
                                CompareVersionList.Add(InitEntity);
                            }
                        }
                        if (dbR2R_PH_CONFIG_INIT_Modify.Rows.Count > 0)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_Modify.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                if (initType.Equals(InitType.CD))
                                {
                                    InitEntity.Context = dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["FUNCTION"].ToString();
                                }
                                else
                                {
                                    InitEntity.Context = dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["PRE_TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["PRE_RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["FUNCTION"].ToString();
                                }
                                string strVersionAValue = "";
                                string strVersionBValue = "";

                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = dbR2R_PH_CONFIG_INIT_Old.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionA_Delete = "";
                                InitEntity.VersionA_NoChange = "";



                                strVersionAValue = dbR2R_PH_CONFIG_INIT_Old.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                strVersionBValue = dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["INIT_PARAMETER_VALUE"].ToString();

                                if (strVersionAValue.Equals(strVersionBValue))
                                {
                                    InitEntity.Result = "Same";

                                    InitEntity.VersionB_Add = "";
                                    InitEntity.VersionB_Modify = "";
                                    InitEntity.VersionB_Delete = "";
                                    InitEntity.VersionB_NoChange = dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                }
                                else 
                                {
                                    InitEntity.VersionB_Add = "";
                                    InitEntity.VersionB_Modify = dbR2R_PH_CONFIG_INIT_Modify.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                    InitEntity.VersionB_Delete = "";
                                    InitEntity.VersionB_NoChange = "";

                                    InitEntity.Result = "Modify";
                                }

                                CompareVersionList.Add(InitEntity);
                            }
                        }

                        if (dbR2R_PH_CONFIG_INIT_Delete.Rows.Count > 0)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_Delete.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                if (initType.Equals(InitType.CD))
                                {
                                    InitEntity.Context = dbR2R_PH_CONFIG_INIT_Delete.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Delete.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Delete.Rows[i]["FUNCTION"].ToString();
                                }
                                else
                                {
                                    InitEntity.Context = dbR2R_PH_CONFIG_INIT_Delete.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Delete.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Delete.Rows[i]["PRE_TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Delete.Rows[i]["PRE_RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_Delete.Rows[i]["FUNCTION"].ToString();
                                }
                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_Delete.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = "";
                                InitEntity.VersionA_Delete = dbR2R_PH_CONFIG_INIT_Delete.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionA_NoChange = "";

                                InitEntity.VersionB_Add = "";
                                InitEntity.VersionB_Modify = "";
                                InitEntity.VersionB_Delete = "";
                                InitEntity.VersionB_NoChange = "";

                                InitEntity.Result = "Delete";
                                CompareVersionList.Add(InitEntity);
                            }
                        }
                    }

                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }

            return CompareVersionList;
        }

        List<string> GetVersionList(int parameterNumber,string strVersion)
        {
            List<string> versionList = new List<string>();
            try
            {
                if (string.IsNullOrEmpty(strVersion))
                {
                    for (int n = 0; n < parameterNumber; n++)
                    {
                        versionList.Add("");
                    }
                }
                else
                {
                    versionList = new List<string>(strVersion.Split(','));
                    int n = parameterNumber - versionList.Count;
                    if (n > 0)
                    {
                        for (int i = 0; i < n; i++)
                        {
                            versionList.Add("");
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return versionList;
        }

        List<string> GetVersionList_PC(int parameterNumber, string strVersion, bool IsDoubleChuckFlag)
        {
            List<string> versionList = new List<string>();
            try
            {
                if (string.IsNullOrEmpty(strVersion))
                {
                    if (IsDoubleChuckFlag)
                    {
                        for (int n = 0; n < parameterNumber * 2; n++)
                        {
                            versionList.Add("");
                        }
                    }
                    else
                    {
                        for (int n = 0; n < parameterNumber; n++)
                        {
                            versionList.Add("");
                        }
                    }
                }
                else
                {
                    if (IsDoubleChuckFlag)
                    {
                        if (strVersion.Contains(";"))
                        {
                            List<string> versionList1 = new List<string>();
                            List<string> versionList2 = new List<string>();

                            string[] strArray = strVersion.Split(';');
                            string strVersion1 = strArray[0];
                            string strVersion2 = strArray[1];
                            versionList1 = new List<string>(strVersion1.Split(','));
                            versionList2 = new List<string>(strVersion2.Split(','));

                            int number = parameterNumber - versionList1.Count;
                            if (number > 0)
                            {
                                for (int i = 0; i < number; i++)
                                {
                                    versionList1.Add("");
                                }
                            }

                            number = parameterNumber - versionList2.Count;
                            if (number > 0)
                            {
                                for (int i = 0; i < number; i++)
                                {
                                    versionList2.Add("");
                                }
                            }

                            foreach (var str in versionList1)
                            {
                                versionList.Add(str);
                            }
                            foreach (var str in versionList2)
                            {
                                versionList.Add(str);
                            }
                        }
                        else
                        {
                            if (string.IsNullOrEmpty(strVersion))
                            {
                                for (int n = 0; n < parameterNumber * 2; n++)
                                {
                                    versionList.Add("");
                                }
                            }
                            else
                            {
                                versionList = new List<string>(strVersion.Split(','));
                                int number = parameterNumber*2 - versionList.Count;
                                if (number > 0)
                                {
                                    for (int i = 0; i < number; i++)
                                    {
                                        versionList.Add("");
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        versionList = GetVersionList(parameterNumber, strVersion);
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return versionList;
        }

        List<CompareDetailEntity> GetDetailCompareList(CompareInitEntity entityCompare,bool IsCd)
        {
            List<CompareDetailEntity> DetailCompareList = new List<CompareDetailEntity>();
            try
            {
                if (entityCompare != null)
                {
                    LblProduct = Product;
                    LblLayer = Layer;
                    LblToolGroup = ToolGroup;
                    if (IsCd)
                    {
                        LblCdInitGroup = entityCompare.Context;
                        LblCdResult = entityCompare.Result;
                    }
                    else
                    {
                        LblCpeInitGroup = entityCompare.Context;
                        LblCpeResult = entityCompare.Result;
                    }

                    int parameterNumber = 0;
                    string strParameterName = "";
                    List<string> parameterNameList = new List<string>();
                    List<string> versionA_AddList = new List<string>();
                    List<string> versionA_ModifyList = new List<string>();
                    List<string> versionA_DeleteList = new List<string>();
                    List<string> versionA_NoChangeList = new List<string>();
                    List<string> versionB_AddList = new List<string>();
                    List<string> versionB_ModifyList = new List<string>();
                    List<string> versionB_DeleteList = new List<string>();
                    List<string> versionB_NoChangeList = new List<string>();

                    strParameterName = entityCompare.ParameterName;
                    if (string.IsNullOrEmpty(strParameterName))
                    {
                        return DetailCompareList;
                    }

                    bool IsHaveVersionA = false;
                    bool IsHaveVersionB = false;
                    if (!string.IsNullOrEmpty(entityCompare.VersionA_Add) || !string.IsNullOrEmpty(entityCompare.VersionA_Modify) || !string.IsNullOrEmpty(entityCompare.VersionA_Delete) || !string.IsNullOrEmpty(entityCompare.VersionA_NoChange))
                    {
                        IsHaveVersionA = true;
                    }
                    if (!string.IsNullOrEmpty(entityCompare.VersionB_Add) || !string.IsNullOrEmpty(entityCompare.VersionB_Modify) || !string.IsNullOrEmpty(entityCompare.VersionB_Delete) || !string.IsNullOrEmpty(entityCompare.VersionB_NoChange))
                    {
                        IsHaveVersionB = true;
                    }

                    parameterNameList = new List<string>(strParameterName.Split(','));
                    parameterNumber = parameterNameList.Count;
                    versionA_AddList = GetVersionList(parameterNumber, entityCompare.VersionA_Add);
                    versionA_ModifyList = GetVersionList(parameterNumber, entityCompare.VersionA_Modify);
                    versionA_DeleteList = GetVersionList(parameterNumber, entityCompare.VersionA_Delete);
                    versionA_NoChangeList = GetVersionList(parameterNumber, entityCompare.VersionA_NoChange);

                    versionB_AddList = GetVersionList(parameterNumber, entityCompare.VersionB_Add);
                    versionB_ModifyList = GetVersionList(parameterNumber, entityCompare.VersionB_Modify);
                    versionB_DeleteList = GetVersionList(parameterNumber, entityCompare.VersionB_Delete);
                    versionB_NoChangeList = GetVersionList(parameterNumber, entityCompare.VersionB_NoChange);

                    for (int i = 0; i < parameterNameList.Count; i++)
                    {
                        CompareDetailEntity entity = new CompareDetailEntity();
                        entity.ParameterName = parameterNameList[i];

                        if (entity.ParameterName.ToUpper().Contains("TIMESTAMP"))
                        {
                            string strVersionAValue = "";
                            string strVersionBValue = "";

                            string strTimeStamp = versionA_AddList[i];
                            if (!string.IsNullOrEmpty(strTimeStamp))
                            {
                                strTimeStamp = strTimeStamp.Replace(';', ':');
                                entity.VersionA_Add = strTimeStamp;
                            }
                            strTimeStamp = versionA_ModifyList[i];
                            if (!string.IsNullOrEmpty(strTimeStamp))
                            {
                                strTimeStamp = strTimeStamp.Replace(';', ':');
                                entity.VersionA_Modify = strTimeStamp;
                            }
                            strTimeStamp = versionA_DeleteList[i];
                            if (!string.IsNullOrEmpty(strTimeStamp))
                            {
                                strTimeStamp = strTimeStamp.Replace(';', ':');
                                entity.VersionA_Delete = strTimeStamp;
                            }

                            strTimeStamp = versionB_AddList[i];
                            if (!string.IsNullOrEmpty(strTimeStamp))
                            {
                                strTimeStamp = strTimeStamp.Replace(';', ':');
                                entity.VersionB_Add = strTimeStamp;
                            }
                            strTimeStamp = versionB_ModifyList[i];
                            if (!string.IsNullOrEmpty(strTimeStamp))
                            {
                                strTimeStamp = strTimeStamp.Replace(';', ':');
                                entity.VersionB_Modify = strTimeStamp;
                            }
                            strTimeStamp = versionB_DeleteList[i];
                            if (!string.IsNullOrEmpty(strTimeStamp))
                            {
                                strTimeStamp = strTimeStamp.Replace(';', ':');
                                entity.VersionB_Delete = strTimeStamp;
                            }

                            if (!string.IsNullOrEmpty(versionA_AddList[i]))
                            {
                                strVersionAValue = versionA_AddList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionA_ModifyList[i]))
                            {
                                strVersionAValue = versionA_ModifyList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionA_DeleteList[i]))
                            {
                                strVersionAValue = versionA_DeleteList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionA_NoChangeList[i]))
                            {
                                strVersionAValue = versionA_NoChangeList[i];
                            }

                            if (!string.IsNullOrEmpty(versionB_AddList[i]))
                            {
                                strVersionBValue = versionB_AddList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionB_ModifyList[i]))
                            {
                                strVersionBValue = versionB_ModifyList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionB_DeleteList[i]))
                            {
                                strVersionBValue = versionB_DeleteList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionB_NoChangeList[i]))
                            {
                                strVersionBValue = versionB_NoChangeList[i];
                            }

                            if (IsHaveVersionA && IsHaveVersionB)
                            {
                                if (strVersionAValue.Equals(strVersionBValue))
                                {
                                    entity.Result = "Same";
                                }
                                else
                                {
                                    entity.Result = "Modify";
                                }
                            }
                            else if (IsHaveVersionA)
                            {
                                entity.Result = "Delete";
                            }
                            else if (IsHaveVersionB)
                            {
                                entity.Result = "Add";
                            }
                        }
                        else
                        {
                            string strVersionAValue = "";
                            string strVersionBValue = "";

                            entity.VersionA_Add = versionA_AddList[i];
                            entity.VersionA_Modify = versionA_ModifyList[i];
                            entity.VersionA_Delete = versionA_DeleteList[i];
                            entity.VersionA_NoChange = versionA_NoChangeList[i];

                            entity.VersionB_Add = versionB_AddList[i];
                            entity.VersionB_Modify = versionB_ModifyList[i];
                            entity.VersionB_Delete = versionB_DeleteList[i];
                            entity.VersionB_NoChange = versionB_NoChangeList[i];

                            if (!string.IsNullOrEmpty(versionA_AddList[i]))
                            {
                                strVersionAValue = versionA_AddList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionA_ModifyList[i]))
                            {
                                strVersionAValue = versionA_ModifyList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionA_DeleteList[i]))
                            {
                                strVersionAValue = versionA_DeleteList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionA_NoChangeList[i]))
                            {
                                strVersionAValue = versionA_NoChangeList[i];
                            }

                            if (!string.IsNullOrEmpty(versionB_AddList[i]))
                            {
                                strVersionBValue = versionB_AddList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionB_ModifyList[i]))
                            {
                                strVersionBValue = versionB_ModifyList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionB_DeleteList[i]))
                            {
                                strVersionBValue = versionB_DeleteList[i];
                            }
                            else if (!string.IsNullOrEmpty(versionB_NoChangeList[i]))
                            {
                                strVersionBValue = versionB_NoChangeList[i];
                            }

                            if (IsHaveVersionA && IsHaveVersionB)
                            {
                                if (strVersionAValue.Equals(strVersionBValue))
                                {
                                    entity.Result = "Same";
                                }
                                else
                                {
                                    entity.Result = "Modify";
                                }
                            }
                            else if (IsHaveVersionA)
                            {
                                entity.Result = "Delete";
                            }
                            else if (IsHaveVersionB)
                            {
                                entity.Result = "Add";
                            }
                        }


                        DetailCompareList.Add(entity);
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return DetailCompareList;
        }

        bool IsDobuleChuck(string strVersion)
        {
            bool flag = false;
            try
            {
                if (string.IsNullOrEmpty(strVersion))
                {
                }
                else if (strVersion.Contains(";"))
                {
                    flag = true;
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return flag;
        }

        void GetPCDetailCompareList(CompareInitEntity entityCompare)
        {
            try
            {
                if (entityCompare != null)
                {
                    LblProduct = Product;
                    LblLayer = Layer;
                    LblToolGroup = ToolGroup;
                    LblPcInitGroup = entityCompare.Context;
                    LblPcResult = entityCompare.Result;

                    bool IsDoubleChuckFlag = false;
                    int parameterNumber = 0;
                    string strParameterName = "";
                    List<string> parameterNameList = new List<string>();
                    List<string> versionA_AddList = new List<string>();
                    List<string> versionA_ModifyList = new List<string>();
                    List<string> versionA_DeleteList = new List<string>();
                    List<string> versionA_NoChangeList = new List<string>();

                    List<string> versionB_AddList = new List<string>();
                    List<string> versionB_ModifyList = new List<string>();
                    List<string> versionB_DeleteList = new List<string>();
                    List<string> versionB_NoChangeList = new List<string>();

                    strParameterName = entityCompare.ParameterName;
                    if (string.IsNullOrEmpty(strParameterName))
                    {
                        return;
                    }

                    parameterNameList = new List<string>(strParameterName.Split(','));


                    bool flagAdd_A = IsDobuleChuck(entityCompare.VersionA_Add);
                    bool flagModify_A = IsDobuleChuck(entityCompare.VersionA_Modify);
                    bool flagDelete_A = IsDobuleChuck(entityCompare.VersionA_Delete);
                    bool flagNoChange_A = IsDobuleChuck(entityCompare.VersionA_NoChange);
                    bool flagAdd_B = IsDobuleChuck(entityCompare.VersionB_Add);
                    bool flagModify_B = IsDobuleChuck(entityCompare.VersionB_Modify);
                    bool flagDelete_B = IsDobuleChuck(entityCompare.VersionB_Delete);
                    bool flagNoChange_B = IsDobuleChuck(entityCompare.VersionB_NoChange);

                    if (flagAdd_A || flagModify_A || flagDelete_A || flagAdd_B || flagModify_B || flagDelete_B || flagNoChange_A|| flagNoChange_B)
                    {
                        IsDoubleChuckFlag = true;
                    }
                    if (IsDoubleChuckFlag)
                    {
                        List<string> parameterNameList1 = new List<string>();
                        List<string> parameterNameList2 = new List<string>();

                        foreach (var str in parameterNameList)
                        {
                            parameterNameList1.Add("Chuck1_" + str);
                        }
                        foreach (var str in parameterNameList)
                        {
                            parameterNameList2.Add("Chuck2_" + str);
                        }

                        parameterNameList = new List<string>();
                        foreach (var str in parameterNameList1)
                        {
                            parameterNameList.Add(str);
                        }
                        foreach (var str in parameterNameList2)
                        {
                            parameterNameList.Add(str);
                        }
                        parameterNumber = parameterNameList.Count / 2;
                    }
                    else
                    {
                        parameterNameList = new List<string>(strParameterName.Split(','));
                        parameterNumber = parameterNameList.Count;
                    }

                    bool IsHaveVersionA = false;
                    bool IsHaveVersionB = false;
                    if (!string.IsNullOrEmpty(entityCompare.VersionA_Add) || !string.IsNullOrEmpty(entityCompare.VersionA_Modify) || !string.IsNullOrEmpty(entityCompare.VersionA_Delete) || !string.IsNullOrEmpty(entityCompare.VersionA_NoChange))
                    {
                        IsHaveVersionA = true;
                    }
                    if (!string.IsNullOrEmpty(entityCompare.VersionB_Add) || !string.IsNullOrEmpty(entityCompare.VersionB_Modify) || !string.IsNullOrEmpty(entityCompare.VersionB_Delete) || !string.IsNullOrEmpty(entityCompare.VersionB_NoChange))
                    {
                        IsHaveVersionB = true;
                    }

                    versionA_AddList = GetVersionList_PC(parameterNumber, entityCompare.VersionA_Add, IsDoubleChuckFlag);
                    versionA_ModifyList = GetVersionList_PC(parameterNumber, entityCompare.VersionA_Modify, IsDoubleChuckFlag);
                    versionA_DeleteList = GetVersionList_PC(parameterNumber, entityCompare.VersionA_Delete, IsDoubleChuckFlag);
                    versionA_NoChangeList = GetVersionList_PC(parameterNumber, entityCompare.VersionA_NoChange, IsDoubleChuckFlag);

                    versionB_AddList = GetVersionList_PC(parameterNumber, entityCompare.VersionB_Add, IsDoubleChuckFlag);
                    versionB_ModifyList = GetVersionList_PC(parameterNumber, entityCompare.VersionB_Modify, IsDoubleChuckFlag);
                    versionB_DeleteList = GetVersionList_PC(parameterNumber, entityCompare.VersionB_Delete, IsDoubleChuckFlag);
                    versionB_NoChangeList = GetVersionList_PC(parameterNumber, entityCompare.VersionB_NoChange, IsDoubleChuckFlag);

                    PcDetailCompareList = new ObservableCollection<CompareDetailEntity>();
                    for (int i = 0; i < parameterNameList.Count; i++)
                    {
                        string strVersionAValue = "";
                        string strVersionBValue = "";

                        CompareDetailEntity entity = new CompareDetailEntity();
                        entity.ParameterName = parameterNameList[i];

                        entity.VersionA_Add = versionA_AddList[i];
                        entity.VersionA_Modify = versionA_ModifyList[i];
                        entity.VersionA_Delete = versionA_DeleteList[i];
                        entity.VersionA_NoChange = versionA_NoChangeList[i];

                        entity.VersionB_Add = versionB_AddList[i];
                        entity.VersionB_Modify = versionB_ModifyList[i];
                        entity.VersionB_Delete = versionB_DeleteList[i];
                        entity.VersionB_NoChange = versionB_NoChangeList[i];

                        if (!string.IsNullOrEmpty(versionA_AddList[i]))
                        {
                            strVersionAValue = versionA_AddList[i];
                        }
                        else if (!string.IsNullOrEmpty(versionA_ModifyList[i]))
                        {
                            strVersionAValue = versionA_ModifyList[i];
                        }
                        else if (!string.IsNullOrEmpty(versionA_DeleteList[i]))
                        {
                            strVersionAValue = versionA_DeleteList[i];
                        }
                        else if (!string.IsNullOrEmpty(versionA_NoChangeList[i]))
                        {
                            strVersionAValue = versionA_NoChangeList[i];
                        }

                        if (!string.IsNullOrEmpty(versionB_AddList[i]))
                        {
                            strVersionBValue = versionB_AddList[i];
                        }
                        else if (!string.IsNullOrEmpty(versionB_ModifyList[i]))
                        {
                            strVersionBValue = versionB_ModifyList[i];
                        }
                        else if (!string.IsNullOrEmpty(versionB_DeleteList[i]))
                        {
                            strVersionBValue = versionB_DeleteList[i];
                        }
                        else if (!string.IsNullOrEmpty(versionB_NoChangeList[i]))
                        {
                            strVersionBValue = versionB_NoChangeList[i];
                        }

                        if (IsHaveVersionA && IsHaveVersionB)
                        {
                            if (strVersionAValue.Equals(strVersionBValue))
                            {
                                entity.Result = "Same";
                            }
                            else
                            {
                                entity.Result = "Modify";
                            }
                        }
                        else if (IsHaveVersionA)
                        {
                            entity.Result = "Delete";
                        }
                        else if (IsHaveVersionB)
                        {
                            entity.Result = "Add";
                        }

                        PcDetailCompareList.Add(entity);
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }        
        #endregion
    }
    public enum InitType
    {
        CD,
        PC,
        CPE
    }
}
