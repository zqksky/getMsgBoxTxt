﻿using MahApps.Metro.Controls;
using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using ProductAndLayerSetting.Views;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Navigation;

namespace ProductAndLayerSetting.ViewModels
{
    class SettingMainViewModel : ViewModelBase
    {
        public SettingMainViewModel()
        {

        }

        IEventAggregator _ea;
        public ISettingMainService _SettingMainService { get; set; }
        public SettingMainViewModel(ISettingMainService settingMainService, IEventAggregator ea, IRegionManager regionManager)
        {
            _ea = ea;
            _regionManager = regionManager;
            _SettingMainService = settingMainService;

            Title = "Product And Layer Setting";

            InitOVLMode();
            GetContextValues();
            QueryGetCfgCommonTable();
            dbInitValueSource = DataTableHelp.CreateInitDataTable();
            dbInitValueUpdate = dbInitValueSource.Clone();
            IsSaveFlag = false;
            IsInvokFlag = false;

            EventAggregator.GetEvent<PCDynamicChangedEvent>().Subscribe(PCDynamicMessageReceived);
            EventAggregator.GetEvent<PCEDynamicChangedEvent>().Subscribe(PCEDynamicMessageReceived);
            EventAggregator.GetEvent<PCStaticChangedEvent>().Subscribe(PCStaticMessageReceived);

            EventAggregator.GetEvent<CPEDynamicChangedEvent>().Subscribe(CPEDynamicMessageReceived);
            EventAggregator.GetEvent<CPEEDynamicChangedEvent>().Subscribe(CPEEDynamicMessageReceived);
            EventAggregator.GetEvent<CPEStaticChangedEvent>().Subscribe(CPEStaticMessageReceived);
            EventAggregator.GetEvent<CPELISChangedEvent>().Subscribe(CPELISMessageReceived);
        }

        #region Loaded Event
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnLoaded));

        bool IsInvokFlag = false;
        string LastProduct = string.Empty;
        string LastLayer = string.Empty;
        string LastToolGroup = string.Empty;
        void OnLoaded()
        {
            string LastProduct = Product;
            string LastLayer = Layer;
            string LastToolGroup = ToolGroup;
            if (IsInvokFlag)
            {
                GetContextValues();
                Product = LastProduct;
                Layer = LastLayer;
                ToolGroup = LastToolGroup;
                //QueryGetCfgCommonTable();

            }
            IsInvokFlag = true;

            #region Set Save Button
            SetBtnSaveStatus(false);
            SetSettingEnable(true);
            #endregion
        }
        #endregion

        #region View Define Field
        private ObservableCollection<string> _PCDynamicMessages = new ObservableCollection<string>();
        public ObservableCollection<string> PCDynamicMessages
        {
            get { return _PCDynamicMessages; }
            set { SetProperty(ref _PCDynamicMessages, value); }
        }

        private void PCDynamicMessageReceived(List<string> strList)
        {
            PCDynamicMessages = new ObservableCollection<string>(strList);
        }

        private ObservableCollection<string> _PCEDynamicMessages = new ObservableCollection<string>();
        public ObservableCollection<string> PCEDynamicMessages
        {
            get { return _PCEDynamicMessages; }
            set { SetProperty(ref _PCEDynamicMessages, value); }
        }

        private void PCEDynamicMessageReceived(List<string> strList)
        {
            PCEDynamicMessages = new ObservableCollection<string>(strList);
        }

        private ObservableCollection<string> _PCStaticMessages = new ObservableCollection<string>();
        public ObservableCollection<string> PCStaticMessages
        {
            get { return _PCStaticMessages; }
            set { SetProperty(ref _PCStaticMessages, value); }
        }

        private void PCStaticMessageReceived(List<string> strList)
        {
            PCStaticMessages = new ObservableCollection<string>(strList);
        }

        private ObservableCollection<string> _CPEEDynamicMessages = new ObservableCollection<string>();
        public ObservableCollection<string> CPEEDynamicMessages
        {
            get { return _CPEEDynamicMessages; }
            set { SetProperty(ref _CPEEDynamicMessages, value); }
        }

        private void CPEEDynamicMessageReceived(List<string> strList)
        {
            CPEEDynamicMessages = new ObservableCollection<string>(strList);
        }

        private ObservableCollection<string> _CPEDynamicMessages = new ObservableCollection<string>();
        public ObservableCollection<string> CPEDynamicMessages
        {
            get { return _CPEDynamicMessages; }
            set { SetProperty(ref _CPEDynamicMessages, value); }
        }

        private void CPEDynamicMessageReceived(List<string> strList)
        {
            CPEDynamicMessages = new ObservableCollection<string>(strList);
        }

        private ObservableCollection<string> _CPEStaticMessages = new ObservableCollection<string>();
        public ObservableCollection<string> CPEStaticMessages
        {
            get { return _CPEStaticMessages; }
            set { SetProperty(ref _CPEStaticMessages, value); }
        }

        private void CPEStaticMessageReceived(List<string> strList)
        {
            CPEStaticMessages = new ObservableCollection<string>(strList);
        }

        private ObservableCollection<string> _CPELISMessages = new ObservableCollection<string>();
        public ObservableCollection<string> CPELISMessages
        {
            get { return _CPELISMessages; }
            set { SetProperty(ref _CPELISMessages, value); }
        }

        private void CPELISMessageReceived(List<string> strList)
        {
            CPELISMessages = new ObservableCollection<string>(strList);
        }
        #endregion

        #region View Navigation
        IRegionManager _regionManager;
        IRegionNavigationJournal _journal;
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            try
            {
                _journal = navigationContext.NavigationService.Journal;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        public override bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        #endregion

        #region View Region Fun
        /// <summary>
        /// Init OVL Mode
        /// </summary>
        void InitOVLMode()
        {
            OVLPCR2RModeList = new List<string>() { "Static", "Dynamic" };
            OVLCPER2RModeList = new List<string>() { "NONE", "Fixed", "Static", "Dynamic", "LIS" };
            OVLCPEOVLModeList = new List<string>() { "CPE6", "CPE15", "CPE19", "NA" };

            ShowCPEModeView("CPE_None");
        }

        SendWaferModeParam SendWaferParam;
        /// <summary>
        /// Show OVL PC View
        /// </summary>
        /// <param name="viewName"></param>
        void ShowWaferModeView(string viewName)
        {
            try
            {
                var parameters = new NavigationParameters();
                if (SendWaferParam == null)
                {
                    SendWaferParam = new SendWaferModeParam();
                    ClearSendWaferParameter();
                }
                parameters.Add("Message", SendWaferParam);

                _regionManager.RequestNavigate("WaferModeContentRegion", viewName, parameters);
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Show OVL CPE View
        /// </summary>
        /// <param name="viewName"></param>
        void ShowCPEModeView(string viewName)
        {
            try
            {
                var parameters = new NavigationParameters();
                if (SendWaferParam == null)
                {
                    SendWaferParam = new SendWaferModeParam();
                    ClearSendWaferParameter();
                }
                GetSendWaferParameter();
                parameters.Add("Message", SendWaferParam);

                _regionManager.RequestNavigate("CPEContentRegion", viewName, parameters);
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Get Send OVL PC/CPE Parameter
        /// </summary>
        void GetSendWaferParameter()
        {
            SendWaferParam = new SendWaferModeParam();
            SendWaferParam.OVLCPEExpireTime = OVLPCExpireTime;// OVLCPEExpireTime;
            SendWaferParam.OVLCPEFeedforeward = OVLCPEFeedforeward.Equals("") ? "false" : OVLCPEFeedforeward;
            SendWaferParam.OVLCPEFixEdge = OVLCPEFixEdge.Equals("") ? "false" : OVLCPEFixEdge;
            SendWaferParam.OVLCPELslCalc = OVLCPELslCalc;
            SendWaferParam.OVLCPELumda = OVLCPELumda;
            SendWaferParam.OVLCPESpecMaxDelta = OVLCPESpecMaxDelta;
            SendWaferParam.OVLCPESpecVarName = OVLCPESpecVarName;
            SendWaferParam.OVLCPEUpdateLot = OVLCPEUpdateLot;
            SendWaferParam.OVLCPEUpdateTime = OVLCPEUpdateTime;
            SendWaferParam.OVLCPEUslCalc = OVLCPEUslCalc;

            SendWaferParam.OVLPCDeadband = OVLPCDeadband;
            SendWaferParam.OVLPCExpireTime = OVLPCExpireTime;
            SendWaferParam.OVLPCFeedforeward = OVLPCFeedforeward.Equals("") ? "false" : OVLPCFeedforeward;
            SendWaferParam.OVLPCLslCalc = OVLPCLslCalc;
            SendWaferParam.OVLPCLslMetro = OVLPCLslMetro;
            SendWaferParam.OVLPCLumda = OVLPCLumda;
            SendWaferParam.OVLPCSpecMaxDelta = OVLPCSpecMaxDelta;
            SendWaferParam.OVLPCSpecVarName = OVLPCSpecVarName;
            SendWaferParam.OVLPCUpdateLot = OVLPCUpdateLot;
            SendWaferParam.OVLPCUpdateTime = OVLPCUpdateTime;
            SendWaferParam.OVLPCUslCalc = OVLPCUslCalc;
            SendWaferParam.OVLPCUslMetro = OVLPCUslMetro;
            //SendWaferParam.ScannerGrop = ScannerGrop;

            SendWaferParam.LIS_UPDATE_TIME = LIS_UPDATE_TIME;
            SendWaferParam.LIS_UPDATE_LOT = LIS_UPDATE_LOT;
            SendWaferParam.SPARSE_SAMPLING = SPARSE_SAMPLING;
            SendWaferParam.DENSE_SAMPLING = DENSE_SAMPLING;
            SendWaferParam.EST_SPARSE_RECIPE = EST_SPARSE_RECIPE;
            SendWaferParam.EST_DENSE_RECIPE = EST_DENSE_RECIPE;
            SendWaferParam.OPTIMIZE_RECIPE = OPTIMIZE_RECIPE;
            SendWaferParam.SAMPLING_TOOLTYPE = SAMPLING_TOOLTYPE;
            SendWaferParam.ESTI_KPI_OCAP = ESTI_KPI_OCAP;
            SendWaferParam.EXCEPTION_CNT = EXCEPTION_CNT;
            SendWaferParam.EXCEPTION_THRESHOLD = EXCEPTION_THRESHOLD;
        }
        /// <summary>
        /// Unused
        /// </summary>
        void ClearSendWaferParameter()
        {
            #region CD
            ClearCDParameterValue();
            #endregion

            #region OVL PC
            ClearOVLPCParameterValue();
            IsLinearFlag = false;
            IsHOPCFlag = false;
            IsIHOPCFlag = false;
            #endregion

            #region OVL CPE
            ClearOVLCPEParameterValue();
            #endregion

            #region CPE LIS
            ClearLISParameterVlaue();
            #endregion
        }
        #endregion

        #region DataTable Define
        DataTable dbInitValueSource = new DataTable();
        DataTable dbInitValueUpdate = new DataTable();

        DataTable dbTypeValue = new DataTable();
        DataTable dbContextValue = new DataTable();
        DataTable dbR2R_PH_CONFIG_COMMON = new DataTable();
        DataTable dbR2R_PH_CONFIG_LIS = new DataTable();
        DataTable dbR2R_PH_CONFIG_INIT_CD = new DataTable();
        DataTable dbR2R_PH_CONFIG_INIT_OVL_PC = new DataTable();
        DataTable dbR2R_PH_CONFIG_INIT_OVL_CPE = new DataTable();
        DataTable dbR2R_PH_CONFIG_SPEC_OVL_PC = new DataTable();
        DataTable dbR2R_PH_CONFIG_SPEC_OVL_CPE = new DataTable();

        CfgSingleTableInfoEntity cfgCommonUpdateEntity = new CfgSingleTableInfoEntity();
        List<string> cfgCommonColumnNameList = new List<string>();
        List<string> cfgCommonColumnKeyList = new List<string>();
        DataTable dbR2R_PH_CONFIG_COMMON_Source = new DataTable();
        DataTable dbR2R_PH_CONFIG_COMMON_Update = new DataTable();

        CfgSingleTableInfoEntity cfgLISUpdateEntity = new CfgSingleTableInfoEntity();
        List<string> cfgLISColumnNameList = new List<string>();
        List<string> cfgLISColumnKeyList = new List<string>();
        DataTable dbR2R_PH_CONFIG_LIS_Source = new DataTable();
        DataTable dbR2R_PH_CONFIG_LIS_Update = new DataTable();

        CfgSingleTableInfoEntity cfgInitCdSourceEntity = new CfgSingleTableInfoEntity();
        CfgSingleTableInfoEntity cfgInitCdUpdateEntity = new CfgSingleTableInfoEntity();
        List<string> cfgInitCdColumnNameList = new List<string>();
        List<string> cfgInitCdColumnKeyList = new List<string>();
        DataTable dbR2R_PH_CONFIG_INIT_CD_Source = new DataTable();
        DataTable dbR2R_PH_CONFIG_INIT_CD_Update = new DataTable();

        CfgSingleTableInfoEntity cfgInitOvlPCSourceEntity = new CfgSingleTableInfoEntity();
        CfgSingleTableInfoEntity cfgInitOvlPCUpdateEntity = new CfgSingleTableInfoEntity();
        List<string> cfgInitOvlPCColumnNameList = new List<string>();
        List<string> cfgInitOvlPCColumnKeyList = new List<string>();
        DataTable dbR2R_PH_CONFIG_INIT_OVL_PC_Source = new DataTable();
        DataTable dbR2R_PH_CONFIG_INIT_OVL_PC_Update = new DataTable();

        CfgSingleTableInfoEntity cfgInitOvlCPESourceEntity = new CfgSingleTableInfoEntity();
        CfgSingleTableInfoEntity cfgInitOvlCPEUpdateEntity = new CfgSingleTableInfoEntity();
        List<string> cfgInitOvlCPEColumnNameList = new List<string>();
        List<string> cfgInitOvlCPEColumnKeyList = new List<string>();
        DataTable dbR2R_PH_CONFIG_INIT_OVL_CPE_Source = new DataTable();
        DataTable dbR2R_PH_CONFIG_INIT_OVL_CPE_Update = new DataTable();
        #endregion

        #region Invoke Webservice
        /// <summary>
        /// Get Context Values
        /// </summary>
        void GetContextValuesVersionCompare()
        {
            try
            {
                CfgGetContextValuesResult contextValue = new CfgGetContextValuesResult();
                contextValue = _SettingMainService.R2R_UI_Config_PH_Get_ContextValues(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion);
                if (contextValue == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_PH_Get_ContextValues Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (contextValue.ReturnCode.Equals("0"))
                {
                    VersionCompareProductList = contextValue.ProductList.Distinct().ToList();
                    VersionCompareLayerList = contextValue.LayerList.Distinct().ToList();
                    VersionCompareToolGroupList = contextValue.ToolGroupList.Distinct().ToList();
                }
                else
                {
                    MyLogger.Trace("Message :: " + contextValue.ReturnText);
                    System.Windows.Forms.MessageBox.Show(contextValue.ReturnText);
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Get Context Values
        /// </summary>
        void GetContextValues()
        {
            try
            {
                //ClientInfo.RequsetId = "RequestId_31";
                //ClientInfo.UserId = "UserID_23";
                //ClientInfo.CurrentVersion = "ClienetVersion_50";

                CfgGetContextValuesResult contextValue = new CfgGetContextValuesResult();
                contextValue = _SettingMainService.R2R_UI_Config_PH_Get_ContextValues(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion);
                if (contextValue == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_PH_Get_ContextValues Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (contextValue.ReturnCode.Equals("0"))
                {
                    //dbContextValue = DataTableHelp.CreateContextValueDataTable(contextValue.ProductList, contextValue.LayerList, contextValue.ToolGroupList, contextValue.ToolVendorList);
                    dbTypeValue = DataTableHelp.CreateToolTypeDataTable(contextValue.ToolGroupList, contextValue.ToolVendorList);

                    CanonToolGroupList = new List<string>();
                    for (int i = 0; i < contextValue.ToolVendorList.Count; i++)
                    {
                        if (contextValue.ToolVendorList[i].ToUpper().Equals("CANON"))
                        {
                            CanonToolGroupList.Add(contextValue.ToolGroupList[i]);
                        }
                    }

                    #region Version Compare
                    VersionCompareProductList = contextValue.ProductList.Distinct().ToList();
                    VersionCompareLayerList = contextValue.LayerList.Distinct().ToList();
                    VersionCompareToolGroupList = contextValue.ToolGroupList.Distinct().ToList();
                    #endregion

                    ProductList = contextValue.ProductList.Distinct().ToList();
                    LayerList = contextValue.LayerList.Distinct().ToList();
                    ToolGroupList = contextValue.ToolGroupList.Distinct().ToList();
                    ToolVendorList = contextValue.ToolVendorList.Distinct().ToList();

                    if (!ProductList.Contains("*"))
                    {
                        ProductList.Insert(0, "*");
                    }
                    if (!LayerList.Contains("*"))
                    {
                        LayerList.Insert(0, "*");
                    }
                    if (!ToolGroupList.Contains("*"))
                    {
                        ToolGroupList.Insert(0, "*");
                    }
                    if (ToolVendorList.Count > 0)
                    {
                        ToolVendor = ToolVendorList[0];
                    }
                }
                else
                {
                    MyLogger.Trace("Message :: " + contextValue.ReturnText);
                    System.Windows.Forms.MessageBox.Show(contextValue.ReturnText);
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Get ToolVendor Vlaue
        /// </summary>
        /// <param name="strToolGroup"></param>
        /// <returns>ToolVendor</returns>
        string GetToolVendor(string strToolGroup)
        {
            string strToolVendor = string.Empty;
            try
            {
                DataRow[] query = dbTypeValue.Select("ToolGroup = '" + strToolGroup + "'");

                if (query.Length > 0)
                {
                    strToolVendor = query[0]["ToolVendor"].ToString();
                }
                else
                {
                    strToolVendor = "";
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }

            return strToolVendor;
        }
        /// <summary>
        /// Get the query string
        /// </summary>
        /// <returns></returns>
        string GetQuerySelect()
        {
            string strSelect = string.Empty;
            try
            {
                if (Product.Equals("*") && Layer.Equals("*") && ToolGroup.Equals("*"))
                {
                    strSelect = "";
                }
                else if (Product.Equals("*"))
                {
                    if (Layer.Equals("*"))
                    {
                        strSelect = "TOOL_GROUP = '" + ToolGroup + "'";
                    }
                    else if (ToolGroup.Equals("*"))
                    {
                        strSelect = "LAYER = '" + Layer + "'";
                    }
                    else
                    {
                        strSelect = "LAYER = '" + Layer + "' and TOOL_GROUP = '" + ToolGroup + "'";
                    }
                }
                else if (Layer.Equals("*"))
                {
                    if (Product.Equals("*"))
                    {
                        strSelect = "TOOL_GROUP = '" + ToolGroup + "'";
                    }
                    else if (ToolGroup.Equals("*"))
                    {
                        strSelect = "PRODUCT = '" + Product + "'";
                    }
                    else
                    {
                        strSelect = "PRODUCT = '" + Product + "' and TOOL_GROUP = '" + ToolGroup + "'";
                    }
                }
                else if (ToolGroup.Equals("*"))
                {
                    if (Product.Equals("*"))
                    {
                        strSelect = "LAYER = '" + Layer + "'";
                    }
                    else if (Layer.Equals("*"))
                    {
                        strSelect = "PRODUCT = '" + Product + "'";
                    }
                    else
                    {
                        strSelect = "PRODUCT = '" + Product + "' and LAYER = '" + Layer + "'";
                    }
                }
                else
                {
                    strSelect = "PRODUCT = '" + Product + "' and LAYER = '" + Layer + "' and TOOL_GROUP = '" + ToolGroup + "'";
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return strSelect;
        }
        /// <summary>
        /// Get the COMMON configuration value
        /// </summary>
        void QueryGetCfgCommonTable()
        {
            try
            {
                CfgGetCommonResult tableContent = new CfgGetCommonResult();
                if (string.IsNullOrEmpty(Product))
                {
                    Product = "*";
                }
                if (string.IsNullOrEmpty(Layer))
                {
                    Layer = "*";
                }
                if (string.IsNullOrEmpty(ToolGroup))
                {
                    ToolGroup = "*";
                }
                tableContent = _SettingMainService.R2R_UI_Config_PH_Get_CONFIG_COMMON(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, Product, Layer, ToolGroup);
                if (tableContent == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_PH_Get_CONFIG_COMMON Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (string.IsNullOrEmpty(tableContent.ReturnCode))
                {

                }
                if (tableContent.ReturnCode.Equals("0") || tableContent.ReturnCode.Equals("1"))
                {
                    CfgSingleTableInfoEntity entityCommon = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(tableContent.Content_R2R_PH_CONFIG_COMMON);
                    if (entityCommon == null)
                    {
                        return;
                    }
                    cfgCommonUpdateEntity = CfgSingleTableInfoHelp.GetUpdateSingleTableInfo(entityCommon, ref dbR2R_PH_CONFIG_COMMON_Source, ref dbR2R_PH_CONFIG_COMMON_Update, ref cfgCommonColumnNameList, ref cfgCommonColumnKeyList);

                    CfgSingleTableInfoEntity entityLIS = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(tableContent.Content_R2R_PH_CONFIG_LIS);
                    if (entityLIS == null)
                    {
                        return;
                    }
                    cfgLISUpdateEntity = CfgSingleTableInfoHelp.GetUpdateSingleTableInfo(entityLIS, ref dbR2R_PH_CONFIG_LIS_Source, ref dbR2R_PH_CONFIG_LIS_Update, ref cfgLISColumnNameList, ref cfgLISColumnKeyList);
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Get the Init value of the context from db
        /// </summary>
        /// <param name="db"></param>
        /// <param name="strColumnName"></param>
        /// <returns></returns>
        string GetInitContent(DataTable db, string strColumnName)
        {
            string strResult = string.Empty;
            try
            {
                #region Query
                string strQuery = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                DataRow[] rows = DataTableHelp.Query(db, strQuery);
                if (rows.Count() > 0)
                {
                    strResult = rows[0][strColumnName].ToString();
                }
                else
                {
                    DataRow rowNew = db.NewRow();
                    rowNew["PRODUCT"] = SelectedProductSetting.Product;
                    rowNew["LAYER"] = SelectedProductSetting.Layer;
                    rowNew["TOOL_GROUP"] = SelectedProductSetting.ToolGroup;
                    db.Rows.Add(rowNew);
                }
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return strResult;
        }
        /// <summary>
        /// Insert the init value of the context to db
        /// </summary>
        /// <param name="strColumnName"></param>
        /// <param name="strContent"></param>
        void InitSourceContentInsert(string strColumnName, string strContent)
        {
            try
            {
                #region Query
                string strQuery = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                DataRow[] rows = DataTableHelp.Query(dbInitValueSource, strQuery);
                if (rows.Count() > 0)
                {
                    if (rows[0][strColumnName].ToString().Equals(""))
                    {
                        rows[0][strColumnName] = strContent;
                    }
                }
                else
                {
                    DataRow rowNew = dbInitValueSource.NewRow();
                    rowNew["PRODUCT"] = SelectedProductSetting.Product;
                    rowNew["LAYER"] = SelectedProductSetting.Layer;
                    rowNew["TOOL_GROUP"] = SelectedProductSetting.ToolGroup;
                    rowNew[strColumnName] = strContent;
                    dbInitValueSource.Rows.Add(rowNew);
                }
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Get the CD Init configuration value
        /// </summary>
        /// <returns></returns>
        bool GetR2R_UI_Config_PH_Get_CONFIG_INIT_CD()
        {
            bool flag = false;
            try
            {
                if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                {
                    //System.Windows.Forms.MessageBox.Show("Please selected!");
                    return false;
                }

                string strContent = GetInitContent(dbInitValueUpdate, "CdInitContent");
                string strContentOriginal = GetInitContent(dbInitValueSource, "CdInitContent");

                CfgGetInitCDResult tableContent = new CfgGetInitCDResult();
                tableContent = _SettingMainService.R2R_UI_Config_PH_Get_CONFIG_INIT_CD(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, ToolVendor, strContent, strContentOriginal);
                if (tableContent == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_PH_Get_CONFIG_INIT_CD Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return false;
                }
                if (string.IsNullOrEmpty(tableContent.ReturnCode))
                {
                    flag = false;
                }
                if (tableContent.ReturnCode.Equals("0") || tableContent.ReturnCode.Equals("1"))
                {
                    flag = true;

                    CfgSingleTableInfoEntity entity = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(tableContent.Content_R2R_PH_CONFIG_INIT_CD);
                    if (entity == null)
                    {
                        return false;
                    }
                    List<string> CDInitialProduct = new List<string>();
                    List<string> CDInitialLayer = new List<string>();
                    List<string> CDInitialToolGroup = new List<string>();
                    List<string> CDInitialTool = new List<string>();
                    List<string> CDInitialReticle = new List<string>();
                    List<string> CDInitialParameter = new List<string>();
                    List<string> CDInitialValue = new List<string>();
                    List<string> CDInitialR2RMode = new List<string>();
                    List<string> CDInitialDoseValue = new List<string>();
                    List<string> CDInitialFocusValue = new List<string>();
                    List<string> CDInitialDoseSensitivity = new List<string>();

                    int itemIndex0 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "PRODUCT:");
                    int itemIndex1 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "LAYER:");
                    int itemIndex2 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "TOOL_GROUP:");
                    int itemIndex3 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "TOOL:");
                    int itemIndex4 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "RETICLE:");
                    int itemIndex5 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "INIT_PARAMETER_NAME:");
                    int itemIndex6 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "INIT_PARAMETER_VALUE:");
                    if (itemIndex0 == -1 || itemIndex1 == -1 || itemIndex2 == -1 || itemIndex3 == -1 || itemIndex4 == -1 || itemIndex5 == -1 || itemIndex6 == -1)
                    {
                        string strMsg = "Please check ColumnFormat!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return false;
                    }

                    CDInitialProduct = new List<string>(entity.ColumnData[itemIndex0].Split(':'));
                    CDInitialLayer = new List<string>(entity.ColumnData[itemIndex1].Split(':'));
                    CDInitialToolGroup = new List<string>(entity.ColumnData[itemIndex2].Split(':'));
                    CDInitialTool = new List<string>(entity.ColumnData[itemIndex3].Split(':'));
                    CDInitialReticle = new List<string>(entity.ColumnData[itemIndex4].Split(':'));
                    CDInitialParameter = new List<string>(entity.ColumnData[itemIndex5].Split(':'));
                    CDInitialValue = new List<string>(entity.ColumnData[itemIndex6].Split(':'));

                    string Content_R2R_PH_CONFIG_INIT_CD_OriginalSort = "";
                    if (!string.IsNullOrEmpty(tableContent.Content_R2R_PH_CONFIG_INIT_CD_Original) && CDInitialParameter.Count > 0)
                    {
                        string UpdateParameterNameItem = CDInitialParameter[0];
                        Content_R2R_PH_CONFIG_INIT_CD_OriginalSort = CfgSingleTableInfoHelp.SortInitOriginalContent(tableContent.Content_R2R_PH_CONFIG_INIT_CD_Original, UpdateParameterNameItem, itemIndex5);
                        InitSourceContentInsert("CdInitContent", Content_R2R_PH_CONFIG_INIT_CD_OriginalSort);
                    }

                    foreach (var str in CDInitialValue)
                    {
                        string[] strArrayList = str.Split(',');
                        CDInitialR2RMode.Add(strArrayList[0]);
                        CDInitialFocusValue.Add(strArrayList[1]);
                        CDInitialDoseValue.Add(strArrayList[2]);
                        CDInitialDoseSensitivity.Add(strArrayList[3]);
                    }

                    List<string> CDToolList = new List<string>();

                    CDInitialSettingList = new List<CD_InitialSettingEntity>();
                    for (int i = 0; i < CDInitialProduct.Count; i++)
                    {
                        CD_InitialSettingEntity entityTmp = new CD_InitialSettingEntity();
                        entityTmp.Product = CDInitialProduct[i];
                        entityTmp.Layer = CDInitialLayer[i];
                        entityTmp.ToolGroup = CDInitialToolGroup[i];
                        entityTmp.Tool = CDInitialTool[i];
                        entityTmp.Reticle = CDInitialReticle[i];
                        entityTmp.Parameter = CDInitialParameter[i];
                        entityTmp.R2RMode = CDInitialR2RMode[i];
                        entityTmp.FocusValue = CDInitialFocusValue[i];
                        entityTmp.DoseValue = CDInitialDoseValue[i];
                        entityTmp.DoseSensitivity = CDInitialDoseSensitivity[i];

                        entityTmp.ToolList = new List<string>(tableContent.LIST_TOOL);
                        //entityTmp.ToolList.Add("newTool");
                        //entityTmp.ToolList.Add("newTool2");
                        entityTmp.R2RModeList = new List<string>() { "Active", "Fixed" };
                        CDInitialSettingList.Add(entityTmp);
                    }

                    #region

                    cfgInitCdSourceEntity = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(Content_R2R_PH_CONFIG_INIT_CD_OriginalSort);
                    cfgInitCdUpdateEntity = CfgSingleTableInfoHelp.GetUpdateSingleTableInfo(entity, ref dbR2R_PH_CONFIG_INIT_CD_Source, ref dbR2R_PH_CONFIG_INIT_CD_Update, ref cfgInitCdColumnNameList, ref cfgInitCdColumnKeyList);
                    #endregion

                }
                else
                {
                    flag = false;
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return flag;
        }
        /// <summary>
        /// Get the OVL PC Init configuration value
        /// </summary>
        /// <returns></returns>
        bool GetR2R_UI_Config_PH_Get_CONFIG_INIT_OVL_PC()
        {
            bool flag = false;
            try
            {
                PC_InitialSettingEntityList = new List<PC_InitialSettingEntity>();
                if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                {
                    //System.Windows.Forms.MessageBox.Show("Please selected!");
                    return false;
                }

                string strContent = GetInitContent(dbInitValueUpdate, "PcInitContent");
                string strContentOriginal = GetInitContent(dbInitValueSource, "PcInitContent");

                string strControlByChuck = SelectedProductSetting.ControlByChuck == "Y" ? "true" : "false";
                CfgGetInitOvlPCResult tableContent = new CfgGetInitOvlPCResult();
                tableContent = _SettingMainService.R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_PC(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, ToolVendor, strControlByChuck, OVLPCOVLMode, OVLPCSpecVarName, OVLPCSpecVarSelect, strContent, strContentOriginal);
                if (tableContent == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_PC Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return false;
                }
                if (string.IsNullOrEmpty(tableContent.ReturnCode))
                {
                    flag = false;
                }
                if (tableContent.ReturnCode.Equals("0") || tableContent.ReturnCode.Equals("1"))
                {
                    flag = true;

                    CfgSingleTableInfoEntity entity = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(tableContent.Content_R2R_PH_CONFIG_INIT_OVL_PC);
                    if (entity == null)
                    {
                        return false;
                    }
                    List<string> OVLPCInitialProduct = new List<string>();
                    List<string> OVLPCInitialLayer = new List<string>();
                    List<string> OVLPCInitialToolGroup = new List<string>();
                    List<string> OVLPCInitialReticle = new List<string>();
                    List<string> OVLPCInitialTool = new List<string>();
                    List<string> OVLPCInitialPreReticle = new List<string>();
                    List<string> OVLPCInitialPreTool = new List<string>();
                    List<string> OVLPCInitialMode = new List<string>();
                    List<string> OVLPCInitialParameter = new List<string>();
                    List<string> OVLPCInitialValue = new List<string>();

                    int itemIndex0 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "PRODUCT:");
                    int itemIndex1 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "LAYER:");
                    int itemIndex2 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "TOOL_GROUP:");
                    int itemIndex3 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "TOOL:");
                    int itemIndex4 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "RETICLE:");
                    int itemIndex5 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "PRE_TOOL:");
                    int itemIndex6 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "PRE_RETICLE:");
                    int itemIndex7 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "OVL_PC_MODE:");
                    int itemIndex8 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "INIT_PARAMETER_NAME:");
                    int itemIndex9 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "INIT_PARAMETER_VALUE:");
                    if (itemIndex0 == -1 || itemIndex1 == -1 || itemIndex2 == -1 || itemIndex3 == -1 || itemIndex4 == -1 || itemIndex5 == -1 || itemIndex6 == -1 || itemIndex7 == -1 || itemIndex8 == -1 || itemIndex9 == -1)
                    {
                        string strMsg = "Please check ColumnFormat!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return false;
                    }

                    OVLPCInitialProduct = new List<string>(entity.ColumnData[itemIndex0].Split(':'));
                    OVLPCInitialLayer = new List<string>(entity.ColumnData[itemIndex1].Split(':'));
                    OVLPCInitialToolGroup = new List<string>(entity.ColumnData[itemIndex2].Split(':'));
                    OVLPCInitialTool = new List<string>(entity.ColumnData[itemIndex3].Split(':'));
                    OVLPCInitialReticle = new List<string>(entity.ColumnData[itemIndex4].Split(':'));
                    OVLPCInitialPreTool = new List<string>(entity.ColumnData[itemIndex5].Split(':'));
                    OVLPCInitialPreReticle = new List<string>(entity.ColumnData[itemIndex6].Split(':'));
                    OVLPCInitialMode = new List<string>(entity.ColumnData[itemIndex7].Split(':'));
                    OVLPCInitialParameter = new List<string>(entity.ColumnData[itemIndex8].Split(':'));
                    OVLPCInitialValue = new List<string>(entity.ColumnData[itemIndex9].Split(':'));

                    string Content_R2R_PH_CONFIG_INIT_OVL_PC_OriginalSort = "";
                    if (!string.IsNullOrEmpty(tableContent.Content_R2R_PH_CONFIG_INIT_OVL_PC_Original) && OVLPCInitialParameter.Count > 0)
                    {
                        string UpdateParameterNameItem = OVLPCInitialParameter[0];  
                        Content_R2R_PH_CONFIG_INIT_OVL_PC_OriginalSort = CfgSingleTableInfoHelp.SortInitOriginalContent(tableContent.Content_R2R_PH_CONFIG_INIT_OVL_PC_Original, UpdateParameterNameItem, itemIndex8);
                        InitSourceContentInsert("PcInitContent", Content_R2R_PH_CONFIG_INIT_OVL_PC_OriginalSort);
                    }


                    for (int i = 0; i < OVLPCInitialProduct.Count; i++)
                    {
                        PC_InitialSettingEntity obj = new PC_InitialSettingEntity();
                        obj.PRODUCT = OVLPCInitialProduct[i];
                        obj.LAYER = OVLPCInitialLayer[i];
                        obj.TOOL_GROUP = OVLPCInitialToolGroup[i];
                        obj.TOOL = OVLPCInitialTool[i];
                        obj.RETICLE = OVLPCInitialReticle[i];
                        obj.PRE_TOOL = OVLPCInitialPreTool[i];
                        obj.PRE_RETICLE = OVLPCInitialPreReticle[i];
                        obj.OVL_PC_MODE = OVLPCInitialMode[i];
                        obj.INIT_PARAMETER_NAME = OVLPCInitialParameter[i];
                        obj.INIT_PARAMETER_VALUE = OVLPCInitialValue[i];

                        if (!OvlInitReticleList.Contains(obj.RETICLE))
                        {
                            OvlInitReticleList.Add(obj.RETICLE);
                        }
                        OvlInitToolList = new List<string>(tableContent.ToolList);
                        if (!OvlInitToolList.Contains(obj.TOOL))
                        {
                            OvlInitToolList.Add(obj.TOOL);
                        }
                        OvlInitToolList.Remove("");
                        OvlInitReticleList.Remove("");
                        obj.ToolList = new List<string>(OvlInitToolList);
                        obj.ReticleList = new List<string>(OvlInitReticleList);

                        PC_InitialSettingEntityList.Add(obj);
                    }

                    List<string> ListTool = new List<string>();
                    List<string> ListReticle = new List<string>();
                    foreach (var obj in PC_InitialSettingEntityList)
                    {
                        foreach (var str in obj.ToolList)
                        {
                            if (!ListTool.Contains(str) && !str.Equals("*"))
                            {
                                ListTool.Add(str);
                            }
                        }
                        foreach (var str in obj.ReticleList)
                        {
                            if (!ListReticle.Contains(str) && !str.Equals("*"))
                            {
                                ListReticle.Add(str);
                            }
                        }
                    }

                    foreach (var obj in PC_InitialSettingEntityList)
                    {
                        obj.ToolList = new List<string>(ListTool);
                        obj.ReticleList = new List<string>(ListReticle);
                    }

                    #region
                    cfgInitOvlPCSourceEntity = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(Content_R2R_PH_CONFIG_INIT_OVL_PC_OriginalSort);
                    cfgInitOvlPCUpdateEntity = CfgSingleTableInfoHelp.GetUpdateSingleTableInfo(entity, ref dbR2R_PH_CONFIG_INIT_OVL_PC_Source, ref dbR2R_PH_CONFIG_INIT_OVL_PC_Update, ref cfgInitOvlPCColumnNameList, ref cfgInitOvlPCColumnKeyList);
                    #endregion
                }
                else
                {
                    flag = false;
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return flag;
        }        
        /// <summary>
        /// Get the OVL CPE Init configuration value
        /// </summary>
        /// <returns></returns>
        bool GetR2R_UI_Config_PH_Get_CONFIG_INIT_OVL_CPE()
        {
            bool flag = false;
            try
            {
                CPE_InitialSettingEntityList = new List<CPE_InitialSettingEntity>();
                if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                {
                    //System.Windows.Forms.MessageBox.Show("Please selected!");
                    return false;
                }

                string strContent = GetInitContent(dbInitValueUpdate, "CpeInitContent");
                string strContentOriginal = GetInitContent(dbInitValueSource, "CpeInitContent");

                CfgGetInitOvlCPEResult tableContent = new CfgGetInitOvlCPEResult();
                tableContent = _SettingMainService.R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_CPE(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, ToolVendor, OVLCPER2RMode, OVLCPEOVLMode, strContent, strContentOriginal);
                if (tableContent == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_PH_Get_CONFIG_INIT_OVL_CPE Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return false;
                }

                if (string.IsNullOrEmpty(tableContent.ReturnCode))
                {
                    flag = false;
                }
                if (tableContent.ReturnCode.Equals("0") || tableContent.ReturnCode.Equals("1"))
                {
                    flag = true;

                    CfgSingleTableInfoEntity entity = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(tableContent.Content_R2R_PH_CONFIG_INIT_OVL_CPE);
                    if (entity == null)
                    {
                        return false;
                    }
                    List<string> OVLCPEInitialProduct = new List<string>();
                    List<string> OVLCPEInitialLayer = new List<string>();
                    List<string> OVLCPEInitialToolGroup = new List<string>();
                    List<string> OVLCPEInitialReticle = new List<string>();
                    List<string> OVLCPEInitialTool = new List<string>();
                    List<string> OVLCPEInitialPreReticle = new List<string>();
                    List<string> OVLCPEInitialPreTool = new List<string>();
                    List<string> OVLCPEInitialParameter = new List<string>();
                    List<string> OVLCPEInitialValue = new List<string>();

                    int itemIndex0 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "PRODUCT:");
                    int itemIndex1 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "LAYER:");
                    int itemIndex2 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "TOOL_GROUP:");
                    int itemIndex3 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "TOOL:");
                    int itemIndex4 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "RETICLE:");
                    int itemIndex5 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "PRE_TOOL:");
                    int itemIndex6 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "PRE_RETICLE:");
                    int itemIndex7 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "INIT_PARAMETER_NAME:");
                    int itemIndex8 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(entity.ColumnFormat, "INIT_PARAMETER_VALUE:");
                    if (itemIndex0 == -1 || itemIndex1 == -1 || itemIndex2 == -1 || itemIndex3 == -1 || itemIndex4 == -1 || itemIndex5 == -1 || itemIndex6 == -1 || itemIndex7 == -1 || itemIndex8 == -1)
                    {
                        string strMsg = "Please check ColumnFormat!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return false;
                    }

                    OVLCPEInitialProduct = new List<string>(entity.ColumnData[itemIndex0].Split(':'));
                    OVLCPEInitialLayer = new List<string>(entity.ColumnData[itemIndex1].Split(':'));
                    OVLCPEInitialToolGroup = new List<string>(entity.ColumnData[itemIndex2].Split(':'));
                    OVLCPEInitialTool = new List<string>(entity.ColumnData[itemIndex3].Split(':'));
                    OVLCPEInitialReticle = new List<string>(entity.ColumnData[itemIndex4].Split(':'));
                    OVLCPEInitialPreTool = new List<string>(entity.ColumnData[itemIndex5].Split(':'));
                    OVLCPEInitialPreReticle = new List<string>(entity.ColumnData[itemIndex6].Split(':'));
                    OVLCPEInitialParameter = new List<string>(entity.ColumnData[itemIndex7].Split(':'));
                    OVLCPEInitialValue = new List<string>(entity.ColumnData[itemIndex8].Split(':'));

                    //string Content_R2R_PH_CONFIG_INIT_OVL_CPE_OriginalSort = "";
                    //if (!string.IsNullOrEmpty(tableContent.Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original) && OVLCPEInitialParameter.Count > 0)
                    //{
                    //    string UpdateParameterNameItem = OVLCPEInitialParameter[0];
                    //    Content_R2R_PH_CONFIG_INIT_OVL_CPE_OriginalSort = SortInitOriginalContent(tableContent.Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original, UpdateParameterNameItem,itemIndex7);
                    //    InitSourceContentInsert("PcInitContent", Content_R2R_PH_CONFIG_INIT_OVL_CPE_OriginalSort);
                    //}

                    //if (!string.IsNullOrEmpty(tableContent.Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original))
                    //{
                    InitSourceContentInsert("CpeInitContent", tableContent.Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original);
                    //}

                    for (int i = 0; i < OVLCPEInitialProduct.Count; i++)
                    {
                        CPE_InitialSettingEntity obj = new CPE_InitialSettingEntity();
                        obj.PRODUCT = OVLCPEInitialProduct[i];
                        obj.LAYER = OVLCPEInitialLayer[i];
                        obj.TOOL_GROUP = OVLCPEInitialToolGroup[i];
                        obj.TOOL = OVLCPEInitialTool[i];
                        obj.RETICLE = OVLCPEInitialReticle[i];
                        obj.PRE_TOOL = OVLCPEInitialPreTool[i];
                        obj.PRE_RETICLE = OVLCPEInitialPreReticle[i];
                        obj.INIT_PARAMETER_NAME = OVLCPEInitialParameter[i];
                        string[] arryValue = OVLCPEInitialValue[i].Split(',');
                        obj.CPESubRecipe = arryValue[0];
                        //obj.CPEModelTimeStamp = arryValue[1];
                        obj.CPEModelTimeStamp = arryValue[1].Replace(";", ":");

                        if (!OvlInitReticleList.Contains(obj.RETICLE))
                        {
                            OvlInitReticleList.Add(obj.RETICLE);
                        }
                        if (!OvlInitPreToolList.Contains(obj.PRE_TOOL))
                        {
                            OvlInitPreToolList.Add(obj.PRE_TOOL);
                        }
                        if (!OvlInitPreReticleList.Contains(obj.PRE_RETICLE))
                        {
                            OvlInitPreReticleList.Add(obj.PRE_RETICLE);
                        }
                        OvlInitToolList = new List<string>(tableContent.ToolList);
                        if (!OvlInitToolList.Contains(obj.TOOL))
                        {
                            OvlInitToolList.Add(obj.TOOL);
                        }
                        OvlInitToolList.Remove("");
                        OvlInitReticleList.Remove("");
                        OvlInitPreToolList.Remove("");
                        OvlInitPreReticleList.Remove("");
                        obj.ToolList = new List<string>(OvlInitToolList);
                        obj.ReticleList = new List<string>(OvlInitReticleList);
                        obj.PreToolList = new List<string>(OvlInitPreToolList);
                        obj.PreReticleList = new List<string>(OvlInitPreReticleList);
                        CPE_InitialSettingEntityList.Add(obj);
                    }

                    List<string> ListTool = new List<string>();
                    List<string> ListReticle = new List<string>();
                    List<string> ListPreTool = new List<string>();
                    List<string> ListPreReticle = new List<string>();
                    foreach (var obj in CPE_InitialSettingEntityList)
                    {
                        foreach (var str in obj.ToolList)
                        {
                            if (!ListTool.Contains(str) && !str.Equals("*"))
                            {
                                ListTool.Add(str);
                            }
                        }
                        foreach (var str in obj.ReticleList)
                        {
                            if (!ListReticle.Contains(str) && !str.Equals("*"))
                            {
                                ListReticle.Add(str);
                            }
                        }
                        foreach (var str in obj.PreToolList)
                        {
                            if (!ListPreTool.Contains(str) && !str.Equals("*"))
                            {
                                ListPreTool.Add(str);
                            }
                        }
                        foreach (var str in obj.PreReticleList)
                        {
                            if (!ListPreReticle.Contains(str) && !str.Equals("*"))
                            {
                                ListPreReticle.Add(str);
                            }
                        }
                    }

                    foreach (var obj in CPE_InitialSettingEntityList)
                    {
                        obj.ToolList = new List<string>(ListTool);
                        obj.ReticleList = new List<string>(ListReticle);
                        obj.PreToolList = new List<string>(ListPreTool);
                        obj.PreReticleList = new List<string>(ListPreReticle);
                    }

                    #region

                    cfgInitOvlCPESourceEntity = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(tableContent.Content_R2R_PH_CONFIG_INIT_OVL_CPE_Original);
                    cfgInitOvlCPEUpdateEntity = CfgSingleTableInfoHelp.GetUpdateSingleTableInfo(entity, ref dbR2R_PH_CONFIG_INIT_OVL_CPE_Source, ref dbR2R_PH_CONFIG_INIT_OVL_CPE_Update, ref cfgInitOvlCPEColumnNameList, ref cfgInitOvlCPEColumnKeyList);
                    #endregion
                }
                else
                {
                    flag = false;
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return flag;
        }
        /// <summary>
        /// Get the OVL PC SPEC configuration value
        /// </summary>
        /// <returns></returns>
        bool GetR2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_PC()
        {
            bool flag = false;
            try
            {
                PCImportExcelCheckEntityList = new List<ImportExcelCheckEntity>();
                PCLimitChuckEntityList = new List<PCLimitChuckEntity>();
                PC_SpecSettingEntityList = new List<PC_SpecSettingEntity>();
                if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                {
                    //System.Windows.Forms.MessageBox.Show("Please selected!");
                    return flag;
                }

                CfgGetSpecOvlPCResult tableContent = new CfgGetSpecOvlPCResult();
                tableContent = _SettingMainService.R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_PC(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, ToolVendor, OVLPCOVLMode,
                    OVLPCSpecVarName, OVLPCSpecVarSelect, OVLPCLslMetro, OVLPCUslMetro, OVLPCLslCalc, OVLPCUslCalc, OVLPCDeadband, OVLPCSpecMaxDelta);
                if (tableContent == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_PC Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return false;
                }

                if (string.IsNullOrEmpty(tableContent.ReturnCode))
                {
                    flag = false;
                }
                if (tableContent.ReturnCode.Equals("0") || tableContent.ReturnCode.Equals("1"))
                {
                    flag = true;
                    for (int i = 0; i < tableContent.OVL_PC_SPEC_VAR_SELECT.Count; i++)
                    {
                        if (tableContent.OVL_PC_SPEC_VAR_SELECT[i].ToUpper().Equals("Y"))
                        {
                            ImportExcelCheckEntity checkEntity = new ImportExcelCheckEntity();
                            checkEntity.Parameter = tableContent.OVL_PC_SPEC_VARNAME[i];
                            checkEntity.Max = tableContent.OVL_PC_USL_CALC[i];
                            checkEntity.Min = tableContent.OVL_PC_LSL_CALC[i];
                            checkEntity.ToolList = new List<string>(tableContent.LIST_TOOL);
                            PCImportExcelCheckEntityList.Add(checkEntity);
                        }


                        PC_SpecSettingEntity entity = new PC_SpecSettingEntity();
                        entity.Parameter = tableContent.OVL_PC_SPEC_VARNAME[i];
                        if (entity.Parameter.StartsWith("K"))
                        {
                            entity.Type = "iHOPC";
                            entity.SelectList = new List<string>() { "Y", "N" };
                        }
                        else if (entity.Parameter.StartsWith("Tx") || entity.Parameter.StartsWith("Ty"))
                        {
                            entity.Type = "HOPC";
                            entity.SelectList = new List<string>() { "Y", "N" };
                        }
                        else
                        {
                            entity.Type = "Linear";
                            entity.SelectList = new List<string>() { "Y" };
                        }
                        entity.Select = tableContent.OVL_PC_SPEC_VAR_SELECT[i];
                        entity.Deadband = tableContent.OVL_PC_DEADBAND[i].ToString();
                        entity.Max_Delta = tableContent.OVL_PC_SPEC_MAX_DELTA[i].ToString();
                        entity.USL_Calc = tableContent.OVL_PC_USL_CALC[i].ToString();
                        entity.LSL_Calc = tableContent.OVL_PC_LSL_CALC[i].ToString();
                        entity.USL_Metro = tableContent.OVL_PC_USL_METRO[i].ToString();
                        entity.LSL_Metro = tableContent.OVL_PC_LSL_METRO[i].ToString();
                        PC_SpecSettingEntityList.Add(entity);

                        PCLimitChuckEntity limitEntity = new PCLimitChuckEntity();
                        limitEntity.Parameter = tableContent.OVL_PC_SPEC_VARNAME[i];
                        limitEntity.Max = tableContent.OVL_PC_USL_CALC[i];
                        limitEntity.Min = tableContent.OVL_PC_LSL_CALC[i];
                        PCLimitChuckEntityList.Add(limitEntity);
                    }
                }
                else
                {
                    flag = false;
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return flag;
        }
        /// <summary>
        /// Get the OVL CPE SPEC configuration value
        /// </summary>
        /// <returns></returns>
        bool GetR2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_CPE()
        {
            bool flag = false;
            try
            {
                CPE_SpecSettingEntityList = new List<CPE_SpecSettingEntity>();
                if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                {
                    //System.Windows.Forms.MessageBox.Show("Please selected!");
                    return false;
                }

                CfgGetSpecOvlCPEResult tableContent = new CfgGetSpecOvlCPEResult();
                tableContent = _SettingMainService.R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_CPE(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, ToolVendor, OVLCPEOVLMode,
                                                        OVLCPESpecVarName, OVLCPELslCalc, OVLCPEUslCalc, OVLCPESpecMaxDelta);
                if (tableContent == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_CPE Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return false;
                }

                if (string.IsNullOrEmpty(tableContent.ReturnCode))
                {
                    flag = false;
                }
                if (tableContent.ReturnCode.Equals("0") || tableContent.ReturnCode.Equals("1"))
                {
                    flag = true;
                    for (int i = 0; i < tableContent.OVL_CPE_SPEC_VARNAME.Count; i++)
                    {
                        CPE_SpecSettingEntity entity = new CPE_SpecSettingEntity();
                        //entity.CPE_Type = ToolVendor;
                        entity.CPE_Type = OVLCPEOVLMode;
                        entity.Parameter = tableContent.OVL_CPE_SPEC_VARNAME[i];
                        entity.Max_Delta = tableContent.OVL_CPE_SPEC_MAX_DELTA[i].ToString();
                        entity.USL = tableContent.OVL_CPE_USL_CALC[i].ToString();
                        entity.LSL = tableContent.OVL_CPE_LSL_CALC[i].ToString();
                        CPE_SpecSettingEntityList.Add(entity);
                    }
                }
                else
                {
                    flag = false;
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return flag;
        }
        #endregion

        #region Clear Parameter Value
        /// <summary>
        /// Clear db
        /// </summary>
        void ClearDataTable()
        {
            dbInitValueSource = new DataTable();
            dbInitValueUpdate = new DataTable();
            dbInitValueSource = DataTableHelp.CreateInitDataTable();
            dbInitValueUpdate = dbInitValueSource.Clone();

            dbR2R_PH_CONFIG_COMMON = new DataTable();
            dbR2R_PH_CONFIG_LIS = new DataTable();
            dbR2R_PH_CONFIG_INIT_CD = new DataTable();
            dbR2R_PH_CONFIG_INIT_OVL_PC = new DataTable();
            dbR2R_PH_CONFIG_INIT_OVL_CPE = new DataTable();
            dbR2R_PH_CONFIG_SPEC_OVL_PC = new DataTable();
            dbR2R_PH_CONFIG_SPEC_OVL_CPE = new DataTable();

            cfgCommonUpdateEntity = new CfgSingleTableInfoEntity();
            cfgCommonColumnNameList = new List<string>();
            cfgCommonColumnKeyList = new List<string>();
            dbR2R_PH_CONFIG_COMMON_Source = new DataTable();
            dbR2R_PH_CONFIG_COMMON_Update = new DataTable();

            cfgLISUpdateEntity = new CfgSingleTableInfoEntity();
            cfgLISColumnNameList = new List<string>();
            cfgLISColumnKeyList = new List<string>();
            dbR2R_PH_CONFIG_LIS_Source = new DataTable();
            dbR2R_PH_CONFIG_LIS_Update = new DataTable();

            cfgInitCdUpdateEntity = new CfgSingleTableInfoEntity();
            cfgInitCdColumnNameList = new List<string>();
            cfgInitCdColumnKeyList = new List<string>();
            dbR2R_PH_CONFIG_INIT_CD_Source = new DataTable();
            dbR2R_PH_CONFIG_INIT_CD_Update = new DataTable();

            cfgInitOvlPCUpdateEntity = new CfgSingleTableInfoEntity();
            cfgInitOvlPCColumnNameList = new List<string>();
            cfgInitOvlPCColumnKeyList = new List<string>();
            dbR2R_PH_CONFIG_INIT_OVL_PC_Source = new DataTable();
            dbR2R_PH_CONFIG_INIT_OVL_PC_Update = new DataTable();

            cfgInitOvlCPEUpdateEntity = new CfgSingleTableInfoEntity();
            cfgInitOvlCPEColumnNameList = new List<string>();
            cfgInitOvlCPEColumnKeyList = new List<string>();
            dbR2R_PH_CONFIG_INIT_OVL_CPE_Source = new DataTable();
            dbR2R_PH_CONFIG_INIT_OVL_CPE_Update = new DataTable();
        }
        /// <summary>
        /// Clear CD Setting Value
        /// </summary>
        void ClearCDSetting()
        {
            IsCdSettingEnable = false;
            IsCdConfirmEnable = false;
            IsCdEditBtnClick = false;
            IsBtnCdInitialEnable = false;

            ClearCDParameterValue();
            CDR2RModeList = new List<string>();
        }
        /// <summary>
        /// Clear OVL PC Setting Value
        /// </summary>
        void ClearOVLPCSetting()
        {
            IsPCSettingEnable = false;
            IsPcConfirmEnable = false;
            IsPCEditBtnClick = false;
            IsBtnPcSpecEnable = false;
            IsBtnPcInitialEnable = false;

            if (!string.IsNullOrEmpty(ToolVendor))
            {
                if (ToolVendor.Equals("CANON"))
                {
                    IsLinearFlag = true;
                    IsHOPCEnableFlag = false;
                    IsIHOPCEnableFlag = false;
                }
            }

            ClearOVLPCParameterValue();

            //OVLPCR2RModeList = new List<string>();
            OVLPCOVLModeList = new List<string>();
            PCLimitChuckEntityList = new List<PCLimitChuckEntity>();
        }
        /// <summary>
        /// Clear OVL CPE Setting Value
        /// </summary>
        void ClearOVLCPESetting()
        {
            IsCPESettingEnable = false;
            IsCpeConfirmEnable = false;
            IsCPEEditBtnClick = false;
            IsBtnCpeSpecEnable = false;
            IsBtnCpeInitialEnable = false;

            if (!string.IsNullOrEmpty(ToolVendor))
            {
                if (ToolVendor.Equals("CANON"))
                {
                    IsCPEEditEnable = false;
                }

            }

            ClearOVLCPEParameterValue();
            //OVLCPER2RModeList = new List<string>();
            //OVLCPEOVLModeList = new List<string>();
        }
        /// <summary>
        /// Clear CD Parameter Value
        /// </summary>
        void ClearCDParameterValue()
        {
            #region by zqk add 2019 1230
            strCDTargetTmp = "";
            strExpireTimeTmp = "";
            strDoseMaxDeltaTmp = "";
            strDoseUSLTmp = "";
            strDoseLSLTmp = "";
            strCDLumdaTmp = "";
            #endregion

            #region CD
            CDR2RMode = "";
            CDTarget = "";
            //DoseSensitivity = "";
            ExpireTime = "";
            DoseMaxDelta = "";
            DoseUSL = "";
            DoseLSL = "";
            CDLumda = "";
            #endregion
        }
        /// <summary>
        /// Clear OVL PC Parameter Value
        /// </summary>
        void ClearOVLPCParameterValue()
        {
            #region OVL PC
            OVLPCR2RMode = "";
            OVLPCOVLMode = "";
            OVLPCSpecVarName = "";
            OVLPCSpecVarSelect = "N";
            OVLPCSpecMaxDelta = "";
            OVLPCDeadband = "";
            OVLPCUslCalc = "";
            OVLPCLslCalc = "";
            OVLPCUslMetro = "";
            OVLPCLslMetro = "";
            OVLPCExpireTime = "999999";
            OVLPCLumda = "0";
            OVLPCUpdateTime = "";
            OVLPCUpdateLot = "";
            OVLPCFeedforeward = "false";
            #endregion
        }
        /// <summary>
        /// Clear OVL CPE Parameter Value
        /// </summary>
        void ClearOVLCPEParameterValue()
        {
            #region OVL CPE
            OVLCPER2RMode = "";
            OVLCPEOVLMode = "";
            OVLCPESpecVarName = "";
            OVLCPESpecMaxDelta = "";
            OVLCPEUslCalc = "";
            OVLCPELslCalc = "";
            OVLCPEExpireTime = "999999";
            OVLCPELumda = "";
            OVLCPEUpdateTime = "";
            OVLCPEUpdateLot = "";
            OVLCPEFeedforeward = "false";
            OVLCPEFixEdge = "false";
            #endregion
        }
        /// <summary>
        /// Clear LIS Parameter Value
        /// </summary>
        void ClearLISParameterVlaue()
        {
            #region LIS
            LIS_UPDATE_TIME = "";
            LIS_UPDATE_LOT = "";
            SPARSE_SAMPLING = "";
            DENSE_SAMPLING = "";
            EST_SPARSE_RECIPE = "";
            EST_DENSE_RECIPE = "";
            OPTIMIZE_RECIPE = "";
            SAMPLING_TOOLTYPE = "";
            ESTI_KPI_OCAP = "";
            EXCEPTION_CNT = "";
            EXCEPTION_THRESHOLD = "";
            #endregion
        }
        #endregion

        #region Version Compare Field
        private bool _IsVersionCompareCheckFlag;
        public bool IsVersionCompareCheckFlag
        {
            get { return this._IsVersionCompareCheckFlag; }
            set { SetProperty(ref this._IsVersionCompareCheckFlag, value); }
        }

        private string _VersionCompareContent = "False";
        public string VersionCompareContent
        {
            get { return this._VersionCompareContent; }
            set { SetProperty(ref this._VersionCompareContent, value); }
        }

        private string _VersionNumber = "0";
        public string VersionNumber
        {
            get { return this._VersionNumber; }
            set { SetProperty(ref this._VersionNumber, value); }
        }

        private string _VersionCompareProduct;
        public string VersionCompareProduct
        {
            get { return this._VersionCompareProduct; }
            set { SetProperty(ref this._VersionCompareProduct, value); }
        }

        private string _VersionCompareLayer;
        public string VersionCompareLayer
        {
            get { return this._VersionCompareLayer; }
            set { SetProperty(ref this._VersionCompareLayer, value); }
        }

        private string _VersionCompareToolGroup;
        public string VersionCompareToolGroup
        {
            get { return this._VersionCompareToolGroup; }
            set { SetProperty(ref this._VersionCompareToolGroup, value); }
        }

        private List<string> _VersionCompareProductList;
        public List<string> VersionCompareProductList
        {
            get { return this._VersionCompareProductList; }
            set { SetProperty(ref this._VersionCompareProductList, value); }
        }

        private List<string> _VersionCompareLayerList;
        public List<string> VersionCompareLayerList
        {
            get { return this._VersionCompareLayerList; }
            set { SetProperty(ref this._VersionCompareLayerList, value); }
        }

        private List<string> _VersionCompareToolGroupList;
        public List<string> VersionCompareToolGroupList
        {
            get { return this._VersionCompareToolGroupList; }
            set { SetProperty(ref this._VersionCompareToolGroupList, value); }
        }
        #endregion

        #region Version Compare Fun
        void GetVersionCompareContext()
        {
            try
            {
                VersionCompareProduct = SelectedProductSetting.Product;
                VersionCompareLayer = SelectedProductSetting.Layer;
                VersionCompareToolGroup = SelectedProductSetting.ToolGroup;
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Version Compare Event 
        private DelegateCommand _VersionCompareCheckedCommand;
        public DelegateCommand VersionCompareCheckedCommand =>
            _VersionCompareCheckedCommand ?? (_VersionCompareCheckedCommand = new DelegateCommand(OnVersionCompareChecked));

        private DelegateCommand _BtnVersionCompareCommand;
        public DelegateCommand BtnVersionCompareCommand =>
            _BtnVersionCompareCommand ?? (_BtnVersionCompareCommand = new DelegateCommand(OnVersionCompareClick));
        #endregion

        #region Version Compare Event Fun
        void OnVersionCompareChecked()
        {
            try
            {
                if (IsVersionCompareCheckFlag)
                {
                    VersionCompareContent = "True";
                }
                else
                {
                    VersionCompareContent = "False";
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        void OnVersionCompareClick()
        {
            try
            {
                GetContextValuesVersionCompare();

                var window = new MetroWindow();//Windows窗体      
                VersionCompare view = new VersionCompare();
                VersionCompareViewModel viewModel = (VersionCompareViewModel)view.DataContext;
                viewModel.CurrentWindow = window;
                viewModel.IsBtnVersionCompareClickFlag = true;

                viewModel.ProductList = VersionCompareProductList;
                viewModel.LayerList = VersionCompareLayerList;
                viewModel.ToolGroupList = VersionCompareToolGroupList;

                viewModel.ConfigUI = ConfigUI;
                viewModel.Product = VersionCompareProduct;
                viewModel.Layer = VersionCompareLayer;
                viewModel.ToolGroup = VersionCompareToolGroup;

                window.Content = view;
                window.Title = "Version Compare";
                //window.Height = 760;
                //window.Width = 1560;
                window.WindowState = WindowState.Maximized;
                //window.ResizeMode = ResizeMode.NoResize;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Set single row save Field 
        bool flagSave = false;
        string strClickSaveMessage = "";

        private bool _IsBtnVersionCompareCheckEnable = true;
        public bool IsBtnVersionCompareCheckEnable
        {
            get { return this._IsBtnVersionCompareCheckEnable; }
            set { SetProperty(ref this._IsBtnVersionCompareCheckEnable, value); }
        }

        private bool _IsBtnVersionCompareEnable = false;
        public bool IsBtnVersionCompareEnable
        {
            get { return this._IsBtnVersionCompareEnable; }
            set { SetProperty(ref this._IsBtnVersionCompareEnable, value); }
        }

        private bool _IsBtnCopyProductEnable = true;
        public bool IsBtnCopyProductEnable
        {
            get { return this._IsBtnCopyProductEnable; }
            set { SetProperty(ref this._IsBtnCopyProductEnable, value); }
        }

        private bool _IsBtnSaveEnable = false;
        public bool IsBtnSaveEnable
        {
            get { return this._IsBtnSaveEnable; }
            set { SetProperty(ref this._IsBtnSaveEnable, value); }
        }

        private bool _IsBtnHistoryEnable = true;
        public bool IsBtnHistoryEnable
        {
            get { return this._IsBtnHistoryEnable; }
            set { SetProperty(ref this._IsBtnHistoryEnable, value); }
        }

        private bool _IsProductSettingButtonEnable = true;
        public bool IsProductSettingButtonEnable
        {
            get { return this._IsProductSettingButtonEnable; }
            set { SetProperty(ref this._IsProductSettingButtonEnable, value); }
        }

        private bool _IsProductSettingEnable = true;
        public bool IsProductSettingEnable
        {
            get { return this._IsProductSettingEnable; }
            set { SetProperty(ref this._IsProductSettingEnable, value); }
        }

        private bool _IsLayerSettingEnable = true;
        public bool IsLayerSettingEnable
        {
            get { return this._IsLayerSettingEnable; }
            set { SetProperty(ref this._IsLayerSettingEnable, value); }
        }
        #endregion

        #region Set single row save Fun
        void SetProductSettingBtnEnable()
        {
            IsEditModeEnable = false;
            IsViewOnlyEnable = false;
            IsBtnAddEnable = false;
        }

        /// <summary>
        /// Set Save Button Status
        /// </summary>
        void SetBtnSaveStatus()
        {
            if (IsCDEditOngoing || IsPCEditOngoing || IsCPEEditOngoing)
            {
                flagSave = false;
                IsBtnSaveEnable = false;

                IsProductSettingEnable = false;
                SetProductSettingBtnEnable();
            }
            else
            {
                flagSave = true;
                IsBtnSaveEnable = true;

                IsBtnVersionCompareCheckEnable = false;
                IsBtnVersionCompareEnable = false;
                IsBtnCopyProductEnable = false;

                IsProductSettingEnable = false;

                SetProductSettingBtnEnable();
                //IsProductSettingButtonEnable = false;
            }
        }
        void SetBtnSaveStatus(bool flag)
        {
            flagSave = flag;
            IsBtnSaveEnable = flag;
        }
        void SetSettingEnable(bool flagEnable)
        {
            IsBtnVersionCompareCheckEnable = flagEnable;
            IsBtnVersionCompareEnable = flagEnable;
            IsBtnCopyProductEnable = flagEnable;

            IsProductSettingEnable = flagEnable;
            IsProductSettingButtonEnable = flagEnable;
            IsLayerSettingEnable = flagEnable;
        }
        #endregion

        #region Set view status Field
        bool bIsDelete = false;
        bool flagCheckStatusError = false;
        string strCheckStatusErrorMessage = string.Empty;
        private string _CheckEditStatusMessage = "You are now in view mode";
        public string CheckEditStatusMessage
        {
            get { return this._CheckEditStatusMessage; }
            set { SetProperty(ref this._CheckEditStatusMessage, value); }
        }

        private string _QueryTime;
        public string QueryTime
        {
            get { return this._QueryTime; }
            set { SetProperty(ref this._QueryTime, value); }
        }

        private string _ConfigUI = "LITHO";
        public string ConfigUI
        {
            get { return this._ConfigUI; }
            set { SetProperty(ref this._ConfigUI, value); }
        }

        private string _CurrentAction;
        public string CurrentAction
        {
            get { return this._CurrentAction; }
            set { SetProperty(ref this._CurrentAction, value); }
        }

        private bool _IsEditModeEnable = true;
        public bool IsEditModeEnable
        {
            get { return this._IsEditModeEnable; }
            set { SetProperty(ref this._IsEditModeEnable, value); }
        }

        private bool _IsViewOnlyEnable = true;
        public bool IsViewOnlyEnable
        {
            get { return this._IsViewOnlyEnable; }
            set { SetProperty(ref this._IsViewOnlyEnable, value); }
        }

        private bool _IsEditModeChecked = false;
        public bool IsEditModeChecked
        {
            get { return this._IsEditModeChecked; }
            set { SetProperty(ref this._IsEditModeChecked, value); }
        }

        private bool _IsViewOnlyChecked = true;
        public bool IsViewOnlyChecked
        {
            get { return this._IsViewOnlyChecked; }
            set { SetProperty(ref this._IsViewOnlyChecked, value); }
        }

        private bool _IsBtnAddEnable = true;
        public bool IsBtnAddEnable
        {
            get { return this._IsBtnAddEnable; }
            set { SetProperty(ref this._IsBtnAddEnable, value); }
        }

        private bool _IsBtnEditEnable = true;
        public bool IsBtnEditEnable
        {
            get { return this._IsBtnEditEnable; }
            set { SetProperty(ref this._IsBtnEditEnable, value); }
        }

        private bool _IsBtnDeleteEnable = true;
        public bool IsBtnDeleteEnable
        {
            get { return this._IsBtnDeleteEnable; }
            set { SetProperty(ref this._IsBtnDeleteEnable, value); }
        }

        private bool _IsCDInitialEnable = true;
        public bool IsCDInitialEnable
        {
            get { return this._IsCDInitialEnable; }
            set { SetProperty(ref this._IsCDInitialEnable, value); }
        }

        private bool _IsPCSpecEnable = true;
        public bool IsPCSpecEnable
        {
            get { return this._IsPCSpecEnable; }
            set { SetProperty(ref this._IsPCSpecEnable, value); }
        }

        private bool _IsPCInitialEnable = true;
        public bool IsPCInitialEnable
        {
            get { return this._IsPCInitialEnable; }
            set { SetProperty(ref this._IsPCInitialEnable, value); }
        }

        private bool _IsCPESpecEnable = true;
        public bool IsCPESpecEnable
        {
            get { return this._IsCPESpecEnable; }
            set { SetProperty(ref this._IsCPESpecEnable, value); }
        }

        private bool _IsCPEInitialEnable = true;
        public bool IsCPEInitialEnable
        {
            get { return this._IsCPEInitialEnable; }
            set { SetProperty(ref this._IsCPEInitialEnable, value); }
        }
        #endregion

        #region Set view status Fun
        /// <summary>
        /// Set ProductSetting Status
        /// </summary>
        /// <param name="flagAdd"></param>
        /// <param name="flagEdit"></param>
        /// <param name="flagDelete"></param>
        /// <param name="flagSave"></param>
        /// <returns></returns>
        void SetProductSettingStatus(bool flagAdd, bool flagEdit, bool flagDelete, bool flagSave)
        {
            IsBtnAddEnable = flagAdd;
            IsBtnEditEnable = flagEdit;
            IsBtnDeleteEnable = flagDelete;
            //IsBtnSaveEnable = flagSave;
        }
        /// <summary>
        /// Set CD And OVL View Status 
        /// </summary>
        /// <param name="flag"></param>
        /// <returns></returns>
        void SetCDAndOVLViewStatus(bool flag)
        {
            IsCDInitialEnable = flag;
            IsPCSpecEnable = flag;
            IsPCInitialEnable = flag;
            IsCPESpecEnable = flag;
            IsCPEInitialEnable = flag;
        }
        /// <summary>
        /// Set CD And OVL Button Status 
        /// </summary>
        /// <param name="flag"></param>
        /// <returns></returns>
        void SetBtnCDAndOVLStatus(bool flag)
        {
            IsBtnCdInitialEnable = flag;
            IsBtnPcSpecEnable = flag;
            IsBtnPcInitialEnable = flag;
            IsBtnCpeSpecEnable = flag;
            IsBtnCpeInitialEnable = flag;
        }
        /// <summary>
        /// Set CD And OVL Edit Button Status 
        /// </summary>
        /// <param name="flag"></param>
        /// <returns></returns>
        void SetBtnCDAndOVLEditStatus(bool flag)
        {
            IsBtnCdEditEnable = flag;
            IsPCEditEnable = flag;
            IsCPEEditEnable = flag;
        }
        /// <summary>
        /// Set Confirm Button Status 
        /// </summary>
        /// <param name="flag"></param>
        /// <returns></returns>
        void SetBtnConfirmStatus(bool flag)
        {
            IsCdConfirmEnable = flag;
            IsPcConfirmEnable = flag;
            IsCpeConfirmEnable = flag;
        }
        /// <summary>
        /// Set View Status 
        /// </summary>
        /// <param name="flag"></param>
        /// <returns></returns>
        void SetViewStatus(int status)
        {
            //delete/edit/add
            if (status == 0x000)    //
            {
                CheckEditStatusMessage = "You are now in view mode";

                SetProductSettingStatus(true, false, false, false);

                SetBtnCDAndOVLEditStatus(false);
                SetBtnConfirmStatus(false);

                SetBtnCDAndOVLStatus(true);
                SetCDAndOVLViewStatus(false);
            }
            else if (status == 0x001)    // add
            {
                //IsBtnSaveEnable = true;
                IsBtnAddEnable = true;
                IsBtnEditEnable = false;
                IsBtnDeleteEnable = false;

                SetBtnCDAndOVLEditStatus(true);

                SetBtnCDAndOVLStatus(false);
                SetCDAndOVLViewStatus(true);
            }
            else if (status == 0x010)   // edit
            {
                SetProductSettingStatus(true, true, false, true);

                SetBtnCDAndOVLEditStatus(true);

                SetBtnCDAndOVLStatus(false);
                SetCDAndOVLViewStatus(true);
            }
            else if (status == 0x100)   // delete
            {
                SetProductSettingStatus(true, false, true, true);

                SetBtnCDAndOVLEditStatus(true);

                SetBtnCDAndOVLStatus(false);
                SetCDAndOVLViewStatus(true);
            }
            else if (status == 0x011)   // edit\add
            {
                SetProductSettingStatus(true, true, false, true);

                SetBtnCDAndOVLEditStatus(true);

                SetBtnCDAndOVLStatus(false);
                SetCDAndOVLViewStatus(true);
            }
            else if (status == 0x101)   // delete\add
            {
                SetProductSettingStatus(true, false, true, true);

                SetBtnCDAndOVLEditStatus(true);

                SetBtnCDAndOVLStatus(false);
                SetCDAndOVLViewStatus(true);
            }
            else if (status == 0x110)   // delete\edit
            {
                SetProductSettingStatus(true, true, true, true);

                SetBtnCDAndOVLEditStatus(true);

                SetBtnCDAndOVLStatus(false);
                SetCDAndOVLViewStatus(true);
            }
            else if (status == 0x111)   // delete\edit\add
            {
                CheckEditStatusMessage = "You are now in Edit mode";

                SetProductSettingStatus(true, true, true, false);

                SetBtnCDAndOVLEditStatus(true);

                SetBtnCDAndOVLStatus(false);
                SetCDAndOVLViewStatus(true);
            }

        }

        #endregion

        #region Set View Status Event
        private DelegateCommand _EditModeCheckedCommand;
        public DelegateCommand EditModeCheckedCommand =>
            _EditModeCheckedCommand ?? (_EditModeCheckedCommand = new DelegateCommand(OnEditModeChecked));

        private DelegateCommand _ViewOnlyCheckedCommand;
        public DelegateCommand ViewOnlyCheckedCommand =>
            _ViewOnlyCheckedCommand ?? (_ViewOnlyCheckedCommand = new DelegateCommand(OnViewOnlyChecked));
        #endregion

        #region Set View Status Event Fun
        bool IsProductSettingAdd = false;
        bool IsProductSettingEdit = false;
        void OnEditModeChecked()
        {
            try
            {
                if (IsEditModeChecked)
                {
                    if (IsProductSettingAdd || IsProductSettingEdit)
                    {
                        SetViewStatus(0x111);
                        IsProductSettingAdd = false;
                        IsProductSettingEdit = false;
                        return;
                    }
                    if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                    {
                        //System.Windows.Forms.MessageBox.Show("Please selected!");
                        return;
                    }

                    #region Check
                    bool isCheckOnly = true;
                    CurrentAction = "ToEdit";
                    string CurrentMode = "View";
                    //string CurrentMode = IsEditModeChecked ? "Edit":"View";
                    CfgEditStatusCheckResult checkResult = this._SettingMainService.R2R_UI_Config_EditStatusCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, QueryTime, isCheckOnly, ConfigUI, CurrentAction, CurrentMode);
                    if (checkResult == null)
                    {
                        string strMsg = "Invoke R2R_UI_Config_EditStatusCheck Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }
                    if (checkResult.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    else if (checkResult.ReturnCode.Equals("0"))
                    {

                    }
                    else if (checkResult.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    if (checkResult.InitMode.ToLower().Equals("edit"))
                    {
                        CheckEditStatusMessage = "You are now in Edit mode";
                        SetViewStatus(0x111);
                    }
                    else if (checkResult.InitMode.ToLower().Equals("view"))
                    {
                        CheckEditStatusMessage = "You are now in view mode ---- Occupied by other";
                        IsViewOnlyChecked = true;
                        SetViewStatus(0);
                    }
                    //else
                    //{
                    //    //view only
                    //    SetViewStatus(0x111);
                    //}
                    #endregion
                }
                else
                {
                    CheckEditStatusMessage = "You are now in view mode";
                    SetViewStatus(0);
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        void OnViewOnlyChecked()
        {
            try
            {
                if (bIsDelete)
                {
                    bIsDelete = false;
                    return;
                }

                if (IsViewOnlyChecked)
                {
                    if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                    {
                        //System.Windows.Forms.MessageBox.Show("Please selected!");
                        return;
                    }

                    #region Check
                    bool isCheckOnly = true;
                    CurrentAction = "ToView";
                    string CurrentMode = "Edit";
                    //string CurrentMode = IsEditModeChecked ? "Edit" : "View";
                    CfgEditStatusCheckResult checkResult = this._SettingMainService.R2R_UI_Config_EditStatusCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, QueryTime, isCheckOnly, ConfigUI, CurrentAction, CurrentMode);
                    if (checkResult == null)
                    {
                        string strMsg = "Invoke R2R_UI_Config_EditStatusCheck Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);

                        return;
                    }
                    if (checkResult.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    else if (checkResult.ReturnCode.Equals("0"))
                    {

                    }
                    else if (checkResult.ReturnCode.Equals("1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    if (checkResult.InitMode.ToLower().Equals("edit"))
                    {
                        IsEditModeChecked = true;
                        CheckEditStatusMessage = "You are now in Edit mode";
                        SetViewStatus(0x111);
                        return;
                    }
                    else if (checkResult.InitMode.ToLower().Equals("view"))
                    {
                        CheckEditStatusMessage = "You are now in view mode ---- Occupied by other";
                        SetViewStatus(0);
                    }
                    #endregion

                    #region Set Save Button
                    flagSave = false;
                    IsBtnSaveEnable = false;
                    #endregion
                }
                else
                {
                    //view only
                    SetViewStatus(0);
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        #endregion

        #region Get Product Info
        /// <summary>
        /// Get Product Setting List Value
        /// </summary>
        void GetProductSettingList()
        {
            try
            {
                #region Product
                AlignmentLayerList = DataTableHelp.GetColumnRecordToList(dbR2R_PH_CONFIG_COMMON_Source, "ALIGMENT_LAYER");
                AlignmentMethodList = DataTableHelp.GetColumnRecordToList(dbR2R_PH_CONFIG_COMMON_Source, "ALIAMENT_METHOD");
                PreLayer1List = DataTableHelp.GetColumnRecordToList(dbR2R_PH_CONFIG_COMMON_Source, "OVERLAY_LAYER");
                PreLayer2List = DataTableHelp.GetColumnRecordToList(dbR2R_PH_CONFIG_COMMON_Source, "PRELAYER_2");
                ChuckDedicationLayerList = DataTableHelp.GetColumnRecordToList(dbR2R_PH_CONFIG_COMMON_Source, "CHUCK_DEDICATION_LAYER");
                CascadePCLayerList = DataTableHelp.GetColumnRecordToList(dbR2R_PH_CONFIG_COMMON_Source, "CASCADE_PC_LAYER");
                CascadeCPELayerList = DataTableHelp.GetColumnRecordToList(dbR2R_PH_CONFIG_COMMON_Source, "CASCADE_CPE_LAYER");
                #endregion

                #region CD
                CDR2RModeList = DataTableHelp.GetColumnRecordToList(dbR2R_PH_CONFIG_COMMON_Source, "CD_R2R_MODE");
                #endregion

                #region OVL PC
                //OVLPCR2RModeList = DataTableHelp.GetDbColumnToList(dbR2R_PH_CONFIG_COMMON_Source, "OVL_PC_R2R_MODE");
                //OVLPCOVLModeList = DataTableHelp.GetDbColumnToList(dbR2R_PH_CONFIG_COMMON_Source, "OVL_PC_OVL_MODE");
                #endregion

                #region OVL CPE
                //OVLCPER2RModeList = DataTableHelp.GetDbColumnToList(dbR2R_PH_CONFIG_COMMON_Source, "OVL_CPE_R2R_MODE");
                //OVLCPEOVLModeList = DataTableHelp.GetDbColumnToList(dbR2R_PH_CONFIG_COMMON_Source, "OVL_CPE_OVL_MODE");
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Get Product Setting Value
        /// </summary>
        void GetProductSettingInfo()
        {
            try
            {
                #region
                //ProductSettingList.Clear();
                ProductSettingList = new ObservableCollection<ProductSettingEntity>();

                string strSelect = GetQuerySelect();
                //DataRow[] rows = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON, strSelect);
                DataRow[] rows = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strSelect);
                if (rows.Count() > 0)
                {
                    for (int i = 0; i < rows.Count(); i++)
                    {
                        #region Product
                        string strToolGroup = rows[i]["TOOL_GROUP"].ToString();
                        string strProduct = rows[i]["PRODUCT"].ToString();
                        string strLayer = rows[i]["LAYER"].ToString();
                        string strAlignmentLayer = rows[i]["ALIGMENT_LAYER"].ToString();
                        string strAlignmentMethod = rows[i]["ALIAMENT_METHOD"].ToString();
                        string strOverlayLayer = rows[i]["OVERLAY_LAYER"].ToString();
                        string strControlByChuck = rows[i]["CONTROL_BY_CHUCK"].ToString();
                        string strChuckDedication = rows[i]["CHUCK_DEDICATION"].ToString();
                        string strChuckDedicationLayer = rows[i]["CHUCK_DEDICATION_LAYER"].ToString();
                        if (strChuckDedicationLayer == null || strChuckDedicationLayer.Equals(""))
                        {
                            strChuckDedicationLayer = "NA";
                        }
                        string strCascadePCLayer = rows[i]["CASCADE_PC_LAYER"].ToString();
                        string strCascadeCPELayer = rows[i]["CASCADE_CPE_LAYER"].ToString();
                        string strPreOverlayLayer = rows[i]["PRELAYER_2"].ToString();
                        #endregion

                        ProductSettingEntity entityProduct = new ProductSettingEntity();
                        entityProduct.Product = strProduct;
                        entityProduct.Layer = strLayer;
                        entityProduct.ToolGroup = strToolGroup;
                        entityProduct.AlignmentLayer = strAlignmentLayer;
                        entityProduct.AlignmentMethod = strAlignmentMethod;
                        entityProduct.PreLayer1 = strOverlayLayer;
                        entityProduct.PreLayer2 = strPreOverlayLayer;
                        entityProduct.ControlByChuck = strControlByChuck.ToUpper().Equals("TRUE") ? "Y" : "N";
                        entityProduct.ChuckDedication = strChuckDedication.ToUpper().Equals("TRUE") ? "Y" : "N";
                        //entityProduct.ChuckDedication = strChuckDedication.Equals("3") ? "Y" : "N";
                        entityProduct.ChuckDedicationLayer = strChuckDedicationLayer;
                        entityProduct.CascadePCLayer = strCascadePCLayer;
                        entityProduct.CascadeCPELayer = strCascadeCPELayer;

                        if (!ProductSettingList.Contains(entityProduct))
                        {
                            ProductSettingList.Add(entityProduct);
                        }
                    }
                    var ProductSettingListSort = ProductSettingList.OrderBy(s => s.Product);
                    ProductSettingList = new ObservableCollection<ProductSettingEntity>(ProductSettingListSort);
                }
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Get LIS Info
        /// <summary>
        /// Get LIS Value
        /// </summary>
        void GetLISSettingInfo()
        {
            try
            {
                #region
                string strSelect = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                DataRow[] rows = DataTableHelp.Query(dbR2R_PH_CONFIG_LIS_Update, strSelect);
                if (rows.Count() > 0)
                {
                    for (int i = 0; i < 1; i++)
                    {
                        #region LIS
                        LIS_UPDATE_TIME = rows[i]["LIS_UPDATE_TIME"].ToString();
                        LIS_UPDATE_LOT = rows[i]["LIS_UPDATE_LOT"].ToString();
                        SPARSE_SAMPLING = rows[i]["SPARSE_SAMPLING"].ToString();
                        DENSE_SAMPLING = rows[i]["DENSE_SAMPLING"].ToString();
                        EST_SPARSE_RECIPE = rows[i]["EST_SPARSE_RECIPE"].ToString();
                        EST_DENSE_RECIPE = rows[i]["EST_DENSE_RECIPE"].ToString();
                        OPTIMIZE_RECIPE = rows[i]["OPTIMIZE_RECIPE"].ToString();
                        SAMPLING_TOOLTYPE = rows[i]["SAMPLING_TOOLTYPE"].ToString();
                        ESTI_KPI_OCAP = rows[i]["ESTI_KPI_OCAP"].ToString();
                        //EXCEPTION_CNT = rows[i]["EXCEPTION_CNT"].ToString();
                        //EXCEPTION_THRESHOLD = rows[i]["EXCEPTION_THRESHOLD"].ToString();
                        #endregion
                    }
                }
                else
                {
                    ClearLISParameterVlaue();
                }

                GetSendWaferParameter();
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Get Layer Info
        /// <summary>
        /// Get Layer Setting List Value
        /// </summary>
        void GetLayerSettingList()
        {
            try
            {
                #region CD
                CDR2RModeList = DataTableHelp.GetColumnRecordToList(dbR2R_PH_CONFIG_COMMON_Source, "CD_R2R_MODE");
                #endregion

                #region OVL PC
                //OVLPCR2RModeList = DataTableHelp.GetDbColumnToList(dbR2R_PH_CONFIG_COMMON_Source, "OVL_PC_R2R_MODE");
                OVLPCOVLModeList = DataTableHelp.GetColumnRecordToList(dbR2R_PH_CONFIG_COMMON_Source, "OVL_PC_OVL_MODE");
                #endregion

                #region OVL CPE
                //OVLCPER2RModeList = DataTableHelp.GetDbColumnToList(dbR2R_PH_CONFIG_COMMON_Source, "OVL_CPE_R2R_MODE");
                //OVLCPEOVLModeList = DataTableHelp.GetDbColumnToList(dbR2R_PH_CONFIG_COMMON_Source, "OVL_CPE_OVL_MODE");
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Get Layer Setting Value
        /// </summary>
        void GetLayerSettingInfo()
        {
            try
            {
                #region
                string strSelect = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                DataRow[] rows = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strSelect);
                if (rows.Count() > 0)
                {
                    for (int i = 0; i < 1; i++)
                    {
                        ToolVendor = rows[i]["TOOL_VENDOR"].ToString();

                        #region CD
                        CDR2RMode = rows[i]["CD_R2R_MODE"].ToString();
                        CDTarget = rows[i]["CD_TARGET"].ToString();
                        DoseSensitivity = rows[i]["DOSE_SENSITIVITY"].ToString();
                        ExpireTime = rows[i]["CD_EXPIRE_TIME"].ToString();
                        DoseMaxDelta = rows[i]["DOSE_MAX_DELTA"].ToString();
                        DoseUSL = rows[i]["DOSE_USL"].ToString();
                        DoseLSL = rows[i]["DOSE_LSL"].ToString();
                        CDLumda = rows[i]["CD_LUMDA"].ToString();
                        #endregion

                        #region OVL PC
                        OVLPCR2RMode = rows[i]["OVL_PC_R2R_MODE"].ToString();
                        OVLPCOVLMode = rows[i]["OVL_PC_OVL_MODE"].ToString();
                        IsLinearFlag = OVLPCOVLMode.ToUpper().Equals("LINEAR") ? true : false;
                        IsHOPCFlag = OVLPCOVLMode.ToUpper().Equals("HOPC") ? true : false;
                        IsIHOPCFlag = OVLPCOVLMode.ToUpper().Equals("IHOPC") ? true : false;
                        if (IsIHOPCFlag)
                        {
                            IsHOPCFlag = true;
                        }

                        OVL_PC_OOC_COUNT = rows[i]["OVL_PC_OOC_COUNT"].ToString();
                        OVL_PC_OOS_COUNT = rows[i]["OVL_PC_OOS_COUNT"].ToString();

                        OVLPCSpecVarName = rows[i]["OVL_PC_SPEC_VARNAME"].ToString();
                        OVLPCSpecVarSelect = rows[i]["OVL_PC_SPEC_VAR_SELECT"].ToString();
                        OVLPCSpecMaxDelta = rows[i]["OVL_PC_SPEC_MAX_DELTA"].ToString();
                        OVLPCDeadband = rows[i]["OVL_PC_DEADBAND"].ToString();
                        OVLPCUslCalc = rows[i]["OVL_PC_USL_CALC"].ToString();
                        OVLPCLslCalc = rows[i]["OVL_PC_LSL_CALC"].ToString();
                        OVLPCUslMetro = rows[i]["OVL_PC_USL_METRO"].ToString();
                        OVLPCLslMetro = rows[i]["OVL_PC_LSL_METRO"].ToString();
                        OVLPCExpireTime = rows[i]["OVL_PC_EXPIRE_TIME"].ToString();
                        OVLPCLumda = rows[i]["OVL_PC_LUMDA"].ToString();
                        OVLPCUpdateTime = rows[i]["OVL_PC_UPDATE_TIME"].ToString();
                        OVLPCUpdateLot = rows[i]["OVL_PC_UPDATE_LOT"].ToString();
                        OVLPCFeedforeward = rows[i]["OVL_PC_FEEDFOREWARD"].ToString();
                        OVLPCFeedforeward = OVLPCFeedforeward.Equals("") ? "false" : OVLPCFeedforeward;
                        #endregion

                        #region OVL CPE
                        OVL_CPE_OOC_COUNT = rows[i]["OVL_CPE_OOC_COUNT"].ToString();
                        OVL_CPE_OOS_COUNT = rows[i]["OVL_CPE_OOS_COUNT"].ToString();

                        OVLCPER2RMode = IsIHOPCFlag ? "NONE" : rows[i]["OVL_CPE_R2R_MODE"].ToString();

                        OVLCPEOVLMode = rows[i]["OVL_CPE_OVL_MODE"].ToString();

                        OVLCPESpecVarName = rows[i]["OVL_CPE_SPEC_VARNAME"].ToString();
                        OVLCPESpecMaxDelta = rows[i]["OVL_CPE_SPEC_MAX_DELTA"].ToString();
                        OVLCPEUslCalc = rows[i]["OVL_CPE_USL_CALC"].ToString();
                        OVLCPELslCalc = rows[i]["OVL_CPE_LSL_CALC"].ToString();
                        OVLCPEExpireTime = rows[i]["OVL_PC_EXPIRE_TIME"].ToString(); //rows[i]["OVL_CPE_EXPIRE_TIME"].ToString();
                        OVLCPELumda = rows[i]["OVL_CPE_LUMDA"].ToString();
                        OVLCPEUpdateTime = rows[i]["OVL_CPE_UPDATE_TIME"].ToString();
                        OVLCPEUpdateLot = rows[i]["OVL_CPE_UPDATE_LOT"].ToString();

                        OVLCPEFixEdge = rows[i]["OVL_CPE_FIX_EDGE"].ToString();
                        OVLCPEFixEdge = OVLCPEFixEdge.Equals("") ? "false" : OVLCPEFixEdge;

                        OVLCPEFeedforeward = rows[i]["OVL_CPE_FEEDFOREWARD"].ToString();
                        OVLCPEFeedforeward = OVLCPEFeedforeward.Equals("") ? "false" : OVLCPEFeedforeward;

                        IsPCEditEnable = OVLCPER2RMode.Equals("LIS") ? false : true;
                        #endregion

                        #region
                        string strListPcChecked = rows[i]["OVL_PC_DYNAMIC_CONTEXT"].ToString();
                        string strListCpeChecked = rows[i]["OVL_CPE_DYNAMIC_CONTEXT"].ToString();
                        string strListTool = rows[i]["LIST_TOOL"].ToString();
                        string strListReticle = rows[i]["LIST_RETICLE"].ToString();
                        string strListPreTool = rows[i]["LIST_PRE_TOOL"].ToString();
                        string strListPreReticle = rows[i]["LIST_PRE_RETICLE"].ToString();
                        //OvlInitToolList = new List<string>(strListTool.Split(','));
                        OvlInitReticleList = new List<string>(strListReticle.Split(','));
                        OvlInitPreToolList = new List<string>(strListPreTool.Split(','));
                        OvlInitPreReticleList = new List<string>(strListPreReticle.Split(','));
                        OvlCpeInitCheckedList = new List<string>(strListCpeChecked.Split(','));
                        #endregion
                    }
                }
                else
                {
                    ClearCDParameterValue();

                    ClearOVLPCParameterValue();
                    IsLinearFlag = false;
                    IsHOPCFlag = false;
                    IsIHOPCFlag = false;

                    ClearOVLCPEParameterValue();
                }
                #endregion

                GetSendWaferParameter();
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region LISSetting Field
        private string _LIS_UPDATE_TIME;
        public string LIS_UPDATE_TIME
        {
            get { return this._LIS_UPDATE_TIME; }
            set { SetProperty(ref this._LIS_UPDATE_TIME, value); }
        }
        private string _LIS_UPDATE_LOT;
        public string LIS_UPDATE_LOT
        {
            get { return this._LIS_UPDATE_LOT; }
            set { SetProperty(ref this._LIS_UPDATE_LOT, value); }
        }
        private string _SPARSE_SAMPLING;
        public string SPARSE_SAMPLING
        {
            get { return this._SPARSE_SAMPLING; }
            set { SetProperty(ref this._SPARSE_SAMPLING, value); }
        }
        private string _DENSE_SAMPLING;
        public string DENSE_SAMPLING
        {
            get { return this._DENSE_SAMPLING; }
            set { SetProperty(ref this._DENSE_SAMPLING, value); }
        }
        private string _EST_SPARSE_RECIPE;
        public string EST_SPARSE_RECIPE
        {
            get { return this._EST_SPARSE_RECIPE; }
            set { SetProperty(ref this._EST_SPARSE_RECIPE, value); }
        }
        private string _EST_DENSE_RECIPE;
        public string EST_DENSE_RECIPE
        {
            get { return this._EST_DENSE_RECIPE; }
            set { SetProperty(ref this._EST_DENSE_RECIPE, value); }
        }
        private string _OPTIMIZE_RECIPE;
        public string OPTIMIZE_RECIPE
        {
            get { return this._OPTIMIZE_RECIPE; }
            set { SetProperty(ref this._OPTIMIZE_RECIPE, value); }
        }
        private string _SAMPLING_TOOLTYPE;
        public string SAMPLING_TOOLTYPE
        {
            get { return this._SAMPLING_TOOLTYPE; }
            set { SetProperty(ref this._SAMPLING_TOOLTYPE, value); }
        }
        private string _ESTI_KPI_OCAP;
        public string ESTI_KPI_OCAP
        {
            get { return this._ESTI_KPI_OCAP; }
            set { SetProperty(ref this._ESTI_KPI_OCAP, value); }
        }
        private string _EXCEPTION_CNT;
        public string EXCEPTION_CNT
        {
            get { return this._EXCEPTION_CNT; }
            set { SetProperty(ref this._EXCEPTION_CNT, value); }
        }
        private string _EXCEPTION_THRESHOLD;
        public string EXCEPTION_THRESHOLD
        {
            get { return this._EXCEPTION_THRESHOLD; }
            set { SetProperty(ref this._EXCEPTION_THRESHOLD, value); }
        }
        #endregion

        #region ProductSetting Field
        bool IsProductSettingAddFlag = false;
        string CurrentEditProduct = "";
        string CurrentEditLayer = "";
        string CurrentEditToolGroup = "";

        private bool _IsSaveFlag = false;
        public bool IsSaveFlag
        {
            get { return this._IsSaveFlag; }
            set { SetProperty(ref this._IsSaveFlag, value); }
        }

        private bool _IsControlByChuckChangeFlag = false;
        public bool IsControlByChuckChangeFlag
        {
            get { return this._IsControlByChuckChangeFlag; }
            set { SetProperty(ref this._IsControlByChuckChangeFlag, value); }
        }
        private bool _IsGrdReadOnly = false;
        public bool IsGrdReadOnly
        {
            get { return this._IsGrdReadOnly; }
            set { SetProperty(ref this._IsGrdReadOnly, value); }
        }
        private bool _IsGrdEnable = true;
        public bool IsGrdEnable
        {
            get { return this._IsGrdEnable; }
            set { SetProperty(ref this._IsGrdEnable, value); }
        }

        private List<string> _CanonToolGroupList = new List<string>();
        public List<string> CanonToolGroupList
        {
            get { return this._CanonToolGroupList; }
            set { SetProperty(ref this._CanonToolGroupList, value); }
        }

        private bool _IsFirstQuery = true;
        public bool IsFirstQuery
        {
            get { return this._IsFirstQuery; }
            set { SetProperty(ref this._IsFirstQuery, value); }
        }

        private bool _IsSelectRowClick = false;
        public bool IsSelectRowClick
        {
            get { return this._IsSelectRowClick; }
            set { SetProperty(ref this._IsSelectRowClick, value); }
        }

        private int _SelectedRowIndex = -1;
        public int SelectedRowIndex
        {
            get { return this._SelectedRowIndex; }
            set { SetProperty(ref this._SelectedRowIndex, value); }
        }

        private string _Product;
        public string Product
        {
            get { return this._Product; }
            set { SetProperty(ref this._Product, value); }
        }

        private List<string> _ProductList = new List<string>();
        public List<string> ProductList
        {
            get { return this._ProductList; }
            set { SetProperty(ref this._ProductList, value); }
        }

        private string _Layer;
        public string Layer
        {
            get { return this._Layer; }
            set { SetProperty(ref this._Layer, value); }
        }

        private List<string> _LayerList = new List<string>();
        public List<string> LayerList
        {
            get { return this._LayerList; }
            set { SetProperty(ref this._LayerList, value); }
        }

        private string _ToolGroup;
        public string ToolGroup
        {
            get { return this._ToolGroup; }
            set { SetProperty(ref this._ToolGroup, value); }
        }

        private List<string> _ToolGroupList = new List<string>();
        public List<string> ToolGroupList
        {
            get { return this._ToolGroupList; }
            set { SetProperty(ref this._ToolGroupList, value); }
        }

        private string _ToolVendor;
        public string ToolVendor
        {
            get { return this._ToolVendor; }
            set { SetProperty(ref this._ToolVendor, value); }
        }

        private List<string> _ToolVendorList = new List<string>();
        public List<string> ToolVendorList
        {
            get { return this._ToolVendorList; }
            set { SetProperty(ref this._ToolVendorList, value); }
        }

        private bool _IsAlignmentLayerEnable;
        public bool IsAlignmentLayerEnable
        {
            get { return this._IsAlignmentLayerEnable; }
            set { SetProperty(ref this._IsAlignmentLayerEnable, value); }
        }

        private bool _IsAlignmentMethodEnable;
        public bool IsAlignmentMethodEnable
        {
            get { return this._IsAlignmentMethodEnable; }
            set { SetProperty(ref this._IsAlignmentMethodEnable, value); }
        }

        private string _AlignmentLayer;
        public string AlignmentLayer
        {
            get { return this._AlignmentLayer; }
            set { SetProperty(ref this._AlignmentLayer, value); }
        }

        private List<string> _AlignmentLayerList = new List<string>();
        public List<string> AlignmentLayerList
        {
            get { return this._AlignmentLayerList; }
            set { SetProperty(ref this._AlignmentLayerList, value); }
        }

        private string _AlignmentMethod;
        public string AlignmentMethod
        {
            get { return this._AlignmentMethod; }
            set { SetProperty(ref this._AlignmentMethod, value); }
        }

        private List<string> _AlignmentMethodList = new List<string>();
        public List<string> AlignmentMethodList
        {
            get { return this._AlignmentMethodList; }
            set { SetProperty(ref this._AlignmentMethodList, value); }
        }

        private string _PreLayer1;
        public string PreLayer1
        {
            get { return this._PreLayer1; }
            set { SetProperty(ref this._PreLayer1, value); }
        }

        private List<string> _PreLayer1List = new List<string>();
        public List<string> PreLayer1List
        {
            get { return this._PreLayer1List; }
            set { SetProperty(ref this._PreLayer1List, value); }
        }

        private string _PreLayer2;
        public string PreLayer2
        {
            get { return this._PreLayer2; }
            set { SetProperty(ref this._PreLayer2, value); }
        }

        private List<string> _PreLayer2List = new List<string>();
        public List<string> PreLayer2List
        {
            get { return this._PreLayer2List; }
            set { SetProperty(ref this._PreLayer2List, value); }
        }

        private string _CascadePCLayer;
        public string CascadePCLayer
        {
            get { return this._CascadePCLayer; }
            set { SetProperty(ref this._CascadePCLayer, value); }
        }

        private List<string> _CascadePCLayerList = new List<string>();
        public List<string> CascadePCLayerList
        {
            get { return this._CascadePCLayerList; }
            set { SetProperty(ref this._CascadePCLayerList, value); }
        }

        private string _CascadePELayer;
        public string CascadeCPELayer
        {
            get { return this._CascadePELayer; }
            set { SetProperty(ref this._CascadePELayer, value); }
        }

        private List<string> _CascadeCPELayerList = new List<string>();
        public List<string> CascadeCPELayerList
        {
            get { return this._CascadeCPELayerList; }
            set { SetProperty(ref this._CascadeCPELayerList, value); }
        }

        private string _ChuckDedicationLayer;
        public string ChuckDedicationLayer
        {
            get { return this._ChuckDedicationLayer; }
            set { SetProperty(ref this._ChuckDedicationLayer, value); }
        }

        private List<string> _ChuckDedicationLayerList = new List<string>();
        public List<string> ChuckDedicationLayerList
        {
            get { return this._ChuckDedicationLayerList; }
            set { SetProperty(ref this._ChuckDedicationLayerList, value); }
        }

        private string _ControlByChuck;
        public string ControlByChuck
        {
            get { return this._ControlByChuck; }
            set { SetProperty(ref this._ControlByChuck, value); }
        }

        private bool _IsControlByChuckYes;
        public bool IsControlByChuckYes
        {
            get { return this._IsControlByChuckYes; }
            set { SetProperty(ref this._IsControlByChuckYes, value); }
        }

        private bool __IsControlByChuckNo;
        public bool IsControlByChuckNo
        {
            get { return this.__IsControlByChuckNo; }
            set { SetProperty(ref this.__IsControlByChuckNo, value); }
        }

        private bool _IsControlByChuckEnable;
        public bool IsControlByChuckEnable
        {
            get { return this._IsControlByChuckEnable; }
            set { SetProperty(ref this._IsControlByChuckEnable, value); }
        }

        private string _ChuckDedication;
        public string ChuckDedication
        {
            get { return this._ChuckDedication; }
            set { SetProperty(ref this._ChuckDedication, value); }
        }

        private bool _IsChuckDedicationYes;
        public bool IsChuckDedicationYes
        {
            get { return this._IsChuckDedicationYes; }
            set { SetProperty(ref this._IsChuckDedicationYes, value); }
        }

        private bool _IsChuckDedicationNo;
        public bool IsChuckDedicationNo
        {
            get { return this._IsChuckDedicationNo; }
            set { SetProperty(ref this._IsChuckDedicationNo, value); }
        }

        private bool _IsChuckDedicationEnable;
        public bool IsChuckDedicationEnable
        {
            get { return this._IsChuckDedicationEnable; }
            set { SetProperty(ref this._IsChuckDedicationEnable, value); }
        }

        private ProductSettingEntity _SelectedProductSetting = new ProductSettingEntity();
        public ProductSettingEntity SelectedProductSetting
        {
            get { return this._SelectedProductSetting; }
            set { SetProperty(ref this._SelectedProductSetting, value); }
        }

        private ObservableCollection<ProductSettingEntity> _ProductSettingList = new ObservableCollection<ProductSettingEntity>();
        public ObservableCollection<ProductSettingEntity> ProductSettingList
        {
            get { return _ProductSettingList; }
            set { SetProperty(ref _ProductSettingList, value); }
        }
        #endregion

        #region ProductSetting Event Define
        private DelegateCommand _ProductSettingMouseLeftButtonUpCommand;
        public DelegateCommand ProductSettingMouseLeftButtonUpCommand =>
            _ProductSettingMouseLeftButtonUpCommand ?? (_ProductSettingMouseLeftButtonUpCommand = new DelegateCommand(OnProductSettingMouseLeftButtonUp));

        private DelegateCommand _ProductSelectionChangedCommand;
        public DelegateCommand ProductSelectionChangedCommand =>
            _ProductSelectionChangedCommand ?? (_ProductSelectionChangedCommand = new DelegateCommand(OnProductSelectionChanged));

        private DelegateCommand _LayerSelectionChangedCommand;
        public DelegateCommand LayerSelectionChangedCommand =>
            _LayerSelectionChangedCommand ?? (_LayerSelectionChangedCommand = new DelegateCommand(OnLayerSelectionChanged));

        private DelegateCommand _ToolGropSelectionChangedCommand;
        public DelegateCommand ToolGropSelectionChangedCommand =>
            _ToolGropSelectionChangedCommand ?? (_ToolGropSelectionChangedCommand = new DelegateCommand(OnToolGropSelectionChanged));

        private DelegateCommand _SelectRowClickCommand;
        public DelegateCommand SelectRowClickCommand =>
            _SelectRowClickCommand ?? (_SelectRowClickCommand = new DelegateCommand(OnSelectRowClick));

        private DelegateCommand _BtnQueryCommand;
        public DelegateCommand BtnQueryCommand =>
            _BtnQueryCommand ?? (_BtnQueryCommand = new DelegateCommand(OnQueryClick));

        private DelegateCommand _BtnAddCommand;
        public DelegateCommand BtnAddCommand =>
            _BtnAddCommand ?? (_BtnAddCommand = new DelegateCommand(OnAddClick));

        private DelegateCommand _BtnEditCommand;
        public DelegateCommand BtnEditCommand =>
            _BtnEditCommand ?? (_BtnEditCommand = new DelegateCommand(OnEditClick));

        private DelegateCommand _BtnDeleteCommand;
        public DelegateCommand BtnDeleteCommand =>
            _BtnDeleteCommand ?? (_BtnDeleteCommand = new DelegateCommand(OnDeleteClick));

        private DelegateCommand _BtnCopyProdCommand;
        public DelegateCommand BtnCopyProdCommand =>
            _BtnCopyProdCommand ?? (_BtnCopyProdCommand = new DelegateCommand(OnCopyProdClick));

        private DelegateCommand _BtnImportCommand;
        public DelegateCommand BtnImportCommand =>
            _BtnImportCommand ?? (_BtnImportCommand = new DelegateCommand(OnImportClick));

        private DelegateCommand _BtnExportCommand;
        public DelegateCommand BtnExportCommand =>
            _BtnExportCommand ?? (_BtnExportCommand = new DelegateCommand(OnExportClick));

        private DelegateCommand _BtnFixedEdgeShotCommand;
        public DelegateCommand BtnFixedEdgeShotCommand =>
            _BtnFixedEdgeShotCommand ?? (_BtnFixedEdgeShotCommand = new DelegateCommand(OnFixedEdgeShotClick));

        private DelegateCommand _BtnSaveCommand;
        public DelegateCommand BtnSaveCommand =>
            _BtnSaveCommand ?? (_BtnSaveCommand = new DelegateCommand(OnSaveClick));

        private DelegateCommand _BtnConfirmCommand;
        public DelegateCommand BtnConfirmCommand =>
            _BtnConfirmCommand ?? (_BtnConfirmCommand = new DelegateCommand(OnConfirmClick));
        #endregion

        #region ProductSetting Event Fun
        /// <summary>
        /// ProductSetting DataGrid MouseLeftButtonUp Event Fun
        /// </summary>
        void OnProductSettingMouseLeftButtonUp()
        {
            try
            {
                if (IsCDEditOngoing || IsPCEditOngoing || IsCPEEditOngoing)
                {
                    if (IsCDEditOngoing)
                    {
                        string strMsg = "Please complete the CD editing!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }
                    else if (IsPCEditOngoing)
                    {
                        string strMsg = "Please complete the PC editing!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }
                    else if (IsCPEEditOngoing)
                    {
                        string strMsg = "Please complete the CPE editing!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }

                    foreach (var obj in ProductSettingList)
                    {
                        if (obj.Product.Equals(CurrentEditProduct) && obj.Layer.Equals(CurrentEditLayer) && obj.ToolGroup.Equals(CurrentEditToolGroup))
                        {
                            SelectedProductSetting = obj;
                            break;
                        }
                    }
                    return;
                }
                else
                {
                    if (flagCheckStatusError)
                    {
                        MyLogger.Trace("Message :: " + strCheckStatusErrorMessage);
                        System.Windows.Forms.MessageBox.Show(strCheckStatusErrorMessage);
                        return;
                    }

                    #region Set Save Button
                    if (flagSave)
                    {
                        //SetSettingEnable(false);
                        foreach (var obj in ProductSettingList)
                        {
                            if (obj.Product.Equals(CurrentEditProduct) && obj.Layer.Equals(CurrentEditLayer) && obj.ToolGroup.Equals(CurrentEditToolGroup))
                            {
                                SelectedProductSetting = obj;
                                break;
                            }
                        }

                        MyLogger.Trace("Message :: " + strClickSaveMessage);
                        System.Windows.Forms.MessageBox.Show(strClickSaveMessage);
                        return;
                    }
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        #region old
        /// <summary>
        /// Product ComboBox SelectionChanged Event Fun
        /// </summary>
        void OnProductSelectionChanged()
        {
            try
            {
                //LayerList.Clear();
                //ToolGroupList.Clear();
                //DataRow[] query = dbContextValue.Select("Product = '" + Product + "'");
                //if (Product.Equals("*"))
                //{
                //    query = dbContextValue.Select();
                //}
                //for (int i = 0; i < query.Length; i++)
                //{
                //    LayerList.Add(query[i]["Layer"].ToString());
                //}
                //LayerList = LayerList.Distinct().ToList();

                ////var query = from p in dbContextValue.AsEnumerable()
                ////            where p.Field<string>(dbContextValue.Columns["Product"]) == Product
                ////            select p.Field<string>(dbContextValue.Columns["Layer"]);
                ////LayerList = query.Distinct().ToList();

                //if (!LayerList.Contains("*"))
                //{
                //    LayerList.Add("*");
                //}

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Layer ComboBox SelectionChanged Event Fun
        /// </summary>
        void OnLayerSelectionChanged()
        {
            try
            {
                //ToolGroupList.Clear();
                //ToolVendorList.Clear();
                //DataRow[] query = dbContextValue.Select("Product = '" + Product + " ' and Layer = '" +Layer + "'");
                //if (Layer.Equals("*"))
                //{
                //    query = dbContextValue.Select();
                //}
                //for (int i = 0; i < query.Length; i++)
                //{
                //    ToolGroupList.Add(query[i]["ToolGroup"].ToString());
                //}
                //ToolGroupList = ToolGroupList.Distinct().ToList();

                ////var query = from p in dbContextValue.AsEnumerable()
                ////            where p.Field<string>(dbContextValue.Columns["Product"]) == Product && p.Field<string>(dbContextValue.Columns["Layer"]) == Layer
                ////            select p.Field<string>(dbContextValue.Columns["ToolGroup"]);
                ////ToolGroupList = query.Distinct().ToList();

                //if (!ToolGroupList.Contains("*"))
                //{
                //    ToolGroupList.Add("*");
                //}
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ToolGroup ComboBox SelectionChanged Event Fun
        /// </summary>
        void OnToolGropSelectionChanged()
        {
            try
            {
                //ToolVendorList.Clear();
                //DataRow[] query = dbContextValue.Select("Product = '" + Product + " ' and Layer = '" + Layer + "' and ToolGroup = '" + ToolGroup + "'");

                //for (int i = 0; i < query.Length; i++)
                //{
                //    ToolVendorList.Add(query[i]["ToolVendor"].ToString());
                //}
                //ToolVendorList = ToolVendorList.Distinct().ToList();

                ////var query = from p in dbContextValue.AsEnumerable()
                ////            where p.Field<string>(dbContextValue.Columns["Product"]) == Product && p.Field<string>(dbContextValue.Columns["Layer"]) == Layer && p.Field<string>(dbContextValue.Columns["ToolGroup"]) == ToolGroup
                ////            select p.Field<string>(dbContextValue.Columns["ToolVendor"]);
                ////ToolVendorList = query.Distinct().ToList();

                //if (ToolVendorList.Count > 0)
                //{
                //    ToolVendor = ToolVendorList[0];
                //}
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        /// <summary>
        /// ProductSetting DataGrid SelectRow Event Fun
        /// </summary>
        void OnSelectRowClick()
        {
            try
            {
                if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                {
                    //System.Windows.Forms.MessageBox.Show("Please selected!");
                    return;
                }
                if (IsCDEditOngoing || IsPCEditOngoing || IsCPEEditOngoing)
                {
                    return;
                }

                #region Set Save Button
                if (flagSave)
                {
                    strClickSaveMessage = "Please save the data!";
                    return;
                }
                #endregion

                #region Version Compare
                GetVersionCompareContext();
                #endregion

                ToolVendor = GetToolVendor(SelectedProductSetting.ToolGroup);

                ClearCDSetting();
                ClearOVLPCSetting();
                ClearOVLCPESetting();

                GetProductSettingList();
                GetLayerSettingList();
                GetLayerSettingInfo();
                GetLISSettingInfo();
                GetSendWaferParameter();

                OnOVLPCR2RModeSelectionChanged();
                OnCPER2RModeSelectionChanged();
                IsSelectRowClick = true;

                if (IsProductSettingAddFlag)
                {
                    //IsCDEditOngoing = true;
                    //IsPCEditOngoing = true;
                    //IsCPEEditOngoing = true;
                }

                if (IsOVLPCChangeFlag)
                {
                }
                else
                {
                    CurrentOVLPCR2RMode = OVLPCR2RMode;
                    CurrentOVLPCOVLMode = OVLPCOVLMode;
                }
                if (IsOVLCPEChangeFlag)
                {
                }
                else
                {
                    CurrentOVLCPER2RMode = OVLCPER2RMode;
                    CurrentOVLCPEOVLMode = OVLCPEOVLMode;
                }

                IsEditModeEnable = true;
                IsViewOnlyEnable = true;

                #region Check
                flagCheckStatusError = false;
                bool isCheckOnly = true;
                CurrentAction = "Switch";
                string CurrentMode = IsEditModeChecked ? "Edit" : "View";
                CfgEditStatusCheckResult checkResult = this._SettingMainService.R2R_UI_Config_EditStatusCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, QueryTime, isCheckOnly, ConfigUI, CurrentAction, CurrentMode);
                if (checkResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_EditStatusCheck Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (checkResult.ReturnCode.Equals("-1"))
                {
                    flagCheckStatusError = true;
                    strCheckStatusErrorMessage = checkResult.ReturnText;
                    //System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    return;
                }
                else if (checkResult.ReturnCode.Equals("0"))
                {

                }
                else if (checkResult.ReturnCode.Equals("1"))
                {
                    flagCheckStatusError = true;
                    strCheckStatusErrorMessage = checkResult.ReturnText;
                    //System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                if (checkResult.InitMode.ToLower().Equals("edit"))
                {
                    IsEditModeChecked = true;
                    CheckEditStatusMessage = "You are now in Edit mode";
                    SetViewStatus(0x111);
                }
                else if (checkResult.InitMode.ToLower().Equals("view"))
                {
                    IsViewOnlyChecked = true;
                    CheckEditStatusMessage = "You are now in view mode";
                    SetViewStatus(0);
                }

                //else
                //{
                //    //view only
                //    SetViewStatus(0);
                //}
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ProductSetting Query Button Click Event Fun
        /// </summary>
        void OnQueryClick()
        {
            try
            {
                #region Set Save Button
                SetBtnSaveStatus(false);
                SetSettingEnable(true);
                #endregion

                IsSelectRowClick = false;
                if (string.IsNullOrEmpty(Product) || string.IsNullOrEmpty(Layer) || string.IsNullOrEmpty(ToolGroup))
                {
                    System.Windows.Forms.MessageBox.Show("Product/Layer/ToolGroup can not null!");
                    return;
                }


                if (IsFirstQuery)
                {
                    ClearCDSetting();
                    ClearOVLPCSetting();
                    ClearOVLCPESetting();

                    ShowWaferModeView("PC_None");
                    ShowCPEModeView("CPE_None");

                    QueryGetCfgCommonTable();
                    GetProductSettingList();
                    GetProductSettingInfo();
                }
                else
                {
                    if (IsSaveFlag)
                    {
                        System.Windows.Forms.MessageBox.Show("The data will refresh!");
                        ClearDataTable();
                        ClearCDSetting();
                        ClearOVLPCSetting();
                        ClearOVLCPESetting();

                        ShowWaferModeView("PC_None");
                        ShowCPEModeView("CPE_None");

                        QueryGetCfgCommonTable();
                        GetProductSettingList();
                        GetProductSettingInfo();
                        IsSaveFlag = false;
                    }
                    else
                    {
                        if (System.Windows.Forms.MessageBox.Show("The data will refresh!", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {
                            ClearDataTable();
                            ClearCDSetting();
                            ClearOVLPCSetting();
                            ClearOVLCPESetting();

                            ShowWaferModeView("PC_None");
                            ShowCPEModeView("CPE_None");

                            QueryGetCfgCommonTable();
                            GetProductSettingList();
                            GetProductSettingInfo();
                        }
                        else
                        {
                            return;
                        }
                    }
                }

                IsGrdEnable = true;
                IsGrdReadOnly = true;
                IsControlByChuckChangeFlag = false;
                IsCDEditOngoing = false;
                IsPCEditOngoing = false;
                IsCPEEditOngoing = false;
                IsProductSettingAddFlag = false;
                IsOVLPCChangeFlag = false;
                IsOVLCPEChangeFlag = false;

                CurrentEditProduct = "";
                CurrentEditLayer = "";
                CurrentEditToolGroup = "";
                CurrentOVLPCR2RMode = "";
                CurrentOVLPCOVLMode = "";
                CurrentOVLCPER2RMode = "";
                CurrentOVLCPEOVLMode = "";

                IsFirstQuery = false;

                #region
                bool falgResult = this._SettingMainService.R2R_UI_Config_ClearEditOccupy(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, ConfigUI);
                if (falgResult)
                {
                }
                #endregion

                QueryTime = CommonHelp.GetQueryTime();
                IsViewOnlyChecked = true;
                CheckEditStatusMessage = "You are now in view mode";
                SetViewStatus(0);
                SetBtnCDAndOVLStatus(false);
                IsEditModeEnable = false;
                IsViewOnlyEnable = false;
                IsViewOnlyChecked = true;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ProductSetting Add Button Click Event Fun
        /// </summary>
        void OnAddClick()
        {
            try
            {
                if (string.IsNullOrEmpty(Product) || string.IsNullOrEmpty(Layer) || string.IsNullOrEmpty(ToolGroup))
                {
                    System.Windows.Forms.MessageBox.Show("Product/Layer/ToolGroup can not null!");
                    return;
                }

                #region
                if (IsCDEditOngoing || IsPCEditOngoing || IsCPEEditOngoing)
                {
                    if (IsCDEditOngoing)
                    {
                        System.Windows.Forms.MessageBox.Show("Please complete the CD editing!");
                    }
                    else if (IsPCEditOngoing)
                    {
                        System.Windows.Forms.MessageBox.Show("Please complete the PC editing!");
                    }
                    else if (IsCPEEditOngoing)
                    {
                        System.Windows.Forms.MessageBox.Show("Please complete the CPE editing!");
                    }

                    foreach (var obj in ProductSettingList)
                    {
                        if (obj.Product.Equals(CurrentEditProduct) && obj.Layer.Equals(CurrentEditLayer) && obj.ToolGroup.Equals(CurrentEditToolGroup))
                        {
                            SelectedProductSetting = obj;
                            break;
                        }
                    }
                    return;
                }
                #endregion

                CurrentEditProduct = "";
                CurrentEditLayer = "";
                CurrentEditToolGroup = "";

                var window = new MetroWindow();//Windows窗体      
                ProductSetting view = new ProductSetting();
                ProductSettingViewModel viewModel = (ProductSettingViewModel)view.DataContext;

                List<string> strListProduct = new List<string>(ProductList);
                strListProduct.Remove("*");

                List<string> strListLayer = new List<string>(LayerList);
                strListLayer.Remove("*");

                List<string> strListToolGroup = new List<string>(ToolGroupList);
                strListToolGroup.Remove("*");
                strListToolGroup.Remove("KT");
                strListToolGroup.Remove("YS");

                ChuckDedicationLayerList = new List<string>(strListLayer);
                PreLayer1List = new List<string>(strListLayer);
                PreLayer2List = new List<string>(strListLayer);
                CascadePCLayerList = new List<string>(strListLayer);
                CascadeCPELayerList = new List<string>(strListLayer);
                AlignmentLayerList = new List<string>(strListLayer);

                AlignmentLayerList.Remove("");
                ChuckDedicationLayerList.Remove("");
                PreLayer1List.Remove("");
                CascadePCLayerList.Remove("");
                CascadeCPELayerList.Remove("");
                PreLayer2List.Remove("");

                viewModel.CurrentWindow = window;
                viewModel.ProductList = strListProduct;
                viewModel.LayerList = strListLayer;
                viewModel.ToolGroupList = strListToolGroup;
                viewModel.AlignmentLayerList = AlignmentLayerList;
                viewModel.AlignmentMethodList = AlignmentMethodList;
                viewModel.OverlayLayerList = PreLayer1List;
                viewModel.ChuckDedicationLayerList = ChuckDedicationLayerList;
                viewModel.CascadePCLayerList = CascadePCLayerList;
                viewModel.CascadeCPELayerList = CascadeCPELayerList;
                viewModel.PreOverlayLayerList = PreLayer2List;

                viewModel.IsProductEnable = true;
                viewModel.IsLayerEnable = true;
                viewModel.IsProductEditable = true;
                viewModel.IsLayerEditable = true;
                viewModel.IsToolGroupEnable = true;

                viewModel.IsAlignmentLayerEnable = true;
                viewModel.IsAlignmentMethodEnable = false;

                viewModel.CanonToolGroupList = new List<string>(CanonToolGroupList);

                if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                {

                    viewModel.Product = Product.Equals("*") ? "" : Product;
                    viewModel.Layer = Layer.Equals("*") ? "" : Layer;
                    viewModel.ToolGroup = ToolGroup.Equals("*") ? "" : ToolGroup;
                    viewModel.AlignmentLayer = "";
                    viewModel.AlignmentMethod = "";
                    viewModel.OverlayLayer = "";
                    viewModel.ChuckDedicationLayer = "";
                    viewModel.CascadePCLayer = "";
                    viewModel.PreOverlayLayer = "";
                    viewModel.CascadeCPELayer = "";

                    if (ToolVendor.ToUpper().Equals("CANON"))
                    {
                        viewModel.IsControlByChuckEnable = false;
                        viewModel.IsControlByChuckYes = false;
                        viewModel.IsControlByChuckNo = true;

                        viewModel.IsChuckDedicationEnable = false;
                        viewModel.IsChuckDedicationYes = false;
                        viewModel.IsChuckDedicationNo = true;
                        viewModel.IsChuckDedicationLayerEnable = false;
                    }

                    else
                    {
                        viewModel.IsControlByChuckEnable = true;
                        viewModel.IsControlByChuckYes = true;
                        viewModel.IsControlByChuckNo = false;

                        viewModel.IsChuckDedicationEnable = true;
                        viewModel.IsChuckDedicationYes = true;
                        viewModel.IsChuckDedicationNo = false;
                        viewModel.IsChuckDedicationLayerEnable = true;
                    }

                }
                else
                {
                    if (ToolVendor.ToUpper().Equals("CANON"))
                    {
                        viewModel.IsControlByChuckEnable = false;
                        viewModel.IsControlByChuckYes = false;
                        viewModel.IsControlByChuckNo = true;

                        viewModel.IsChuckDedicationEnable = false;
                        viewModel.IsChuckDedicationYes = false;
                        viewModel.IsChuckDedicationNo = true;
                        viewModel.IsChuckDedicationLayerEnable = false;
                    }
                    else
                    {
                        viewModel.IsControlByChuckEnable = true;
                        if (SelectedProductSetting.ChuckDedication != null && SelectedProductSetting.ControlByChuck.ToUpper().Equals("Y"))
                        {
                            viewModel.IsControlByChuckYes = true;
                            viewModel.IsControlByChuckNo = false;
                        }
                        else
                        {
                            viewModel.IsControlByChuckYes = false;
                            viewModel.IsControlByChuckNo = true;
                        }

                        viewModel.IsChuckDedicationEnable = true;
                        if (SelectedProductSetting.ChuckDedication != null && SelectedProductSetting.ChuckDedication.ToUpper().Equals("Y"))
                        {
                            viewModel.IsChuckDedicationYes = true;
                            viewModel.IsChuckDedicationNo = false;
                            viewModel.IsChuckDedicationLayerEnable = true;
                        }
                        else
                        {
                            viewModel.IsChuckDedicationYes = false;
                            viewModel.IsChuckDedicationNo = true;
                            viewModel.IsChuckDedicationLayerEnable = false;
                        }
                    }


                    if (!ChuckDedicationLayerList.Contains(SelectedProductSetting.ChuckDedicationLayer))
                    {
                        ChuckDedicationLayerList.Add(SelectedProductSetting.ChuckDedicationLayer);
                    }
                    if (!AlignmentLayerList.Contains(SelectedProductSetting.AlignmentLayer))
                    {
                        AlignmentLayerList.Add(SelectedProductSetting.AlignmentLayer);
                    }
                    if (!PreLayer1List.Contains(SelectedProductSetting.PreLayer1))
                    {
                        PreLayer1List.Add(SelectedProductSetting.PreLayer1);
                    }
                    if (!PreLayer2List.Contains(SelectedProductSetting.PreLayer2))
                    {
                        PreLayer2List.Add(SelectedProductSetting.PreLayer2);
                    }
                    if (!CascadePCLayerList.Contains(SelectedProductSetting.CascadePCLayer))
                    {
                        CascadePCLayerList.Add(SelectedProductSetting.CascadePCLayer);
                    }
                    if (!CascadeCPELayerList.Contains(SelectedProductSetting.CascadeCPELayer))
                    {
                        CascadeCPELayerList.Add(SelectedProductSetting.CascadeCPELayer);
                    }

                    viewModel.OverlayLayerList = PreLayer1List;
                    viewModel.ChuckDedicationLayerList = ChuckDedicationLayerList;
                    viewModel.CascadePCLayerList = CascadePCLayerList;
                    viewModel.CascadeCPELayerList = CascadeCPELayerList;
                    viewModel.PreOverlayLayerList = PreLayer2List;

                    viewModel.Product = SelectedProductSetting.Product;
                    viewModel.Layer = SelectedProductSetting.Layer;
                    viewModel.ToolGroup = SelectedProductSetting.ToolGroup;
                    viewModel.AlignmentLayer = SelectedProductSetting.AlignmentLayer;
                    viewModel.AlignmentMethod = SelectedProductSetting.AlignmentMethod;
                    viewModel.OverlayLayer = SelectedProductSetting.PreLayer1;
                    viewModel.ChuckDedicationLayer = SelectedProductSetting.ChuckDedicationLayer;
                    viewModel.CascadePCLayer = SelectedProductSetting.CascadePCLayer;
                    viewModel.PreOverlayLayer = SelectedProductSetting.PreLayer2;
                    viewModel.CascadeCPELayer = SelectedProductSetting.CascadeCPELayer;
                }

                window.Content = view;
                window.Title = "Product Add Setting";
                window.Height = 520;
                window.Width = 480;
                //window.ResizeMode = ResizeMode.NoResize;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();

                if (viewModel.IsBtnOkClick)
                {
                    #region Check
                    bool isCheckOnly = false;
                    CurrentAction = "Add";
                    string CurrentMode = IsEditModeChecked ? "Edit" : "View";
                    if (string.IsNullOrEmpty(QueryTime))
                    {
                        QueryTime = CommonHelp.GetQueryTime();
                    }
                    CfgEditStatusCheckResult checkResult = this._SettingMainService.R2R_UI_Config_EditStatusCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, viewModel.Product, viewModel.Layer, viewModel.ToolGroup, QueryTime, isCheckOnly, ConfigUI, CurrentAction, CurrentMode);
                    if (checkResult == null)
                    {
                        string strMsg = "Invoke R2R_UI_Config_EditStatusCheck Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }
                    if (checkResult.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    else if (checkResult.ReturnCode.Equals("0"))
                    {
                        IsProductSettingAdd = true;
                    }
                    else if (checkResult.ReturnCode.Equals("1"))
                    {
                        IsProductSettingAdd = true;

                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    if (checkResult.InitMode.ToLower().Equals("edit"))
                    {
                        CheckEditStatusMessage = "You are now in edit mode";
                        IsEditModeChecked = true;
                        IsViewOnlyChecked = false;
                        SetViewStatus(0x111);

                        #region
                        ProductSettingEntity ProductSettingNew = new ProductSettingEntity();
                        ProductSettingNew.Product = viewModel.Product;
                        ProductSettingNew.Layer = viewModel.Layer;
                        ProductSettingNew.ToolGroup = viewModel.ToolGroup;
                        ProductSettingNew.AlignmentLayer = viewModel.AlignmentLayer;
                        ProductSettingNew.AlignmentMethod = viewModel.AlignmentMethod;
                        ProductSettingNew.PreLayer1 = viewModel.OverlayLayer;

                        viewModel.ControlByChuck = viewModel.IsControlByChuckYes ? "Y" : "N";
                        ProductSettingNew.ControlByChuck = viewModel.ControlByChuck;

                        viewModel.ChuckDedication = viewModel.IsChuckDedicationYes ? "Y" : "N";
                        ProductSettingNew.ChuckDedication = viewModel.ChuckDedication;

                        string strChuck = "NA";
                        if (string.IsNullOrEmpty(viewModel.ChuckDedicationLayer))
                        {

                        }
                        else
                        {
                            strChuck = viewModel.ChuckDedicationLayer;
                        }
                        ProductSettingNew.ChuckDedicationLayer = strChuck;
                        ProductSettingNew.CascadePCLayer = viewModel.CascadePCLayer;
                        ProductSettingNew.PreLayer2 = viewModel.PreOverlayLayer;
                        ProductSettingNew.CascadeCPELayer = viewModel.CascadeCPELayer;

                        string strJson = JsonHelp.SerializeObject(ProductSettingNew);
                        foreach (var obj in ProductSettingList)
                        {
                            string str = JsonHelp.SerializeObject(obj);
                            if (str.Equals(strJson))
                            {
                                return;
                            }
                        }
                        if (ProductSettingNew.Product != null && ProductSettingNew.Layer != null && ProductSettingNew.ToolGroup != null)
                        {
                            foreach (var obj in ProductSettingList)
                            {
                                if (obj.Product.Equals(ProductSettingNew.Product) && obj.Layer.Equals(ProductSettingNew.Layer) && obj.ToolGroup.Equals(ProductSettingNew.ToolGroup))
                                {
                                    System.Windows.Forms.MessageBox.Show("Have exists!");
                                    return;
                                }
                            }

                            if (!ProductList.Contains(ProductSettingNew.Product))
                            {
                                ProductList.Add(ProductSettingNew.Product);
                            }
                            if (!LayerList.Contains(ProductSettingNew.Layer))
                            {
                                LayerList.Add(ProductSettingNew.Layer);
                            }
                            if (!ToolGroupList.Contains(ProductSettingNew.ToolGroup))
                            {
                                ToolGroupList.Add(ProductSettingNew.ToolGroup);
                            }
                            if (!PreLayer1List.Contains(ProductSettingNew.PreLayer1))
                            {
                                PreLayer1List.Add(ProductSettingNew.PreLayer1);
                            }
                            if (!PreLayer1List.Contains(ProductSettingNew.PreLayer1))
                            {
                                PreLayer1List.Add(ProductSettingNew.PreLayer1);
                            }
                            if (!PreLayer2List.Contains(ProductSettingNew.PreLayer2))
                            {
                                PreLayer2List.Add(ProductSettingNew.PreLayer2);
                            }
                            if (!CascadePCLayerList.Contains(ProductSettingNew.CascadePCLayer))
                            {
                                CascadePCLayerList.Add(ProductSettingNew.CascadePCLayer);
                            }
                            if (!CascadeCPELayerList.Contains(ProductSettingNew.CascadeCPELayer))
                            {
                                CascadeCPELayerList.Add(ProductSettingNew.CascadeCPELayer);
                            }

                            ProductSettingList.Add(ProductSettingNew);

                            #region Add New Row
                            string strToolVendor = string.Empty;
                            if (dbR2R_PH_CONFIG_COMMON_Update.Columns.Count < 1)
                            {
                                dbR2R_PH_CONFIG_COMMON_Update = DataTableHelp.GetCommonDataTable();
                            }
                            if (dbR2R_PH_CONFIG_COMMON_Update.Rows.Count > 0)
                            {
                                DataRow[] queryCommon = dbR2R_PH_CONFIG_COMMON_Update.Select("PRODUCT = '" + viewModel.Product + "' and LAYER = '" + viewModel.Layer + "'");
                                if (queryCommon.Length > 0)
                                {
                                    for (int i = 0; i < queryCommon.Length; i++)
                                    {
                                        if (viewModel.IsChuckDedicationYes)
                                        {
                                            string strChuckDedication = queryCommon[i]["CHUCK_DEDICATION"].ToString().ToUpper();
                                            if (strChuckDedication.Equals("TRUE"))
                                            {
                                                //queryCommon[i]["CHUCK_DEDICATION"] = viewModel.ChuckDedication == "Y" ? "true" : "false";
                                                queryCommon[i]["CHUCK_DEDICATION_LAYER"] = strChuck;
                                            }
                                        }

                                        queryCommon[i]["ALIGMENT_LAYER"] = viewModel.AlignmentLayer;
                                        //queryCommon[i]["ALIAMENT_METHOD"] = viewModel.AlignmentMethod;
                                        queryCommon[i]["OVERLAY_LAYER"] = viewModel.OverlayLayer;
                                        //queryCommon[i]["CONTROL_BY_CHUCK"] = viewModel.ControlByChuck == "Y" ? "true" : "false";
                                        queryCommon[i]["CASCADE_PC_LAYER"] = viewModel.CascadePCLayer;
                                        queryCommon[i]["CASCADE_CPE_LAYER"] = viewModel.CascadeCPELayer;
                                        queryCommon[i]["PRELAYER_2"] = viewModel.PreOverlayLayer;
                                    }
                                }
                            }

                            DataRow row = dbR2R_PH_CONFIG_COMMON_Update.NewRow();
                            for (int i = 0; i < 58; i++)
                            {
                                row[i] = "";
                            }

                            strToolVendor = GetToolVendor(viewModel.ToolGroup);
                            row["TOOL_VENDOR"] = strToolVendor;

                            row["OVL_PC_DYNAMIC_CONTEXT"] = "TOOL,RETICLE";
                            row["OVL_CPE_DYNAMIC_CONTEXT"] = "TOOL";

                            row["OVL_PC_EXPIRE_TIME"] = "7";
                            row["OVL_PC_LUMDA"] = "0.3";
                            row["OVL_CPE_EXPIRE_TIME"] = row["OVL_PC_EXPIRE_TIME"].ToString().Equals("") ? "7" : OVLPCExpireTime;
                            row["OVL_CPE_LUMDA"] = "0.3";

                            row["OVL_PC_FEEDFOREWARD"] = "false";
                            row["OVL_CPE_FEEDFOREWARD"] = "false";
                            row["OVL_CPE_FIX_EDGE"] = "false";

                            row["PRODUCT"] = viewModel.Product;
                            row["LAYER"] = viewModel.Layer;
                            row["TOOL_GROUP"] = viewModel.ToolGroup;
                            row["ALIGMENT_LAYER"] = viewModel.AlignmentLayer;
                            row["ALIAMENT_METHOD"] = viewModel.AlignmentMethod;
                            row["OVERLAY_LAYER"] = viewModel.OverlayLayer;

                            row["CONTROL_BY_CHUCK"] = viewModel.ControlByChuck == "Y" ? "true" : "false";
                            row["CHUCK_DEDICATION"] = viewModel.ChuckDedication == "Y" ? "true" : "false";
                            row["CHUCK_DEDICATION_LAYER"] = strChuck;
                            row["CASCADE_PC_LAYER"] = viewModel.CascadePCLayer;
                            row["CASCADE_CPE_LAYER"] = viewModel.CascadeCPELayer;
                            row["PRELAYER_2"] = viewModel.PreOverlayLayer;

                            dbR2R_PH_CONFIG_COMMON_Update.Rows.Add(row);

                            #endregion
                        }
                        GetProductSettingInfo();

                        bool flag = false;
                        foreach (var obj in ProductSettingList)
                        {
                            if (ProductSettingList.Count == 1)
                            {
                                //SelectedProductSetting = ProductSettingList[0];
                                flag = true;
                                break;
                            }
                            if (obj.Product.Equals(ProductSettingNew.Product) && obj.Layer.Equals(ProductSettingNew.Layer) && obj.ToolGroup.Equals(ProductSettingNew.ToolGroup))
                            {
                                SelectedProductSetting = obj;
                                flag = true;
                                break;
                            }
                        }
                        if (!flag)
                        {
                            ProductSettingList.Add(ProductSettingNew);
                            SelectedProductSetting = ProductSettingNew;
                        }

                        CurrentEditProduct = SelectedProductSetting.Product;
                        CurrentEditLayer = SelectedProductSetting.Layer;
                        CurrentEditToolGroup = SelectedProductSetting.ToolGroup;

                        //CurrentOVLPCR2RMode = "Add";
                        //CurrentOVLPCOVLMode = "Add";
                        //CurrentOVLCPER2RMode = "Add";
                        //CurrentOVLCPEOVLMode = "Add";

                        IsControlByChuckChangeFlag = viewModel.IsControlByChuckChangeFlag;
                        IsControlByChuckChangeFlag = true;
                        IsGrdReadOnly = true;
                        IsGrdEnable = false;

                        IsProductSettingAddFlag = true;
                        IsOVLPCChangeFlag = true;
                        IsOVLCPEChangeFlag = true;
                        IsCDEditOngoing = true;
                        IsPCEditOngoing = true;
                        IsCPEEditOngoing = true;
                        #endregion
                    }
                    else if (checkResult.InitMode.ToLower().Equals("view"))
                    {
                        CheckEditStatusMessage = "You are now in view mode ---- Occupied by other";
                        IsEditModeChecked = false;
                        IsViewOnlyChecked = true;
                        SetViewStatus(0);
                    }
                    //else
                    //{
                    //    //view only
                    //    SetViewStatus(0);
                    //}
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ProductSetting Edit Button Click Event Fun
        /// </summary>
        void OnEditClick()
        {
            try
            {
                if (this.SelectedProductSetting == null)
                {
                    System.Windows.Forms.MessageBox.Show("Row is not selected!");
                    return;
                }

                if (SelectedProductSetting.Product == null)
                {
                    System.Windows.Forms.MessageBox.Show("Please selected!");
                    return;
                }

                CurrentEditProduct = "";
                CurrentEditLayer = "";
                CurrentEditToolGroup = "";

                var window = new MetroWindow();//Windows窗体      
                ProductSetting view = new ProductSetting();
                ProductSettingViewModel viewModel = (ProductSettingViewModel)view.DataContext;

                List<string> strListProduct = new List<string>(ProductList);
                strListProduct.Remove("*");

                List<string> strListLayer = new List<string>(LayerList);
                strListLayer.Remove("*");

                List<string> strListToolGroup = new List<string>(ToolGroupList);
                strListToolGroup.Remove("*");
                strListToolGroup.Remove("KT");
                strListToolGroup.Remove("YS");

                ChuckDedicationLayerList = new List<string>(strListLayer);
                PreLayer1List = new List<string>(strListLayer);
                PreLayer2List = new List<string>(strListLayer);
                CascadePCLayerList = new List<string>(strListLayer);
                CascadeCPELayerList = new List<string>(strListLayer);
                AlignmentLayerList = new List<string>(strListLayer);

                if (!ChuckDedicationLayerList.Contains(SelectedProductSetting.ChuckDedicationLayer))
                {
                    ChuckDedicationLayerList.Add(SelectedProductSetting.ChuckDedicationLayer);
                }
                if (!AlignmentLayerList.Contains(SelectedProductSetting.AlignmentLayer))
                {
                    AlignmentLayerList.Add(SelectedProductSetting.AlignmentLayer);
                }
                if (!PreLayer1List.Contains(SelectedProductSetting.PreLayer1))
                {
                    PreLayer1List.Add(SelectedProductSetting.PreLayer1);
                }
                if (!PreLayer2List.Contains(SelectedProductSetting.PreLayer2))
                {
                    PreLayer2List.Add(SelectedProductSetting.PreLayer2);
                }
                if (!CascadePCLayerList.Contains(SelectedProductSetting.CascadePCLayer))
                {
                    CascadePCLayerList.Add(SelectedProductSetting.CascadePCLayer);
                }
                if (!CascadeCPELayerList.Contains(SelectedProductSetting.CascadeCPELayer))
                {
                    CascadeCPELayerList.Add(SelectedProductSetting.CascadeCPELayer);
                }

                AlignmentLayerList.Remove("");
                ChuckDedicationLayerList.Remove("");
                PreLayer1List.Remove("");
                CascadePCLayerList.Remove("");
                CascadeCPELayerList.Remove("");
                PreLayer2List.Remove("");

                viewModel.CurrentWindow = window;
                viewModel.ProductList = strListProduct;
                viewModel.LayerList = strListLayer;
                viewModel.ToolGroupList = strListToolGroup;
                viewModel.AlignmentLayerList = AlignmentLayerList;
                viewModel.AlignmentMethodList = AlignmentMethodList;
                viewModel.OverlayLayerList = PreLayer1List;
                viewModel.ChuckDedicationLayerList = ChuckDedicationLayerList;
                viewModel.CascadePCLayerList = CascadePCLayerList;
                viewModel.CascadeCPELayerList = CascadeCPELayerList;
                viewModel.PreOverlayLayerList = PreLayer2List;


                viewModel.IsProductEditable = false;
                viewModel.IsLayerEditable = false;
                viewModel.IsToolGroupEnable = false;
                viewModel.IsAlignmentLayerEnable = true;
                viewModel.IsAlignmentMethodEnable = false;

                viewModel.CanonToolGroupList = new List<string>(CanonToolGroupList);

                if (ToolVendor.ToUpper().Equals("CANON"))
                {
                    viewModel.IsControlByChuckEnable = false;
                    viewModel.IsControlByChuckYes = false;
                    viewModel.IsControlByChuckNo = true;

                    viewModel.IsChuckDedicationEnable = false;
                    viewModel.IsChuckDedicationYes = false;
                    viewModel.IsChuckDedicationNo = true;
                    viewModel.IsChuckDedicationLayerEnable = false;
                }
                else
                {
                    viewModel.IsControlByChuckEnable = true;
                    if (SelectedProductSetting.ChuckDedication != null && SelectedProductSetting.ControlByChuck.ToUpper().Equals("Y"))
                    {
                        viewModel.IsControlByChuckYes = true;
                        viewModel.IsControlByChuckNo = false;
                    }
                    else
                    {
                        viewModel.IsControlByChuckYes = false;
                        viewModel.IsControlByChuckNo = true;
                    }

                    viewModel.IsChuckDedicationEnable = true;
                    if (SelectedProductSetting.ChuckDedication != null && SelectedProductSetting.ChuckDedication.ToUpper().Equals("Y"))
                    {
                        viewModel.IsChuckDedicationYes = true;
                        viewModel.IsChuckDedicationNo = false;
                        viewModel.IsChuckDedicationLayerEnable = true;
                    }
                    else
                    {
                        viewModel.IsChuckDedicationYes = false;
                        viewModel.IsChuckDedicationNo = true;
                        viewModel.IsChuckDedicationLayerEnable = false;
                    }
                }

                viewModel.IsProductEnable = false;
                viewModel.IsLayerEnable = false;
                viewModel.Product = SelectedProductSetting.Product;
                viewModel.Layer = SelectedProductSetting.Layer;
                viewModel.ToolGroup = SelectedProductSetting.ToolGroup;
                viewModel.AlignmentLayer = SelectedProductSetting.AlignmentLayer;
                viewModel.AlignmentMethod = SelectedProductSetting.AlignmentMethod;
                viewModel.OverlayLayer = SelectedProductSetting.PreLayer1;
                viewModel.PreOverlayLayer = SelectedProductSetting.PreLayer2;
                viewModel.ChuckDedicationLayer = SelectedProductSetting.ChuckDedicationLayer;
                viewModel.CascadePCLayer = SelectedProductSetting.CascadePCLayer;
                viewModel.CascadeCPELayer = SelectedProductSetting.CascadeCPELayer;

                window.Content = view;
                window.Title = "Product Edit Setting";
                window.Height = 520;
                window.Width = 480;
                //window.WindowStyle = WindowStyle.None;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();

                if (viewModel.IsBtnOkClick)
                {
                    #region Check
                    bool isCheckOnly = false;
                    CurrentAction = "Edit_Product";
                    string CurrentMode = IsEditModeChecked ? "Edit" : "View";
                    CfgEditStatusCheckResult checkResult = this._SettingMainService.R2R_UI_Config_EditStatusCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, viewModel.Product, viewModel.Layer, viewModel.ToolGroup, QueryTime, isCheckOnly, ConfigUI, CurrentAction, CurrentMode);
                    if (checkResult == null)
                    {
                        string strMsg = "Invoke R2R_UI_Config_EditStatusCheck Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }
                    if (checkResult.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    else if (checkResult.ReturnCode.Equals("0"))
                    {
                        IsProductSettingEdit = true;
                    }
                    else if (checkResult.ReturnCode.Equals("1"))
                    {
                        IsProductSettingEdit = true;
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    if (checkResult.InitMode.ToLower().Equals("edit"))
                    {
                        CheckEditStatusMessage = "You are now in edit mode";
                        IsEditModeChecked = true;
                        IsViewOnlyChecked = false;
                        SetViewStatus(0x111);

                        #region
                        //ProductList = viewModel.ProductList;
                        //LayerList = viewModel.LayerList;
                        SelectedProductSetting.Product = viewModel.Product;
                        SelectedProductSetting.Layer = viewModel.Layer;
                        SelectedProductSetting.ToolGroup = viewModel.ToolGroup;
                        SelectedProductSetting.AlignmentLayer = viewModel.AlignmentLayer;
                        SelectedProductSetting.AlignmentMethod = viewModel.AlignmentMethod;
                        SelectedProductSetting.PreLayer1 = viewModel.OverlayLayer;
                        SelectedProductSetting.PreLayer2 = viewModel.PreOverlayLayer;

                        string strChuckDedicationTmp = "false";
                        string strControlByChuckTmp = "false";

                        viewModel.ControlByChuck = viewModel.IsControlByChuckYes ? "Y" : "N";
                        SelectedProductSetting.ControlByChuck = viewModel.ControlByChuck;
                        strControlByChuckTmp = viewModel.ControlByChuck.Equals("Y") ? "true" : "false";

                        viewModel.ChuckDedication = viewModel.IsChuckDedicationYes ? "Y" : "N";
                        SelectedProductSetting.ChuckDedication = viewModel.ChuckDedication;
                        strChuckDedicationTmp = viewModel.ChuckDedication.Equals("Y") ? "true" : "false";

                        string strChuck = "NA";
                        if (string.IsNullOrEmpty(viewModel.ChuckDedicationLayer))
                        {

                        }
                        else
                        {
                            strChuck = viewModel.ChuckDedicationLayer;
                        }

                        SelectedProductSetting.ChuckDedicationLayer = strChuck;
                        SelectedProductSetting.CascadePCLayer = viewModel.CascadePCLayer;
                        SelectedProductSetting.CascadeCPELayer = viewModel.CascadeCPELayer;

                        if (!PreLayer1List.Contains(SelectedProductSetting.PreLayer1))
                        {
                            PreLayer1List.Add(SelectedProductSetting.PreLayer1);
                        }
                        if (!AlignmentLayerList.Contains(SelectedProductSetting.AlignmentLayer))
                        {
                            AlignmentLayerList.Add(SelectedProductSetting.AlignmentLayer);
                        }
                        if (!PreLayer2List.Contains(SelectedProductSetting.PreLayer2))
                        {
                            PreLayer2List.Add(SelectedProductSetting.PreLayer2);
                        }
                        if (!CascadePCLayerList.Contains(SelectedProductSetting.CascadePCLayer))
                        {
                            CascadePCLayerList.Add(SelectedProductSetting.CascadePCLayer);
                        }
                        if (!CascadeCPELayerList.Contains(SelectedProductSetting.CascadeCPELayer))
                        {
                            CascadeCPELayerList.Add(SelectedProductSetting.CascadeCPELayer);
                        }

                        string strSelect = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";

                        //System.Windows.Forms.MessageBox.Show(viewModel.ChuckDedication);
                        ObservableCollection<ProductSettingEntity> list = new ObservableCollection<ProductSettingEntity>(ProductSettingList);
                        ProductSettingList.Clear();
                        ProductSettingList = new ObservableCollection<ProductSettingEntity>(list);

                        #region Edit Row
                        DataRow[] queryCommon = dbR2R_PH_CONFIG_COMMON_Update.Select("PRODUCT = '" + viewModel.Product + "' and LAYER = '" + viewModel.Layer + "'");
                        if (queryCommon.Length > 0)
                        {
                            for (int i = 0; i < queryCommon.Length; i++)
                            {
                                if (viewModel.IsChuckDedicationYes)
                                {
                                    string strChuckDedication = queryCommon[i]["CHUCK_DEDICATION"].ToString().ToUpper();
                                    if (strChuckDedication.Equals("TRUE"))
                                    {
                                        queryCommon[i]["CHUCK_DEDICATION_LAYER"] = strChuck;
                                    }
                                    else
                                    {
                                        //strChuck = queryCommon[i]["CHUCK_DEDICATION_LAYER"].ToString();
                                    }
                                }

                                queryCommon[i]["ALIGMENT_LAYER"] = viewModel.AlignmentLayer;
                                //queryCommon[i]["ALIAMENT_METHOD"] = viewModel.AlignmentMethod;
                                queryCommon[i]["OVERLAY_LAYER"] = viewModel.OverlayLayer;
                                //queryCommon[i]["CHUCK_DEDICATION"] = viewModel.ChuckDedication == "Y" ? "true" : "false";
                                //queryCommon[i]["CONTROL_BY_CHUCK"] = viewModel.ControlByChuck == "Y" ? "true" : "false";
                                //queryCommon[i]["CHUCK_DEDICATION_LAYER"] = strChuck;
                                queryCommon[i]["CASCADE_PC_LAYER"] = viewModel.CascadePCLayer;
                                queryCommon[i]["CASCADE_CPE_LAYER"] = viewModel.CascadeCPELayer;
                                queryCommon[i]["PRELAYER_2"] = viewModel.PreOverlayLayer;
                            }
                        }

                        DataRow[] rows = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strSelect);
                        if (rows.Count() > 0)
                        {
                            //rows[0]["PRODUCT"] = viewModel.Product;
                            //rows[0]["LAYER"] = viewModel.Layer;
                            //rows[0]["TOOL_GROUP"] = viewModel.ToolGroup;
                            rows[0]["ALIGMENT_LAYER"] = viewModel.AlignmentLayer;
                            rows[0]["ALIAMENT_METHOD"] = viewModel.AlignmentMethod;
                            rows[0]["OVERLAY_LAYER"] = viewModel.OverlayLayer;

                            rows[0]["CONTROL_BY_CHUCK"] = viewModel.ControlByChuck == "Y" ? "true" : "false";
                            rows[0]["CHUCK_DEDICATION"] = viewModel.ChuckDedication == "Y" ? "true" : "false";
                            rows[0]["CHUCK_DEDICATION_LAYER"] = viewModel.ChuckDedicationLayer;
                            rows[0]["CASCADE_PC_LAYER"] = viewModel.CascadePCLayer;
                            rows[0]["CASCADE_CPE_LAYER"] = viewModel.CascadeCPELayer;
                            rows[0]["PRELAYER_2"] = viewModel.PreOverlayLayer;
                        }
                        #endregion

                        GetProductSettingInfo();

                        foreach (var obj in ProductSettingList)
                        {
                            if (obj.Product.Equals(viewModel.Product) && obj.Layer.Equals(viewModel.Layer) && obj.ToolGroup.Equals(viewModel.ToolGroup))
                            {
                                SelectedProductSetting = obj;
                                break;
                            }
                        }

                        IsControlByChuckChangeFlag = viewModel.IsControlByChuckChangeFlag;
                        if (IsControlByChuckChangeFlag)
                        {
                            IsGrdReadOnly = true;
                            IsGrdEnable = false;

                            //IsCDEditOngoing = true;
                            if (OVLPCR2RMode.Equals("NONE"))
                            {
                                IsPCEditOngoing = false;
                                IsOVLPCChangeFlag = false;
                            }
                            else
                            {
                                IsOVLPCChangeFlag = true;
                                IsPCEditOngoing = true;
                            }
                            //if (OVLCPER2RMode.Equals("NONE"))
                            //{
                            //    IsCPEEditOngoing = false;
                            //}
                            //else
                            //{
                            //    IsCPEEditOngoing = true;
                            //}

                            CurrentEditProduct = SelectedProductSetting.Product;
                            CurrentEditLayer = SelectedProductSetting.Layer;
                            CurrentEditToolGroup = SelectedProductSetting.ToolGroup;
                        }
                        #endregion

                        #region Set Save Button
                        SetBtnSaveStatus();
                        #endregion
                    }
                    else if (checkResult.InitMode.ToLower().Equals("view"))
                    {
                        CheckEditStatusMessage = "You are now in view mode ---- Occupied by other";
                        IsEditModeChecked = false;
                        IsViewOnlyChecked = true;
                        SetViewStatus(0);
                    }
                    //else
                    //{
                    //    //view only
                    //    SetViewStatus(0);
                    //}
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ProductSetting Confirm Button Click Event Fun Test FixedEdge
        /// </summary>
        void OnConfirmClick()
        {
            try
            {

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ProductSetting Delete Button Click Event Fun
        /// </summary>
        void OnDeleteClick()
        {
            try
            {
                if (this.SelectedProductSetting == null)
                {
                    System.Windows.Forms.MessageBox.Show("Row is not selected!");
                    return;
                }
                if (SelectedProductSetting.Product.Equals("") || SelectedProductSetting.Layer.Equals("") || SelectedProductSetting.ToolGroup.Equals(""))
                {
                    return;
                }

                #region Version Compare test 0123
                //CfgGetLatestResult VersionLatest = new CfgGetLatestResult();
                //if (IsVersionCompareCheckFlag)
                //{
                //    VersionLatest = _SettingMainService.R2R_UI_Config_GetLatestConfig(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, VersionCompareProduct, VersionCompareLayer, VersionCompareToolGroup, ConfigUI);
                //    if (VersionLatest == null)
                //    {
                //        string strMsg = "Invoke R2R_UI_Config_GetLatestConfig Error!";
                //        MyLogger.Trace("Message :: " + strMsg);
                //        System.Windows.Forms.MessageBox.Show(strMsg);
                //        return;
                //    }
                //    if (VersionLatest.ReturnCode.Equals("-1"))
                //    {
                //        return;
                //    }
                //    else
                //    {
                //        if (string.IsNullOrEmpty(VersionLatest.Latest_Version_Common))
                //        {
                //            dbR2R_PH_CONFIG_COMMON_Source = dbR2R_PH_CONFIG_COMMON_Update.Clone();
                //            DataTable dbR2R_PH_CONFIG_COMMON_Old = dbR2R_PH_CONFIG_COMMON_Update.Clone();
                //        }
                //        else
                //        {
                //            CfgSingleTableInfoEntity entityCommon = new CfgSingleTableInfoEntity();
                //            entityCommon = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(VersionLatest.Latest_Version_Common);
                //            DataTable dbR2R_PH_CONFIG_COMMON_Old = CfgSingleTableInfoHelp.CreateDataTable(entityCommon);
                //        }

                //        CfgSingleTableInfoEntity entityLIS = new CfgSingleTableInfoEntity();
                //        entityLIS = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(VersionLatest.Latest_Version_LIS);
                //        DataTable dbR2R_PH_CONFIG_LIS_Old = CfgSingleTableInfoHelp.CreateDataTable(entityLIS);

                //        CfgSingleTableInfoEntity entityCDInit = new CfgSingleTableInfoEntity();
                //        entityCDInit = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(VersionLatest.Latest_Version_CD_Init);
                //        DataTable dbR2R_PH_CONFIG_CD_Init_Old = CfgSingleTableInfoHelp.CreateDataTable(entityCDInit);

                //        CfgSingleTableInfoEntity entityPCInit = new CfgSingleTableInfoEntity();
                //        entityPCInit = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(VersionLatest.Latest_Version_OVL_PC_Init);
                //        DataTable dbR2R_PH_CONFIG_PC_Init_Old = CfgSingleTableInfoHelp.CreateDataTable(entityPCInit);

                //        CfgSingleTableInfoEntity entityCPEInit = new CfgSingleTableInfoEntity();
                //        entityCPEInit = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(VersionLatest.Latest_Version_OVL_CPE_Init);
                //        DataTable dbR2R_PH_CONFIG_CPE_Init_Old = CfgSingleTableInfoHelp.CreateDataTable(entityCPEInit);
                //    }

                //}
                #endregion

                #region Check
                bool isCheckOnly = false;
                CurrentAction = "Delete";
                string CurrentMode = IsEditModeChecked ? "Edit" : "View";
                CfgEditStatusCheckResult checkResult = this._SettingMainService.R2R_UI_Config_EditStatusCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, QueryTime, isCheckOnly, ConfigUI, CurrentAction, CurrentMode);
                if (checkResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_EditStatusCheck Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (checkResult.ReturnCode.Equals("-1"))
                {
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                else if (checkResult.ReturnCode.Equals("0"))
                {

                }
                else if (checkResult.ReturnCode.Equals("1"))
                {
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                if (checkResult.InitMode.ToLower().Equals("edit"))
                {
                    CheckEditStatusMessage = "You are now in edit mode";
                    IsEditModeChecked = true;
                    IsViewOnlyChecked = false;
                    SetViewStatus(0x111);

                    #region Delete Row
                    string strSelect = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                    DataRow[] rows = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strSelect);
                    if (rows.Count() > 0)
                    {
                        for (int i = 0; i < rows.Count(); i++)
                        {
                            dbR2R_PH_CONFIG_COMMON_Update.Rows.Remove(rows[i]);
                        }
                    }

                    DataRow[] rowsLIS = DataTableHelp.Query(dbR2R_PH_CONFIG_LIS_Update, strSelect);
                    foreach (DataRow row in rowsLIS)
                    {
                        dbR2R_PH_CONFIG_LIS_Update.Rows.Remove(row);
                    }

                    DataRow[] rowsInit = DataTableHelp.Query(dbInitValueUpdate, strSelect);
                    foreach (DataRow row in rowsInit)
                    {
                        dbInitValueUpdate.Rows.Remove(row);
                    }

                    ProductSettingList.Remove(SelectedProductSetting);

                    if (IsProductSettingAddFlag)
                    {
                        IsProductSettingAddFlag = false;
                        CurrentEditProduct = "";
                        CurrentEditLayer = "";
                        CurrentEditToolGroup = "";
                    }

                    IsCDEditOngoing = false;
                    IsPCEditOngoing = false;
                    IsCPEEditOngoing = false;
                    IsOVLCPEChangeFlag = false;
                    IsOVLPCChangeFlag = false;

                    ClearCDSetting();
                    ClearOVLPCSetting();
                    ClearOVLCPESetting();
                    SendWaferParam = null;

                    ShowWaferModeView("PC_None");
                    ShowCPEModeView("CPE_None");

                    //if (ProductSettingList.Count>0)
                    //{
                    //    SelectedProductSetting = ProductSettingList[0];
                    //}
                    #endregion

                    #region Set Save Button
                    SetBtnSaveStatus(true);
                    SetSettingEnable(false);
                    #endregion
                }
                else if (checkResult.InitMode.ToLower().Equals("view"))
                {
                    bIsDelete = true;
                    CheckEditStatusMessage = "You are now in view mode ---- Occupied by other";
                    IsEditModeChecked = false;
                    IsViewOnlyChecked = true;
                    SetViewStatus(0);
                }
                //else
                //{
                //    //view only
                //    SetViewStatus(0);
                //}
                #endregion

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ProductSetting Import Button Click Event Fun
        /// </summary>
        void OnImportClick()
        {
            try
            {

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ProductSetting Export Button Click Event Fun
        /// </summary>
        void OnExportClick()
        {
            try
            {

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ProductSetting FixedEdgeSho Button Click Event Fun
        /// </summary>
        void OnFixedEdgeShotClick()
        {
            try
            {
                if (this.SelectedProductSetting == null)
                {
                    System.Windows.Forms.MessageBox.Show("Row is not selected!");
                    return;
                }

                if (SelectedProductSetting.Product == null)
                {
                    System.Windows.Forms.MessageBox.Show("Please selected!");
                    return;
                }

                //Test Fixed Edge Shot
                var window = new MetroWindow();//Windows窗体      
                FixedEdgeShotSetting view = new FixedEdgeShotSetting();
                FixedEdgeShotSettingViewModel viewModel = (FixedEdgeShotSettingViewModel)view.DataContext;

                viewModel.CurrentWindow = window;
                viewModel.Product = SelectedProductSetting.Product;
                viewModel.Layer = SelectedProductSetting.Layer;
                viewModel.ToolGroup = SelectedProductSetting.ToolGroup;

                window.Content = view;
                window.Title = "Fixed Edge Shot Setting";
                window.Height = 600;
                window.Width = 1400;
                //window.WindowStyle = WindowStyle.None;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ProductSetting Save Button Click Event Fun
        /// </summary>
        void OnSaveClick()
        {
            try
            {
                #region Check CD&&PC&&CPE
                if (IsCDEditOngoing || IsPCEditOngoing || IsCPEEditOngoing)
                {
                    #region Set Save Button
                    SetBtnSaveStatus(false);
                    #endregion

                    if (IsCDEditOngoing)
                    {
                        System.Windows.Forms.MessageBox.Show("Please complete the CD editing!");
                    }
                    else if (IsPCEditOngoing)
                    {
                        System.Windows.Forms.MessageBox.Show("Please complete the PC editing!");
                    }
                    else if (IsCPEEditOngoing)
                    {
                        System.Windows.Forms.MessageBox.Show("Please complete the CPE editing!");
                    }
                    return;
                }
                else
                {

                }
                #endregion

                #region Check Changed

                #region Version Compare
                CfgGetLatestResult VersionLatest = new CfgGetLatestResult();
                if (IsVersionCompareCheckFlag)
                {
                    VersionLatest = _SettingMainService.R2R_UI_Config_GetLatestConfig(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, VersionCompareProduct, VersionCompareLayer, VersionCompareToolGroup, ConfigUI);
                    if (VersionLatest == null)
                    {
                        string strMsg = "Invoke R2R_UI_Config_GetLatestConfig Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }
                    if (VersionLatest.ReturnCode.Equals("-1"))
                    {
                        return;
                    }
                    else
                    {
                        string strSelect = "PRODUCT = '" + VersionCompareProduct + "' and LAYER = '" + VersionCompareLayer + "' and TOOL_GROUP = '" + VersionCompareToolGroup + "'";
                        DataRow[] rowCommons = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strSelect);
                        if (rowCommons.Count() > 0)
                        {
                            DataTable dbCommonTemp = dbR2R_PH_CONFIG_COMMON_Update.Clone();
                            for (int i = 0; i < rowCommons.Count(); i++)
                            {
                                dbCommonTemp.Rows.Add(rowCommons[0].ItemArray);  //添加数据行
                            }
                            dbR2R_PH_CONFIG_COMMON_Update = dbCommonTemp;

                        }
                        else
                        {
                            dbR2R_PH_CONFIG_COMMON_Update.Clear();
                        }

                        DataRow[] rowLIS = DataTableHelp.Query(dbR2R_PH_CONFIG_LIS_Update, strSelect);
                        if (rowLIS.Count() > 0)
                        {
                            DataTable dbLISTemp = dbR2R_PH_CONFIG_LIS_Update.Clone();
                            for (int i = 0; i < rowLIS.Count(); i++)
                            {
                                dbLISTemp.Rows.Add(rowLIS[0].ItemArray);  //添加数据行
                            }
                            dbR2R_PH_CONFIG_LIS_Update = dbLISTemp;

                        }
                        else
                        {
                            dbR2R_PH_CONFIG_LIS_Update.Clear();
                        }
                    }

                }
                #endregion

                #region COMMON
                #region Version Compare
                List<CompareCommonEntity> CommonCompareList = new List<CompareCommonEntity>();
                if (IsVersionCompareCheckFlag)
                {
                    if (string.IsNullOrEmpty(VersionLatest.Latest_Version_Common))
                    {
                        dbR2R_PH_CONFIG_COMMON_Source = dbR2R_PH_CONFIG_COMMON_Update.Clone();
                    }
                    else
                    {
                        CfgSingleTableInfoEntity entityCommon = new CfgSingleTableInfoEntity();
                        entityCommon = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(VersionLatest.Latest_Version_Common);
                        dbR2R_PH_CONFIG_COMMON_Source = CfgSingleTableInfoHelp.CreateDataTable(entityCommon);
                        dbR2R_PH_CONFIG_COMMON_Source = DataTableHelp.RemoveBlankRow(dbR2R_PH_CONFIG_COMMON_Source, cfgCommonColumnKeyList);
                    }

                }
                #endregion

                DataTable dbCfgCommonChanged = DataTableHelp.CompareDataTable(dbR2R_PH_CONFIG_COMMON_Source, dbR2R_PH_CONFIG_COMMON_Update, cfgCommonColumnKeyList);
                DataTable dbR2R_PH_CONFIG_COMMON_Old = DataTableHelp.GetChangedRecord(dbCfgCommonChanged, "Status", "Old");
                DataTable dbR2R_PH_CONFIG_COMMON_Modify = DataTableHelp.GetChangedRecord(dbCfgCommonChanged, "Status", "Edit");
                DataTable dbR2R_PH_CONFIG_COMMON_Add = DataTableHelp.GetChangedRecord(dbCfgCommonChanged, "Status", "Add");
                DataTable dbR2R_PH_CONFIG_COMMON_Delete = DataTableHelp.GetChangedRecord(dbCfgCommonChanged, "Status", "Delete");

                string contentCfgCommonAdd = "";
                if (dbR2R_PH_CONFIG_COMMON_Add.Rows.Count > 0)
                {
                    cfgCommonUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_COMMON_Add, cfgCommonColumnNameList);
                    contentCfgCommonAdd = JsonHelp.SerializeObject(cfgCommonUpdateEntity);

                    #region Version Compare
                    if (IsVersionCompareCheckFlag)
                    {
                        foreach (var strColumn in cfgCommonColumnNameList)
                        {
                            CompareCommonEntity commonEntity = new CompareCommonEntity();
                            commonEntity.Context = strColumn;
                            commonEntity.VersionA = "";
                            commonEntity.VersionB = dbR2R_PH_CONFIG_COMMON_Add.Rows[0][strColumn].ToString();
                            commonEntity.Result = "Add";
                            CommonCompareList.Add(commonEntity);
                        }
                    }
                    #endregion
                }

                string contentCfgCommonModify = "";
                if (dbR2R_PH_CONFIG_COMMON_Modify.Rows.Count > 0)
                {
                    cfgCommonUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_COMMON_Modify, cfgCommonColumnNameList);
                    contentCfgCommonModify = JsonHelp.SerializeObject(cfgCommonUpdateEntity);

                    #region Version Compare
                    if (IsVersionCompareCheckFlag)
                    {
                        foreach (var strColumn in cfgCommonColumnNameList)
                        {
                            CompareCommonEntity commonEntity = new CompareCommonEntity();
                            commonEntity.Context = strColumn;
                            commonEntity.VersionA = dbR2R_PH_CONFIG_COMMON_Old.Rows[0][strColumn].ToString();
                            commonEntity.VersionB = dbR2R_PH_CONFIG_COMMON_Modify.Rows[0][strColumn].ToString();
                            if (commonEntity.VersionA.Equals(commonEntity.VersionB))
                            {
                                commonEntity.Result = "Same";
                            }
                            else
                            {
                                commonEntity.Result = "Modify";
                            }

                            CommonCompareList.Add(commonEntity);
                        }
                    }
                    #endregion
                }

                string contentCfgCommonDelete = "";
                if (dbR2R_PH_CONFIG_COMMON_Delete.Rows.Count > 0)
                {
                    //cfgCommonUpdateEntity.ColumnData = new string[54];
                    cfgCommonUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_COMMON_Delete, cfgCommonColumnNameList);
                    contentCfgCommonDelete = JsonHelp.SerializeObject(cfgCommonUpdateEntity);

                    #region Version Compare
                    if (IsVersionCompareCheckFlag)
                    {
                        foreach (var strColumn in cfgCommonColumnNameList)
                        {
                            CompareCommonEntity commonEntity = new CompareCommonEntity();
                            commonEntity.Context = strColumn;
                            commonEntity.VersionA = dbR2R_PH_CONFIG_COMMON_Delete.Rows[0][strColumn].ToString();
                            commonEntity.VersionB = "";
                            commonEntity.Result = "Delete";
                            CommonCompareList.Add(commonEntity);
                        }
                    }
                    #endregion
                }
                #endregion

                #region LIS
                #region Version Compare
                List<CompareCommonEntity> LISCompareList = new List<CompareCommonEntity>();
                if (IsVersionCompareCheckFlag)
                {
                    if (string.IsNullOrEmpty(VersionLatest.Latest_Version_LIS))
                    {
                        dbR2R_PH_CONFIG_LIS_Source = dbR2R_PH_CONFIG_LIS_Update.Clone();
                    }
                    else
                    {
                        CfgSingleTableInfoEntity entityLIS = new CfgSingleTableInfoEntity();
                        entityLIS = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(VersionLatest.Latest_Version_LIS);
                        dbR2R_PH_CONFIG_LIS_Source = CfgSingleTableInfoHelp.CreateDataTable(entityLIS);
                        dbR2R_PH_CONFIG_LIS_Source = DataTableHelp.RemoveBlankRow(dbR2R_PH_CONFIG_LIS_Source, cfgLISColumnKeyList);
                    }
                }
                #endregion

                DataTable dbCfgLISChanged = DataTableHelp.CompareDataTable(dbR2R_PH_CONFIG_LIS_Source, dbR2R_PH_CONFIG_LIS_Update, cfgLISColumnKeyList);
                DataTable dbR2R_PH_CONFIG_LIS_Old = DataTableHelp.GetChangedRecord(dbCfgLISChanged, "Status", "Old");
                DataTable dbR2R_PH_CONFIG_LIS_Modify = DataTableHelp.GetChangedRecord(dbCfgLISChanged, "Status", "Edit");
                DataTable dbR2R_PH_CONFIG_LIS_Add = DataTableHelp.GetChangedRecord(dbCfgLISChanged, "Status", "Add");
                DataTable dbR2R_PH_CONFIG_LIS_Delete = DataTableHelp.GetChangedRecord(dbCfgLISChanged, "Status", "Delete");

                string contentCfgLISAdd = "";
                if (dbR2R_PH_CONFIG_LIS_Add.Rows.Count > 0)
                {
                    cfgLISUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_LIS_Add, cfgLISColumnNameList);
                    contentCfgLISAdd = JsonHelp.SerializeObject(cfgLISUpdateEntity);

                    #region Version Compare
                    if (IsVersionCompareCheckFlag)
                    {
                        foreach (var strColumn in cfgLISColumnNameList)
                        {
                            CompareCommonEntity LISEntity = new CompareCommonEntity();
                            LISEntity.Context = strColumn;
                            LISEntity.VersionA = "";
                            LISEntity.VersionB = dbR2R_PH_CONFIG_LIS_Add.Rows[0][strColumn].ToString();
                            LISEntity.Result = "Add";
                            LISCompareList.Add(LISEntity);
                        }
                    }
                    #endregion
                }

                string contentCfgLISModify = "";
                if (dbR2R_PH_CONFIG_LIS_Modify.Rows.Count > 0)
                {
                    cfgLISUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_LIS_Modify, cfgLISColumnNameList);
                    contentCfgLISModify = JsonHelp.SerializeObject(cfgLISUpdateEntity);

                    #region Version Compare
                    if (IsVersionCompareCheckFlag)
                    {
                        foreach (var strColumn in cfgLISColumnNameList)
                        {
                            CompareCommonEntity LISEntity = new CompareCommonEntity();
                            LISEntity.Context = strColumn;
                            LISEntity.VersionA = dbR2R_PH_CONFIG_LIS_Old.Rows[0][strColumn].ToString();
                            LISEntity.VersionB = dbR2R_PH_CONFIG_LIS_Modify.Rows[0][strColumn].ToString();
                            if (LISEntity.VersionA.Equals(LISEntity.VersionB))
                            {
                                LISEntity.Result = "Same";
                            }
                            else
                            {
                                LISEntity.Result = "Modify";
                            }

                            LISCompareList.Add(LISEntity);
                        }
                    }
                    #endregion
                }
                string contentCfgLISDelete = "";
                if (dbR2R_PH_CONFIG_LIS_Delete.Rows.Count > 0)
                {
                    //cfgLISUpdateEntity.ColumnData = new string[14];
                    cfgLISUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_LIS_Delete, cfgLISColumnNameList);
                    contentCfgLISDelete = JsonHelp.SerializeObject(cfgLISUpdateEntity);

                    #region Version Compare
                    if (IsVersionCompareCheckFlag)
                    {
                        foreach (var strColumn in cfgLISColumnNameList)
                        {
                            CompareCommonEntity LISEntity = new CompareCommonEntity();
                            LISEntity.Context = strColumn;
                            LISEntity.VersionA = dbR2R_PH_CONFIG_LIS_Delete.Rows[0][strColumn].ToString();
                            LISEntity.VersionB = "";
                            LISEntity.Result = "Delete";
                            LISCompareList.Add(LISEntity);
                        }
                    }
                    #endregion
                }
                #endregion

                #region INIT CD
                string contentCfgInitCdAdd = "";
                string contentCfgInitCdModify = "";
                string contentCfgInitCdDelete = "";

                List<CompareInitEntity> CDInitCompareList = new List<CompareInitEntity>();

                DataTable dbR2R_PH_CONFIG_INIT_CD_SourceTemp = DataTableHelp.GetInitDataTable(dbInitValueSource, "CdInitContent", "PcInitContent", "CpeInitContent");
                DataTable dbR2R_PH_CONFIG_INIT_CD_UpdateTemp = DataTableHelp.GetInitDataTable(dbInitValueUpdate, "CdInitContent", "PcInitContent", "CpeInitContent");
                if (dbR2R_PH_CONFIG_INIT_CD_UpdateTemp.Rows.Count > 0)
                {
                    dbR2R_PH_CONFIG_INIT_CD_Update = CfgSingleTableInfoHelp.SingleTableInfoEntityToInitDataTable(cfgInitCdUpdateEntity, dbR2R_PH_CONFIG_INIT_CD_UpdateTemp, "CdInitContent");
                    if (cfgInitCdSourceEntity != null)
                    {
                        dbR2R_PH_CONFIG_INIT_CD_Source = CfgSingleTableInfoHelp.SingleTableInfoEntityToInitDataTable(cfgInitCdSourceEntity, dbR2R_PH_CONFIG_INIT_CD_SourceTemp, "CdInitContent");
                    }
                    else
                    {
                        dbR2R_PH_CONFIG_INIT_CD_Source = dbR2R_PH_CONFIG_INIT_CD_Update.Clone();
                    }

                    #region Version Compare
                    if (IsVersionCompareCheckFlag)
                    {
                        if (string.IsNullOrEmpty(VersionLatest.Latest_Version_CD_Init))
                        {
                            dbR2R_PH_CONFIG_INIT_CD_Source = dbR2R_PH_CONFIG_INIT_CD_Update.Clone();
                        }
                        else
                        {
                            int ParameterNameItemIndex = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitCdUpdateEntity.ColumnFormat, "INIT_PARAMETER_NAME:");
                            string UpdateParameterNameItem = CfgSingleTableInfoHelp.GetParameterNameItem(cfgInitCdUpdateEntity.ColumnData[ParameterNameItemIndex]);
                            string LatestVersionInitSort = CfgSingleTableInfoHelp.SortInitOriginalContent(VersionLatest.Latest_Version_CD_Init, UpdateParameterNameItem, ParameterNameItemIndex);

                            CfgSingleTableInfoEntity entityCDInit = new CfgSingleTableInfoEntity();
                            entityCDInit = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(LatestVersionInitSort);

                            dbR2R_PH_CONFIG_INIT_CD_Source = CfgSingleTableInfoHelp.CreateDataTable(entityCDInit);
                            dbR2R_PH_CONFIG_INIT_CD_Source = DataTableHelp.RemoveBlankRow(dbR2R_PH_CONFIG_INIT_CD_Source, cfgInitCdColumnKeyList);
                        }
                    }
                    #endregion

                    DataTable dbCfgInitCdChanged = DataTableHelp.CompareDataTable(dbR2R_PH_CONFIG_INIT_CD_Source, dbR2R_PH_CONFIG_INIT_CD_Update, cfgInitCdColumnKeyList);
                    DataTable dbR2R_PH_CONFIG_INIT_CD_Old = DataTableHelp.GetChangedRecord(dbCfgInitCdChanged, "Status", "Old");
                    DataTable dbR2R_PH_CONFIG_INIT_CD_Modify = DataTableHelp.GetChangedRecord(dbCfgInitCdChanged, "Status", "Edit");
                    DataTable dbR2R_PH_CONFIG_INIT_CD_Add = DataTableHelp.GetChangedRecord(dbCfgInitCdChanged, "Status", "Add");
                    DataTable dbR2R_PH_CONFIG_INIT_CD_Delete = DataTableHelp.GetChangedRecord(dbCfgInitCdChanged, "Status", "Delete");


                    if (dbR2R_PH_CONFIG_INIT_CD_Add.Rows.Count > 0)
                    {
                        cfgInitCdUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_INIT_CD_Add, cfgInitCdColumnNameList);
                        contentCfgInitCdAdd = JsonHelp.SerializeObject(cfgInitCdUpdateEntity);

                        #region Version Compare
                        if (IsVersionCompareCheckFlag)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_CD_Add.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                InitEntity.Context = dbR2R_PH_CONFIG_INIT_CD_Add.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_CD_Add.Rows[i]["RETICLE"].ToString();
                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_CD_Add.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = "";
                                InitEntity.VersionA_Delete = "";
                                InitEntity.VersionB_Add = dbR2R_PH_CONFIG_INIT_CD_Add.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionB_Modify = "";
                                InitEntity.VersionB_Delete = "";
                                InitEntity.Result = "Add";
                                CDInitCompareList.Add(InitEntity);
                            }

                        }
                        #endregion
                    }

                    if (dbR2R_PH_CONFIG_INIT_CD_Modify.Rows.Count > 0)
                    {
                        cfgInitCdUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_INIT_CD_Modify, cfgInitCdColumnNameList);
                        contentCfgInitCdModify = JsonHelp.SerializeObject(cfgInitCdUpdateEntity);

                        #region Version Compare
                        if (IsVersionCompareCheckFlag)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_CD_Modify.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                InitEntity.Context = dbR2R_PH_CONFIG_INIT_CD_Modify.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_CD_Modify.Rows[i]["RETICLE"].ToString();
                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_CD_Modify.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = dbR2R_PH_CONFIG_INIT_CD_Old.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionA_Delete = "";
                                InitEntity.VersionB_Add = "";
                                InitEntity.VersionB_Modify = dbR2R_PH_CONFIG_INIT_CD_Modify.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionB_Delete = "";
                                if (InitEntity.VersionA_Modify.Equals(InitEntity.VersionB_Modify))
                                {
                                    InitEntity.Result = "Same";
                                }
                                else
                                {
                                    InitEntity.Result = "Modify";
                                }

                                CDInitCompareList.Add(InitEntity);
                            }

                        }
                        #endregion
                    }

                    if (dbR2R_PH_CONFIG_INIT_CD_Delete.Rows.Count > 0)
                    {
                        cfgInitCdUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_INIT_CD_Delete, cfgInitCdColumnNameList);
                        contentCfgInitCdDelete = JsonHelp.SerializeObject(cfgInitCdUpdateEntity);

                        #region Version Compare
                        if (IsVersionCompareCheckFlag)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_CD_Delete.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                InitEntity.Context = dbR2R_PH_CONFIG_INIT_CD_Delete.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_CD_Delete.Rows[i]["RETICLE"].ToString();
                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_CD_Delete.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = "";
                                InitEntity.VersionA_Delete = dbR2R_PH_CONFIG_INIT_CD_Delete.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionB_Add = "";
                                InitEntity.VersionB_Modify = "";
                                InitEntity.VersionB_Delete = "";
                                //CDEntity.VersionA = dbR2R_PH_CONFIG_INIT_CD_Delete.Rows[i][6].ToString();
                                InitEntity.Result = "Delete";
                                CDInitCompareList.Add(InitEntity);
                            }

                        }
                        #endregion
                    }
                }
                //else
                //{
                //    if (dbR2R_PH_CONFIG_INIT_CD_SourceTemp.Rows.Count > 0)
                //    {
                //        if (cfgInitCdSourceEntity != null)
                //        {
                //            contentCfgInitCdDelete = JsonHelp.SerializeObject(cfgInitCdSourceEntity);
                //        }
                //    }
                //}
                #endregion

                #region OVL PC Init 
                string contentCfgInitOvlPCAdd = "";
                string contentCfgInitOvlPCModify = "";
                string contentCfgInitOvlPCDelete = "";

                List<CompareInitEntity> PCInitCompareList = new List<CompareInitEntity>();

                DataTable dbR2R_PH_CONFIG_INIT_OVL_PC_SourceTemp = DataTableHelp.GetInitDataTable(dbInitValueSource, "PcInitContent", "CpeInitContent", "CdInitContent");
                DataTable dbR2R_PH_CONFIG_INIT_OVL_PC_UpdateTemp = DataTableHelp.GetInitDataTable(dbInitValueUpdate, "PcInitContent", "CpeInitContent", "CdInitContent");
                if (dbR2R_PH_CONFIG_INIT_OVL_PC_UpdateTemp.Rows.Count > 0)
                {
                    dbR2R_PH_CONFIG_INIT_OVL_PC_Update = CfgSingleTableInfoHelp.SingleTableInfoEntityToInitDataTable(cfgInitOvlPCUpdateEntity, dbR2R_PH_CONFIG_INIT_OVL_PC_UpdateTemp, "PcInitContent");
                    if (cfgInitOvlPCSourceEntity != null)
                    {
                        dbR2R_PH_CONFIG_INIT_OVL_PC_Source = CfgSingleTableInfoHelp.SingleTableInfoEntityToInitDataTable(cfgInitOvlPCSourceEntity, dbR2R_PH_CONFIG_INIT_OVL_PC_SourceTemp, "PcInitContent");
                    }
                    else
                    {
                        dbR2R_PH_CONFIG_INIT_OVL_PC_Source = dbR2R_PH_CONFIG_INIT_OVL_PC_Update.Clone();
                    }

                    #region Version Compare
                    if (IsVersionCompareCheckFlag)
                    {
                        if (string.IsNullOrEmpty(VersionLatest.Latest_Version_OVL_PC_Init))
                        {
                            dbR2R_PH_CONFIG_INIT_OVL_PC_Source = dbR2R_PH_CONFIG_INIT_OVL_PC_Update.Clone();
                        }
                        else
                        {
                            int ParameterNameItemIndex = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitCdUpdateEntity.ColumnFormat, "INIT_PARAMETER_NAME:");
                            string UpdateParameterNameItem = CfgSingleTableInfoHelp.GetParameterNameItem(cfgInitOvlPCUpdateEntity.ColumnData[ParameterNameItemIndex]);
                            string lastPcInit = CfgSingleTableInfoHelp.SortInitOriginalContent(VersionLatest.Latest_Version_OVL_PC_Init, UpdateParameterNameItem, ParameterNameItemIndex);

                            CfgSingleTableInfoEntity entityPCInit = new CfgSingleTableInfoEntity();
                            entityPCInit = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(lastPcInit);
                            dbR2R_PH_CONFIG_INIT_OVL_PC_Source = CfgSingleTableInfoHelp.CreateDataTable(entityPCInit);
                            dbR2R_PH_CONFIG_INIT_OVL_PC_Source = DataTableHelp.RemoveBlankRow(dbR2R_PH_CONFIG_INIT_OVL_PC_Source, cfgInitOvlPCColumnKeyList);
                        }
                    }
                    #endregion

                    DataTable dbCfgInitOvlPCChanged = DataTableHelp.CompareDataTable(dbR2R_PH_CONFIG_INIT_OVL_PC_Source, dbR2R_PH_CONFIG_INIT_OVL_PC_Update, cfgInitOvlPCColumnKeyList);
                    DataTable dbR2R_PH_CONFIG_INIT_OVL_PC_Old = DataTableHelp.GetChangedRecord(dbCfgInitOvlPCChanged, "Status", "Old");
                    DataTable dbR2R_PH_CONFIG_INIT_OVL_PC_Modify = DataTableHelp.GetChangedRecord(dbCfgInitOvlPCChanged, "Status", "Edit");
                    DataTable dbR2R_PH_CONFIG_INIT_OVL_PC_Add = DataTableHelp.GetChangedRecord(dbCfgInitOvlPCChanged, "Status", "Add");
                    DataTable dbR2R_PH_CONFIG_INIT_OVL_PC_Delete = DataTableHelp.GetChangedRecord(dbCfgInitOvlPCChanged, "Status", "Delete");


                    if (dbR2R_PH_CONFIG_INIT_OVL_PC_Add.Rows.Count > 0)
                    {
                        cfgInitOvlPCUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_INIT_OVL_PC_Add, cfgInitOvlPCColumnNameList);
                        contentCfgInitOvlPCAdd = JsonHelp.SerializeObject(cfgInitOvlPCUpdateEntity);

                        #region Version Compare
                        if (IsVersionCompareCheckFlag)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_OVL_PC_Add.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                InitEntity.Context = dbR2R_PH_CONFIG_INIT_OVL_PC_Add.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_PC_Add.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_PC_Add.Rows[i]["PRE_TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_PC_Add.Rows[i]["PRE_RETICLE"].ToString();
                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_OVL_PC_Add.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = "";
                                InitEntity.VersionA_Delete = "";
                                InitEntity.VersionB_Add = dbR2R_PH_CONFIG_INIT_OVL_PC_Add.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionB_Modify = "";
                                InitEntity.VersionB_Delete = "";
                                //CDEntity.VersionB = dbR2R_PH_CONFIG_INIT_OVL_PC_Add.Rows[i][9].ToString();
                                InitEntity.Result = "Add";
                                PCInitCompareList.Add(InitEntity);
                            }

                        }
                        #endregion
                    }

                    if (dbR2R_PH_CONFIG_INIT_OVL_PC_Modify.Rows.Count > 0)
                    {
                        cfgInitOvlPCUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_INIT_OVL_PC_Modify, cfgInitOvlPCColumnNameList);
                        contentCfgInitOvlPCModify = JsonHelp.SerializeObject(cfgInitOvlPCUpdateEntity);

                        #region Version Compare
                        if (IsVersionCompareCheckFlag)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_OVL_PC_Modify.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                InitEntity.Context = dbR2R_PH_CONFIG_INIT_OVL_PC_Modify.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_PC_Modify.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_PC_Modify.Rows[i]["PRE_TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_PC_Modify.Rows[i]["PRE_RETICLE"].ToString();
                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_OVL_PC_Modify.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = dbR2R_PH_CONFIG_INIT_OVL_PC_Old.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionA_Delete = "";
                                InitEntity.VersionB_Add = "";
                                InitEntity.VersionB_Modify = dbR2R_PH_CONFIG_INIT_OVL_PC_Modify.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionB_Delete = "";

                                if (InitEntity.VersionA_Modify.Equals(InitEntity.VersionB_Modify))
                                {
                                    InitEntity.Result = "Same";
                                }
                                else
                                {
                                    InitEntity.Result = "Modify";
                                }
                                PCInitCompareList.Add(InitEntity);
                            }

                        }
                        #endregion
                    }

                    if (dbR2R_PH_CONFIG_INIT_OVL_PC_Delete.Rows.Count > 0)
                    {
                        cfgInitOvlPCUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_INIT_OVL_PC_Delete, cfgInitOvlPCColumnNameList);
                        contentCfgInitOvlPCDelete = JsonHelp.SerializeObject(cfgInitOvlPCUpdateEntity);

                        #region Version Compare
                        if (IsVersionCompareCheckFlag)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_OVL_PC_Delete.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                InitEntity.Context = dbR2R_PH_CONFIG_INIT_OVL_PC_Delete.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_PC_Delete.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_PC_Delete.Rows[i]["PRE_TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_PC_Delete.Rows[i]["PRE_RETICLE"].ToString();
                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_OVL_PC_Delete.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = "";
                                InitEntity.VersionA_Delete = dbR2R_PH_CONFIG_INIT_OVL_PC_Delete.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionB_Add = "";
                                InitEntity.VersionB_Modify = "";
                                InitEntity.VersionB_Delete = "";
                                InitEntity.Result = "Delete";
                                PCInitCompareList.Add(InitEntity);
                            }

                        }
                        #endregion
                    }
                }
                //else
                //{
                //    if (dbR2R_PH_CONFIG_INIT_OVL_PC_SourceTemp.Rows.Count > 0)
                //    {
                //        if (cfgInitOvlPCSourceEntity != null)
                //        {
                //            contentCfgInitOvlPCDelete = JsonHelp.SerializeObject(cfgInitOvlPCSourceEntity);
                //        }
                //    }
                //}
                #endregion

                #region OVL CPE Init
                string contentCfgInitOvlCPEAdd = "";
                string contentCfgInitOvlCPEModify = "";
                string contentCfgInitOvlCPEDelete = "";

                bool bISFixedMode = false;
                if (!string.IsNullOrEmpty(OVLCPER2RMode))
                {
                    if (OVLCPER2RMode.Equals("Fixed"))
                    {
                        bISFixedMode = true;
                    }
                }
                List<CompareInitEntity> CPEInitCompareList = new List<CompareInitEntity>();

                DataTable dbR2R_PH_CONFIG_INIT_OVL_CPE_SourceTemp = DataTableHelp.GetInitDataTable(dbInitValueSource, "CpeInitContent", "PcInitContent", "CdInitContent");
                DataTable dbR2R_PH_CONFIG_INIT_OVL_CPE_UpdateTemp = DataTableHelp.GetInitDataTable(dbInitValueUpdate, "CpeInitContent", "PcInitContent", "CdInitContent");
                if (dbR2R_PH_CONFIG_INIT_OVL_CPE_UpdateTemp.Rows.Count > 0)
                {
                    dbR2R_PH_CONFIG_INIT_OVL_CPE_Update = CfgSingleTableInfoHelp.SingleTableInfoEntityToInitDataTable(cfgInitOvlCPEUpdateEntity, dbR2R_PH_CONFIG_INIT_OVL_CPE_UpdateTemp, "CpeInitContent");
                    if (cfgInitOvlCPESourceEntity != null)
                    {
                        dbR2R_PH_CONFIG_INIT_OVL_CPE_Source = CfgSingleTableInfoHelp.SingleTableInfoEntityToInitDataTable(cfgInitOvlCPESourceEntity, dbR2R_PH_CONFIG_INIT_OVL_CPE_SourceTemp, "CpeInitContent");
                    }
                    else
                    {
                        dbR2R_PH_CONFIG_INIT_OVL_CPE_Source = dbR2R_PH_CONFIG_INIT_OVL_CPE_Update.Clone();
                    }

                    #region Version Compare
                    if (IsVersionCompareCheckFlag)
                    {
                        if (string.IsNullOrEmpty(VersionLatest.Latest_Version_OVL_CPE_Init))
                        {
                            dbR2R_PH_CONFIG_INIT_OVL_CPE_Source = dbR2R_PH_CONFIG_INIT_OVL_CPE_Update.Clone();
                        }
                        else
                        {
                            //string UpdateParameterNameItem = GetParameterNameItem(cfgInitOvlCPEUpdateEntity.ColumnData[7]);
                            //string LatestVersionInitSort = SortInitOriginalContent(VersionLatest.Latest_Version_OVL_CPE_Init, UpdateParameterNameItem,7);

                            CfgSingleTableInfoEntity entityCPEInit = new CfgSingleTableInfoEntity();
                            entityCPEInit = JsonHelp.DeserializeJsonToObject<CfgSingleTableInfoEntity>(VersionLatest.Latest_Version_OVL_CPE_Init);

                            dbR2R_PH_CONFIG_INIT_OVL_CPE_Source = CfgSingleTableInfoHelp.CreateDataTable(entityCPEInit);
                            dbR2R_PH_CONFIG_INIT_OVL_CPE_Source = DataTableHelp.RemoveBlankRow(dbR2R_PH_CONFIG_INIT_OVL_CPE_Source, cfgInitOvlCPEColumnKeyList);
                        }
                    }
                    #endregion

                    DataTable dbCfgInitOvlCPEChanged = DataTableHelp.CompareDataTable(dbR2R_PH_CONFIG_INIT_OVL_CPE_Source, dbR2R_PH_CONFIG_INIT_OVL_CPE_Update, cfgInitOvlCPEColumnKeyList);
                    DataTable dbR2R_PH_CONFIG_INIT_OVL_CPE_Old = DataTableHelp.GetChangedRecord(dbCfgInitOvlCPEChanged, "Status", "Old");
                    DataTable dbR2R_PH_CONFIG_INIT_OVL_CPE_Modify = DataTableHelp.GetChangedRecord(dbCfgInitOvlCPEChanged, "Status", "Edit");
                    DataTable dbR2R_PH_CONFIG_INIT_OVL_CPE_Add = DataTableHelp.GetChangedRecord(dbCfgInitOvlCPEChanged, "Status", "Add");
                    DataTable dbR2R_PH_CONFIG_INIT_OVL_CPE_Delete = DataTableHelp.GetChangedRecord(dbCfgInitOvlCPEChanged, "Status", "Delete");


                    if (dbR2R_PH_CONFIG_INIT_OVL_CPE_Add.Rows.Count > 0)
                    {
                        cfgInitOvlCPEUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_INIT_OVL_CPE_Add, cfgInitOvlCPEColumnNameList);
                        contentCfgInitOvlCPEAdd = JsonHelp.SerializeObject(cfgInitOvlCPEUpdateEntity);

                        #region Version Compare
                        if (IsVersionCompareCheckFlag)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_OVL_CPE_Add.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                InitEntity.Context = dbR2R_PH_CONFIG_INIT_OVL_CPE_Add.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_CPE_Add.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_CPE_Add.Rows[i]["PRE_TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_CPE_Add.Rows[i]["PRE_RETICLE"].ToString();
                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_OVL_CPE_Add.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                if (!bISFixedMode)
                                {
                                    if (InitEntity.ParameterName.Contains("CPE_Model_Timestamp"))
                                    {
                                        InitEntity.ParameterName = InitEntity.ParameterName.Replace(",CPE_Model_Timestamp", "");
                                    }
                                }
                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = "";
                                InitEntity.VersionA_Delete = "";
                                InitEntity.VersionB_Add = dbR2R_PH_CONFIG_INIT_OVL_CPE_Add.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionB_Add = InitEntity.VersionB_Add.TrimEnd(',');
                                InitEntity.VersionB_Modify = "";
                                InitEntity.VersionB_Delete = "";
                                //CDEntity.VersionB = dbR2R_PH_CONFIG_INIT_OVL_CPE_Add.Rows[i][8].ToString();
                                InitEntity.Result = "Add";
                                CPEInitCompareList.Add(InitEntity);
                            }

                        }
                        #endregion
                    }

                    if (dbR2R_PH_CONFIG_INIT_OVL_CPE_Modify.Rows.Count > 0)
                    {
                        cfgInitOvlCPEUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_INIT_OVL_CPE_Modify, cfgInitOvlCPEColumnNameList);
                        contentCfgInitOvlCPEModify = JsonHelp.SerializeObject(cfgInitOvlCPEUpdateEntity);

                        #region Version Compare
                        if (IsVersionCompareCheckFlag)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_OVL_CPE_Modify.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                InitEntity.Context = dbR2R_PH_CONFIG_INIT_OVL_CPE_Modify.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_CPE_Modify.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_CPE_Modify.Rows[i]["PRE_TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_CPE_Modify.Rows[i]["PRE_RETICLE"].ToString();
                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_OVL_CPE_Modify.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                if (!bISFixedMode)
                                {
                                    if (InitEntity.ParameterName.Contains("CPE_Model_Timestamp"))
                                    {
                                        //by zqk note 20200727
                                        InitEntity.ParameterName = InitEntity.ParameterName.Replace(",CPE_Model_Timestamp", "");
                                    }
                                }

                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = dbR2R_PH_CONFIG_INIT_OVL_CPE_Old.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionA_Delete = "";
                                InitEntity.VersionB_Add = "";
                                InitEntity.VersionB_Modify = dbR2R_PH_CONFIG_INIT_OVL_CPE_Modify.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionB_Modify = InitEntity.VersionB_Modify.TrimEnd(',');//by zqk note 20200727
                                InitEntity.VersionB_Delete = "";

                                if (InitEntity.VersionA_Modify.Equals(InitEntity.VersionB_Modify))
                                {
                                    InitEntity.Result = "Same";
                                }
                                else
                                {
                                    InitEntity.Result = "Modify";
                                }
                                CPEInitCompareList.Add(InitEntity);
                            }

                        }
                        #endregion
                    }

                    if (dbR2R_PH_CONFIG_INIT_OVL_CPE_Delete.Rows.Count > 0)
                    {
                        cfgInitOvlCPEUpdateEntity.ColumnData = CfgSingleTableInfoHelp.DataTableConvert(dbR2R_PH_CONFIG_INIT_OVL_CPE_Delete, cfgInitOvlCPEColumnNameList);
                        contentCfgInitOvlCPEDelete = JsonHelp.SerializeObject(cfgInitOvlCPEUpdateEntity);

                        #region Version Compare
                        if (IsVersionCompareCheckFlag)
                        {
                            for (int i = 0; i < dbR2R_PH_CONFIG_INIT_OVL_CPE_Delete.Rows.Count; i++)
                            {
                                CompareInitEntity InitEntity = new CompareInitEntity();
                                InitEntity.Context = dbR2R_PH_CONFIG_INIT_OVL_CPE_Delete.Rows[i]["TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_CPE_Delete.Rows[i]["RETICLE"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_CPE_Delete.Rows[i]["PRE_TOOL"].ToString() + " : " + dbR2R_PH_CONFIG_INIT_OVL_CPE_Delete.Rows[i]["PRE_RETICLE"].ToString();
                                InitEntity.ParameterName = dbR2R_PH_CONFIG_INIT_OVL_CPE_Delete.Rows[i]["INIT_PARAMETER_NAME"].ToString();
                                if (!bISFixedMode)
                                {
                                    if (InitEntity.ParameterName.Contains("CPE_Model_Timestamp"))
                                    {
                                        InitEntity.ParameterName = InitEntity.ParameterName.Replace(",CPE_Model_Timestamp", "");
                                    }
                                }
                                InitEntity.VersionA_Add = "";
                                InitEntity.VersionA_Modify = "";
                                InitEntity.VersionA_Delete = dbR2R_PH_CONFIG_INIT_OVL_CPE_Delete.Rows[i]["INIT_PARAMETER_VALUE"].ToString();
                                InitEntity.VersionA_Delete = InitEntity.VersionA_Delete.TrimEnd(',');
                                InitEntity.VersionB_Add = "";
                                InitEntity.VersionB_Modify = "";
                                InitEntity.VersionB_Delete = "";
                                //CDEntity.VersionB = dbR2R_PH_CONFIG_INIT_OVL_CPE_Delete.Rows[i][8].ToString();
                                InitEntity.Result = "Delete";
                                CPEInitCompareList.Add(InitEntity);
                            }

                        }
                        #endregion
                    }
                }
                //else 
                //{
                //    if (dbR2R_PH_CONFIG_INIT_OVL_CPE_SourceTemp.Rows.Count > 0)
                //    {
                //        if (cfgInitOvlCPESourceEntity != null)
                //        {
                //            contentCfgInitOvlCPEDelete = JsonHelp.SerializeObject(cfgInitOvlCPESourceEntity);
                //        }
                //    }
                //}
                #endregion

                if (contentCfgCommonDelete.Equals("") && contentCfgCommonAdd.Equals("") && contentCfgCommonModify.Equals("") &&
                    contentCfgLISDelete.Equals("") && contentCfgLISAdd.Equals("") && contentCfgLISModify.Equals("") &&
                    contentCfgInitCdDelete.Equals("") && contentCfgInitCdAdd.Equals("") && contentCfgInitCdModify.Equals("") &&
                    contentCfgInitOvlPCDelete.Equals("") && contentCfgInitOvlPCAdd.Equals("") && contentCfgInitOvlPCModify.Equals("") &&
                    contentCfgInitOvlCPEDelete.Equals("") && contentCfgInitOvlCPEAdd.Equals("") && contentCfgInitOvlCPEModify.Equals(""))
                {
                    System.Windows.Forms.MessageBox.Show("Not Change!");
                    IsSaveFlag = true;
                    OnQueryClick();

                    #region Set Save Button
                    SetBtnSaveStatus(false);
                    #endregion

                    return;
                }
                #endregion

                #region Version Compare
                if (IsVersionCompareCheckFlag)
                {
                    GetContextValuesVersionCompare();

                    var windowVersion = new MetroWindow();//Windows窗体      
                    VersionCompare viewVersion = new VersionCompare();
                    VersionCompareViewModel viewModelVersion = (VersionCompareViewModel)viewVersion.DataContext;
                    viewModelVersion.CurrentWindow = windowVersion;
                    viewModelVersion.IsBtnVersionCompareClickFlag = false;
                    viewModelVersion.IsUpdateValidationFlag = false;

                    viewModelVersion.ProductList = VersionCompareProductList;
                    viewModelVersion.LayerList = VersionCompareLayerList;
                    viewModelVersion.ToolGroupList = VersionCompareToolGroupList;
                    if (!viewModelVersion.ProductList.Contains(VersionCompareProduct))
                    {
                        viewModelVersion.ProductList.Add(VersionCompareProduct);
                    }
                    if (!viewModelVersion.LayerList.Contains(VersionCompareLayer))
                    {
                        viewModelVersion.LayerList.Add(VersionCompareLayer);
                    }
                    if (!viewModelVersion.ToolGroupList.Contains(VersionCompareToolGroup))
                    {
                        viewModelVersion.ToolGroupList.Add(VersionCompareToolGroup);
                    }
                    viewModelVersion.Product = VersionCompareProduct;
                    viewModelVersion.Layer = VersionCompareLayer;
                    viewModelVersion.ToolGroup = VersionCompareToolGroup;

                    viewModelVersion.CommonCompareList = new ObservableCollection<CompareCommonEntity>(CommonCompareList);
                    viewModelVersion.LISCompareList = new ObservableCollection<CompareCommonEntity>(LISCompareList);

                    viewModelVersion.CDInitCompareList = new ObservableCollection<CompareInitEntity>(CDInitCompareList);
                    viewModelVersion.PCInitCompareList = new ObservableCollection<CompareInitEntity>(PCInitCompareList);
                    viewModelVersion.CPEInitCompareList = new ObservableCollection<CompareInitEntity>(CPEInitCompareList);

                    windowVersion.Content = viewVersion;
                    windowVersion.Title = "Version Compare";
                    //windowVersion.Height = 960;
                    //windowVersion.Width = 1920;
                    windowVersion.WindowState = WindowState.Maximized;
                    //windowVersion.ResizeMode = ResizeMode.NoResize;
                    windowVersion.ResizeMode = ResizeMode.CanMinimize;
                    windowVersion.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                    windowVersion.ShowDialog();

                    if (!viewModelVersion.FlagSave)
                    {
                        return;
                    }
                }

                #endregion

                var windowCheck = new MetroWindow();//Windows窗体      
                UserCheck viewCheck = new UserCheck();
                UserCheckViewModel viewModelCheck = (UserCheckViewModel)viewCheck.DataContext;
                viewModelCheck.CurrentWindow = windowCheck;
                viewModelCheck.CurrentUserName = ClientInfo.CurrentUser;
                viewModelCheck.CurrentPassword = ClientInfo.Password;
                viewModelCheck.UserName = "";
                viewModelCheck.Password = "";

                windowCheck.Content = viewCheck;
                windowCheck.Title = "User Verification";
                windowCheck.Height = 240;
                windowCheck.Width = 400;
                //window.ResizeMode = ResizeMode.NoResize;
                windowCheck.ResizeMode = ResizeMode.CanMinimize;
                windowCheck.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                windowCheck.ShowDialog();

                if (viewModelCheck.IsCheckSuccess)
                {
                    bool flag = this._SettingMainService.R2R_UI_Config_PH_Update_CONFIG(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion,
                                                         contentCfgCommonDelete, contentCfgCommonAdd, contentCfgCommonModify,
                                                         contentCfgLISDelete, contentCfgLISAdd, contentCfgLISModify,
                                                         contentCfgInitCdDelete, contentCfgInitCdAdd, contentCfgInitCdModify,
                                                         contentCfgInitOvlPCDelete, contentCfgInitOvlPCAdd, contentCfgInitOvlPCModify,
                                                         contentCfgInitOvlCPEDelete, contentCfgInitOvlCPEAdd, contentCfgInitOvlCPEModify, QueryTime);
                    if (flag)
                    {
                        #region Version Compare

                        var windowVersion = new MetroWindow();//Windows窗体      
                        VersionCompare viewVersion = new VersionCompare();
                        VersionCompareViewModel viewModelVersion = (VersionCompareViewModel)viewVersion.DataContext;
                        viewModelVersion.CurrentWindow = windowVersion;
                        viewModelVersion.IsBtnVersionCompareClickFlag = false;
                        viewModelVersion.IsUpdateValidationFlag = true;

                        //by zqk add 20200508
                        if (!VersionCompareProductList.Contains(VersionCompareProduct))
                        {
                            VersionCompareProductList.Add(VersionCompareProduct);
                        }
                        if (!VersionCompareLayerList.Contains(VersionCompareLayer))
                        {
                            VersionCompareLayerList.Add(VersionCompareLayer);
                        }
                        if (!VersionCompareToolGroupList.Contains(VersionCompareToolGroup))
                        {
                            VersionCompareToolGroupList.Add(VersionCompareToolGroup);
                        }

                        viewModelVersion.ProductList = VersionCompareProductList;
                        viewModelVersion.LayerList = VersionCompareLayerList;
                        viewModelVersion.ToolGroupList = VersionCompareToolGroupList;


                        viewModelVersion.Product = VersionCompareProduct;
                        viewModelVersion.Layer = VersionCompareLayer;
                        viewModelVersion.ToolGroup = VersionCompareToolGroup;


                        windowVersion.Content = viewVersion;
                        windowVersion.Title = "Version Compare";
                        //windowVersion.Height = 960;
                        //windowVersion.Width = 1920;
                        windowVersion.WindowState = WindowState.Maximized;
                        //windowVersion.ResizeMode = ResizeMode.NoResize;
                        windowVersion.ResizeMode = ResizeMode.CanMinimize;
                        windowVersion.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                        windowVersion.ShowDialog();

                        #endregion

                        dbR2R_PH_CONFIG_COMMON_Source = dbR2R_PH_CONFIG_COMMON_Update.Copy();
                        dbR2R_PH_CONFIG_LIS_Source = dbR2R_PH_CONFIG_LIS_Update.Copy();
                        dbInitValueSource = dbInitValueUpdate.Copy();

                        IsProductSettingAddFlag = false;
                        IsCDEditOngoing = false;
                        IsPCEditOngoing = false;
                        IsCPEEditOngoing = false;
                        IsOVLPCChangeFlag = false;
                        IsOVLCPEChangeFlag = false;

                        CurrentEditProduct = "";
                        CurrentEditLayer = "";
                        CurrentEditToolGroup = "";

                        IsSaveFlag = true;
                        OnQueryClick();

                        #region Set Save Button
                        SetBtnSaveStatus(false);
                        SetSettingEnable(true);
                        #endregion
                    }
                    else
                    {
                        IsSaveFlag = true;
                        OnQueryClick();

                        #region Set Save Button
                        SetBtnSaveStatus(false);
                        #endregion

                        return;
                    }

                }
                else
                {
                    IsSaveFlag = true;
                    OnQueryClick();
                    //System.Windows.Forms.MessageBox.Show("Please check user information!");
                }
            }
            catch (Exception ee)
            {
                IsSaveFlag = true;
                OnQueryClick();

                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ProductSetting CopyProd Button Click Event Fun
        /// </summary>
        void OnCopyProdClick()
        {
            try
            {
                #region
                if (IsCDEditOngoing || IsPCEditOngoing || IsCPEEditOngoing)
                {
                    if (IsCDEditOngoing)
                    {
                        System.Windows.Forms.MessageBox.Show("Please complete the CD editing!");
                    }
                    else if (IsPCEditOngoing)
                    {
                        System.Windows.Forms.MessageBox.Show("Please complete the PC editing!");
                    }
                    else if (IsCPEEditOngoing)
                    {
                        System.Windows.Forms.MessageBox.Show("Please complete the CPE editing!");
                    }

                    foreach (var obj in ProductSettingList)
                    {
                        if (obj.Product.Equals(CurrentEditProduct) && obj.Layer.Equals(CurrentEditLayer) && obj.ToolGroup.Equals(CurrentEditToolGroup))
                        {
                            SelectedProductSetting = obj;
                            break;
                        }
                    }
                    return;
                }
                #endregion

                var window = new MetroWindow();//Windows窗体      
                CopyProd view = new CopyProd();
                CopyProdViewModel viewModel = (CopyProdViewModel)view.DataContext;

                List<string> strListProduct = new List<string>(ProductList);
                List<string> strListLayer = new List<string>(LayerList);
                List<string> strListToLayer = new List<string>(LayerList);
                strListProduct.Remove("*");
                strListToLayer.Remove("*");
                viewModel.ProductList = strListProduct;
                viewModel.LayerList = strListLayer;
                viewModel.ToLayerList = strListToLayer;
                viewModel.FromProduct = "";
                viewModel.FromLayer = "";
                viewModel.ToProduct = "";
                viewModel.ToLayer = "";
                viewModel.CurrentWindow = window;

                window.Content = view;
                window.Title = "Copy Product Setting";
                window.Height = 300;
                window.Width = 690;
                //window.WindowStyle = WindowStyle.None;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();
                if (viewModel.IsCopySuccess)
                {
                    string strProduct = Product;
                    string strLayer = Layer;
                    string strToolGroup = ToolGroup;
                    IsSaveFlag = true;
                    GetContextValues();
                    Product = strProduct;
                    Layer = strLayer;
                    ToolGroup = strToolGroup;
                    OnQueryClick();
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        #endregion

        #region CDSetting Field
        bool IsCDEditOngoing = false;

        private bool _IsCdConfirmEnable = false;
        public bool IsCdConfirmEnable
        {
            get { return this._IsCdConfirmEnable; }
            set { SetProperty(ref this._IsCdConfirmEnable, value); }
        }

        private bool _IsBtnCdCancelEnable = false;
        public bool IsBtnCdCancelEnable
        {
            get { return this._IsBtnCdCancelEnable; }
            set { SetProperty(ref this._IsBtnCdCancelEnable, value); }
        }

        private bool _IsBtnCdInitialEnable = false;
        public bool IsBtnCdInitialEnable
        {
            get { return this._IsBtnCdInitialEnable; }
            set { SetProperty(ref this._IsBtnCdInitialEnable, value); }
        }

        private bool _IsCdSettingEnable = false;
        public bool IsCdSettingEnable
        {
            get { return this._IsCdSettingEnable; }
            set { SetProperty(ref this._IsCdSettingEnable, value); }
        }

        private bool _IsCdEditBtnClick = false;
        public bool IsCdEditBtnClick
        {
            get { return this._IsCdEditBtnClick; }
            set { SetProperty(ref this._IsCdEditBtnClick, value); }
        }

        private bool _IsBtnCdEditEnable = false;
        public bool IsBtnCdEditEnable
        {
            get { return this._IsBtnCdEditEnable; }
            set { SetProperty(ref this._IsBtnCdEditEnable, value); }
        }

        private string _CDR2RMode = "";
        public string CDR2RMode
        {
            get { return this._CDR2RMode; }
            set { SetProperty(ref this._CDR2RMode, value); }
        }

        private List<string> _CDR2RModeList;
        public List<string> CDR2RModeList
        {
            get { return this._CDR2RModeList; }
            set { SetProperty(ref this._CDR2RModeList, value); }
        }

        private string _ExpireTime;
        public string ExpireTime
        {
            get { return this._ExpireTime; }
            set { SetProperty(ref this._ExpireTime, value); }
        }

        private string _CDTarget;
        public string CDTarget
        {
            get { return this._CDTarget; }
            set { SetProperty(ref this._CDTarget, value); }
        }

        private string _DoseMaxDelta;
        public string DoseMaxDelta
        {
            get { return this._DoseMaxDelta; }
            set { SetProperty(ref this._DoseMaxDelta, value); }
        }

        private string _Deadband;
        public string Deadband
        {
            get { return this._Deadband; }
            set { SetProperty(ref this._Deadband, value); }
        }

        private string _DoseSensitivity;
        public string DoseSensitivity
        {
            get { return this._DoseSensitivity; }
            set { SetProperty(ref this._DoseSensitivity, value); }
        }

        private string _DoseUSL;
        public string DoseUSL
        {
            get { return this._DoseUSL; }
            set { SetProperty(ref this._DoseUSL, value); }
        }

        private string _DoseLSL;
        public string DoseLSL
        {
            get { return this._DoseLSL; }
            set { SetProperty(ref this._DoseLSL, value); }
        }

        private string _DoseLumda;
        public string DoseLumda
        {
            get { return this._DoseLumda; }
            set { SetProperty(ref this._DoseLumda, value); }
        }

        private string _MaxOfOut;
        public string MaxOfOut
        {
            get { return this._MaxOfOut; }
            set { SetProperty(ref this._MaxOfOut, value); }
        }

        private string _MinOfOut;
        public string MinOfOut
        {
            get { return this._MinOfOut; }
            set { SetProperty(ref this._MinOfOut, value); }
        }

        private string _MinPiontOfAvg;
        public string MinPiontOfAvg
        {
            get { return this._MinPiontOfAvg; }
            set { SetProperty(ref this._MinPiontOfAvg, value); }
        }

        private string _CDLumda;
        public string CDLumda
        {
            get { return this._CDLumda; }
            set { SetProperty(ref this._CDLumda, value); }
        }

        private List<CD_InitialSettingEntity> _CDInitialSettingList = new List<CD_InitialSettingEntity>();
        public List<CD_InitialSettingEntity> CDInitialSettingList
        {
            get { return this._CDInitialSettingList; }
            set { SetProperty(ref this._CDInitialSettingList, value); }
        }

        List<CD_InitialSettingEntity> CDInitialSettingListUpdate = new List<CD_InitialSettingEntity>();
        #endregion

        #region CDSetting Event Define
        private DelegateCommand _CDTargetKeyDownCommand;
        public DelegateCommand CDTargetKeyDownCommand =>
            _CDTargetKeyDownCommand ?? (_CDTargetKeyDownCommand = new DelegateCommand(OnCDTargetKeyDown));

        private DelegateCommand _CDTargetChangedCommand;
        public DelegateCommand CDTargetChangedCommand =>
            _CDTargetChangedCommand ?? (_CDTargetChangedCommand = new DelegateCommand(OnCDTargetChanged));

        private DelegateCommand _CDTargetLostFocusCommand;
        public DelegateCommand CDTargetLostFocusCommand =>
            _CDTargetLostFocusCommand ?? (_CDTargetLostFocusCommand = new DelegateCommand(OnCDTargetLostFocus));

        private DelegateCommand _ExpireTimeKeyDownCommand;
        public DelegateCommand ExpireTimeKeyDownCommand =>
            _ExpireTimeKeyDownCommand ?? (_ExpireTimeKeyDownCommand = new DelegateCommand(OnExpireTimeKeyDown));

        private DelegateCommand _ExpireTimeChangedCommand;
        public DelegateCommand ExpireTimeChangedCommand =>
            _ExpireTimeChangedCommand ?? (_ExpireTimeChangedCommand = new DelegateCommand(OnExpireTimeChanged));

        private DelegateCommand _ExpireTimeLostFocusCommand;
        public DelegateCommand ExpireTimeLostFocusCommand =>
            _ExpireTimeLostFocusCommand ?? (_ExpireTimeLostFocusCommand = new DelegateCommand(OnExpireTimeLostFocus));

        private DelegateCommand _DoseMaxDeltaKeyDownCommand;
        public DelegateCommand DoseMaxDeltaKeyDownCommand =>
            _DoseMaxDeltaKeyDownCommand ?? (_DoseMaxDeltaKeyDownCommand = new DelegateCommand(OnDoseMaxDeltaKeyDown));

        private DelegateCommand _DoseMaxDeltaChangedCommand;
        public DelegateCommand DoseMaxDeltaChangedCommand =>
            _DoseMaxDeltaChangedCommand ?? (_DoseMaxDeltaChangedCommand = new DelegateCommand(OnDoseMaxDeltaChanged));

        private DelegateCommand _DoseMaxDeltaLostFocusCommand;
        public DelegateCommand DoseMaxDeltaLostFocusCommand =>
            _DoseMaxDeltaLostFocusCommand ?? (_DoseMaxDeltaLostFocusCommand = new DelegateCommand(OnDoseMaxDeltaLostFocus));

        private DelegateCommand _DoseUSLKeyDownCommand;
        public DelegateCommand DoseUSLKeyDownCommand =>
            _DoseUSLKeyDownCommand ?? (_DoseUSLKeyDownCommand = new DelegateCommand(OnDoseUSLKeyDown));

        private DelegateCommand _DoseUSLChangedCommand;
        public DelegateCommand DoseUSLChangedCommand =>
            _DoseUSLChangedCommand ?? (_DoseUSLChangedCommand = new DelegateCommand(OnDoseUSLChanged));

        private DelegateCommand _DoseUSLLostFocusCommand;
        public DelegateCommand DoseUSLLostFocusCommand =>
            _DoseUSLLostFocusCommand ?? (_DoseUSLLostFocusCommand = new DelegateCommand(OnDoseUSLLostFocus));

        private DelegateCommand _DoseLSLKeyDownCommand;
        public DelegateCommand DoseLSLKeyDownCommand =>
            _DoseLSLKeyDownCommand ?? (_DoseLSLKeyDownCommand = new DelegateCommand(OnDoseLSLKeyDown));

        private DelegateCommand _DoseLSLChangedCommand;
        public DelegateCommand DoseLSLChangedCommand =>
            _DoseLSLChangedCommand ?? (_DoseLSLChangedCommand = new DelegateCommand(OnDoseLSLChanged));

        private DelegateCommand _DoseLSLLostFocusCommand;
        public DelegateCommand DoseLSLLostFocusCommand =>
            _DoseLSLLostFocusCommand ?? (_DoseLSLLostFocusCommand = new DelegateCommand(OnDoseLSLLostFocus));

        private DelegateCommand _CDLumdaKeyDownCommand;
        public DelegateCommand CDLumdaKeyDownCommand =>
            _CDLumdaKeyDownCommand ?? (_CDLumdaKeyDownCommand = new DelegateCommand(OnCDLumdaKeyDown));

        private DelegateCommand _CDLumdaChangedCommand;
        public DelegateCommand CDLumdaChangedCommand =>
            _CDLumdaChangedCommand ?? (_CDLumdaChangedCommand = new DelegateCommand(OnCDLumdaChanged));

        private DelegateCommand _CDLumdaLostFocusCommand;
        public DelegateCommand CDLumdaLostFocusCommand =>
            _CDLumdaLostFocusCommand ?? (_CDLumdaLostFocusCommand = new DelegateCommand(OnCDLumdaLostFocus));

        private DelegateCommand _CDR2RModeSelectionChangedCommand;
        public DelegateCommand CDR2RModeSelectionChangedCommand =>
            _CDR2RModeSelectionChangedCommand ?? (_CDR2RModeSelectionChangedCommand = new DelegateCommand(OnCDR2RModeSelectionChanged));

        private DelegateCommand _BtnCDEditCommand;
        public DelegateCommand BtnCDEditCommand =>
            _BtnCDEditCommand ?? (_BtnCDEditCommand = new DelegateCommand(OnCDEditClick));

        private DelegateCommand _BtnCDConfirmCommand;
        public DelegateCommand BtnCDConfirmCommand =>
            _BtnCDConfirmCommand ?? (_BtnCDConfirmCommand = new DelegateCommand(OnCDConfirmClick));

        private DelegateCommand _BtnCDInitialSettingCommand;
        public DelegateCommand BtnCDInitialSettingCommand =>
            _BtnCDInitialSettingCommand ?? (_BtnCDInitialSettingCommand = new DelegateCommand(OnCDInitialSettingClick));
        #endregion

        #region CDSetting Event Fun
        string strCDTargetTmp = string.Empty;
        /// <summary>
        /// CD Target KeyDown Event Fun
        /// </summary>
        void OnCDTargetKeyDown()
        {
            try
            {
                strCDTargetTmp = CDTarget;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CD Target TextChanged Event Fun
        /// </summary>
        void OnCDTargetChanged()
        {
            try
            {
                double tmp = double.NaN;
                if (double.TryParse(CDTarget, out tmp))
                {

                }
                else
                {
                    //System.Windows.Forms.MessageBox.Show("CD Target was not in a correct format!");
                    CDTarget = strCDTargetTmp;
                    return;
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CD Target LostFocus Event Fun
        /// </summary>
        void OnCDTargetLostFocus()
        {
            try
            {
                double tmp = double.NaN;
                if (double.TryParse(CDTarget, out tmp))
                {

                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("CD Target was not in a correct format!");
                    CDTarget = strCDTargetTmp;
                    return;
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        string strExpireTimeTmp = string.Empty;
        /// <summary>
        /// CD Target KeyDown Event Fun
        /// </summary>
        void OnExpireTimeKeyDown()
        {
            try
            {
                strExpireTimeTmp = ExpireTime;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ExpireTime TextChanged Event Fun
        /// </summary>
        void OnExpireTimeChanged()
        {
            try
            {

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// ExpireTime LostFocus Event Fun
        /// </summary>
        void OnExpireTimeLostFocus()
        {
            try
            {
                uint tmp = 0;
                if (uint.TryParse(ExpireTime, out tmp))
                {

                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Expire Time was not in a correct format!");
                    ExpireTime = strExpireTimeTmp;
                    return;
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        string strDoseMaxDeltaTmp = string.Empty;
        /// <summary>
        /// CD Target KeyDown Event Fun
        /// </summary>
        void OnDoseMaxDeltaKeyDown()
        {
            try
            {
                strDoseMaxDeltaTmp = DoseMaxDelta;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Dose MaxDelta TextChanged Event Fun
        /// </summary>
        void OnDoseMaxDeltaChanged()
        {
            try
            {


            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Dose MaxDelta LostFocus Event Fun
        /// </summary>
        void OnDoseMaxDeltaLostFocus()
        {
            try
            {
                double tmp = double.NaN;
                if (double.TryParse(DoseMaxDelta, out tmp))
                {

                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Dose MaxDelta was not in a correct format!");
                    DoseMaxDelta = strDoseMaxDeltaTmp;
                    return;
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        string strDoseUSLTmp = string.Empty;
        /// <summary>
        /// CD Target KeyDown Event Fun
        /// </summary>
        void OnDoseUSLKeyDown()
        {
            try
            {
                strDoseUSLTmp = DoseUSL;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Dose USL TextChanged Event Fun
        /// </summary>
        void OnDoseUSLChanged()
        {
            try
            {

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Dose USL LostFocus Event Fun
        /// </summary>
        void OnDoseUSLLostFocus()
        {
            try
            {
                double tmp = double.NaN;
                if (double.TryParse(DoseUSL, out tmp))
                {
                    #region
                    //bool flag = false;
                    //flag = GetR2R_UI_Config_PH_Get_CONFIG_INIT_CD();
                    //if (!flag)
                    //{
                    //    //DoseUSL = strDoseUSLTmp;
                    //    return;
                    //}
                    //else
                    //{
                    //    foreach (var obj in CDInitialSettingList)
                    //    {
                    //        if (double.TryParse(obj.DoseValue, out tmp))
                    //        {
                    //            if (tmp < double.Parse(DoseLSL) || tmp > double.Parse(DoseUSL))
                    //            {
                    //                System.Windows.Forms.MessageBox.Show("DoseValue out of range!");
                    //                //DoseUSL = strDoseUSLTmp;
                    //                return;
                    //            }
                    //        }
                    //        else
                    //        {
                    //            System.Windows.Forms.MessageBox.Show("Input DoseValue was not in a correct format!");
                    //            return;
                    //        }
                    //    }
                    //}
                    #endregion
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Dose USL was not in a correct format!");
                    DoseUSL = strDoseUSLTmp;
                    return;
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        string strDoseLSLTmp = string.Empty;
        /// <summary>
        /// CD Target KeyDown Event Fun
        /// </summary>
        void OnDoseLSLKeyDown()
        {
            try
            {
                strDoseLSLTmp = DoseLSL;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Dose LSL TextChanged Event Fun
        /// </summary>
        void OnDoseLSLChanged()
        {
            try
            {


            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        ///Dose LSL LostFocus Event Fun
        /// </summary>
        void OnDoseLSLLostFocus()
        {
            try
            {
                double tmp = double.NaN;
                if (double.TryParse(DoseLSL, out tmp))
                {
                    #region
                    //bool flag = false;
                    //flag = GetR2R_UI_Config_PH_Get_CONFIG_INIT_CD();
                    //if (!flag)
                    //{
                    //    //DoseLSL = strDoseLSLTmp;
                    //    return;
                    //}
                    //else
                    //{
                    //    foreach (var obj in CDInitialSettingList)
                    //    {
                    //        if (double.TryParse(obj.DoseValue, out tmp))
                    //        {
                    //            if (tmp < double.Parse(DoseLSL) || tmp > double.Parse(DoseUSL))
                    //            {
                    //                System.Windows.Forms.MessageBox.Show("DoseValue out of range!");
                    //                //DoseLSL = strDoseLSLTmp;
                    //                return;
                    //            }
                    //        }
                    //        else
                    //        {
                    //            System.Windows.Forms.MessageBox.Show("Input DoseValue was not in a correct format!");
                    //            return;
                    //        }
                    //    }
                    //}
                    #endregion
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Dose LSL was not in a correct format!");
                    DoseLSL = strDoseLSLTmp;
                    return;
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        string strCDLumdaTmp = string.Empty;
        /// <summary>
        /// CD Lumda KeyDown Event Fun
        /// </summary>
        void OnCDLumdaKeyDown()
        {
            try
            {
                strCDLumdaTmp = CDLumda;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CD Lumda TextChanged Event Fun
        /// </summary>
        void OnCDLumdaChanged()
        {
            try
            {


            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        ///CD Lumda LostFocus Event Fun
        /// </summary>
        void OnCDLumdaLostFocus()
        {
            try
            {
                double tmp = double.NaN;
                if (double.TryParse(CDLumda, out tmp))
                {
                    if (tmp < 0 || tmp > 1)
                    {
                        System.Windows.Forms.MessageBox.Show("The Lumda has to be between 0 and 1!");
                        CDLumda = strCDLumdaTmp;
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("CD Lumda was not in a correct format!");
                    CDLumda = strCDLumdaTmp;
                    return;
                }

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CDR2RMode ComboBox SelectionChanged Event Fun
        /// </summary>
        void OnCDR2RModeSelectionChanged()
        {
            try
            {

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CD Edit Button Click Event Fun
        /// </summary>
        void OnCDEditClick()
        {
            try
            {
                if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                {
                    System.Windows.Forms.MessageBox.Show("Please select a record!");
                    return;
                }

                #region Check
                IsBtnSaveEnable = false;
                IsCdSettingEnable = true;
                IsCdEditBtnClick = true;
                IsCdConfirmEnable = true;
                IsBtnCdInitialEnable = false;

                IsCPEEditEnable = false;
                IsPCEditEnable = false;
                IsBtnPcSpecEnable = false;
                IsBtnPcInitialEnable = false;
                IsBtnCpeSpecEnable = false;
                IsBtnCpeInitialEnable = false;
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CD Confirm Button Click Event Fun
        /// </summary>
        void OnCDConfirmClick()
        {
            try
            {
                #region Check
                bool isCheckOnly = false;
                CurrentAction = "Edit";
                string CurrentMode = IsEditModeChecked ? "Edit" : "View";
                CfgEditStatusCheckResult checkResult = this._SettingMainService.R2R_UI_Config_EditStatusCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, QueryTime, isCheckOnly, ConfigUI, CurrentAction, CurrentMode);
                if (checkResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_EditStatusCheck Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (checkResult.ReturnCode.Equals("-1"))
                {
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                else if (checkResult.ReturnCode.Equals("0"))
                {

                }
                else if (checkResult.ReturnCode.Equals("1"))
                {
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                if (checkResult.InitMode.ToLower().Equals("edit"))
                {
                    CheckEditStatusMessage = "You are now in edit mode";
                    IsEditModeChecked = true;
                    IsViewOnlyChecked = false;
                    SetViewStatus(0x111);

                    #region Set Save Button
                    SetBtnSaveStatus();
                    #endregion

                    #region
                    #region Empty check
                    //if (String.IsNullOrEmpty(CDR2RMode))
                    //{
                    //    IsPCEditEnable = false;
                    //    IsCPEEditEnable = false;

                    //    System.Windows.Forms.MessageBox.Show("CD R2R Mode cannot be empty!");
                    //    return;
                    //}
                    if (String.IsNullOrEmpty(CDTarget))
                    {
                        IsPCEditEnable = false;
                        IsCPEEditEnable = false;

                        System.Windows.Forms.MessageBox.Show("CD Target cannot be empty!");
                        return;
                    }

                    if (String.IsNullOrEmpty(ExpireTime))
                    {
                        IsPCEditEnable = false;
                        IsCPEEditEnable = false;

                        System.Windows.Forms.MessageBox.Show("CD Expire Time cannot be empty!");
                        return;
                    }
                    if (String.IsNullOrEmpty(DoseMaxDelta))
                    {
                        IsPCEditEnable = false;
                        IsCPEEditEnable = false;

                        System.Windows.Forms.MessageBox.Show("Dose Max Delta cannot be empty!");
                        return;
                    }
                    if (String.IsNullOrEmpty(DoseUSL))
                    {
                        IsPCEditEnable = false;
                        IsCPEEditEnable = false;

                        System.Windows.Forms.MessageBox.Show("Dose USL cannot be empty!");
                        return;
                    }
                    if (String.IsNullOrEmpty(DoseLSL))
                    {
                        IsPCEditEnable = false;
                        IsCPEEditEnable = false;

                        System.Windows.Forms.MessageBox.Show("Dose LSL cannot be empty!");
                        return;
                    }
                    if (String.IsNullOrEmpty(CDLumda))
                    {
                        IsPCEditEnable = false;
                        IsCPEEditEnable = false;

                        System.Windows.Forms.MessageBox.Show("CD Lambda cannot be empty!");
                        return;
                    }

                    #endregion

                    if (IsCdEditBtnClick)
                    {
                        IsCdConfirmEnable = false;
                        IsCdSettingEnable = false;
                        IsBtnCdInitialEnable = true;
                    }

                    #region Edit Row
                    string strSelect = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                    DataRow[] rows = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strSelect);
                    if (rows.Count() > 0)
                    {
                        #region CD
                        if (string.IsNullOrEmpty(CDR2RMode))
                        {
                            CDR2RMode = "";
                        }
                        rows[0]["CD_R2R_MODE"] = CDR2RMode;
                        rows[0]["CD_TARGET"] = CDTarget;
                        rows[0]["DOSE_SENSITIVITY"] = DoseSensitivity;
                        rows[0]["CD_EXPIRE_TIME"] = ExpireTime;
                        rows[0]["DOSE_MAX_DELTA"] = DoseMaxDelta;
                        rows[0]["DOSE_USL"] = DoseUSL;
                        rows[0]["DOSE_LSL"] = DoseLSL;
                        rows[0]["CD_LUMDA"] = CDLumda;
                        #endregion
                    }
                    #endregion

                    IsCPEEditEnable = false;
                    IsPCEditEnable = false;

                    CurrentEditProduct = SelectedProductSetting.Product;
                    CurrentEditLayer = SelectedProductSetting.Layer;
                    CurrentEditToolGroup = SelectedProductSetting.ToolGroup;

                    IsCDEditOngoing = true;//by zqk Add 20191226
                    System.Windows.Forms.MessageBox.Show("Please check the CD_InitialSetting!");
                    #endregion

                    #region Set Save Button
                    SetBtnSaveStatus();
                    #endregion
                }
                else if (checkResult.InitMode.ToLower().Equals("view"))
                {
                    CheckEditStatusMessage = "You are now in view mode ---- Occupied by other";
                    IsEditModeChecked = false;
                    IsViewOnlyChecked = true;
                    SetViewStatus(0);
                }
                //else
                //{
                //    //view only
                //    SetViewStatus(0);
                //}
                #endregion

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CD InitialSetting Button Click Event Fun
        /// </summary>
        void OnCDInitialSettingClick()
        {
            try
            {
                bool flag = false;
                flag = GetR2R_UI_Config_PH_Get_CONFIG_INIT_CD();
                if (!flag)
                {
                    return;
                }

                var window = new MetroWindow();//Windows窗体      

                CD_InitialSetting view = new CD_InitialSetting();
                CD_InitialSettingViewModel viewModel = (CD_InitialSettingViewModel)view.DataContext;
                viewModel.CurrentWindow = window;
                viewModel.Product = SelectedProductSetting.Product;
                viewModel.Layer = SelectedProductSetting.Layer;
                viewModel.ToolGroup = SelectedProductSetting.ToolGroup;
                viewModel.IsCDInitialEnable = IsCDInitialEnable;
                viewModel.DoseUSL = DoseUSL;
                viewModel.DoseLSL = DoseLSL;

                //GetCDInitialSettingInfo();
                viewModel.SettingList = new ObservableCollection<CD_InitialSettingEntity>(CDInitialSettingList);

                window.Content = view;
                window.Title = "CD Initial Setting";
                window.Height = 450;
                window.Width = 800;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();

                if (viewModel.IsBtnOkClick)
                {
                    CDInitialSettingListUpdate = new List<CD_InitialSettingEntity>(viewModel.SettingList);

                    string strProduct = string.Empty;
                    string strLayer = string.Empty;
                    string strToolGroup = string.Empty;
                    string strTool = string.Empty;
                    string strReticle = string.Empty;
                    string strParmeter = string.Empty;
                    string strValue = string.Empty;
                    foreach (CD_InitialSettingEntity obj in CDInitialSettingListUpdate)
                    {
                        strProduct += obj.Product + ":";
                        strLayer += obj.Layer + ":";
                        strToolGroup += obj.ToolGroup + ":";
                        strTool += obj.Tool + ":";
                        strReticle += obj.Reticle + ":";
                        strParmeter += obj.Parameter + ":";
                        //str += obj.R2RMode + "," + obj.DoseValue + "," + obj.FocusValue + ":";
                        strValue += obj.R2RMode + "," + obj.FocusValue + "," + obj.DoseValue + "," + obj.DoseSensitivity + ":";
                    }
                    strProduct = CfgSingleTableInfoHelp.RemoveLastChar(strProduct, ":");
                    strLayer = CfgSingleTableInfoHelp.RemoveLastChar(strLayer, ":");
                    strToolGroup = CfgSingleTableInfoHelp.RemoveLastChar(strToolGroup, ":");
                    strTool = CfgSingleTableInfoHelp.RemoveLastChar(strTool, ":");
                    strReticle = CfgSingleTableInfoHelp.RemoveLastChar(strReticle, ":");
                    strParmeter = CfgSingleTableInfoHelp.RemoveLastChar(strParmeter, ":");
                    strValue = CfgSingleTableInfoHelp.RemoveLastChar(strValue, ":");

                    int itemIndex0 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitCdUpdateEntity.ColumnFormat, "PRODUCT:");
                    int itemIndex1 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitCdUpdateEntity.ColumnFormat, "LAYER:");
                    int itemIndex2 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitCdUpdateEntity.ColumnFormat, "TOOL_GROUP:");
                    int itemIndex3 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitCdUpdateEntity.ColumnFormat, "TOOL:");
                    int itemIndex4 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitCdUpdateEntity.ColumnFormat, "RETICLE:");
                    int itemIndex5 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitCdUpdateEntity.ColumnFormat, "INIT_PARAMETER_NAME:");
                    int itemIndex6 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitCdUpdateEntity.ColumnFormat, "INIT_PARAMETER_VALUE:");
                    if (itemIndex0 == -1 || itemIndex1 == -1 || itemIndex2 == -1 || itemIndex3 == -1 || itemIndex4 == -1 || itemIndex5 == -1 || itemIndex6 == -1)
                    {
                        string strMsg = "Please check ColumnFormat!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }

                    cfgInitCdUpdateEntity.ColumnData[itemIndex0] = strProduct;
                    cfgInitCdUpdateEntity.ColumnData[itemIndex1] = strLayer;
                    cfgInitCdUpdateEntity.ColumnData[itemIndex2] = strToolGroup;
                    cfgInitCdUpdateEntity.ColumnData[itemIndex3] = strTool;
                    cfgInitCdUpdateEntity.ColumnData[itemIndex4] = strReticle;
                    cfgInitCdUpdateEntity.ColumnData[itemIndex5] = strParmeter;
                    cfgInitCdUpdateEntity.ColumnData[itemIndex6] = strValue;

                    #region Save
                    string strContent = JsonHelp.SerializeObject(cfgInitCdUpdateEntity);
                    string strQuery = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                    DataRow[] rows = DataTableHelp.Query(dbInitValueUpdate, strQuery);
                    if (rows.Count() > 0)
                    {
                        rows[0]["CdInitContent"] = strContent;

                    }
                    #endregion

                    IsCPEEditEnable = true;
                    IsPCEditEnable = true;

                    IsCDEditOngoing = false;

                    CurrentEditProduct = SelectedProductSetting.Product;
                    CurrentEditLayer = SelectedProductSetting.Layer;
                    CurrentEditToolGroup = SelectedProductSetting.ToolGroup;

                    #region Set Save Button
                    SetBtnSaveStatus();
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region OVLSetting Field
        bool IsCPEEditOngoing = false;
        bool IsPCEditOngoing = false;
        bool IsOVLPCChangeFlag = false;
        bool IsOVLCPEChangeFlag = false;

        string CurrentOVLPCR2RMode = string.Empty;
        string CurrentOVLPCOVLMode = string.Empty;
        string CurrentOVLCPER2RMode = string.Empty;
        string CurrentOVLCPEOVLMode = string.Empty;

        List<string> OvlCpeInitCheckedList = new List<string>();
        List<string> OvlInitToolList = new List<string>();
        List<string> OvlInitReticleList = new List<string>();
        List<string> OvlInitPreToolList = new List<string>();
        List<string> OvlInitPreReticleList = new List<string>();

        List<PC_InitialSettingEntity> PC_InitialSettingEntityList = new List<PC_InitialSettingEntity>();
        List<PC_InitialSettingEntity> PC_InitialSettingEntityListUpdate = new List<PC_InitialSettingEntity>();

        List<CPE_InitialSettingEntity> CPE_InitialSettingEntityList = new List<CPE_InitialSettingEntity>();
        List<CPE_InitialSettingEntity> CPE_InitialSettingEntityListUpdate = new List<CPE_InitialSettingEntity>();

        List<PC_SpecSettingEntity> PC_SpecSettingEntityList = new List<PC_SpecSettingEntity>();
        List<CPE_SpecSettingEntity> CPE_SpecSettingEntityList = new List<CPE_SpecSettingEntity>();
        List<PCLimitChuckEntity> PCLimitChuckEntityList = new List<PCLimitChuckEntity>();
        List<ImportExcelCheckEntity> PCImportExcelCheckEntityList = new List<ImportExcelCheckEntity>();


        private string _OVL_PC_OOC_COUNT;
        public string OVL_PC_OOC_COUNT
        {
            get { return this._OVL_PC_OOC_COUNT; }
            set { SetProperty(ref this._OVL_PC_OOC_COUNT, value); }
        }

        private string _OVL_PC_OOS_COUNT;
        public string OVL_PC_OOS_COUNT
        {
            get { return this._OVL_PC_OOS_COUNT; }
            set { SetProperty(ref this._OVL_PC_OOS_COUNT, value); }
        }

        private string _OVL_CPE_OOC_COUNT;
        public string OVL_CPE_OOC_COUNT
        {
            get { return this._OVL_CPE_OOC_COUNT; }
            set { SetProperty(ref this._OVL_CPE_OOC_COUNT, value); }
        }

        private string _OVL_CPE_OOS_COUNT;
        public string OVL_CPE_OOS_COUNT
        {
            get { return this._OVL_PC_OOS_COUNT; }
            set { SetProperty(ref this._OVL_PC_OOS_COUNT, value); }
        }

        private bool _IsPcConfirmEnable = false;
        public bool IsPcConfirmEnable
        {
            get { return this._IsPcConfirmEnable; }
            set { SetProperty(ref this._IsPcConfirmEnable, value); }
        }

        private bool _IsBtnPcCancelEnable = false;
        public bool IsBtnPcCancelEnable
        {
            get { return this._IsBtnPcCancelEnable; }
            set { SetProperty(ref this._IsBtnPcCancelEnable, value); }
        }

        private bool _IsCpeConfirmEnable = false;
        public bool IsCpeConfirmEnable
        {
            get { return this._IsCpeConfirmEnable; }
            set { SetProperty(ref this._IsCpeConfirmEnable, value); }
        }

        private bool _IsBtnCpeCancelEnable = false;
        public bool IsBtnCpeCancelEnable
        {
            get { return this._IsBtnCpeCancelEnable; }
            set { SetProperty(ref this._IsBtnCpeCancelEnable, value); }
        }

        private bool _IsBtnPcSpecEnable = false;
        public bool IsBtnPcSpecEnable
        {
            get { return this._IsBtnPcSpecEnable; }
            set { SetProperty(ref this._IsBtnPcSpecEnable, value); }
        }

        private bool _IsBtnPcInitialEnable = false;
        public bool IsBtnPcInitialEnable
        {
            get { return this._IsBtnPcInitialEnable; }
            set { SetProperty(ref this._IsBtnPcInitialEnable, value); }
        }

        private bool _IsBtnCpeSpecEnable = false;
        public bool IsBtnCpeSpecEnable
        {
            get { return this._IsBtnCpeSpecEnable; }
            set { SetProperty(ref this._IsBtnCpeSpecEnable, value); }
        }

        private bool _IsBtnCpeInitialEnable = false;
        public bool IsBtnCpeInitialEnable
        {
            get { return this._IsBtnCpeInitialEnable; }
            set { SetProperty(ref this._IsBtnCpeInitialEnable, value); }
        }

        private bool _IsHOPCEnableFlag = false;
        public bool IsHOPCEnableFlag
        {
            get { return this._IsHOPCEnableFlag; }
            set { SetProperty(ref this._IsHOPCEnableFlag, value); }
        }

        private bool _IsIHOPCEnableFlag = false;
        public bool IsIHOPCEnableFlag
        {
            get { return this._IsIHOPCEnableFlag; }
            set { SetProperty(ref this._IsIHOPCEnableFlag, value); }
        }

        private bool _IsLinearFlag;
        public bool IsLinearFlag
        {
            get { return this._IsLinearFlag; }
            set { SetProperty(ref this._IsLinearFlag, value); }
        }

        private bool _IsHOPCFlag = false;
        public bool IsHOPCFlag
        {
            get { return this._IsHOPCFlag; }
            set { SetProperty(ref this._IsHOPCFlag, value); }
        }

        private bool _IsIHOPCFlag = false;
        public bool IsIHOPCFlag
        {
            get { return this._IsIHOPCFlag; }
            set { SetProperty(ref this._IsIHOPCFlag, value); }
        }

        private bool _IsPCSettingEnable = false;
        public bool IsPCSettingEnable
        {
            get { return this._IsPCSettingEnable; }
            set { SetProperty(ref this._IsPCSettingEnable, value); }
        }

        private bool _IsPCEditEnable = false;
        public bool IsPCEditEnable
        {
            get { return this._IsPCEditEnable; }
            set { SetProperty(ref this._IsPCEditEnable, value); }
        }

        private bool _IsPCEditBtnClick = false;
        public bool IsPCEditBtnClick
        {
            get { return this._IsPCEditBtnClick; }
            set { SetProperty(ref this._IsPCEditBtnClick, value); }
        }
        private bool _IsCPEEditEnable = false;
        public bool IsCPEEditEnable
        {
            get { return this._IsCPEEditEnable; }
            set { SetProperty(ref this._IsCPEEditEnable, value); }
        }

        private bool _IsCPESettingEnable = false;
        public bool IsCPESettingEnable
        {
            get { return this._IsCPESettingEnable; }
            set { SetProperty(ref this._IsCPESettingEnable, value); }
        }

        private bool _IsCPEEditBtnClick = false;
        public bool IsCPEEditBtnClick
        {
            get { return this._IsCPEEditBtnClick; }
            set { SetProperty(ref this._IsCPEEditBtnClick, value); }
        }

        private string _OVLPCSpecMaxDelta;
        public string OVLPCSpecMaxDelta
        {
            get { return this._OVLPCSpecMaxDelta; }
            set { SetProperty(ref this._OVLPCSpecMaxDelta, value); }
        }
        private string _OVLPCDeadband;
        public string OVLPCDeadband
        {
            get { return this._OVLPCDeadband; }
            set { SetProperty(ref this._OVLPCDeadband, value); }
        }
        private string _OVLPCUslCalc;
        public string OVLPCUslCalc
        {
            get { return this._OVLPCUslCalc; }
            set { SetProperty(ref this._OVLPCUslCalc, value); }
        }
        private string _OVLPCUslMetro;
        public string OVLPCUslMetro
        {
            get { return this._OVLPCUslMetro; }
            set { SetProperty(ref this._OVLPCUslMetro, value); }
        }

        private string _OVLPCLslMetro;
        public string OVLPCLslMetro
        {
            get { return this._OVLPCLslMetro; }
            set { SetProperty(ref this._OVLPCLslMetro, value); }
        }

        private string _OVLPCExpireTime;
        public string OVLPCExpireTime
        {
            get { return this._OVLPCExpireTime; }
            set { SetProperty(ref this._OVLPCExpireTime, value); }
        }
        private string _OVLPCLslCalc;
        public string OVLPCLslCalc
        {
            get { return this._OVLPCLslCalc; }
            set { SetProperty(ref this._OVLPCLslCalc, value); }
        }
        private string _OVLPCLumda;
        public string OVLPCLumda
        {
            get { return this._OVLPCLumda; }
            set { SetProperty(ref this._OVLPCLumda, value); }
        }

        private string _OVLPCUpdateTime;
        public string OVLPCUpdateTime
        {
            get { return this._OVLPCUpdateTime; }
            set { SetProperty(ref this._OVLPCUpdateTime, value); }
        }

        private string _OVLPCUpdateLot;
        public string OVLPCUpdateLot
        {
            get { return this._OVLPCUpdateLot; }
            set { SetProperty(ref this._OVLPCUpdateLot, value); }
        }

        private string _OVLCPER2RMode;
        public string OVLCPER2RMode
        {
            get { return this._OVLCPER2RMode; }
            set { SetProperty(ref this._OVLCPER2RMode, value); }
        }

        private string _OVLCPEOVLMode;
        public string OVLCPEOVLMode
        {
            get { return this._OVLCPEOVLMode; }
            set { SetProperty(ref this._OVLCPEOVLMode, value); }
        }

        private string _OVLCPESpecVarName;
        public string OVLCPESpecVarName
        {
            get { return this._OVLCPESpecVarName; }
            set { SetProperty(ref this._OVLCPESpecVarName, value); }
        }

        private string _OVLCPESpecMaxDelta;
        public string OVLCPESpecMaxDelta
        {
            get { return this._OVLCPESpecMaxDelta; }
            set { SetProperty(ref this._OVLCPESpecMaxDelta, value); }
        }

        private string _OVLCPEUslCalc;
        public string OVLCPEUslCalc
        {
            get { return this._OVLCPEUslCalc; }
            set { SetProperty(ref this._OVLCPEUslCalc, value); }
        }

        private string _OVLCPELslCalc;
        public string OVLCPELslCalc
        {
            get { return this._OVLCPELslCalc; }
            set { SetProperty(ref this._OVLCPELslCalc, value); }
        }

        private string _OVLCPEExpireTime;
        public string OVLCPEExpireTime
        {
            get { return this._OVLCPEExpireTime; }
            set { SetProperty(ref this._OVLCPEExpireTime, value); }
        }
        private string _OVLCPELumda;
        public string OVLCPELumda
        {
            get { return this._OVLCPELumda; }
            set { SetProperty(ref this._OVLCPELumda, value); }
        }

        private string _OVLCPEUpdateTime;
        public string OVLCPEUpdateTime
        {
            get { return this._OVLCPEUpdateTime; }
            set { SetProperty(ref this._OVLCPEUpdateTime, value); }
        }

        private string _OVLCPEUpdateLot;
        public string OVLCPEUpdateLot
        {
            get { return this._OVLCPEUpdateLot; }
            set { SetProperty(ref this._OVLCPEUpdateLot, value); }
        }

        private string _ListTool;
        public string ListTool
        {
            get { return this._ListTool; }
            set { SetProperty(ref this._ListTool, value); }
        }

        private string _ListReticle;
        public string ListReticle
        {
            get { return this._ListReticle; }
            set { SetProperty(ref this._ListReticle, value); }
        }

        private string _OVLPCFeedforeward;
        public string OVLPCFeedforeward
        {
            get { return this._OVLPCFeedforeward; }
            set { SetProperty(ref this._OVLPCFeedforeward, value); }
        }


        private string _OVLCPEFeedforeward;
        public string OVLCPEFeedforeward
        {
            get { return this._OVLCPEFeedforeward; }
            set { SetProperty(ref this._OVLCPEFeedforeward, value); }
        }

        private string _OVLCPEFixEdge;
        public string OVLCPEFixEdge
        {
            get { return this._OVLCPEFixEdge; }
            set { SetProperty(ref this._OVLCPEFixEdge, value); }
        }

        private string _ListPreTool;
        public string ListPreTool
        {
            get { return this._ListPreTool; }
            set { SetProperty(ref this._ListPreTool, value); }
        }

        private string _ListPreReticle;
        public string ListPreReticle
        {
            get { return this._ListPreReticle; }
            set { SetProperty(ref this._ListPreReticle, value); }
        }

        private string _OVLPCSpecVarName;
        public string OVLPCSpecVarName
        {
            get { return this._OVLPCSpecVarName; }
            set { SetProperty(ref this._OVLPCSpecVarName, value); }
        }

        private string _OVLPCSpecVarSelect;
        public string OVLPCSpecVarSelect
        {
            get { return this._OVLPCSpecVarSelect; }
            set { SetProperty(ref this._OVLPCSpecVarSelect, value); }
        }

        private string _OVLPCR2RMode;
        public string OVLPCR2RMode
        {
            get { return this._OVLPCR2RMode; }
            set { SetProperty(ref this._OVLPCR2RMode, value); }
        }
        private string _OVLPCOVLMode;
        public string OVLPCOVLMode
        {
            get { return this._OVLPCOVLMode; }
            set { SetProperty(ref this._OVLPCOVLMode, value); }
        }

        private List<string> _OVLPCR2RModeList;
        public List<string> OVLPCR2RModeList
        {
            get { return this._OVLPCR2RModeList; }
            set { SetProperty(ref this._OVLPCR2RModeList, value); }
        }

        private List<string> _OVLPCOVLModeList;
        public List<string> OVLPCOVLModeList
        {
            get { return this._OVLPCOVLModeList; }
            set { SetProperty(ref this._OVLPCOVLModeList, value); }
        }

        private List<string> _OVLCPER2RModeList;
        public List<string> OVLCPER2RModeList
        {
            get { return this._OVLCPER2RModeList; }
            set { SetProperty(ref this._OVLCPER2RModeList, value); }
        }

        private List<string> _OVLCPEOVLModeList;
        public List<string> OVLCPEOVLModeList
        {
            get { return this._OVLCPEOVLModeList; }
            set { SetProperty(ref this._OVLCPEOVLModeList, value); }
        }
        #endregion

        #region OVLSetting Event Define
        private DelegateCommand _OVLPCR2RModeSelectionChangedCommand;
        public DelegateCommand OVLPCR2RModeSelectionChangedCommand =>
            _OVLPCR2RModeSelectionChangedCommand ?? (_OVLPCR2RModeSelectionChangedCommand = new DelegateCommand(OnOVLPCR2RModeSelectionChanged));

        private DelegateCommand _CPER2RModeSelectionChangedCommand;
        public DelegateCommand CPER2RModeSelectionChangedCommand =>
            _CPER2RModeSelectionChangedCommand ?? (_CPER2RModeSelectionChangedCommand = new DelegateCommand(OnCPER2RModeSelectionChanged));

        private DelegateCommand _CPEOVLModeSelectionChangedCommand;
        public DelegateCommand CPEOVLModeSelectionChangedCommand =>
            _CPEOVLModeSelectionChangedCommand ?? (_CPEOVLModeSelectionChangedCommand = new DelegateCommand(OnCPEOVLModeSelectionChanged));

        private DelegateCommand _BtnPCSpecSettingCommand;
        public DelegateCommand BtnPCSpecSettingCommand =>
            _BtnPCSpecSettingCommand ?? (_BtnPCSpecSettingCommand = new DelegateCommand(OnPCSpecSettingClick));

        private DelegateCommand _BtnPCInitialSettingCommand;
        public DelegateCommand BtnPCInitialSettingCommand =>
            _BtnPCInitialSettingCommand ?? (_BtnPCInitialSettingCommand = new DelegateCommand(OnPCInitialSettingClick));

        private DelegateCommand _BtnCPESpecSettingCommand;
        public DelegateCommand BtnCPESpecSettingCommand =>
            _BtnCPESpecSettingCommand ?? (_BtnCPESpecSettingCommand = new DelegateCommand(OnCPESpecSettingClick));

        private DelegateCommand _BtnCPEInitialSettingCommand;
        public DelegateCommand BtnCPEInitialSettingCommand =>
            _BtnCPEInitialSettingCommand ?? (_BtnCPEInitialSettingCommand = new DelegateCommand(OnCPEInitialSettingClick));

        private DelegateCommand _BtnPCEditdCommand;
        public DelegateCommand BtnPCEditdCommand =>
            _BtnPCEditdCommand ?? (_BtnPCEditdCommand = new DelegateCommand(OnPCEditClick));

        private DelegateCommand _BtnPCConfirmCommand;
        public DelegateCommand BtnPCConfirmCommand =>
            _BtnPCConfirmCommand ?? (_BtnPCConfirmCommand = new DelegateCommand(OnPCConfirmClick));

        private DelegateCommand _BtnCPEEditdCommand;
        public DelegateCommand BtnCPEEditdCommand =>
            _BtnCPEEditdCommand ?? (_BtnCPEEditdCommand = new DelegateCommand(OnCPEEditClick));

        private DelegateCommand _BtnCPEConfirmCommand;
        public DelegateCommand BtnCPEConfirmCommand =>
            _BtnCPEConfirmCommand ?? (_BtnCPEConfirmCommand = new DelegateCommand(OnCPEConfirmClick));

        private DelegateCommand _IHOPCClickCommand;
        public DelegateCommand IHOPCClickCommand =>
            _IHOPCClickCommand ?? (_IHOPCClickCommand = new DelegateCommand(OnIHOPCClick));

        private DelegateCommand _HOPCClickCommand;
        public DelegateCommand HOPCClickCommand =>
            _HOPCClickCommand ?? (_HOPCClickCommand = new DelegateCommand(OnHOPCClick));

        #endregion

        #region OVLSetting Event Fun
        /// <summary>
        /// PCSpecSetting Button Click Event Fun
        /// </summary>
        void OnPCSpecSettingClick()
        {
            try
            {
                if (!string.IsNullOrEmpty(OVLPCR2RMode))
                {
                    if (OVLPCR2RMode.ToUpper().Equals("NONE"))
                    {
                        System.Windows.Forms.MessageBox.Show("OVL PC R2RMode is NONE Cannot Click PC Spec Setting!");
                        return;
                    }

                }

                bool flag = false;
                flag = GetR2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_PC();
                if (!flag)
                {
                    return;
                }

                #region
                //flag = GetR2R_UI_Config_PH_Get_CONFIG_INIT_OVL_PC();
                //if (!flag)
                //{
                //    return;
                //}

                #endregion

                var window = new MetroWindow();//Windows窗体      
                PC_SpecSetting view = new PC_SpecSetting();
                PC_SpecSettingViewModel viewModel = (PC_SpecSettingViewModel)view.DataContext;

                viewModel.CurrentWindow = window;
                viewModel.Product = SelectedProductSetting.Product;
                viewModel.Layer = SelectedProductSetting.Layer;
                viewModel.ToolGroup = SelectedProductSetting.ToolGroup;
                viewModel.OOCCount = OVL_PC_OOC_COUNT;
                viewModel.OOSCount = OVL_PC_OOS_COUNT;
                viewModel.SettingList = new ObservableCollection<PC_SpecSettingEntity>(PC_SpecSettingEntityList);
                viewModel.IsPCSpecEnable = IsPCSpecEnable;

                //viewModel.PCInitialSettingList = new ObservableCollection<PC_InitialSettingEntity>(PC_InitialSettingEntityList);
                viewModel.ChuckCheckList = new List<ImportExcelCheckEntity>(PCImportExcelCheckEntityList);

                window.Content = view;
                window.Title = "PC Spec Setting";
                window.Height = 640;
                window.Width = 1080;
                //window.ResizeMode = ResizeMode.NoResize;
                //window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();

                if (viewModel.IsBtnOkClick)
                {
                    PCImportExcelCheckEntityList = new List<ImportExcelCheckEntity>(viewModel.ChuckCheckList);
                    PCLimitChuckEntityList = new List<PCLimitChuckEntity>();
                    List<PC_SpecSettingEntity> entityList = new List<PC_SpecSettingEntity>(viewModel.SettingList);

                    string strParameter = "";
                    string strSelect = "";
                    string strMax_Delta = "";
                    string strDeadband = "";
                    string strUSL_Calc = "";
                    string strLSL_Calc = "";
                    string strUSL_Metro = "";
                    string strLSL_Metro = "";
                    foreach (PC_SpecSettingEntity entity in entityList)
                    {
                        strParameter += entity.Parameter + ",";
                        strSelect += entity.Select + ",";
                        strMax_Delta += entity.Max_Delta.ToString() + ",";
                        strDeadband += entity.Deadband.ToString() + ",";
                        strUSL_Calc += entity.USL_Calc.ToString() + ",";
                        strLSL_Calc += entity.LSL_Calc.ToString() + ",";
                        strUSL_Metro += entity.USL_Metro.ToString() + ",";
                        strLSL_Metro += entity.LSL_Metro.ToString() + ",";

                        PCLimitChuckEntity limitEntity = new PCLimitChuckEntity();
                        limitEntity.Parameter = entity.Parameter;
                        limitEntity.Max = double.Parse(entity.USL_Calc);
                        limitEntity.Min = double.Parse(entity.LSL_Calc);
                        PCLimitChuckEntityList.Add(limitEntity);
                    }

                    #region Edit Row
                    string strQuery = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                    DataRow[] rows = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strQuery);
                    if (rows.Count() > 0)
                    {

                        OVLPCSpecVarName = CfgSingleTableInfoHelp.RemoveLastChar(strParameter, ",");
                        OVLPCSpecVarSelect = CfgSingleTableInfoHelp.RemoveLastChar(strSelect, ",");
                        OVLPCSpecMaxDelta = CfgSingleTableInfoHelp.RemoveLastChar(strMax_Delta, ",");
                        OVLPCDeadband = CfgSingleTableInfoHelp.RemoveLastChar(strDeadband, ",");
                        OVLPCUslCalc = CfgSingleTableInfoHelp.RemoveLastChar(strUSL_Calc, ",");
                        OVLPCLslCalc = CfgSingleTableInfoHelp.RemoveLastChar(strLSL_Calc, ",");
                        OVLPCUslMetro = CfgSingleTableInfoHelp.RemoveLastChar(strUSL_Metro, ",");
                        OVLPCLslMetro = CfgSingleTableInfoHelp.RemoveLastChar(strLSL_Metro, ",");

                        rows[0]["OVL_PC_SPEC_VARNAME"] = OVLPCSpecVarName;
                        rows[0]["OVL_PC_SPEC_VAR_SELECT"] = OVLPCSpecVarSelect;
                        rows[0]["OVL_PC_SPEC_MAX_DELTA"] = OVLPCSpecMaxDelta;
                        rows[0]["OVL_PC_DEADBAND"] = OVLPCDeadband;
                        rows[0]["OVL_PC_USL_CALC"] = OVLPCUslCalc;
                        rows[0]["OVL_PC_LSL_CALC"] = OVLPCLslCalc;
                        rows[0]["OVL_PC_USL_METRO"] = OVLPCUslMetro;
                        rows[0]["OVL_PC_LSL_METRO"] = OVLPCLslMetro;

                        rows[0]["OVL_PC_OOC_COUNT"] = viewModel.OOCCount;
                        rows[0]["OVL_PC_OOS_COUNT"] = viewModel.OOSCount;
                    }
                    #endregion

                    IsBtnPcInitialEnable = true;

                    IsBtnCdEditEnable = false;
                    IsCPEEditEnable = false;

                    CurrentEditProduct = SelectedProductSetting.Product;
                    CurrentEditLayer = SelectedProductSetting.Layer;
                    CurrentEditToolGroup = SelectedProductSetting.ToolGroup;

                    IsPCEditOngoing = true;//by zqk Add 20191226
                    System.Windows.Forms.MessageBox.Show("Please check the PC_InitialSetting!");
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// PCInitialSetting Button Click Event Fun
        /// </summary>
        void OnPCInitialSettingClick()
        {
            try
            {
                bool flag = false;
                flag = GetR2R_UI_Config_PH_Get_CONFIG_INIT_OVL_PC();
                if (!flag)
                {
                    return;
                }


                //List<PC_InitialParamSettingEntity> PC_InitialParamSettingEntityList = new List<PC_InitialParamSettingEntity>();

                var window = new MetroWindow();//Windows窗体      
                PC_InitialSetting view = new PC_InitialSetting();
                PC_InitialSettingViewModel viewModel = (PC_InitialSettingViewModel)view.DataContext;

                viewModel.CurrentWindow = window;
                viewModel.Product = SelectedProductSetting.Product;
                viewModel.Layer = SelectedProductSetting.Layer;
                viewModel.ToolGroup = SelectedProductSetting.ToolGroup;
                viewModel.SettingList = new ObservableCollection<PC_InitialSettingEntity>(PC_InitialSettingEntityList);

                List<PCLimitChuckEntity> PCLimitChuckListSort = new List<PCLimitChuckEntity>();
                List<ImportExcelCheckEntity> ImportCheckListSort = new List<ImportExcelCheckEntity>();
                if (PC_InitialSettingEntityList.Count > 0)
                {
                    string parameterItem = CfgSingleTableInfoHelp.GetParameterNameItem(PC_InitialSettingEntityList[0].INIT_PARAMETER_NAME);
                    List<string> parameterNameItemList = new List<string>(parameterItem.Split(','));
                    foreach (var str in parameterNameItemList)
                    {
                        foreach (var entityTmp in PCLimitChuckEntityList)
                        {
                            if (str.Equals(entityTmp.Parameter))
                            {
                                PCLimitChuckListSort.Add(entityTmp);
                                break;
                            }
                        }

                        foreach (var entityTmp in PCImportExcelCheckEntityList)
                        {
                            if (str.Equals(entityTmp.Parameter))
                            {
                                ImportCheckListSort.Add(entityTmp);
                                break;
                            }
                        }
                    }

                }

                //viewModel.PCLimitChuckList = new List<PCLimitChuckEntity>(PCLimitChuckEntityList);
                //viewModel.ImportCheckList = new List<ImportExcelCheckEntity>(PCImportExcelCheckEntityList);

                viewModel.PCLimitChuckList = new List<PCLimitChuckEntity>(PCLimitChuckListSort);
                viewModel.ImportCheckList = new List<ImportExcelCheckEntity>(ImportCheckListSort);
                viewModel.IsPCInitialEnable = IsPCInitialEnable;

                window.Content = view;
                window.Title = "PC Initial Setting";
                window.Height = 640;
                window.Width = 1080;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();

                if (viewModel.IsBtnOkClick)
                {
                    PC_InitialSettingEntityListUpdate = new List<PC_InitialSettingEntity>(viewModel.SettingList);

                    #region 
                    string strProduct = string.Empty;
                    string strLayer = string.Empty;
                    string strToolGroup = string.Empty;
                    string strTool = string.Empty;
                    string strReticle = string.Empty;
                    string strPreTool = string.Empty;
                    string strPreReticle = string.Empty;
                    string strMode = string.Empty;
                    string strParmeter = string.Empty;
                    string strValue = string.Empty;

                    string strListTool = string.Empty;
                    string strListReticle = string.Empty;
                    List<string> ListTool = new List<string>();
                    List<string> ListReticle = new List<string>();

                    foreach (PC_InitialSettingEntity obj in PC_InitialSettingEntityListUpdate)
                    {
                        strProduct += obj.PRODUCT + ":";
                        strLayer += obj.LAYER + ":";
                        strToolGroup += obj.TOOL_GROUP + ":";
                        strTool += obj.TOOL + ":";
                        strReticle += obj.RETICLE + ":";
                        strPreTool += obj.PRE_TOOL + ":";
                        strPreReticle += obj.PRE_RETICLE + ":";
                        strMode += obj.OVL_PC_MODE + ":";
                        strParmeter += obj.INIT_PARAMETER_NAME + ":";
                        strValue += obj.INIT_PARAMETER_VALUE + ":";

                        foreach (var str in obj.ToolList)
                        {
                            if (!ListTool.Contains(str))
                            {
                                ListTool.Add(str);
                            }
                        }
                        if (!ListReticle.Contains(obj.RETICLE))
                        {
                            ListReticle.Add(obj.RETICLE);
                        }
                        foreach (var str in obj.ReticleList)
                        {
                            if (!ListReticle.Contains(str))
                            {
                                ListReticle.Add(str);
                            }
                        }
                    }

                    ListTool.Remove("*");
                    ListReticle.Remove("*");

                    foreach (var str in ListTool)
                    {
                        strListTool += str + ",";
                    }
                    foreach (var str in ListReticle)
                    {
                        strListReticle += str + ",";
                    }
                    strListTool = CfgSingleTableInfoHelp.RemoveLastChar(strListTool, ",");
                    strListReticle = CfgSingleTableInfoHelp.RemoveLastChar(strListReticle, ",");

                    strProduct = CfgSingleTableInfoHelp.RemoveLastChar(strProduct, ":");
                    strLayer = CfgSingleTableInfoHelp.RemoveLastChar(strLayer, ":");
                    strToolGroup = CfgSingleTableInfoHelp.RemoveLastChar(strToolGroup, ":");
                    strTool = CfgSingleTableInfoHelp.RemoveLastChar(strTool, ":");
                    strReticle = CfgSingleTableInfoHelp.RemoveLastChar(strReticle, ":");
                    strPreTool = CfgSingleTableInfoHelp.RemoveLastChar(strPreTool, ":");
                    strPreReticle = CfgSingleTableInfoHelp.RemoveLastChar(strPreReticle, ":");
                    strMode = CfgSingleTableInfoHelp.RemoveLastChar(strMode, ":");
                    strParmeter = CfgSingleTableInfoHelp.RemoveLastChar(strParmeter, ":");
                    strValue = CfgSingleTableInfoHelp.RemoveLastChar(strValue, ":");

                    int itemIndex0 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlPCUpdateEntity.ColumnFormat, "PRODUCT:");
                    int itemIndex1 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlPCUpdateEntity.ColumnFormat, "LAYER:");
                    int itemIndex2 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlPCUpdateEntity.ColumnFormat, "TOOL_GROUP:");
                    int itemIndex3 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlPCUpdateEntity.ColumnFormat, "TOOL:");
                    int itemIndex4 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlPCUpdateEntity.ColumnFormat, "RETICLE:");
                    int itemIndex5 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlPCUpdateEntity.ColumnFormat, "PRE_TOOL:");
                    int itemIndex6 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlPCUpdateEntity.ColumnFormat, "PRE_RETICLE:");
                    int itemIndex7 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlPCUpdateEntity.ColumnFormat, "OVL_PC_MODE:");
                    int itemIndex8 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlPCUpdateEntity.ColumnFormat, "INIT_PARAMETER_NAME:");
                    int itemIndex9 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlPCUpdateEntity.ColumnFormat, "INIT_PARAMETER_VALUE:");
                    if (itemIndex0 == -1 || itemIndex1 == -1 || itemIndex2 == -1 || itemIndex3 == -1 || itemIndex4 == -1 || itemIndex5 == -1 || itemIndex6 == -1 || itemIndex7 == -1 || itemIndex8 == -1 || itemIndex9 == -1)
                    {
                        string strMsg = "Please check ColumnFormat!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }
                    cfgInitOvlPCUpdateEntity.ColumnData[itemIndex0] = strProduct;
                    cfgInitOvlPCUpdateEntity.ColumnData[itemIndex1] = strLayer;
                    cfgInitOvlPCUpdateEntity.ColumnData[itemIndex2] = strToolGroup;
                    cfgInitOvlPCUpdateEntity.ColumnData[itemIndex3] = strTool;
                    cfgInitOvlPCUpdateEntity.ColumnData[itemIndex4] = strReticle;
                    cfgInitOvlPCUpdateEntity.ColumnData[itemIndex5] = strPreTool;
                    cfgInitOvlPCUpdateEntity.ColumnData[itemIndex6] = strPreReticle;
                    cfgInitOvlPCUpdateEntity.ColumnData[itemIndex7] = strMode;
                    cfgInitOvlPCUpdateEntity.ColumnData[itemIndex8] = strParmeter;
                    cfgInitOvlPCUpdateEntity.ColumnData[itemIndex9] = strValue;
                    #endregion

                    #region Save
                    string strContent = JsonHelp.SerializeObject(cfgInitOvlPCUpdateEntity);
                    string strQuery = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                    DataRow[] rows = DataTableHelp.Query(dbInitValueUpdate, strQuery);
                    if (rows.Count() > 0)
                    {
                        rows[0]["PcInitContent"] = strContent;

                    }

                    DataRow[] rowsCommon = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strQuery);
                    if (rowsCommon.Count() > 0)
                    {
                        rowsCommon[0]["LIST_TOOL"] = strListTool;
                        rowsCommon[0]["LIST_RETICLE"] = strListReticle;
                    }
                    #endregion

                    IsBtnCdEditEnable = true;
                    IsCPEEditEnable = true;
                    IsPCEditEnable = true;//by zqk add 1225

                    IsPCEditOngoing = false;

                    //by zqk Add 2020 0313
                    if (!string.IsNullOrEmpty(OVLCPER2RMode) && OVLCPER2RMode.ToUpper().Equals("NONE"))
                    {
                        IsCPEEditOngoing = false;
                    }

                    CurrentEditProduct = SelectedProductSetting.Product;
                    CurrentEditLayer = SelectedProductSetting.Layer;
                    CurrentEditToolGroup = SelectedProductSetting.ToolGroup;

                    #region Set Save Button
                    SetBtnSaveStatus();
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CPESpecSetting Button Click Event Fun
        /// </summary>
        void OnCPESpecSettingClick()
        {
            try
            {
                bool flag = false;
                flag = GetR2R_UI_Config_PH_Get_CONFIG_SPEC_OVL_CPE();
                if (!flag)
                {
                    return;
                }

                var window = new MetroWindow();//Windows窗体      
                CPE_SpecSetting view = new CPE_SpecSetting();
                CPE_SpecSettingViewModel viewModel = (CPE_SpecSettingViewModel)view.DataContext;

                viewModel.CurrentWindow = window;
                viewModel.Product = SelectedProductSetting.Product;
                viewModel.Layer = SelectedProductSetting.Layer;
                viewModel.ToolGroup = SelectedProductSetting.ToolGroup;
                viewModel.OOCCount = OVL_CPE_OOC_COUNT;
                viewModel.OOSCount = OVL_CPE_OOS_COUNT;
                viewModel.SettingList = new ObservableCollection<CPE_SpecSettingEntity>(CPE_SpecSettingEntityList);
                viewModel.IsCPESpecEnable = IsCPESpecEnable;

                window.Content = view;
                window.Title = "CPE Spec Setting";
                window.Height = 640;
                window.Width = 1080;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();

                if (viewModel.IsBtnOkClick)
                {
                    OVL_CPE_OOC_COUNT = viewModel.OOCCount;
                    List<CPE_SpecSettingEntity> entityList = new List<CPE_SpecSettingEntity>(viewModel.SettingList);

                    string strParameter = "";
                    string strMax_Delta = "";
                    string strUSL_Calc = "";
                    string strLSL_Calc = "";
                    foreach (CPE_SpecSettingEntity entity in entityList)
                    {
                        strParameter += entity.Parameter + ",";
                        strMax_Delta += entity.Max_Delta.ToString() + ",";
                        strUSL_Calc += entity.USL.ToString() + ",";
                        strLSL_Calc += entity.LSL.ToString() + ",";
                    }

                    #region Edit Row
                    string strQuery = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                    DataRow[] rows = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strQuery);
                    if (rows.Count() > 0)
                    {
                        OVLCPESpecVarName = CfgSingleTableInfoHelp.RemoveLastChar(strParameter, ",");
                        OVLCPESpecMaxDelta = CfgSingleTableInfoHelp.RemoveLastChar(strMax_Delta, ",");
                        OVLCPEUslCalc = CfgSingleTableInfoHelp.RemoveLastChar(strUSL_Calc, ",");
                        OVLCPELslCalc = CfgSingleTableInfoHelp.RemoveLastChar(strLSL_Calc, ",");

                        rows[0]["OVL_CPE_SPEC_VARNAME"] = OVLCPESpecVarName;
                        rows[0]["OVL_CPE_SPEC_MAX_DELTA"] = OVLCPESpecMaxDelta;
                        rows[0]["OVL_CPE_USL_CALC"] = OVLCPEUslCalc;
                        rows[0]["OVL_CPE_LSL_CALC"] = OVLCPELslCalc;
                        rows[0]["OVL_CPE_OOC_COUNT"] = viewModel.OOCCount;
                        rows[0]["OVL_CPE_OOS_COUNT"] = viewModel.OOSCount;
                    }
                    #endregion

                    if (!OVLCPER2RMode.Equals("NONE"))
                    {
                        IsBtnCpeInitialEnable = true;

                        IsCPEEditOngoing = true;

                        IsBtnCdEditEnable = false;
                        IsPCEditEnable = false;
                    }

                    CurrentEditProduct = SelectedProductSetting.Product;
                    CurrentEditLayer = SelectedProductSetting.Layer;
                    CurrentEditToolGroup = SelectedProductSetting.ToolGroup;

                    #region Set Save Button
                    SetBtnSaveStatus();
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CPEInitialSetting Button Click Event Fun
        /// </summary>
        void OnCPEInitialSettingClick()
        {
            try
            {
                bool flag = false;
                flag = GetR2R_UI_Config_PH_Get_CONFIG_INIT_OVL_CPE();
                if (!flag)
                {
                    return;
                }


                foreach (var obj in CPE_InitialSettingEntityList)
                {
                    if (OVLCPER2RMode.Equals("Fixed"))
                    {
                        obj.RETICLE = "*";
                        obj.PRE_TOOL = "*";
                        obj.PRE_RETICLE = "*";
                    }

                    if (obj.TOOL.Equals("*"))
                    {
                        if (!obj.ToolList.Contains("*"))
                        {
                            obj.ToolList.Add("*");
                        }
                    }
                    if (obj.RETICLE.Equals("*"))
                    {
                        if (!obj.ReticleList.Contains("*"))
                        {
                            obj.ReticleList.Add("*");
                        }
                    }
                    if (obj.PRE_TOOL.Equals("*"))
                    {
                        if (!obj.PreToolList.Contains("*"))
                        {
                            obj.PreToolList.Add("*");
                        }
                    }
                    if (obj.PRE_RETICLE.Equals("*"))
                    {
                        if (!obj.PreReticleList.Contains("*"))
                        {
                            obj.PreReticleList.Add("*");
                        }
                    }

                }

                //EventAggregator.GetEvent<CPEInitialFlagEvent>().Publish(OVLCPER2RMode);
                var window = new MetroWindow();//Windows窗体      
                CPE_InitialSetting view = new CPE_InitialSetting();
                CPE_InitialSettingViewModel viewModel = (CPE_InitialSettingViewModel)view.DataContext;

                viewModel.CurrentWindow = window;
                viewModel.CPER2RMode = OVLCPER2RMode;
                viewModel.Product = SelectedProductSetting.Product;
                viewModel.Layer = SelectedProductSetting.Layer;
                viewModel.ToolGroup = SelectedProductSetting.ToolGroup;
                viewModel.SettingList = new ObservableCollection<CPE_InitialSettingEntity>(CPE_InitialSettingEntityList);
                viewModel.CheckedList = new List<string>(OvlCpeInitCheckedList);
                viewModel.IsCPEInitialEnable = IsCPEInitialEnable;

                window.Content = view;
                window.Title = "CPE Initial Setting";
                window.Height = 640;
                window.Width = 1200;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();

                if (viewModel.IsBtnOkClick)
                {
                    //foreach (var str in viewModel.CheckedList)
                    //{
                    //    if (!OvlCpeInitCheckedList.Contains(str))
                    //    {
                    //        OvlCpeInitCheckedList.Add(str);
                    //    }
                    //}

                    CPE_InitialSettingEntityListUpdate = new List<CPE_InitialSettingEntity>(viewModel.SettingList);

                    //List<CPE_InitialSettingEntity> ChangeList = new List<CPE_InitialSettingEntity>();
                    //ChangeList = CPE_InitialSettingEntityListUpdate.Except(CPE_InitialSettingEntityList).ToList();

                    string strProduct = string.Empty;
                    string strLayer = string.Empty;
                    string strToolGroup = string.Empty;
                    string strTool = string.Empty;
                    string strReticle = string.Empty;
                    string strPreTool = string.Empty;
                    string strPreReticle = string.Empty;
                    string strParmeter = string.Empty;
                    string strValue = string.Empty;

                    string strListTool = string.Empty;
                    string strListReticle = string.Empty;
                    string strListPreTool = string.Empty;
                    string strListPreReticle = string.Empty;
                    string strCheckedList = string.Empty;

                    List<string> ListTool = new List<string>();
                    List<string> ListReticle = new List<string>();
                    List<string> ListPreTool = new List<string>();
                    List<string> ListPreReticle = new List<string>();

                    OvlCpeInitCheckedList = new List<string>(viewModel.CheckedList);
                    foreach (var str in viewModel.CheckedList)
                    {
                        strCheckedList += str + ",";
                    }
                    strCheckedList = CfgSingleTableInfoHelp.RemoveLastChar(strCheckedList, ",");

                    foreach (CPE_InitialSettingEntity obj in CPE_InitialSettingEntityListUpdate)
                    {
                        strProduct += obj.PRODUCT + ":";
                        strLayer += obj.LAYER + ":";
                        strToolGroup += obj.TOOL_GROUP + ":";
                        strTool += obj.TOOL + ":";
                        strReticle += obj.RETICLE + ":";
                        strPreTool += obj.PRE_TOOL + ":";
                        strPreReticle += obj.PRE_RETICLE + ":";
                        strParmeter += obj.INIT_PARAMETER_NAME + ":";
                        strValue += obj.CPESubRecipe + "," + obj.CPEModelTimeStamp + ":";

                        foreach (var str in obj.ToolList)
                        {
                            if (!ListTool.Contains(str))
                            {
                                ListTool.Add(str);
                            }
                        }
                        foreach (var str in obj.ReticleList)
                        {
                            if (!ListReticle.Contains(str))
                            {
                                ListReticle.Add(str);
                            }
                        }
                        foreach (var str in obj.PreToolList)
                        {
                            if (!ListPreTool.Contains(str))
                            {
                                ListPreTool.Add(str);
                            }
                        }
                        foreach (var str in obj.PreReticleList)
                        {
                            if (!ListPreReticle.Contains(str))
                            {
                                ListPreReticle.Add(str);
                            }
                        }
                    }
                    ListTool.Remove("*");
                    ListReticle.Remove("*");
                    ListPreTool.Remove("*");
                    ListPreReticle.Remove("*");

                    foreach (var str in ListTool)
                    {
                        strListTool += str + ",";
                    }
                    foreach (var str in ListReticle)
                    {
                        strListReticle += str + ",";
                    }
                    foreach (var str in ListPreTool)
                    {
                        strListPreTool += str + ",";
                    }
                    foreach (var str in ListPreReticle)
                    {
                        strListPreReticle += str + ",";
                    }
                    strListTool = CfgSingleTableInfoHelp.RemoveLastChar(strListTool, ",");
                    strListReticle = CfgSingleTableInfoHelp.RemoveLastChar(strListReticle, ",");
                    strListPreTool = CfgSingleTableInfoHelp.RemoveLastChar(strListPreTool, ",");
                    strListPreReticle = CfgSingleTableInfoHelp.RemoveLastChar(strListPreReticle, ",");

                    strProduct = CfgSingleTableInfoHelp.RemoveLastChar(strProduct, ":");
                    strLayer = CfgSingleTableInfoHelp.RemoveLastChar(strLayer, ":");
                    strToolGroup = CfgSingleTableInfoHelp.RemoveLastChar(strToolGroup, ":");
                    strTool = CfgSingleTableInfoHelp.RemoveLastChar(strTool, ":");
                    strReticle = CfgSingleTableInfoHelp.RemoveLastChar(strReticle, ":");
                    strPreTool = CfgSingleTableInfoHelp.RemoveLastChar(strPreTool, ":");
                    strPreReticle = CfgSingleTableInfoHelp.RemoveLastChar(strPreReticle, ":");
                    strParmeter = CfgSingleTableInfoHelp.RemoveLastChar(strParmeter, ":");
                    strValue = CfgSingleTableInfoHelp.RemoveLastChar(strValue, ":");

                    int itemIndex0 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlCPEUpdateEntity.ColumnFormat, "PRODUCT:");
                    int itemIndex1 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlCPEUpdateEntity.ColumnFormat, "LAYER:");
                    int itemIndex2 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlCPEUpdateEntity.ColumnFormat, "TOOL_GROUP:");
                    int itemIndex3 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlCPEUpdateEntity.ColumnFormat, "TOOL:");
                    int itemIndex4 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlCPEUpdateEntity.ColumnFormat, "RETICLE:");
                    int itemIndex5 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlCPEUpdateEntity.ColumnFormat, "PRE_TOOL:");
                    int itemIndex6 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlCPEUpdateEntity.ColumnFormat, "PRE_RETICLE:");
                    int itemIndex7 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlCPEUpdateEntity.ColumnFormat, "INIT_PARAMETER_NAME:");
                    int itemIndex8 = CfgSingleTableInfoHelp.GetParameterNameItemIndex(cfgInitOvlCPEUpdateEntity.ColumnFormat, "INIT_PARAMETER_VALUE:");
                    if (itemIndex0 == -1 || itemIndex1 == -1 || itemIndex2 == -1 || itemIndex3 == -1 || itemIndex4 == -1 || itemIndex5 == -1 || itemIndex6 == -1 || itemIndex7 == -1 || itemIndex8 == -1)
                    {
                        string strMsg = "Please check ColumnFormat!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                    }

                    cfgInitOvlCPEUpdateEntity.ColumnData[itemIndex0] = strProduct;
                    cfgInitOvlCPEUpdateEntity.ColumnData[itemIndex1] = strLayer;
                    cfgInitOvlCPEUpdateEntity.ColumnData[itemIndex2] = strToolGroup;
                    cfgInitOvlCPEUpdateEntity.ColumnData[itemIndex3] = strTool;
                    cfgInitOvlCPEUpdateEntity.ColumnData[itemIndex4] = strReticle;
                    cfgInitOvlCPEUpdateEntity.ColumnData[itemIndex5] = strPreTool;
                    cfgInitOvlCPEUpdateEntity.ColumnData[itemIndex6] = strPreReticle;
                    cfgInitOvlCPEUpdateEntity.ColumnData[itemIndex7] = strParmeter;
                    cfgInitOvlCPEUpdateEntity.ColumnData[itemIndex8] = strValue;

                    #region Save
                    string strContent = JsonHelp.SerializeObject(cfgInitOvlCPEUpdateEntity);
                    string strQuery = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                    DataRow[] rows = DataTableHelp.Query(dbInitValueUpdate, strQuery);
                    if (rows.Count() > 0)
                    {
                        rows[0]["CpeInitContent"] = strContent;

                    }

                    DataRow[] rowsCommon = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strQuery);
                    if (rowsCommon.Count() > 0)
                    {
                        rowsCommon[0]["LIST_TOOL"] = strListTool;
                        rowsCommon[0]["LIST_RETICLE"] = strListReticle;
                        rowsCommon[0]["LIST_PRE_TOOL"] = strListPreTool;
                        rowsCommon[0]["LIST_PRE_RETICLE"] = strListPreReticle;
                        rowsCommon[0]["OVL_CPE_DYNAMIC_CONTEXT"] = strCheckedList;
                    }
                    #endregion

                    IsBtnCdEditEnable = true;
                    IsPCEditEnable = true;

                    IsCPEEditOngoing = false;

                    if (!string.IsNullOrEmpty(OVLPCR2RMode) && OVLPCR2RMode.ToUpper().Equals("NONE"))
                    {
                        if (!string.IsNullOrEmpty(OVLCPER2RMode) && OVLCPER2RMode.ToUpper().Equals("LIS"))
                        {
                            IsPCEditOngoing = false;
                        }
                        else
                        {
                            IsPCEditOngoing = true;
                        }
                    }

                    CurrentEditProduct = SelectedProductSetting.Product;
                    CurrentEditLayer = SelectedProductSetting.Layer;
                    CurrentEditToolGroup = SelectedProductSetting.ToolGroup;

                    #region Set Save Button
                    SetBtnSaveStatus();
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// PC Edit Button Click Event Fun
        /// </summary>
        void OnPCEditClick()
        {

            try
            {
                if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                {
                    System.Windows.Forms.MessageBox.Show("Please select a record!");
                    return;
                }
                #region
                IsBtnSaveEnable = false;
                IsPCSettingEnable = true;
                IsPCEditBtnClick = true;
                IsPcConfirmEnable = true;
                IsBtnPcSpecEnable = false;
                IsBtnPcInitialEnable = false;

                IsBtnCdEditEnable = false;
                IsCPEEditEnable = false;
                IsBtnCdInitialEnable = false;
                IsBtnCpeSpecEnable = false;
                IsBtnCpeInitialEnable = false;

                if (ToolVendor.Equals("CANON"))
                {
                    IsLinearFlag = true;

                    IsHOPCFlag = false;
                    IsIHOPCFlag = false;
                    IsHOPCEnableFlag = false;
                    IsIHOPCEnableFlag = false;
                }

                if (IsIHOPCFlag)
                {
                    IsHOPCFlag = true;
                    IsHOPCEnableFlag = false;
                }
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// PC Confirm Button Click Event Fun
        /// </summary>
        void OnPCConfirmClick()
        {
            try
            {
                //by zqk add 2020-0525
                if (!string.IsNullOrEmpty(OVLCPER2RMode) && !OVLCPER2RMode.Equals("LIS"))
                {
                    if (string.IsNullOrEmpty(OVLPCR2RMode) || OVLPCR2RMode.Equals("NONE"))
                    {
                        System.Windows.Forms.MessageBox.Show("OVL_PC_R2R_MODE  and OVL_PC_OVL_MODE cannot be empty!");
                        return;
                    }
                }


                #region Check
                bool isCheckOnly = false;
                CurrentAction = "Edit";
                string CurrentMode = IsEditModeChecked ? "Edit" : "View";
                CfgEditStatusCheckResult checkResult = this._SettingMainService.R2R_UI_Config_EditStatusCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, QueryTime, isCheckOnly, ConfigUI, CurrentAction, CurrentMode);
                if (checkResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_EditStatusCheck Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (checkResult.ReturnCode.Equals("-1"))
                {
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                else if (checkResult.ReturnCode.Equals("0"))
                {

                }
                else if (checkResult.ReturnCode.Equals("1"))
                {
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                if (checkResult.InitMode.ToLower().Equals("edit"))
                {
                    CheckEditStatusMessage = "You are now in edit mode";
                    IsEditModeChecked = true;
                    IsViewOnlyChecked = false;
                    SetViewStatus(0x111);

                    #region Set Save Button
                    SetBtnSaveStatus();
                    #endregion

                    #region
                    #region PC Edit Row
                    string strSelect = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                    DataRow[] rows = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strSelect);
                    if (rows.Count() > 0)
                    {
                        #region OVL PC 
                        rows[0]["OVL_PC_R2R_MODE"] = OVLPCR2RMode;
                        if (!IsHOPCFlag && !IsIHOPCFlag)
                        {
                            OVLPCOVLMode = "Linear";
                        }
                        else if (IsLinearFlag && IsHOPCFlag && IsIHOPCFlag)
                        {
                            OVLPCOVLMode = "iHOPC";
                        }
                        else if (IsLinearFlag && IsHOPCFlag)
                        {
                            OVLPCOVLMode = "HOPC";
                        }
                        rows[0]["OVL_PC_OVL_MODE"] = OVLPCOVLMode;

                        #region Init Data
                        rows[0]["OVL_PC_EXPIRE_TIME"] = OVLPCExpireTime.Equals("") ? "7" : OVLPCExpireTime;
                        rows[0]["OVL_PC_LUMDA"] = OVLPCLumda.Equals("") ? "0.3" : OVLPCLumda;
                        rows[0]["OVL_PC_UPDATE_TIME"] = OVLPCUpdateTime;
                        rows[0]["OVL_PC_UPDATE_LOT"] = OVLPCUpdateLot;
                        rows[0]["OVL_PC_FEEDFOREWARD"] = OVLPCFeedforeward.Equals("") ? "false" : OVLPCFeedforeward;
                        #endregion

                        if (string.IsNullOrEmpty(OVLPCR2RMode))
                        {
                            IsBtnCdEditEnable = false;
                            IsCPEEditEnable = false;

                            System.Windows.Forms.MessageBox.Show("OVL PC R2RMode cannot be empty!");
                            return;
                        }
                        else if (OVLPCR2RMode.Equals("Static"))
                        {
                            EventAggregator.GetEvent<PCStaticChangedEvent>().Subscribe(PCStaticMessageReceived);
                            if (PCStaticMessages.Count > 0)
                            {
                                #region Empty check
                                //if (String.IsNullOrEmpty(PCStaticMessages[1]))
                                //{
                                //    System.Windows.Forms.MessageBox.Show("Wafer Lumda cannot be empty!");
                                //    return;
                                //}
                                //if (String.IsNullOrEmpty(PCStaticMessages[2]))
                                //{
                                //    System.Windows.Forms.MessageBox.Show("PC Update Time cannot be empty!");
                                //    return;
                                //}
                                //if (String.IsNullOrEmpty(PCStaticMessages[3]))
                                //{
                                //    System.Windows.Forms.MessageBox.Show("PC Update Lot cannot be empty!");
                                //    return;
                                //}
                                //if (String.IsNullOrEmpty(PCStaticMessages[4]))
                                //{
                                //    System.Windows.Forms.MessageBox.Show("PC Expire Time cannot be empty!");
                                //    return;
                                //}
                                #endregion

                                rows[0]["OVL_PC_FEEDFOREWARD"] = PCStaticMessages[0].Equals("") ? "false" : PCStaticMessages[0];
                                rows[0]["OVL_PC_LUMDA"] = PCStaticMessages[1];
                                rows[0]["OVL_PC_UPDATE_TIME"] = PCStaticMessages[2];
                                rows[0]["OVL_PC_UPDATE_LOT"] = PCStaticMessages[3];
                                rows[0]["OVL_PC_EXPIRE_TIME"] = PCStaticMessages[4];
                                rows[0]["OVL_CPE_EXPIRE_TIME"] = PCStaticMessages[4];
                            }
                        }
                        else if (OVLPCR2RMode.Equals("Dynamic"))
                        {
                            EventAggregator.GetEvent<PCDynamicChangedEvent>().Subscribe(PCDynamicMessageReceived);
                            if (PCDynamicMessages.Count > 0)
                            {

                                #region Empty check
                                if (String.IsNullOrEmpty(PCDynamicMessages[1]))
                                {
                                    IsBtnCdEditEnable = false;
                                    IsCPEEditEnable = false;

                                    System.Windows.Forms.MessageBox.Show("The Lumda has to be between 0 and 1!");
                                    //System.Windows.Forms.MessageBox.Show("Wafer Lumda cannot be empty!");
                                    return;
                                }
                                if (String.IsNullOrEmpty(PCDynamicMessages[2]))
                                {
                                    IsBtnCdEditEnable = false;
                                    IsCPEEditEnable = false;
                                    System.Windows.Forms.MessageBox.Show("PC Expire Time cannot be empty!");
                                    return;
                                }
                                #endregion

                                rows[0]["OVL_PC_FEEDFOREWARD"] = PCDynamicMessages[0].Equals("") ? "false" : PCDynamicMessages[0];
                                rows[0]["OVL_PC_LUMDA"] = PCDynamicMessages[1];
                                rows[0]["OVL_PC_EXPIRE_TIME"] = PCDynamicMessages[2];
                                rows[0]["OVL_CPE_EXPIRE_TIME"] = PCDynamicMessages[2];
                            }

                        }
                        #endregion
                    }
                    #endregion

                    #region CPE Edit Row (NONE case)
                    if (OVLCPER2RMode.Equals("NONE") || OVLCPER2RMode.Equals("Fixed") || OVLCPER2RMode.Equals("Static") || OVLCPER2RMode.Equals("Dynamic") || OVLCPER2RMode.Equals("e-Dynamic"))
                    {
                        if (rows.Count() > 0)
                        {
                            rows[0]["OVL_CPE_R2R_MODE"] = OVLCPER2RMode;
                            rows[0]["OVL_CPE_OVL_MODE"] = OVLCPEOVLMode;

                            #region Init Data
                            rows[0]["OVL_CPE_EXPIRE_TIME"] = rows[0]["OVL_PC_EXPIRE_TIME"].ToString().Equals("") ? "7" : rows[0]["OVL_PC_EXPIRE_TIME"].ToString();//OVLCPEExpireTime.Equals("") ? "7" : OVLCPEExpireTime;
                            rows[0]["OVL_CPE_LUMDA"] = OVLCPELumda.Equals("") ? "0.3" : OVLCPELumda;
                            rows[0]["OVL_CPE_UPDATE_TIME"] = OVLCPEUpdateLot;
                            rows[0]["OVL_CPE_UPDATE_LOT"] = OVLCPEUpdateLot;
                            rows[0]["OVL_CPE_FEEDFOREWARD"] = OVLCPEFeedforeward.Equals("") ? "false" : OVLCPEFeedforeward;
                            rows[0]["OVL_CPE_FIX_EDGE"] = OVLCPEFixEdge.Equals("") ? "false" : OVLCPEFixEdge;

                            #endregion

                            #region Clear LIS Data
                            ClearLISParameterVlaue();

                            string strQueryLIS = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                            DataRow[] rowsLISSource = DataTableHelp.Query(dbR2R_PH_CONFIG_LIS_Source, strQueryLIS);
                            DataRow[] rowsLISUpdate = DataTableHelp.Query(dbR2R_PH_CONFIG_LIS_Update, strQueryLIS);
                            foreach (var row in rowsLISSource)
                            {
                                dbR2R_PH_CONFIG_LIS_Source.Rows.Remove(row);
                            }
                            foreach (var row in rowsLISUpdate)
                            {
                                dbR2R_PH_CONFIG_LIS_Update.Rows.Remove(row);
                            }
                            #endregion

                        }
                    }
                    #endregion

                    #region LIS Edit Row
                    else if (OVLCPER2RMode.Equals("LIS"))
                    {
                        #region Init Data
                        string strSelectCommon = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                        DataRow[] rowsCommon = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strSelectCommon);
                        if (rowsCommon.Count() > 0)
                        {
                            OVLCPEOVLMode = "NA";
                            rowsCommon[0]["OVL_CPE_OVL_MODE"] = OVLCPEOVLMode;
                            rowsCommon[0]["OVL_CPE_R2R_MODE"] = OVLCPER2RMode;

                            rowsCommon[0]["OVL_CPE_EXPIRE_TIME"] = rowsCommon[0]["OVL_PC_EXPIRE_TIME"].ToString().Equals("") ? "7" : rowsCommon[0]["OVL_PC_EXPIRE_TIME"].ToString(); //OVLCPEExpireTime.Equals("") ? "7" : OVLCPEExpireTime;
                            rowsCommon[0]["OVL_CPE_LUMDA"] = OVLCPELumda.Equals("") ? "0.3" : OVLCPELumda;
                            rowsCommon[0]["OVL_CPE_UPDATE_TIME"] = OVLCPEUpdateLot;
                            rowsCommon[0]["OVL_CPE_UPDATE_LOT"] = OVLCPEUpdateLot;
                            rowsCommon[0]["OVL_CPE_FEEDFOREWARD"] = OVLCPEFeedforeward.Equals("") ? "false" : OVLCPEFeedforeward;
                            rowsCommon[0]["OVL_CPE_FIX_EDGE"] = OVLCPEFixEdge.Equals("") ? "false" : OVLCPEFixEdge;

                            #region Init OVL PC Data
                            rowsCommon[0]["OVL_PC_R2R_MODE"] = OVLPCR2RMode;
                            rowsCommon[0]["OVL_PC_OVL_MODE"] = OVLPCOVLMode;

                            rowsCommon[0]["OVL_PC_EXPIRE_TIME"] = OVLPCExpireTime.Equals("") ? "7" : OVLPCExpireTime;
                            rowsCommon[0]["OVL_PC_LUMDA"] = OVLPCLumda.Equals("") ? "0.3" : OVLPCLumda;
                            rowsCommon[0]["OVL_PC_UPDATE_TIME"] = OVLPCUpdateTime;
                            rowsCommon[0]["OVL_PC_UPDATE_LOT"] = OVLPCUpdateLot;
                            rowsCommon[0]["OVL_PC_FEEDFOREWARD"] = OVLPCFeedforeward.Equals("") ? "false" : OVLPCFeedforeward;
                            #endregion
                        }
                        #endregion

                        string strSelectLIS = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                        DataRow[] rowsLIS = DataTableHelp.Query(dbR2R_PH_CONFIG_LIS_Update, strSelectLIS);
                        if (rowsLIS.Count() > 0)
                        {

                            EventAggregator.GetEvent<CPELISChangedEvent>().Subscribe(CPELISMessageReceived);

                            #region Empty check
                            if (string.IsNullOrEmpty(CPELISMessages[0]))
                            {
                                IsBtnCdEditEnable = false;
                                IsCPEEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("LIS Update Time cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[1]))
                            {
                                IsBtnCdEditEnable = false;
                                IsCPEEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("LIS Update Lot cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[2]))
                            {
                                IsBtnCdEditEnable = false;
                                IsCPEEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Sparse Sampling cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[3]))
                            {
                                IsBtnCdEditEnable = false;
                                IsCPEEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Dense Sampling cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[4]))
                            {
                                IsBtnCdEditEnable = false;
                                IsCPEEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("EST Sparse Recipe cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[5]))
                            {
                                IsBtnCdEditEnable = false;
                                IsCPEEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("EST Dense Recipe cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[6]))
                            {
                                IsBtnCdEditEnable = false;
                                IsCPEEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Optimize Recipe cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[7]))
                            {
                                IsBtnCdEditEnable = false;
                                IsCPEEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Sampling ToolType cannot be empty!");
                                return;
                            }
                            #endregion

                            rowsLIS[0]["LIS_UPDATE_TIME"] = CPELISMessages[0];
                            rowsLIS[0]["LIS_UPDATE_LOT"] = CPELISMessages[1];
                            rowsLIS[0]["SPARSE_SAMPLING"] = CPELISMessages[2];
                            rowsLIS[0]["DENSE_SAMPLING"] = CPELISMessages[3];
                            rowsLIS[0]["EST_SPARSE_RECIPE"] = CPELISMessages[4];
                            rowsLIS[0]["EST_DENSE_RECIPE"] = CPELISMessages[5];
                            rowsLIS[0]["OPTIMIZE_RECIPE"] = CPELISMessages[6];
                            rowsLIS[0]["SAMPLING_TOOLTYPE"] = CPELISMessages[7];

                            //rowsLIS[0]["ESTI_KPI_OCAP"] = CPELISMessages[8];
                            //rowsLIS[0]["EXCEPTION_CNT"] = CPELISMessages[];
                            //rowsLIS[0]["EXCEPTION_THRESHOLD"] = CPELISMessages[];
                        }
                        else
                        {
                            DataRow rowNew = dbR2R_PH_CONFIG_LIS_Update.NewRow();
                            rowNew["PRODUCT"] = SelectedProductSetting.Product;
                            rowNew["LAYER"] = SelectedProductSetting.Layer;
                            rowNew["TOOL_GROUP"] = SelectedProductSetting.ToolGroup;
                            rowNew["LIS_UPDATE_TIME"] = CPELISMessages[0];
                            rowNew["LIS_UPDATE_LOT"] = CPELISMessages[1];
                            rowNew["SPARSE_SAMPLING"] = CPELISMessages[2];
                            rowNew["DENSE_SAMPLING"] = CPELISMessages[3];
                            rowNew["EST_SPARSE_RECIPE"] = CPELISMessages[4];
                            rowNew["EST_DENSE_RECIPE"] = CPELISMessages[5];
                            rowNew["OPTIMIZE_RECIPE"] = CPELISMessages[6];
                            rowNew["SAMPLING_TOOLTYPE"] = CPELISMessages[7];

                            rowNew["ESTI_KPI_OCAP"] = "1";
                            rowNew["EXCEPTION_CNT"] = "1";
                            rowNew["EXCEPTION_THRESHOLD"] = "1";
                            dbR2R_PH_CONFIG_LIS_Update.Rows.Add(rowNew);
                        }
                    }
                    #endregion

                    GetLayerSettingInfo();

                    if (OVLCPER2RMode.Equals("Static") || OVLCPER2RMode.Equals("Dynamic"))
                    {
                        PCExpirTimeChanged();
                    }

                    IsBtnCdEditEnable = false;
                    IsCPEEditEnable = false;

                    if (OVLPCR2RMode.Equals(CurrentOVLPCR2RMode) && OVLPCOVLMode.Equals(CurrentOVLPCOVLMode))
                    {
                        IsPCEditOngoing = false;
                        IsOVLPCChangeFlag = false;
                    }
                    else
                    {
                        CurrentEditProduct = SelectedProductSetting.Product;
                        CurrentEditLayer = SelectedProductSetting.Layer;
                        CurrentEditToolGroup = SelectedProductSetting.ToolGroup;
                        IsPCEditOngoing = true;
                        IsOVLPCChangeFlag = true;
                    }

                    if (OVLPCR2RMode.Equals("NONE"))
                    {
                        IsPCEditOngoing = false;
                    }
                    if (string.IsNullOrEmpty(OVLPCOVLMode))
                    {
                    }
                    else if (OVLPCOVLMode.ToUpper().Equals("IHOPC"))
                    {
                        IsCPEEditOngoing = false;
                    }

                    IsLinearFlag = OVLPCR2RMode.Equals("NONE") ? false : true;

                    #region Enable PC Spec button
                    if (IsPCEditBtnClick)
                    {
                        IsPcConfirmEnable = false;
                        IsPCSettingEnable = false;
                        IsBtnPcSpecEnable = OVLPCR2RMode.Equals("NONE") ? false : true;

                        //IsPCEditEnable = OVLPCR2RMode.Equals("NONE") ? true : false;
                        IsBtnCdEditEnable = OVLPCR2RMode.Equals("NONE") ? true : false;
                        IsCPEEditEnable = OVLPCR2RMode.Equals("NONE") ? true : false;
                    }
                    #endregion

                    #endregion

                    #region Set Save Button
                    SetBtnSaveStatus();
                    #endregion
                }
                else if (checkResult.InitMode.ToLower().Equals("view"))
                {
                    CheckEditStatusMessage = "You are now in view mode ---- Occupied by other";
                    IsEditModeChecked = false;
                    IsViewOnlyChecked = true;
                    SetViewStatus(0);
                }
                //else
                //{
                //    //view only
                //    SetViewStatus(0);
                //}
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CPE Edit Button Click Event Fun
        /// </summary>
        void OnCPEEditClick()
        {
            try
            {
                if (SelectedProductSetting == null || SelectedProductSetting.Product == null)
                {
                    System.Windows.Forms.MessageBox.Show("Please select a record!");
                    return;
                }

                #region Check
                IsBtnSaveEnable = false;
                IsCPESettingEnable = true;
                IsCPEEditBtnClick = true;
                IsCpeConfirmEnable = true;
                IsBtnCpeSpecEnable = false;
                IsBtnCpeInitialEnable = false;

                IsBtnCdEditEnable = false;
                IsPCEditEnable = false;
                IsBtnCdInitialEnable = false;
                IsBtnPcSpecEnable = false;
                IsBtnPcInitialEnable = false;
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CPE Confirm Button Click Event Fun
        /// </summary>
        void OnCPEConfirmClick()
        {
            try
            {

                #region Check
                bool isCheckOnly = false;
                CurrentAction = "Edit";
                string CurrentMode = IsEditModeChecked ? "Edit" : "View";
                CfgEditStatusCheckResult checkResult = this._SettingMainService.R2R_UI_Config_EditStatusCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, SelectedProductSetting.Product, SelectedProductSetting.Layer, SelectedProductSetting.ToolGroup, QueryTime, isCheckOnly, ConfigUI, CurrentAction, CurrentMode);
                if (checkResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_EditStatusCheck Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (checkResult.ReturnCode.Equals("-1"))
                {
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                else if (checkResult.ReturnCode.Equals("0"))
                {

                }
                else if (checkResult.ReturnCode.Equals("1"))
                {
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                if (checkResult.InitMode.ToLower().Equals("edit"))
                {
                    CheckEditStatusMessage = "You are now in edit mode";
                    IsEditModeChecked = true;
                    IsViewOnlyChecked = false;
                    SetViewStatus(0x111);

                    #region Set Save Button
                    SetBtnSaveStatus();
                    #endregion

                    #region
                    #region CPE Edit Row
                    if (string.IsNullOrEmpty(OVLCPER2RMode))
                    {
                        IsBtnCdEditEnable = false;
                        IsPCEditEnable = false;

                        System.Windows.Forms.MessageBox.Show("OVL CPE R2RMode cannot be empty!");
                        return;
                    }
                    // If switch to LIS and cause PC R2R mode empty, turn PC config ongoing flag as true
                    if (string.IsNullOrEmpty(OVLPCR2RMode))
                        IsPCEditOngoing = true;

                    if (OVLCPER2RMode.Equals("NONE") || OVLCPER2RMode.Equals("Fixed") || OVLCPER2RMode.Equals("Static") || OVLCPER2RMode.Equals("Dynamic") || OVLCPER2RMode.Equals("e-Dynamic"))
                    {
                        string strSelect = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                        DataRow[] rows = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strSelect);
                        if (rows.Count() > 0)
                        {
                            rows[0]["OVL_CPE_R2R_MODE"] = OVLCPER2RMode;
                            rows[0]["OVL_CPE_OVL_MODE"] = OVLCPEOVLMode;

                            #region Clear Data
                            rows[0]["OVL_CPE_EXPIRE_TIME"] = rows[0]["OVL_PC_EXPIRE_TIME"].ToString().Equals("") ? "7" : OVLPCExpireTime;
                            rows[0]["OVL_CPE_LUMDA"] = "0.3";
                            rows[0]["OVL_CPE_UPDATE_TIME"] = "";
                            rows[0]["OVL_CPE_UPDATE_LOT"] = "";
                            rows[0]["OVL_CPE_FEEDFOREWARD"] = "false";
                            rows[0]["OVL_CPE_FIX_EDGE"] = "false";

                            OVLCPEExpireTime = "999999";
                            OVLCPELumda = "";
                            OVLCPEUpdateTime = "";
                            OVLCPEUpdateLot = "";
                            OVLCPEFeedforeward = "false";
                            OVLCPEFixEdge = "false";
                            #endregion

                            #region Clear LIS Data
                            ClearLISParameterVlaue();

                            string strQueryLIS = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                            DataRow[] rowsLISSource = DataTableHelp.Query(dbR2R_PH_CONFIG_LIS_Source, strQueryLIS);
                            DataRow[] rowsLISUpdate = DataTableHelp.Query(dbR2R_PH_CONFIG_LIS_Update, strQueryLIS);
                            foreach (var row in rowsLISSource)
                            {
                                dbR2R_PH_CONFIG_LIS_Source.Rows.Remove(row);
                            }
                            foreach (var row in rowsLISUpdate)
                            {
                                dbR2R_PH_CONFIG_LIS_Update.Rows.Remove(row);
                            }
                            #endregion

                            if (OVLCPER2RMode.Equals("Static"))
                            {
                                if (string.IsNullOrEmpty(OVLCPEOVLMode))
                                {
                                    IsBtnCdEditEnable = false;
                                    IsPCEditEnable = false;

                                    System.Windows.Forms.MessageBox.Show("Please selected OVL_CPE_MODE");
                                    return;
                                }

                                EventAggregator.GetEvent<CPEStaticChangedEvent>().Subscribe(CPEStaticMessageReceived);

                                if (CPEStaticMessages.Count > 0)
                                {
                                    #region Empty check
                                    if (string.IsNullOrEmpty(CPEStaticMessages[2]))
                                    {
                                        IsBtnCdEditEnable = false;
                                        IsPCEditEnable = false;

                                        System.Windows.Forms.MessageBox.Show("The Lumda has to be between 0 and 1!");
                                        //System.Windows.Forms.MessageBox.Show("Wafer Lumda cannot be empty!");
                                        return;
                                    }
                                    if (string.IsNullOrEmpty(CPEStaticMessages[3]))
                                    {
                                        IsBtnCdEditEnable = false;
                                        IsPCEditEnable = false;

                                        System.Windows.Forms.MessageBox.Show("CPE Update Time cannot be empty!");
                                        return;
                                    }
                                    if (string.IsNullOrEmpty(CPEStaticMessages[4]))
                                    {
                                        IsBtnCdEditEnable = false;
                                        IsPCEditEnable = false;

                                        System.Windows.Forms.MessageBox.Show("CPE Update Lot cannot be empty!");
                                        return;
                                    }
                                    //if (string.IsNullOrEmpty(CPEStaticMessages[5]))
                                    //{
                                    //    System.Windows.Forms.MessageBox.Show("CPE Expire Time cannot be empty!");
                                    //    return;
                                    //}
                                    #endregion

                                    rows[0]["OVL_CPE_FEEDFOREWARD"] = CPEStaticMessages[0].Equals("") ? "false" : CPEStaticMessages[0];
                                    rows[0]["OVL_CPE_FIX_EDGE"] = CPEStaticMessages[1];
                                    rows[0]["OVL_CPE_LUMDA"] = CPEStaticMessages[2];
                                    rows[0]["OVL_CPE_UPDATE_TIME"] = CPEStaticMessages[3];
                                    rows[0]["OVL_CPE_UPDATE_LOT"] = CPEStaticMessages[4];
                                    rows[0]["OVL_CPE_EXPIRE_TIME"] = CPEStaticMessages[5];
                                }
                            }

                            else if (OVLCPER2RMode.Equals("Dynamic"))
                            {
                                if (string.IsNullOrEmpty(OVLCPEOVLMode))
                                {
                                    IsBtnCdEditEnable = false;
                                    IsPCEditEnable = false;

                                    System.Windows.Forms.MessageBox.Show("Please selected OVL_CPE_MODE");
                                    return;
                                }

                                EventAggregator.GetEvent<CPEDynamicChangedEvent>().Subscribe(CPEDynamicMessageReceived);
                                if (CPEDynamicMessages.Count > 0)
                                {
                                    #region Empty check
                                    if (string.IsNullOrEmpty(CPEDynamicMessages[2]))
                                    {
                                        IsBtnCdEditEnable = false;
                                        IsPCEditEnable = false;

                                        System.Windows.Forms.MessageBox.Show("The Lumda has to be between 0 and 1!");
                                        //System.Windows.Forms.MessageBox.Show("Wafer Lumda cannot be empty!");
                                        return;
                                    }
                                    if (string.IsNullOrEmpty(CPEDynamicMessages[3]))
                                    {
                                        IsBtnCdEditEnable = false;
                                        IsPCEditEnable = false;

                                        System.Windows.Forms.MessageBox.Show("CPE Update Time cannot be empty!");
                                        return;
                                    }
                                    if (string.IsNullOrEmpty(CPEDynamicMessages[4]))
                                    {
                                        IsBtnCdEditEnable = false;
                                        IsPCEditEnable = false;

                                        System.Windows.Forms.MessageBox.Show("CPE Update Lot cannot be empty!");
                                        return;
                                    }
                                    //if (string.IsNullOrEmpty(CPEDynamicMessages[5]))
                                    //{
                                    //    System.Windows.Forms.MessageBox.Show("CPE Expire Time cannot be empty!");
                                    //    return;
                                    //}
                                    #endregion

                                    rows[0]["OVL_CPE_FEEDFOREWARD"] = CPEDynamicMessages[0].Equals("") ? "false" : CPEDynamicMessages[0];
                                    rows[0]["OVL_CPE_FIX_EDGE"] = CPEDynamicMessages[1];
                                    rows[0]["OVL_CPE_LUMDA"] = CPEDynamicMessages[2];
                                    rows[0]["OVL_CPE_UPDATE_TIME"] = CPEDynamicMessages[3];
                                    rows[0]["OVL_CPE_UPDATE_LOT"] = CPEDynamicMessages[4];
                                    rows[0]["OVL_CPE_EXPIRE_TIME"] = CPEDynamicMessages[5];
                                }
                            }
                            else if (OVLCPER2RMode.Equals("NONE"))
                            {
                                IsBtnCdEditEnable = true;
                                IsPCEditEnable = true;
                                IsCPEEditOngoing = false;

                            }
                            else if (OVLCPER2RMode.Equals("Fixed"))
                            {

                            }
                            else if (OVLCPER2RMode.Equals("e-Dynamic"))
                            {
                                //EventAggregator.GetEvent<CPEDynamicChangedEvent>().Subscribe(CPEDynamicMessageReceived);
                                //rows[0]["OVL_CPE_FEEDFOREWARD"] = CPEDynamicMessages[0].Equals("") ? "false" : CPEDynamicMessages[0];
                                //rows[0]["OVL_CPE_FIX_EDGE"] = CPEDynamicMessages[1];
                                //rows[0]["OVL_CPE_LUMDA"] = CPEDynamicMessages[2];
                                //rows[0]["OVL_CPE_UPDATE_TIME"] = CPEDynamicMessages[3];
                                //rows[0]["OVL_CPE_UPDATE_LOT"] = CPEDynamicMessages[4];
                                //rows[0]["OVL_CPE_EXPIRE_TIME"] = CPEDynamicMessages[5];
                            }
                        }
                    }
                    #endregion

                    #region LIS Edit Row
                    else if (OVLCPER2RMode.Equals("LIS"))
                    {

                        string strSelectLIS = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                        DataRow[] rowsLIS = DataTableHelp.Query(dbR2R_PH_CONFIG_LIS_Update, strSelectLIS);
                        if (rowsLIS.Count() > 0)
                        {

                            EventAggregator.GetEvent<CPELISChangedEvent>().Subscribe(CPELISMessageReceived);

                            #region Empty check
                            if (string.IsNullOrEmpty(CPELISMessages[0]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("LIS Update Time cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[1]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("LIS Update Lot cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[2]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Sparse Sampling cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[3]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Dense Sampling cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[4]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("EST Sparse Recipe cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[5]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("EST Dense Recipe cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[6]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Optimize Recipe cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[7]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Sampling ToolType cannot be empty!");
                                return;
                            }
                            #endregion

                            rowsLIS[0]["LIS_UPDATE_TIME"] = CPELISMessages[0];
                            rowsLIS[0]["LIS_UPDATE_LOT"] = CPELISMessages[1];
                            rowsLIS[0]["SPARSE_SAMPLING"] = CPELISMessages[2];
                            rowsLIS[0]["DENSE_SAMPLING"] = CPELISMessages[3];
                            rowsLIS[0]["EST_SPARSE_RECIPE"] = CPELISMessages[4];
                            rowsLIS[0]["EST_DENSE_RECIPE"] = CPELISMessages[5];
                            rowsLIS[0]["OPTIMIZE_RECIPE"] = CPELISMessages[6];
                            rowsLIS[0]["SAMPLING_TOOLTYPE"] = CPELISMessages[7];

                            //rowsLIS[0]["ESTI_KPI_OCAP"] = CPELISMessages[8];
                            //rowsLIS[0]["EXCEPTION_CNT"] = CPELISMessages[];
                            //rowsLIS[0]["EXCEPTION_THRESHOLD"] = CPELISMessages[];
                        }
                        else
                        {
                            #region Empty check
                            if (string.IsNullOrEmpty(CPELISMessages[0]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("LIS Update Time cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[1]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("LIS Update Lot cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[2]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Sparse Sampling cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[3]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Dense Sampling cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[4]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("EST Sparse Recipe cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[5]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("EST Dense Recipe cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[6]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Optimize Recipe cannot be empty!");
                                return;
                            }
                            if (string.IsNullOrEmpty(CPELISMessages[7]))
                            {
                                IsBtnCdEditEnable = false;
                                IsPCEditEnable = false;

                                System.Windows.Forms.MessageBox.Show("Sampling ToolType cannot be empty!");
                                return;
                            }
                            #endregion

                            DataRow rowNew = dbR2R_PH_CONFIG_LIS_Update.NewRow();
                            rowNew["PRODUCT"] = SelectedProductSetting.Product;
                            rowNew["LAYER"] = SelectedProductSetting.Layer;
                            rowNew["TOOL_GROUP"] = SelectedProductSetting.ToolGroup;
                            rowNew["LIS_UPDATE_TIME"] = CPELISMessages[0];
                            rowNew["LIS_UPDATE_LOT"] = CPELISMessages[1];
                            rowNew["SPARSE_SAMPLING"] = CPELISMessages[2];
                            rowNew["DENSE_SAMPLING"] = CPELISMessages[3];
                            rowNew["EST_SPARSE_RECIPE"] = CPELISMessages[4];
                            rowNew["EST_DENSE_RECIPE"] = CPELISMessages[5];
                            rowNew["OPTIMIZE_RECIPE"] = CPELISMessages[6];
                            rowNew["SAMPLING_TOOLTYPE"] = CPELISMessages[7];

                            rowNew["ESTI_KPI_OCAP"] = "1";
                            rowNew["EXCEPTION_CNT"] = "1";
                            rowNew["EXCEPTION_THRESHOLD"] = "1";
                            dbR2R_PH_CONFIG_LIS_Update.Rows.Add(rowNew);

                        }

                        #region Clear Data
                        string strSelectCommon = "PRODUCT = '" + SelectedProductSetting.Product + "' and LAYER = '" + SelectedProductSetting.Layer + "' and TOOL_GROUP = '" + SelectedProductSetting.ToolGroup + "'";
                        DataRow[] rowsCommon = DataTableHelp.Query(dbR2R_PH_CONFIG_COMMON_Update, strSelectCommon);
                        if (rowsCommon.Count() > 0)
                        {
                            #region Init OVL CPE Data
                            OVLCPEOVLMode = "NA";
                            rowsCommon[0]["OVL_CPE_OVL_MODE"] = OVLCPEOVLMode;
                            rowsCommon[0]["OVL_CPE_R2R_MODE"] = OVLCPER2RMode;

                            rowsCommon[0]["OVL_CPE_EXPIRE_TIME"] = rowsCommon[0]["OVL_PC_EXPIRE_TIME"].ToString().Equals("") ? "7" : OVLPCExpireTime;
                            rowsCommon[0]["OVL_CPE_LUMDA"] = "0.3";
                            rowsCommon[0]["OVL_CPE_UPDATE_TIME"] = "";
                            rowsCommon[0]["OVL_CPE_UPDATE_LOT"] = "";
                            rowsCommon[0]["OVL_CPE_FEEDFOREWARD"] = "false";
                            rowsCommon[0]["OVL_CPE_FIX_EDGE"] = "false";
                            #endregion

                            #region Init OVL PC Data
                            rowsCommon[0]["OVL_PC_R2R_MODE"] = OVLPCR2RMode;

                            rowsCommon[0]["OVL_PC_OVL_MODE"] = "";

                            rowsCommon[0]["OVL_PC_EXPIRE_TIME"] = "7";
                            rowsCommon[0]["OVL_PC_LUMDA"] = "0.3";
                            rowsCommon[0]["OVL_PC_UPDATE_TIME"] = "";
                            rowsCommon[0]["OVL_PC_UPDATE_LOT"] = "";
                            rowsCommon[0]["OVL_PC_FEEDFOREWARD"] = "false";
                            #endregion
                        }
                        #endregion

                    }
                    #endregion

                    GetLayerSettingInfo();

                    if (OVLCPER2RMode.Equals(CurrentOVLCPER2RMode) && OVLCPEOVLMode.Equals(CurrentOVLCPEOVLMode))
                    {
                        IsCPEEditOngoing = false;
                        IsOVLCPEChangeFlag = false;
                    }
                    else
                    {
                        CurrentEditProduct = SelectedProductSetting.Product;
                        CurrentEditLayer = SelectedProductSetting.Layer;
                        CurrentEditToolGroup = SelectedProductSetting.ToolGroup;
                        IsCPEEditOngoing = true;
                        IsOVLCPEChangeFlag = true;
                    }
                    if (OVLCPER2RMode.Equals("NONE"))
                    {
                        IsBtnCdEditEnable = true;
                        IsPCEditEnable = true;

                        IsCPEEditOngoing = false;
                    }
                    else
                    {
                        IsBtnCdEditEnable = false;
                        IsPCEditEnable = false;
                    }
                    //if (OVLPCR2RMode.Equals("LIS"))//by zqk modify 20200522
                    if (OVLCPER2RMode.Equals("LIS"))
                    {
                        IsPCEditOngoing = true;
                    }

                    if (string.IsNullOrEmpty(OVLPCR2RMode))
                    {
                        IsLinearFlag = false;
                    }
                    else
                    {
                        IsLinearFlag = OVLPCR2RMode.Equals("NONE") ? false : true;
                    }

                    #region Enable CPE Spec Button
                    if (IsCPEEditBtnClick)
                    {
                        IsCPESettingEnable = false;
                        IsCpeConfirmEnable = false;
                        if (OVLCPER2RMode.Equals("NONE") || OVLCPER2RMode.Equals("Fixed") || OVLCPER2RMode.Equals("LIS"))
                        {
                            IsBtnCpeSpecEnable = false;
                            if (!OVLCPER2RMode.Equals("NONE"))
                            {
                                IsBtnCpeInitialEnable = true;
                            }
                        }
                        else
                        {
                            IsBtnCpeSpecEnable = true;
                        }
                    }
                    #endregion

                    #endregion

                    #region Set Save Button
                    SetBtnSaveStatus();
                    #endregion
                }
                else if (checkResult.InitMode.ToLower().Equals("view"))
                {
                    CheckEditStatusMessage = "You are now in view mode ---- Occupied by other";
                    IsEditModeChecked = false;
                    IsViewOnlyChecked = true;
                    SetViewStatus(0);
                }
                //else
                //{
                //    //view only
                //    SetViewStatus(0);
                //}
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// PC HOPC CheckBox Click Event Fun
        /// </summary>
        void OnHOPCClick()
        {
            try
            {

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// PC iHOPC CheckBox Click Event Fun
        /// </summary>
        void OnIHOPCClick()
        {
            try
            {
                if (IsIHOPCFlag)
                {
                    IsHOPCFlag = true;
                    IsHOPCEnableFlag = false;
                    OVLCPER2RMode = "NONE";
                    OVLCPEOVLMode = "NA";
                    OVLCPER2RModeList = new List<string>() { "NONE" };
                    OVLCPEOVLModeList = new List<string>() { "NA" };

                }
                else
                {
                    IsHOPCEnableFlag = true;
                    OVLCPER2RModeList = new List<string>() { "LIS", "Fixed", "NONE", "Static", "Dynamic" };
                    OVLCPEOVLModeList = new List<string>() { "CPE6", "CPE15", "CPE19", "NA" };
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// PC R2RMode SelectionChanged Event Fun
        /// </summary>
        void OnOVLPCR2RModeSelectionChanged()
        {
            try
            {
                if (OVLCPER2RMode == null)
                {

                }
                else if (OVLCPER2RMode.Equals("LIS"))
                {
                    OVLPCR2RModeList = new List<string>() { "NONE" };
                    OVLPCR2RMode = "NONE";
                    //IsPCEditOngoing = false;
                }
                else
                {
                    OVLPCR2RModeList = new List<string>() { "Static", "Dynamic" };
                }
                if (OVLPCR2RMode == null)
                {
                    return;
                }

                string strKey = OVLPCR2RMode;
                string strViewName = string.Empty;

                switch (strKey)
                {
                    case "Static":
                        strViewName = "PC_" + strKey;

                        IsLinearFlag = true;
                        IsIHOPCEnableFlag = ToolVendor.ToUpper().Equals("CANON") ? false : true;
                        IsHOPCEnableFlag = ToolVendor.ToUpper().Equals("CANON") ? false : true;
                        if (ToolVendor.ToUpper().Equals("CANON"))
                        {
                            IsIHOPCFlag = false;
                            IsHOPCFlag = false;
                        }
                        break;
                    case "Dynamic":
                        strViewName = "PC_" + strKey;

                        IsLinearFlag = true;
                        IsIHOPCEnableFlag = ToolVendor.ToUpper().Equals("CANON") ? false : true;
                        IsHOPCEnableFlag = ToolVendor.ToUpper().Equals("CANON") ? false : true;
                        if (ToolVendor.ToUpper().Equals("CANON"))
                        {
                            IsIHOPCFlag = false;
                            IsHOPCFlag = false;
                        }
                        break;
                    case "e-Dynamic":
                        strViewName = "PC_EDynamic";

                        IsLinearFlag = true;
                        IsIHOPCEnableFlag = ToolVendor.ToUpper().Equals("CANON") ? false : true;
                        IsHOPCEnableFlag = ToolVendor.ToUpper().Equals("CANON") ? false : true;
                        if (ToolVendor.ToUpper().Equals("CANON"))
                        {
                            IsIHOPCFlag = false;
                            IsHOPCFlag = false;
                        }
                        break;
                    default:
                        strViewName = "PC_None";

                        IsLinearFlag = false;
                        IsHOPCFlag = false;
                        IsIHOPCFlag = false;
                        IsIHOPCEnableFlag = false;
                        IsHOPCEnableFlag = false;
                        break;
                }
                ShowWaferModeView(strViewName);
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CPE R2RMode SelectionChanged Event Fun
        /// </summary>
        void OnCPER2RModeSelectionChanged()
        {
            try
            {
                if (ToolVendor.ToUpper().Equals("CANON"))
                {
                    OVLCPEOVLModeList = new List<string>() { "NA" };
                    OVLCPEOVLMode = "NA";

                    OVLCPER2RModeList = new List<string>() { "NONE" };
                    OVLCPER2RMode = "NONE";
                }
                else
                {
                    if (OVLPCOVLMode == "iHOPC")
                    {
                        OVLCPER2RModeList = new List<string>() { "NONE" };
                        OVLCPEOVLModeList = new List<string>() { "NA" };
                    }
                    else
                    {
                        OVLCPER2RModeList = new List<string>() { "LIS", "Fixed", "NONE", "Static", "Dynamic" };
                        OVLCPEOVLModeList = new List<string>() { "CPE6", "CPE15", "CPE19" };
                    }
                }

                string strKey = OVLCPER2RMode;
                string strViewName = string.Empty;
                IsBtnCpeInitialEnable = false;
                switch (strKey)
                {
                    case "NONE":
                        strViewName = "CPE_None";
                        OVLCPEOVLModeList = new List<string>() { "NA" };
                        OVLCPEOVLMode = "NA";

                        OVLPCR2RModeList = new List<string>() { "Static", "Dynamic" };

                        //IsCPEEditOngoing = false;
                        IsPCEditEnable = IsEditModeChecked ? true : false;//by zqk modify 2020-01-09
                        IsLinearFlag = true;
                        IsIHOPCEnableFlag = true;
                        IsHOPCEnableFlag = true;
                        break;
                    case "Fixed":
                        strViewName = "CPE_" + strKey;
                        OVLCPEOVLModeList = new List<string>() { "NA" };
                        OVLCPEOVLMode = "NA";

                        OVLPCR2RModeList = new List<string>() { "Static", "Dynamic" };

                        IsPCEditEnable = IsEditModeChecked ? true : false;//by zqk modify 2020-01-09
                        IsLinearFlag = true;
                        IsIHOPCEnableFlag = true;
                        IsHOPCEnableFlag = true;
                        break;
                    case "Static":
                        strViewName = "CPE_" + strKey;
                        OVLCPEOVLModeList = new List<string>() { "CPE6", "CPE15", "CPE19" };
                        OVLPCR2RModeList = new List<string>() { "Static", "Dynamic" };

                        IsLinearFlag = true;
                        IsIHOPCEnableFlag = true;
                        IsHOPCEnableFlag = true;
                        IsPCEditEnable = IsEditModeChecked ? true : false;//by zqk modify 2020-01-09

                        break;
                    case "Dynamic":
                        strViewName = "CPE_" + strKey;
                        OVLCPEOVLModeList = new List<string>() { "CPE6", "CPE15", "CPE19" };
                        OVLPCR2RModeList = new List<string>() { "Static", "Dynamic" };

                        IsLinearFlag = true;
                        IsIHOPCEnableFlag = true;
                        IsHOPCEnableFlag = true;
                        IsPCEditEnable = IsEditModeChecked ? true : false;//by zqk modify 2020-01-09
                        break;
                    case "LIS":
                        strViewName = "CPE_" + strKey;
                        OVLCPEOVLModeList = new List<string>() { "NA" };
                        OVLCPEOVLMode = "NA";

                        if (OVLPCR2RMode.Equals("NONE"))
                        {
                        }
                        else
                        {
                            IsOVLPCChangeFlag = true;
                            OVLPCR2RModeList = new List<string>() { "NONE" };
                            OVLPCR2RMode = "NONE";
                        }

                        IsPCEditEnable = false;
                        IsLinearFlag = false;
                        IsHOPCFlag = false;
                        IsIHOPCFlag = false;
                        IsIHOPCEnableFlag = false;
                        IsHOPCEnableFlag = false;

                        break;
                    case "e-Dynamic":
                        strViewName = "CPE_EDynamic";
                        IsPCEditEnable = IsEditModeChecked ? true : false;//by zqk modify 2020-01-09
                        break;
                    default:
                        OVLPCR2RModeList = new List<string>() { "Static", "Dynamic" };
                        strViewName = "CPE_None";
                        break;
                }

                ShowCPEModeView(strViewName);
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CPE OVLMode SelectionChanged Event Fun
        /// </summary>
        void OnCPEOVLModeSelectionChanged()
        {
            try
            {

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CPE R2RMode SelectionChanged Event Fun
        /// </summary>
        void PCExpirTimeChanged()
        {
            try
            {
                string strKey = OVLCPER2RMode;
                string strViewName = string.Empty;
                switch (strKey)
                {
                    case "Static":
                        strViewName = "CPE_" + strKey;

                        break;
                    case "Dynamic":
                        strViewName = "CPE_" + strKey;
                        break;
                    default:
                        break;
                }

                ShowCPEModeView(strViewName);
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

    }
}
