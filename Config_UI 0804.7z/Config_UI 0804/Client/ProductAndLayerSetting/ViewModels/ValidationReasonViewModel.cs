﻿using Prism.Commands;
using Prism.Events;
using ProductAndLayerSettingService.IService;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProductAndLayerSetting.ViewModels
{
    class ValidationReasonViewModel : ViewModelBase
    {
        IEventAggregator _ea;

        public ISettingMainService ValidationService { get; set; }
        public ValidationReasonViewModel(ISettingMainService userCheckService, IEventAggregator ea)
        {
            _ea = ea;
            this.ValidationService = userCheckService;
            Title = "ValidationReason";
        }


        #region Filed
        private bool _IsCheckSuccess = false;
        public bool IsCheckSuccess
        {
            get { return this._IsCheckSuccess; }
            set { SetProperty(ref this._IsCheckSuccess, value); }
        }

        private string _Reason;
        public string Reason
        {
            get { return this._Reason; }
            set { SetProperty(ref this._Reason, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _BtnOkCommand;
        public DelegateCommand BtnOkCommand =>
            _BtnOkCommand ?? (_BtnOkCommand = new DelegateCommand(OnBtnOKClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));
        #endregion

        #region Event Fun
        /// <summary>
        /// Ok Button Click Event Fun
        /// </summary>
        void OnBtnOKClick()
        {
            try
            {
                if (string.IsNullOrEmpty(Reason))
                {
                    MessageBox.Show("Please input verification reason!");
                    return;
                }
                else
                {
                    IsCheckSuccess = true;
                    this.CurrentWindow.Close();
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Cancel Button Click Event Fun
        /// </summary>
        void OnBtnCancelClick()
        {
            try
            {
                IsCheckSuccess = false;
                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion
    }
}
