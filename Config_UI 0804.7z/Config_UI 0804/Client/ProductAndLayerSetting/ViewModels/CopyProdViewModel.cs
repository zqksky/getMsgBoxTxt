﻿using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Models;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using R2R.Common.Data.CommonEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;

namespace ProductAndLayerSetting.ViewModels
{
    class CopyProdViewModel : ViewModelBase
    {
        public CopyProdViewModel()
        {

        }
        public ISettingMainService _SettingMainService { get; set; }
        public CopyProdViewModel(ISettingMainService settingMainService, IEventAggregator ea)
        {
            this._SettingMainService = settingMainService;
            Title = "Copy Product Setting";

        }

        #region UI object attirbute initialization
        private bool _IsCopySuccess = false;
        public bool IsCopySuccess
        {
            get { return this._IsCopySuccess; }
            set { SetProperty(ref this._IsCopySuccess, value); }
        }

        private bool _IsFromProductEditable = true;
        public bool IsFromProductEditable
        {
            get { return this._IsFromProductEditable; }
            set { SetProperty(ref this._IsFromProductEditable, value); }
        }

        private bool _IsFromLayerEditable = true;
        public bool IsFromLayerEditable
        {
            get { return this._IsFromLayerEditable; }
            set { SetProperty(ref this._IsFromLayerEditable, value); }
        }

        private bool _IsToProductEditable = true;
        public bool IsToProductEditable
        {
            get { return this._IsToProductEditable; }
            set { SetProperty(ref this._IsToProductEditable, value); }
        }

        private bool _IsToLayerEditable = true;
        public bool IsToLayerEditable
        {
            get { return this._IsToLayerEditable; }
            set { SetProperty(ref this._IsToLayerEditable, value); }
        }

        private bool _IsFromProductEnable = true;
        public bool IsFromProductEnable
        {
            get { return this._IsFromProductEnable; }
            set { SetProperty(ref this._IsFromProductEnable, value); }
        }

        private bool _IsToProductEnable = true;
        public bool IsToProductEnable
        {
            get { return this._IsToProductEnable; }
            set { SetProperty(ref this._IsToProductEnable, value); }
        }

        private bool _IsFromLayerEnable = true;
        public bool IsFromLayerEnable
        {
            get { return this._IsFromLayerEnable; }
            set { SetProperty(ref this._IsFromLayerEnable, value); }
        }

        private bool _IsToLayerEnable = true;
        public bool IsToLayerEnable
        {
            get { return this._IsToLayerEnable; }
            set { SetProperty(ref this._IsToLayerEnable, value); }
        }

        private bool _IsBtnConfirmCopyEnable = true;
        public bool IsBtnConfirmCopyEnable
        {
            get { return this._IsBtnConfirmCopyEnable; }
            set { SetProperty(ref this._IsBtnConfirmCopyEnable, value); }
        }
        #endregion

        #region Value Initialization
        /// <summary>
        /// Initialized Values
        /// </summary>
        private List<string> _ProductList = new List<string>();
        public List<string> ProductList
        {
            get { return this._ProductList; }
            set { SetProperty(ref this._ProductList, value); }
        }

        private List<string> _LayerList = new List<string>();
        public List<string> LayerList
        {
            get { return this._LayerList; }
            set { SetProperty(ref this._LayerList, value); }
        }

        private List<string> _ToLayerList = new List<string>();
        public List<string> ToLayerList
        {
            get { return this._ToLayerList; }
            set { SetProperty(ref this._ToLayerList, value); }
        }

        private string _FromProduct;
        public string FromProduct
        {
            get { return this._FromProduct; }
            set { SetProperty(ref this._FromProduct, value); }
        }
        private string _ToProduct;
        public string ToProduct
        {
            get { return this._ToProduct; }
            set { SetProperty(ref this._ToProduct, value); }
        }
        private string _FromLayer;
        public string FromLayer
        {
            get { return this._FromLayer; }
            set { SetProperty(ref this._FromLayer, value); }
        }
        private string _ToLayer;
        public string ToLayer
        {
            get { return this._ToLayer; }
            set { SetProperty(ref this._ToLayer, value); }
        }
        #endregion

        #region Event Define
        //private DelegateCommand _FromProductKeyDownCommand;
        //public DelegateCommand FromProductKeyDownCommand =>
        //    _FromProductKeyDownCommand ?? (_FromProductKeyDownCommand = new DelegateCommand(OnFromProductKeyDown));

        //private DelegateCommand _FromLayerKeyDownCommand;
        //public DelegateCommand FromLayerKeyDownCommand =>
        //    _FromLayerKeyDownCommand ?? (_FromLayerKeyDownCommand = new DelegateCommand(OnFromLayerKeyDown));

        private DelegateCommand _FromProductLostFocusCommand;
        public DelegateCommand FromProductLostFocusCommand =>
            _FromProductLostFocusCommand ?? (_FromProductLostFocusCommand = new DelegateCommand(OnFromProductLostFocus));

        private DelegateCommand _FromLayerLostFocusCommand;
        public DelegateCommand FromLayerLostFocusCommand =>
            _FromLayerLostFocusCommand ?? (_FromLayerLostFocusCommand = new DelegateCommand(OnFromLayerLostFocus));

        //private DelegateCommand _FromProductSelectionChangedCommand;
        //public DelegateCommand FromProductSelectionChangedCommand =>
        //    _FromProductSelectionChangedCommand ?? (_FromProductSelectionChangedCommand = new DelegateCommand(OnFromProductSelectionChanged));

        private DelegateCommand _FromLayerSelectionChangedCommand;
        public DelegateCommand FromLayerSelectionChangedCommand =>
            _FromLayerSelectionChangedCommand ?? (_FromLayerSelectionChangedCommand = new DelegateCommand(OnFromLayerSelectionChanged));

        //private DelegateCommand _ToProductKeyDownCommand;
        //public DelegateCommand ToProductKeyDownCommand =>
        //    _ToProductKeyDownCommand ?? (_ToProductKeyDownCommand = new DelegateCommand(OnToProductKeyDown));

        //private DelegateCommand _ToLayerKeyDownCommand;
        //public DelegateCommand ToLayerKeyDownCommand =>
        //    _ToLayerKeyDownCommand ?? (_ToLayerKeyDownCommand = new DelegateCommand(OnToLayerKeyDown));

        private DelegateCommand _ToProductLostFocusCommand;
        public DelegateCommand ToProductLostFocusCommand =>
            _ToProductLostFocusCommand ?? (_ToProductLostFocusCommand = new DelegateCommand(OnToProductLostFocus));

        private DelegateCommand _ToLayerLostFocusCommand;
        public DelegateCommand ToLayerLostFocusCommand =>
            _ToLayerLostFocusCommand ?? (_ToLayerLostFocusCommand = new DelegateCommand(OnToLayerLostFocus));

        //private DelegateCommand _ToProductSelectionChangedCommand;
        //public DelegateCommand ToProductSelectionChangedCommand =>
        //    _ToProductSelectionChangedCommand ?? (_ToProductSelectionChangedCommand = new DelegateCommand(OnFromProductSelectionChanged));

        //private DelegateCommand _ToLayerSelectionChangedCommand;
        //public DelegateCommand ToLayerSelectionChangedCommand =>
        //    _ToLayerSelectionChangedCommand ?? (_ToLayerSelectionChangedCommand = new DelegateCommand(OnToLayerSelectionChanged));

        private DelegateCommand _BtnCopyProdConfirmCommand;
        public DelegateCommand BtnCopyProdConfirmCommand =>
            _BtnCopyProdConfirmCommand ?? (_BtnCopyProdConfirmCommand = new DelegateCommand(OnBtnCopyProdConfirmClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));
        #endregion

        #region Event Fun
        /// <summary>
        /// Product TextChanged Event Fun
        /// </summary>
        void OnFromProductLostFocus()
        {
            try
            {
                if (FromProduct.Equals("*"))
                {
                    FromProduct = "";
                    System.Windows.Forms.MessageBox.Show("From Product cannot be *");
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Layer TextChanged Event Fun
        /// </summary>
        void OnFromLayerLostFocus()
        {
            try
            {
                if (!string.IsNullOrEmpty(FromLayer))
                {
                    if (FromLayer.Equals("*"))
                    {
                        if (!ToLayerList.Contains("*"))
                        {
                            ToLayerList.Add("*");
                        }
                        ToLayer = "*";
                        IsToLayerEnable = false;
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(ToLayer))
                        {
                            if (ToLayer.Equals("*"))
                            {
                                ToLayer = "";
                                ToLayerList.Remove("*");
                            }
                            IsToLayerEnable = true;
                        }
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(ToLayer))
                    {
                        if (ToLayer.Equals("*"))
                        {
                            ToLayer = "";
                            ToLayerList.Remove("*");
                        }
                        IsToLayerEnable = true;
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }


        /// <summary>
        /// Layer SelectionChanged Event Fun
        /// </summary>
        void OnFromLayerSelectionChanged()
        {
            try
            {
                if (string.IsNullOrEmpty(FromLayer))
                {
                    if (!string.IsNullOrEmpty(ToLayer))
                    {
                        if (ToLayer.Equals("*"))
                        {
                            ToLayer = "";
                            ToLayerList.Remove("*");
                        }
                        IsToLayerEnable = true;
                    }
                    return;
                }
                if (FromLayer.Equals("*"))
                {
                    if (!ToLayerList.Contains("*"))
                    {
                        ToLayerList.Add("*");
                    }
                    ToLayer = "*";
                    IsToLayerEnable = false;
                }
                else
                {
                    if (!string.IsNullOrEmpty(ToLayer))
                    {
                        if (ToLayer.Equals("*"))
                        {
                            ToLayer = "";
                            ToLayerList.Remove("*");
                        }
                        IsToLayerEnable = true;
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Product TextChanged Event Fun
        /// </summary>
        void OnToProductLostFocus()
        {
            try
            {
                if (ToProduct.Equals("*"))
                {
                    ToProduct = "";
                    System.Windows.Forms.MessageBox.Show("To Product cannot be *");
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Layer TextChanged Event Fun
        /// </summary>
        void OnToLayerLostFocus()
        {
            try
            {
                if (!string.IsNullOrEmpty(ToLayer))
                {
                    if (ToLayer.Equals("*"))
                    {
                        ToLayer = "";
                        ToLayerList.Remove("*");
                        System.Windows.Forms.MessageBox.Show("To Layer cannot be *");
                    }
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CopyProdConfirm Button Click Event fun
        /// </summary>
        void OnBtnCopyProdConfirmClick()
        {
            try
            {
                if (string.IsNullOrEmpty(FromProduct) || string.IsNullOrEmpty(FromLayer) || string.IsNullOrEmpty(ToProduct) || string.IsNullOrEmpty(ToLayer))
                {
                    System.Windows.Forms.MessageBox.Show("Product and Layer cannot be empty!");
                    return;
                }

                CfgUpdateResult resultCheck = new CfgUpdateResult();
                resultCheck = _SettingMainService.R2R_UI_Config_PH_CopyProduct(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, FromProduct, ToProduct, FromLayer, ToLayer, true);
                if (resultCheck.ReturnCode.Equals("0"))
                {
                    CfgUpdateResult result = new CfgUpdateResult();
                    result = _SettingMainService.R2R_UI_Config_PH_CopyProduct(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, FromProduct, ToProduct, FromLayer, ToLayer, false);
                    if (result.ReturnCode.Equals("0") || result.ReturnCode.Equals("1"))
                    {
                        IsCopySuccess = true;
                        System.Windows.Forms.MessageBox.Show("Copy Success!");
                        this.CurrentWindow.Close();
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show(result.ReturnText);
                    }
                }
                else if (resultCheck.ReturnCode.Equals("1"))
                {
                    System.Windows.Forms.MessageBox.Show(resultCheck.ReturnText);
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show(resultCheck.ReturnText);
                }
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        /// <summary>
        /// Cancel Button Click Event fun
        /// </summary>
        void OnBtnCancelClick()
        {
            try
            {
                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

    }
}
