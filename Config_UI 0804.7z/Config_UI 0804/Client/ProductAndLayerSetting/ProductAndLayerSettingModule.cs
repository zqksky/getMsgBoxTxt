﻿using Prism.Ioc;
using Prism.Modularity;
using ProductAndLayerSetting.Views;
using ProductAndLayerSettingService.IService;
using ProductAndLayerSettingService.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAndLayerSetting
{
    public class ProductAndLayerSettingModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {
            //var regionManager = containerProvider.Resolve<IRegionManager>();
            //regionManager.RegisterViewWithRegion("ContentRegion", typeof(LithoMain));
            ////regionManager.RegisterViewWithRegion("ContentRegion", typeof(SingleLot));

            //regionManager.RegisterViewWithRegion("LithoMainRegion", typeof(LithoMain));
            //regionManager.RegisterViewWithRegion("SingleLotRegion", typeof(SingleLot));
        }


        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<SettingMain>();
            containerRegistry.RegisterForNavigation<ProductSetting>();

            containerRegistry.RegisterForNavigation<CD_InitialSetting>();

            containerRegistry.RegisterForNavigation<CPE_Dynamic>();
            containerRegistry.RegisterForNavigation<CPE_EDynamic>();
            containerRegistry.RegisterForNavigation<CPE_Fixed>();
            containerRegistry.RegisterForNavigation<CPE_InitialSetting>();
            containerRegistry.RegisterForNavigation<CPE_LIS>();
            containerRegistry.RegisterForNavigation<CPE_None>();
            containerRegistry.RegisterForNavigation<CPE_SpecSetting>();
            containerRegistry.RegisterForNavigation<CPE_Static>();
            containerRegistry.RegisterForNavigation <FixedEdgeShotSetting>();

            containerRegistry.RegisterForNavigation<PC_Dynamic>();
            containerRegistry.RegisterForNavigation<PC_EDynamic>();
            containerRegistry.RegisterForNavigation<PC_InitialSetting>();
            containerRegistry.RegisterForNavigation<PC_None>();
            containerRegistry.RegisterForNavigation<PC_SpecSetting>();
            containerRegistry.RegisterForNavigation<PC_Static>();
            containerRegistry.RegisterForNavigation<UserCheck>();
            containerRegistry.RegisterForNavigation<VersionCompare>();
            containerRegistry.RegisterForNavigation<ValidationReason>();

            containerRegistry.RegisterSingleton<ISettingMainService, SettingMainService>();
            //containerRegistry.RegisterSingleton<ISingleLotService, SingleLotService>();
            //containerRegistry.RegisterSingleton<ILithoMainService, LithoMainService>();
            //containerRegistry.RegisterSingleton<IViewDraftService, ViewDraftService>();
            //containerRegistry.RegisterSingleton<IViewHistoryService, ViewHistoryService>();
            //containerRegistry.RegisterSingleton<IViewPendingCRService, ViewPendingCRService>();

        }
    }
}
