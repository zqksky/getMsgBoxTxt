﻿using AdminConfigManagement.Views;
using AdminConfigService.IService;
using AdminConfigService.Service;
using Prism.Ioc;
using Prism.Modularity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminConfigManagement
{
    public class AdminConfigManagementModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {

        }


        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<AdminConfig>();
            containerRegistry.RegisterForNavigation<UserGroupSetting>();
            containerRegistry.RegisterForNavigation<ProductGroupSetting>();
            containerRegistry.RegisterForNavigation<PriorityLevelSetting>();

            containerRegistry.RegisterSingleton<IAdminConfigManageService, AdminConfigManageService>();

        }
    }
}
