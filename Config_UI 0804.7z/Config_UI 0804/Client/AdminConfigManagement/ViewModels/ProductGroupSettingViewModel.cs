﻿using AdminConfigService.IService;
using Prism.Commands;
using Prism.Events;
using R2R.Client.Framework;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AdminConfigManagement.ViewModels
{
    class ProductGroupSettingViewModel : ViewModelBase
    {
        IEventAggregator _ea;

        public IAdminConfigManageService AdminService { get; set; }
        public ProductGroupSettingViewModel(IAdminConfigManageService adminService, IEventAggregator ea)
        {
            _ea = ea;
            this.AdminService = adminService;
            Title = "Product Group Setting";
        }

        #region ProductGroup Setting Field Define
        private bool _IsKeyEnable = false;
        public bool IsKeyEnable
        {
            get { return this._IsKeyEnable; }
            set { SetProperty(ref this._IsKeyEnable, value); }
        }

        private bool _IsBtnOkClick = false;
        public bool IsBtnOkClick
        {
            get { return this._IsBtnOkClick; }
            set { SetProperty(ref this._IsBtnOkClick, value); }
        }

        private bool _IsBtnCancelClick = false;
        public bool IsBtnCancelClick
        {
            get { return this._IsBtnCancelClick; }
            set { SetProperty(ref this._IsBtnCancelClick, value); }
        }

        private string _CfgProduct;
        public string CfgProduct
        {
            get { return this._CfgProduct; }
            set { SetProperty(ref this._CfgProduct, value); }
        }

        private string _CfgProductGroup;
        public string CfgProductGroup
        {
            get { return this._CfgProductGroup; }
            set { SetProperty(ref this._CfgProductGroup, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region ProductGroup Setting Event Define
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnInit));

        private DelegateCommand _BtnOkCommand;
        public DelegateCommand BtnOkCommand =>
            _BtnOkCommand ?? (_BtnOkCommand = new DelegateCommand(OnBtnOkClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));
        #endregion

        #region ProductGroup Setting Event Fun
        /// <summary>
        /// Init Event Fun
        /// </summary>
        void OnInit()
        {
            try
            {


            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Ok Button Click Event Fun
        /// </summary>
        void OnBtnOkClick()
        {
            try
            {
                if (string.IsNullOrEmpty(CfgProduct) || string.IsNullOrEmpty(CfgProductGroup))
                {
                    IsBtnOkClick = false;
                    IsBtnCancelClick = true;
                }
                else
                {
                    IsBtnOkClick = true;
                    IsBtnCancelClick = false;
                }
                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Cancel Button Click Event Fun
        /// </summary>
        void OnBtnCancelClick()
        {
            try
            {
                IsBtnOkClick = false;
                IsBtnCancelClick = true;

                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion
    }
}
