﻿using AdminConfigService.IService;
using Prism.Commands;
using Prism.Events;
using R2R.Client.Framework;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AdminConfigManagement.ViewModels
{
    class UserGroupSettingViewModel : ViewModelBase
    {
        IEventAggregator _ea;

        public IAdminConfigManageService AdminService { get; set; }
        public UserGroupSettingViewModel(IAdminConfigManageService adminService, IEventAggregator ea)
        {
            _ea = ea;
            this.AdminService = adminService;
            Title = "User Group Setting";
        }

        #region UserGroup Setting Field Define
        private bool _IsBtnOkClick = false;
        public bool IsBtnOkClick
        {
            get { return this._IsBtnOkClick; }
            set { SetProperty(ref this._IsBtnOkClick, value); }
        }

        private bool _IsBtnCancelClick = false;
        public bool IsBtnCancelClick
        {
            get { return this._IsBtnCancelClick; }
            set { SetProperty(ref this._IsBtnCancelClick, value); }
        }

        private string _CfgUser;
        public string CfgUser
        {
            get { return this._CfgUser; }
            set { SetProperty(ref this._CfgUser, value); }
        }

        private string _CfgUserGroup;
        public string CfgUserGroup
        {
            get { return this._CfgUserGroup; }
            set { SetProperty(ref this._CfgUserGroup, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region UserGroup Setting Event Define
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnInit));

        private DelegateCommand _BtnOkCommand;
        public DelegateCommand BtnOkCommand =>
            _BtnOkCommand ?? (_BtnOkCommand = new DelegateCommand(OnBtnOkClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));
        #endregion

        #region UserGroup Setting Event Fun
        /// <summary>
        /// Init Event Fun
        /// </summary>
        void OnInit()
        {
            try
            {


            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// Ok Button Click Event Fun
        /// </summary>
        void OnBtnOkClick()
        {
            try
            {
                if (string.IsNullOrEmpty(CfgUser) || string.IsNullOrEmpty(CfgUserGroup))
                {
                    IsBtnOkClick = false;
                    IsBtnCancelClick = true;
                }
                else
                {
                    IsBtnOkClick = true;
                    IsBtnCancelClick = false;
                }

                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Cancel Button Click Event Fun
        /// </summary>
        void OnBtnCancelClick()
        {
            try
            {
                IsBtnOkClick = false;
                IsBtnCancelClick = true;

                this.CurrentWindow.Close();
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion
    }
}
