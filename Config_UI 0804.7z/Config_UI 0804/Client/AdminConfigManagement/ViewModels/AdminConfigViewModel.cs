﻿using AdminConfigManagement.Views;
using AdminConfigService.IService;
using AdminConfigService.Models;
using MahApps.Metro.Controls;
using Prism.Commands;
using Prism.Events;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;

namespace AdminConfigManagement.ViewModels
{
    public class AdminConfigViewModel : ViewModelBase
    {
        IEventAggregator _ea;

        public IAdminConfigManageService AdminService { get; set; }
        public AdminConfigViewModel(IAdminConfigManageService adminService, IEventAggregator ea)
        {
            _ea = ea;
            this.AdminService = adminService;
            Title = "Admin Config";

            CfgAreaList = GetAreaList();
        }

        #region Loaded Event
        private DelegateCommand _LoadedCommand;
        public DelegateCommand LoadedCommand =>
            _LoadedCommand ?? (_LoadedCommand = new DelegateCommand(OnLoaded));

        bool IsInvokFlag = false;
        string LastCfgArea = string.Empty;
        void OnLoaded()
        {
            try
            {
                string LastCfgArea = "";
                if (!string.IsNullOrEmpty(CfgArea))
                {
                    LastCfgArea = CfgArea;
                }
                
                if (IsInvokFlag)
                {
                    CfgAreaList = GetAreaList();
                    CfgArea = LastCfgArea;

                    ClearParameter();
                }
                IsInvokFlag = true;

                if (!string.IsNullOrEmpty(CfgArea))
                {
                    bool falgResult = this.AdminService.R2R_UI_Config_ClearAdminOccupy(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, CfgArea);
                    if (falgResult)
                    {
                    }
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Init Fun
        void ClearParameter()
        {
            try
            {
                CfgUserGroupListSource = new List<CfgUserGroupEntity>();
                CfgProductGroupListSource = new List<CfgProductGroupEntity>();
                CfgPriorityLevelListSource = new List<CfgPriorityLevelEntity>();

                CfgUserGroupList = new ObservableCollection<CfgUserGroupEntity>();
                CfgProductGroupList = new ObservableCollection<CfgProductGroupEntity>();
                CfgPriorityLevelList = new ObservableCollection<CfgPriorityLevelEntity>();

                IsAreaSelectionCancel = false;
                IsUserGroupSerachClick = false;
                IsProductGroupSerachClick = false;
                IsPriorityLevelSerachClick = false;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Parameter Define
        bool IsAreaSelectionCancel = false;
        bool IsUserGroupSerachClick = false;
        bool IsProductGroupSerachClick = false;
        bool IsPriorityLevelSerachClick = false;

        string strLastArea = string.Empty;

        static string AccessControlByOtherMessage = "You are now in view mode - Occupied by other";
        static string AccessControlViewModeMessage = "You are now in view mode";

        string UserGroupQueryTime = "";
        string ProductGroupQueryTime = "";
        string PriorityLevelQueryTime = "";

        List<CfgUserGroupEntity> CfgUserGroupListSource = new List<CfgUserGroupEntity>();
        List<CfgProductGroupEntity> CfgProductGroupListSource = new List<CfgProductGroupEntity>();
        List<CfgPriorityLevelEntity> CfgPriorityLevelListSource = new List<CfgPriorityLevelEntity>();
        #endregion

        #region Access Control Field
        private bool _IsBtnCfgUserGroupEditEnable = true;
        public bool IsBtnCfgUserGroupEditEnable
        {
            get { return this._IsBtnCfgUserGroupEditEnable; }
            set { SetProperty(ref this._IsBtnCfgUserGroupEditEnable, value); }
        }

        private bool _IsBtnCfgUserGroupDeleteEnable = true;
        public bool IsBtnCfgUserGroupDeleteEnable
        {
            get { return this._IsBtnCfgUserGroupDeleteEnable; }
            set { SetProperty(ref this._IsBtnCfgUserGroupDeleteEnable, value); }
        }

        private bool _IsBtnCfgProductGroupEditEnable = true;
        public bool IsBtnCfgProductGroupEditEnable
        {
            get { return this._IsBtnCfgProductGroupEditEnable; }
            set { SetProperty(ref this._IsBtnCfgProductGroupEditEnable, value); }
        }

        private bool _IsBtnCfgProductGroupDeleteEnable = true;
        public bool IsBtnCfgProductGroupDeleteEnable
        {
            get { return this._IsBtnCfgProductGroupDeleteEnable; }
            set { SetProperty(ref this._IsBtnCfgProductGroupDeleteEnable, value); }
        }

        private bool _IsBtnCfgPriorityLevelEditEnable = true;
        public bool IsBtnCfgPriorityLevelEditEnable
        {
            get { return this._IsBtnCfgPriorityLevelEditEnable; }
            set { SetProperty(ref this._IsBtnCfgPriorityLevelEditEnable, value); }
        }

        private bool _IsBtnCfgPriorityLevelDeleteEnable = true;
        public bool IsBtnCfgPriorityLevelDeleteEnable
        {
            get { return this._IsBtnCfgPriorityLevelDeleteEnable; }
            set { SetProperty(ref this._IsBtnCfgPriorityLevelDeleteEnable, value); }
        }
        #endregion

        #region Access Control Fun

        #endregion

        #region Area Field
        private string _CfgArea;
        public string CfgArea
        {
            get { return this._CfgArea; }
            set { SetProperty(ref this._CfgArea, value); }
        }

        private List<string> _CfgAreaList = new List<string>();
        public List<string> CfgAreaList
        {
            get { return this._CfgAreaList; }
            set { SetProperty(ref this._CfgAreaList, value); }
        }
        #endregion

        #region Area Event Define
        private DelegateCommand _CfgAreaSelectionChangedCommand;
        public DelegateCommand CfgAreaSelectionChangedCommand =>
            _CfgAreaSelectionChangedCommand ?? (_CfgAreaSelectionChangedCommand = new DelegateCommand(OnCfgAreaSelectionChanged));
        #endregion

        #region Area Event Fun
        /// <summary>
        /// CfgArea SelectionChanged
        /// </summary>
        void OnCfgAreaSelectionChanged()
        {
            try
            {
                if (IsAreaSelectionCancel)
                {
                    IsAreaSelectionCancel = false;
                    return;
                }
                if (IsUserGroupSerachClick || IsProductGroupSerachClick || IsPriorityLevelSerachClick)
                {
                    if (System.Windows.Forms.MessageBox.Show("The data will refresh!", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        ClearParameter();

                        bool falgResult = this.AdminService.R2R_UI_Config_ClearAdminOccupy(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, CfgArea);
                        if (falgResult)
                        {
                        }

                        //if (IsUserGroupSerachClick)
                        //{
                        //    string strSource = JsonHelp.SerializeObject(CfgUserGroupListSource);
                        //    CfgUserGroupList = new ObservableCollection<CfgUserGroupEntity>(JsonHelp.DeserializeJsonToList<CfgUserGroupEntity>(strSource));
                        //}
                        //if (IsProductGroupSerachClick)
                        //{
                        //    string strSource = JsonHelp.SerializeObject(CfgProductGroupListSource);
                        //    CfgProductGroupList = new ObservableCollection<CfgProductGroupEntity>(JsonHelp.DeserializeJsonToList<CfgProductGroupEntity>(strSource));
                        //}
                        //if (IsPriorityLevelSerachClick)
                        //{
                        //    string strSource = JsonHelp.SerializeObject(CfgPriorityLevelListSource);
                        //    CfgPriorityLevelList = new ObservableCollection<CfgPriorityLevelEntity>(JsonHelp.DeserializeJsonToList<CfgPriorityLevelEntity>(strSource));
                        //}
                    }
                    else
                    {
                        IsAreaSelectionCancel = true;
                        CfgArea = strLastArea;
                        return;
                    }
                }

                EventAggregator.GetEvent<AdminUIConfigChangedEvent>().Publish(CfgArea);

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region CfgUserGroup Filed Define
        private bool _IsUserGroupReadOnly = true;
        public bool IsUserGroupReadOnly
        {
            get { return this._IsUserGroupReadOnly; }
            set { SetProperty(ref this._IsUserGroupReadOnly, value); }
        }

        private string _CfgUser="*";
        public string CfgUser
        {
            get { return this._CfgUser; }
            set { SetProperty(ref this._CfgUser, value); }
        }

        private string _CfgUserGroup="*";
        public string CfgUserGroup
        {
            get { return this._CfgUserGroup; }
            set { SetProperty(ref this._CfgUserGroup, value); }
        }

        private CfgUserGroupEntity _SelectedUserGroup;
        public CfgUserGroupEntity SelectedUserGroup
        {
            get { return this._SelectedUserGroup; }
            set { SetProperty(ref this._SelectedUserGroup, value); }
        }

        private ObservableCollection<CfgUserGroupEntity> _CfgUserGroupList = new ObservableCollection<CfgUserGroupEntity>();
        public ObservableCollection<CfgUserGroupEntity> CfgUserGroupList
        {
            get { return _CfgUserGroupList; }
            set { SetProperty(ref _CfgUserGroupList, value); }
        }
        #endregion

        #region CfgUserGroup Event Define
        private DelegateCommand _BtnCfgUserGroupSearchCommand;
        public DelegateCommand BtnCfgUserGroupSearchCommand =>
            _BtnCfgUserGroupSearchCommand ?? (_BtnCfgUserGroupSearchCommand = new DelegateCommand(OnCfgUserGroupSearchClick));

        private DelegateCommand _UserGroupSelectionChangedCommand;
        public DelegateCommand UserGroupSelectionChangedCommand =>
            _UserGroupSelectionChangedCommand ?? (_UserGroupSelectionChangedCommand = new DelegateCommand(OnCfgUserGroupSelectionChanged));

        private DelegateCommand _UserGroupLostFocusCommand;
        public DelegateCommand UserGroupLostFocusCommand =>
            _UserGroupLostFocusCommand ?? (_UserGroupLostFocusCommand = new DelegateCommand(OnCfgUserGroupLostFocus));

        private DelegateCommand _BtnCfgUserGroupAddCommand;
        public DelegateCommand BtnCfgUserGroupAddCommand =>
            _BtnCfgUserGroupAddCommand ?? (_BtnCfgUserGroupAddCommand = new DelegateCommand(OnCfgUserGroupAddClick));

        private DelegateCommand _BtnCfgUserGroupEditCommand;
        public DelegateCommand BtnCfgUserGroupEditCommand =>
            _BtnCfgUserGroupEditCommand ?? (_BtnCfgUserGroupEditCommand = new DelegateCommand(OnCfgUserGroupEditClick));

        private DelegateCommand _BtnCfgUserGroupDeleteCommand;
        public DelegateCommand BtnCfgUserGroupDeleteCommand =>
            _BtnCfgUserGroupDeleteCommand ?? (_BtnCfgUserGroupDeleteCommand = new DelegateCommand(OnCfgUserGroupDeleteClick));

        private DelegateCommand _BtnCfgUserGroupSaveCommand;
        public DelegateCommand BtnCfgUserGroupSaveCommand =>
            _BtnCfgUserGroupSaveCommand ?? (_BtnCfgUserGroupSaveCommand = new DelegateCommand(OnCfgUserGroupSaveClick));
        #endregion

        #region CfgUserGroup Event Function
        /// <summary>
        /// CfgUserGroup Search Button Click
        /// </summary>
        void OnCfgUserGroupSearchClick()
        {
            try
            {
                if (string.IsNullOrEmpty(CfgArea) || string.IsNullOrEmpty(CfgUser) || string.IsNullOrEmpty(CfgUserGroup))
                {
                    string strMsg = "Area/UserId/UserGroup cannot be empty !";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                CfgUserGroupListSource = new List<CfgUserGroupEntity>();
                CfgUserGroupList = new ObservableCollection<CfgUserGroupEntity>();
                CfgAdminGetResult CfgAdminResult = this.AdminService.R2R_UI_Config_AdminConfigGet(ClientInfo.CurrentServer, ClientInfo.RequsetId, CfgUser, ClientInfo.CurrentVersion, 1,  CfgUserGroup, "", "", CfgArea, "");
                //CfgAdminGetResult CfgAdminResult = this.AdminService.R2R_UI_Config_AdminConfigGet(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 1, CfgUser, CfgUserGroup, "", "", "", "");
                if (CfgAdminResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_AdminConfigGet Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                if (CfgAdminResult.IsOutputNull)
                {
                    string strMsg = "Output Null!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                for (int i = 0; i < CfgAdminResult.UserID.Count; i++)
                {
                    CfgUserGroupEntity entity = new CfgUserGroupEntity();
                    entity.UserId = CfgAdminResult.UserID[i];
                    entity.UserGroup = CfgAdminResult.UserGroup[i];
                    entity.Action = "Old";
                    CfgUserGroupListSource.Add(entity);
                    //CfgUserGroupList.Add(entity);
                }
                string strSource = JsonHelp.SerializeObject(CfgUserGroupListSource);
                //CfgUserGroupListSource = JsonHelp.DeserializeJsonToList<CfgUserGroupEntity>(strSource);

                CfgUserGroupList.Clear();
                CfgUserGroupList = new ObservableCollection<CfgUserGroupEntity>(JsonHelp.DeserializeJsonToList<CfgUserGroupEntity>(strSource));
                UserGroupQueryTime = CommonHelp.GetQueryTime();
                strLastArea = CfgArea;
                IsUserGroupSerachClick = true;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CfgUserGroup SelectionChanged
        /// </summary>
        void OnCfgUserGroupSelectionChanged()
        {
            try
            {
                if (SelectedUserGroup != null)
                {
                    #region Access Control
                    //bool isCheckOnly = false;
                    //string OptAction = "Edit";
                    //CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 1, SelectedUserGroup.UserId, SelectedUserGroup.UserGroup, "", "", CfgArea, "", OptAction, UserGroupQueryTime, isCheckOnly);
                    //if (checkResult.ReturnCode.Equals("-1"))
                    //{
                    //    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    //    return;
                    //}
                    //else if (checkResult.ReturnCode.Equals("0"))
                    //{
                    //    //IsUserGroupSettingEdit = true;
                    //}
                    //else if (checkResult.ReturnCode.Equals("1"))
                    //{
                    //    //IsUserGroupSettingEdit = true;
                    //    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    //}
                    //if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                    //{
                    //    System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                    //    return;
                    //}
                    //if (checkResult.InitMode.ToLower().Equals("edit"))
                    //{
                    //    IsBtnCfgUserGroupEditEnable = true;
                    //    IsBtnCfgUserGroupDeleteEnable = true;
                    //}
                    //else if (checkResult.InitMode.ToLower().Equals("view"))
                    //{
                    //    //System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                    //    //IsBtnCfgUserGroupEditEnable = false;
                    //    //IsBtnCfgUserGroupDeleteEnable = false;
                    //}
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// UserGroup LostFocus
        /// </summary>
        void OnCfgUserGroupLostFocus()
        {
            try
            {
                //IsPriorityLevelReadOnly = true;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CfgUserGroup Add Button Click
        /// </summary>
        void OnCfgUserGroupAddClick()
        {
            try
            {
                var window = new MetroWindow();//Windows窗体      
                UserGroupSetting view = new UserGroupSetting();
                UserGroupSettingViewModel viewModel = (UserGroupSettingViewModel)view.DataContext;

                string strCfgUser = "";
                string strCfgUserGroup = "";
                string strCfgAction = "";
                if (SelectedUserGroup != null)
                {
                    strCfgUser = SelectedUserGroup.UserId;
                    strCfgUserGroup = SelectedUserGroup.UserGroup;
                }

                viewModel.CurrentWindow = window;
                viewModel.CfgUser = strCfgUser;
                viewModel.CfgUserGroup = strCfgUserGroup;

                window.Content = view;
                window.Title = "UserGroup Add Setting";
                window.Height = 240;
                window.Width = 480;
                //window.ResizeMode = ResizeMode.NoResize;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();

                if (viewModel.IsBtnOkClick)
                {
                    CfgUserGroupEntity addEntity = new CfgUserGroupEntity();
                    addEntity.UserId = viewModel.CfgUser;
                    addEntity.UserGroup = viewModel.CfgUserGroup;
                    addEntity.Action = "Add";

                    string strJson = JsonHelp.SerializeObject(addEntity);
                    MyLogger.Trace("EventFun:: " +
                                    string.Format("AddRow<{0}>", strJson));

                    #region Access Control
                    bool isCheckOnly = false;
                    string OptAction = "Add";
                    CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 1, viewModel.CfgUser, viewModel.CfgUserGroup, "", "", CfgArea, "", OptAction, UserGroupQueryTime, isCheckOnly);
                    if (checkResult == null)
                    {
                        string strMsg = "Invoke R2R_UI_Config_AccessControlCheck Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }
                    if (checkResult.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                        return;
                    }
                    else if (checkResult.ReturnCode.Equals("0"))
                    {
                        //IsUserGroupSettingEdit = true;
                    }
                    else if (checkResult.ReturnCode.Equals("1"))
                    {
                        //IsUserGroupSettingEdit = true;
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                    {
                        MyLogger.Trace("Message :: " + AccessControlByOtherMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                        return;
                    }
                    if (checkResult.InitMode.ToLower().Equals("edit"))
                    {
                        #region Add Entity
                        CfgUserGroupEntity modifyEntity = new CfgUserGroupEntity();
                        modifyEntity.UserId = viewModel.CfgUser;
                        modifyEntity.UserGroup = viewModel.CfgUserGroup;
                        modifyEntity.Action = "Add";
                        foreach (var obj in CfgUserGroupList)
                        {
                            if (obj.UserId.Equals(viewModel.CfgUser) && obj.UserGroup.Equals(viewModel.CfgUserGroup))
                            {
                                string strMsg = "Have exists!";
                                MyLogger.Trace("Message :: " + strMsg);
                                System.Windows.Forms.MessageBox.Show(strMsg);
                                return;
                            }
                        }

                        CfgUserGroupList.Add(modifyEntity);
                        SelectedUserGroup = modifyEntity;
                        #endregion
                    }
                    else if (checkResult.InitMode.ToLower().Equals("view"))
                    {
                        MyLogger.Trace("Message :: " + AccessControlViewModeMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                    }
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CfgUserGroup Edit Button Click
        /// </summary>
        void OnCfgUserGroupEditClick()
        {
            try
            {
                if (this.SelectedUserGroup == null)
                {
                    string strMsg = "Row is not selected!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                var window = new MetroWindow();//Windows窗体      
                UserGroupSetting view = new UserGroupSetting();
                UserGroupSettingViewModel viewModel = (UserGroupSettingViewModel)view.DataContext;

                string strCfgUser = SelectedUserGroup.UserId;
                string strCfgUserGroup = SelectedUserGroup.UserGroup;
                viewModel.CurrentWindow = window;
                viewModel.CfgUser = strCfgUser;
                viewModel.CfgUserGroup = strCfgUserGroup;

                window.Content = view;
                window.Title = "UserGroup Edit Setting";
                window.Height = 240;
                window.Width = 480;
                //window.ResizeMode = ResizeMode.NoResize;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();
                if (viewModel.IsBtnOkClick)
                {
                    #region Access Control
                    bool isCheckOnly = false;
                    string OptAction = "Edit";
                    CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 1, viewModel.CfgUser, viewModel.CfgUserGroup, "", "", CfgArea, "", OptAction, UserGroupQueryTime, isCheckOnly);
                    if (checkResult == null)
                    {
                        string strMsg = "Invoke R2R_UI_Config_AccessControlCheck Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }
                    if (checkResult.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                        return;
                    }
                    else if (checkResult.ReturnCode.Equals("0"))
                    {
                        //IsUserGroupSettingEdit = true;
                    }
                    else if (checkResult.ReturnCode.Equals("1"))
                    {
                        //IsUserGroupSettingEdit = true;
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                    {
                        MyLogger.Trace("Message :: " + AccessControlByOtherMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                        return;
                    }
                    if (checkResult.InitMode.ToLower().Equals("edit"))
                    {
                        #region Add Entity
                        CfgUserGroupEntity modifyEntity = new CfgUserGroupEntity();
                        modifyEntity.UserId = viewModel.CfgUser;
                        modifyEntity.UserGroup = viewModel.CfgUserGroup;

                        foreach (var obj in CfgUserGroupList)
                        {
                            if (obj.UserId.Equals(viewModel.CfgUser) && obj.UserGroup.Equals(viewModel.CfgUserGroup))
                            {
                                System.Windows.Forms.MessageBox.Show("Have exists!");
                                return;
                            }
                        }

                        SelectedUserGroup.UserId = viewModel.CfgUser;
                        SelectedUserGroup.UserGroup = viewModel.CfgUserGroup;

                        ObservableCollection<CfgUserGroupEntity> list = new ObservableCollection<CfgUserGroupEntity>(CfgUserGroupList);
                        CfgUserGroupList.Clear();
                        CfgUserGroupList = new ObservableCollection<CfgUserGroupEntity>(list);
                        #endregion
                    }
                    else if (checkResult.InitMode.ToLower().Equals("view"))
                    {
                        MyLogger.Trace("Message :: " + AccessControlViewModeMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                    }
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CfgUserGroup Delete Button Click
        /// </summary>
        void OnCfgUserGroupDeleteClick()
        {
            try
            {
                if (SelectedUserGroup == null)
                {
                    string strMsg = "Please select a row!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                //if (CfgUserGroupList.Count == 1)
                //{
                //    string strMsg = "Only one record!";
                //    MyLogger.Trace("Message :: " + strMsg);
                //    System.Windows.Forms.MessageBox.Show(strMsg);
                //    return;
                //}

                string strJson = JsonHelp.SerializeObject(SelectedUserGroup);
                MyLogger.Trace("EventFun:: " +
                                string.Format("DeleteRow<{0}>", strJson));

                if (SelectedUserGroup.Action.Equals("Add"))
                {
                    CfgUserGroupList.Remove(SelectedUserGroup);
                    return;
                }

                #region Access Control
                bool isCheckOnly = false;
                string OptAction = "Delete";
                CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 1, SelectedUserGroup.UserId, SelectedUserGroup.UserGroup, "", "", CfgArea, "", OptAction, UserGroupQueryTime, isCheckOnly);
                if (checkResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_AccessControlCheck Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (checkResult.ReturnCode.Equals("-1"))
                {
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    return;
                }
                else if (checkResult.ReturnCode.Equals("0"))
                {
                    //IsUserGroupSettingEdit = true;
                }
                else if (checkResult.ReturnCode.Equals("1"))
                {
                    //IsUserGroupSettingEdit = true;
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                {
                    MyLogger.Trace("Message :: " + AccessControlByOtherMessage);
                    System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                    return;
                }
                if (checkResult.InitMode.ToLower().Equals("edit"))
                {
                    #region Delete Entity
                    CfgUserGroupList.Remove(SelectedUserGroup);
                    #endregion
                }
                else if (checkResult.InitMode.ToLower().Equals("view"))
                {
                    MyLogger.Trace("Message :: " + AccessControlViewModeMessage);
                    System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                }
                #endregion

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CfgUserGroup Save Button Click
        /// </summary>
        void OnCfgUserGroupSaveClick()
        {
            try
            {
                List<string> userIdAddList = new List<string>();
                List<string> userGroupAddList = new List<string>();

                List<string> userIdDeleteList = new List<string>();
                List<string> userGroupDeleteList = new List<string>();

                List<CfgUserGroupEntity> entityList = new List<CfgUserGroupEntity>();
                entityList = GetUserGroupAdd(CfgUserGroupListSource, CfgUserGroupList.ToList());
                foreach (var obj in entityList)
                {
                    userIdAddList.Add(obj.UserId);
                    userGroupAddList.Add(obj.UserGroup);
                }
                entityList = GetUserGroupDelete(CfgUserGroupListSource, CfgUserGroupList.ToList());
                foreach (var obj in entityList)
                {
                    userIdDeleteList.Add(obj.UserId);
                    userGroupDeleteList.Add(obj.UserGroup);
                }

                CfgUpdateResult result = this.AdminService.R2R_UI_Config_UserGroupSave(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, CfgArea,
                    userIdAddList.ToArray(), userGroupAddList.ToArray(), 
                    userIdDeleteList.ToArray(), userGroupDeleteList.ToArray());
                if (result != null)
                {
                    if (result.ReturnCode.Equals("0"))
                    {
                        OnCfgUserGroupSearchClick();
                    }
                    MyLogger.Trace("Message :: " + result.ReturnText);
                    System.Windows.Forms.MessageBox.Show(result.ReturnText);
                }
                else
                {
                    string strMsg = "Invoke R2R_UI_Config_UserGroupSave Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region CfgProductGroup Filed Define
        private bool _IsProductGroupReadOnly = true;
        public bool IsProductGroupReadOnly
        {
            get { return this._IsProductGroupReadOnly; }
            set { SetProperty(ref this._IsProductGroupReadOnly, value); }
        }

        private string _CfgProduct = "*";
        public string CfgProduct
        {
            get { return this._CfgProduct; }
            set { SetProperty(ref this._CfgProduct, value); }
        }

        private string _CfgProductGroup="*";
        public string CfgProductGroup
        {
            get { return this._CfgProductGroup; }
            set { SetProperty(ref this._CfgProductGroup, value); }
        }

        private CfgProductGroupEntity _SelectedProductGroup;
        public CfgProductGroupEntity SelectedProductGroup
        {
            get { return this._SelectedProductGroup; }
            set { SetProperty(ref this._SelectedProductGroup, value); }
        }

        private ObservableCollection<CfgProductGroupEntity> _CfgProductGroupList = new ObservableCollection<CfgProductGroupEntity>();
        public ObservableCollection<CfgProductGroupEntity> CfgProductGroupList
        {
            get { return _CfgProductGroupList; }
            set { SetProperty(ref _CfgProductGroupList, value); }
        }
        #endregion

        #region CfgProductGroup Event Define
        private DelegateCommand _ProductGroupSelectionChangedCommand;
        public DelegateCommand ProductGroupSelectionChangedCommand =>
            _ProductGroupSelectionChangedCommand ?? (_ProductGroupSelectionChangedCommand = new DelegateCommand(OnCfgProductGroupSelectionChanged));

        private DelegateCommand _ProductGroupLostFocusCommand;
        public DelegateCommand ProductGroupLostFocusCommand =>
            _ProductGroupLostFocusCommand ?? (_ProductGroupLostFocusCommand = new DelegateCommand(OnCfgProductGroupLostFocus));

        private DelegateCommand _BtnCfgProductGroupSearchCommand;
        public DelegateCommand BtnCfgProductGroupSearchCommand =>
            _BtnCfgProductGroupSearchCommand ?? (_BtnCfgProductGroupSearchCommand = new DelegateCommand(OnCfgProductGroupSearchClick));

        private DelegateCommand _BtnCfgProductGroupAddCommand;
        public DelegateCommand BtnCfgProductGroupAddCommand =>
            _BtnCfgProductGroupAddCommand ?? (_BtnCfgProductGroupAddCommand = new DelegateCommand(OnCfgProductGroupAddClick));

        private DelegateCommand _BtnCfgProductGroupEditCommand;
        public DelegateCommand BtnCfgProductGroupEditCommand =>
            _BtnCfgProductGroupEditCommand ?? (_BtnCfgProductGroupEditCommand = new DelegateCommand(OnCfgProductGroupEditClick));

        private DelegateCommand _BtnCfgProductGroupDeleteCommand;
        public DelegateCommand BtnCfgProductGroupDeleteCommand =>
            _BtnCfgProductGroupDeleteCommand ?? (_BtnCfgProductGroupDeleteCommand = new DelegateCommand(OnCfgProductGroupDeleteClick));

        private DelegateCommand _BtnCfgProductGroupSaveCommand;
        public DelegateCommand BtnCfgProductGroupSaveCommand =>
            _BtnCfgProductGroupSaveCommand ?? (_BtnCfgProductGroupSaveCommand = new DelegateCommand(OnCfgProductGroupSaveClick));
        #endregion

        #region CfgProductGroup Event Function
        /// <summary>
        /// CfgProductGroup Search Button Click
        /// </summary>
        void OnCfgProductGroupSearchClick()
        {
            try
            {
                if (string.IsNullOrEmpty(CfgArea) || string.IsNullOrEmpty(CfgProduct) || string.IsNullOrEmpty(CfgProductGroup))
                {
                    string strMsg = "Area/Product/ProductGroup cannot be empty !";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                CfgProductGroupListSource = new List<CfgProductGroupEntity>();
                CfgProductGroupList = new ObservableCollection<CfgProductGroupEntity>();
                CfgAdminGetResult CfgAdminResult = this.AdminService.R2R_UI_Config_AdminConfigGet(ClientInfo.CurrentServer, ClientInfo.RequsetId, "", ClientInfo.CurrentVersion, 2,  "", CfgProduct, CfgProductGroup, CfgArea, "");
                //CfgAdminGetResult CfgAdminResult = this.AdminService.R2R_UI_Config_AdminConfigGet(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 2, "", "", CfgProduct, CfgProductGroup, "", "");
                if (CfgAdminResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_AdminConfigGet Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                if (CfgAdminResult.IsOutputNull)
                {
                    string strMsg = "Output Null!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                for (int i = 0; i < CfgAdminResult.Product.Count; i++)
                {
                    CfgProductGroupEntity entity = new CfgProductGroupEntity();
                    entity.Product = CfgAdminResult.Product[i];
                    entity.ProductGroup = CfgAdminResult.ProductGroup[i];
                    entity.Action = "Old";
                    CfgProductGroupListSource.Add(entity);
                    //CfgProductGroupList.Add(entity);
                }
                string strSource = JsonHelp.SerializeObject(CfgProductGroupListSource);
                //CfgProductGroupListSource = JsonHelp.DeserializeJsonToList<DeserializeJsonToList>(strSource);

                CfgProductGroupList.Clear();
                CfgProductGroupList = new ObservableCollection<CfgProductGroupEntity>(JsonHelp.DeserializeJsonToList<CfgProductGroupEntity>(strSource));

                ProductGroupQueryTime = CommonHelp.GetQueryTime();

                strLastArea = CfgArea;
                IsProductGroupSerachClick = true;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CfgProductGroup SelectionChanged
        /// </summary>
        void OnCfgProductGroupSelectionChanged()
        {
            try
            {
                if (SelectedProductGroup != null)
                {
                    #region Access Control
                    //bool isCheckOnly = false;
                    //string OptAction = "Edit";
                    //CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser,  ClientInfo.CurrentVersion, 2, "", "", SelectedProductGroup.Product, SelectedProductGroup.ProductGroup, "", "", OptAction, ProductGroupQueryTime, isCheckOnly);
                    //if (checkResult.ReturnCode.Equals("-1"))
                    //{
                    //    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    //    return;
                    //}
                    //else if (checkResult.ReturnCode.Equals("0"))
                    //{
                    //    //IsUserGroupSettingEdit = true;
                    //}
                    //else if (checkResult.ReturnCode.Equals("1"))
                    //{
                    //    //IsUserGroupSettingEdit = true;
                    //    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    //}
                    //if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                    //{
                    //    System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                    //    return;
                    //}
                    //if (checkResult.InitMode.ToLower().Equals("edit"))
                    //{
                    //    IsBtnCfgProductGroupEditEnable = true;
                    //    IsBtnCfgProductGroupDeleteEnable = true;
                    //}
                    //else if (checkResult.InitMode.ToLower().Equals("view"))
                    //{
                    //    //IsBtnCfgProductGroupEditEnable = false;
                    //    //IsBtnCfgProductGroupDeleteEnable = false;
                    //    //System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                    //}
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// ProductGroup LostFocus
        /// </summary>
        void OnCfgProductGroupLostFocus()
        {
            try
            {
                //IsPriorityLevelReadOnly = true;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CfgProductGroup Add Button Click
        /// </summary>
        void OnCfgProductGroupAddClick()
        {
            try
            {
                var window = new MetroWindow();//Windows窗体      
                ProductGroupSetting view = new ProductGroupSetting();
                ProductGroupSettingViewModel viewModel = (ProductGroupSettingViewModel)view.DataContext;

                string strCfgProduct = "";
                string strCfgProductGroup = "";
                if (SelectedProductGroup != null)
                {
                    strCfgProduct = SelectedProductGroup.Product;
                    strCfgProductGroup = SelectedProductGroup.ProductGroup;
                }
                viewModel.CurrentWindow = window;
                viewModel.CfgProduct = strCfgProduct;
                viewModel.CfgProductGroup = strCfgProductGroup;
                viewModel.IsKeyEnable = true;

                window.Content = view;
                window.Title = "ProductGroup Add Setting";
                window.Height = 240;
                window.Width = 480;
                //window.ResizeMode = ResizeMode.NoResize;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();

                CfgProductGroupEntity addEntity = new CfgProductGroupEntity();
                addEntity.Product = viewModel.CfgProduct;
                addEntity.ProductGroup = viewModel.CfgProductGroup;
                addEntity.Action = "Add";

                string strJson = JsonHelp.SerializeObject(addEntity);
                MyLogger.Trace("EventFun:: " +
                                string.Format("AddRow<{0}>", strJson));

                if (viewModel.IsBtnOkClick)
                {
                    #region Access Control
                    bool isCheckOnly = false;
                    string OptAction = "Add";
                    CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 2, "", "", viewModel.CfgProduct, viewModel.CfgProductGroup, CfgArea, "", OptAction, ProductGroupQueryTime, isCheckOnly);
                    if(checkResult==null)
                    {
                        string strMsg = "Invoke R2R_UI_Config_AccessControlCheck Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }
                    if (checkResult.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                        return;
                    }
                    else if (checkResult.ReturnCode.Equals("0"))
                    {
                        //IsUserGroupSettingEdit = true;
                    }
                    else if (checkResult.ReturnCode.Equals("1"))
                    {
                        //IsUserGroupSettingEdit = true;
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                    {
                        MyLogger.Trace("Message :: " + AccessControlByOtherMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                        return;
                    }
                    if (checkResult.InitMode.ToLower().Equals("edit"))
                    {
                        #region Add Entity
                        CfgProductGroupEntity modifyEntity = new CfgProductGroupEntity();
                        modifyEntity.Product = viewModel.CfgProduct;
                        modifyEntity.ProductGroup = viewModel.CfgProductGroup;
                        modifyEntity.Action = "Add";
                        foreach (var obj in CfgProductGroupList)
                        {
                            if (obj.Product.Equals(viewModel.CfgProduct) && obj.ProductGroup.Equals(viewModel.CfgProductGroup))
                            {
                                string strMsg = "Have exists!";
                                MyLogger.Trace("Message :: " + strMsg);
                                System.Windows.Forms.MessageBox.Show(strMsg);
                                return;
                            }
                        }

                        CfgProductGroupList.Add(modifyEntity);
                        SelectedProductGroup = modifyEntity;
                        #endregion
                    }
                    else if (checkResult.InitMode.ToLower().Equals("view"))
                    {
                        MyLogger.Trace("Message :: " + AccessControlViewModeMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                    }
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CfgProductGroup Edit Button Click
        /// </summary>
        void OnCfgProductGroupEditClick()
        {
            try
            {
                if (this.SelectedProductGroup == null)
                {
                    string strMsg = "Row is not selected!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                string strJson = JsonHelp.SerializeObject(SelectedProductGroup);
                MyLogger.Trace("EventFun:: " +
                                string.Format("EditRow<{0}>", strJson));

                var window = new MetroWindow();//Windows窗体      
                ProductGroupSetting view = new ProductGroupSetting();
                ProductGroupSettingViewModel viewModel = (ProductGroupSettingViewModel)view.DataContext;

                string strCfgProduct = SelectedProductGroup.Product;
                string strCfgProductGroup = SelectedProductGroup.ProductGroup;

                viewModel.CurrentWindow = window;
                viewModel.CfgProduct = strCfgProduct;
                viewModel.CfgProductGroup = strCfgProductGroup;
                viewModel.IsKeyEnable = false;

                window.Content = view;
                window.Title = "ProductGroup Add Setting";
                window.Height = 240;
                window.Width = 480;
                //window.ResizeMode = ResizeMode.NoResize;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();

                if (viewModel.IsBtnOkClick)
                {

                    CfgProductGroupEntity editEntity = new CfgProductGroupEntity();
                    editEntity.Product = viewModel.CfgProduct;
                    editEntity.ProductGroup = viewModel.CfgProductGroup;
                    strJson = JsonHelp.SerializeObject(editEntity);
                    MyLogger.Trace("EventFun:: " +
                                    string.Format("EditResult<{0}>", strJson));

                    #region Access Control
                    bool isCheckOnly = false;
                    string OptAction = "Edit";
                    CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 2, "", "", viewModel.CfgProduct, viewModel.CfgProductGroup, CfgArea, "", OptAction, ProductGroupQueryTime, isCheckOnly);
                    if (checkResult == null)
                    {
                        string strMsg = "Invoke R2R_UI_Config_AccessControlCheck Error!";
                        MyLogger.Trace("Message :: " + strMsg);
                        System.Windows.Forms.MessageBox.Show(strMsg);
                        return;
                    }
                    if (checkResult.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                        return;
                    }
                    else if (checkResult.ReturnCode.Equals("0"))
                    {
                        //IsUserGroupSettingEdit = true;
                    }
                    else if (checkResult.ReturnCode.Equals("1"))
                    {
                        //IsUserGroupSettingEdit = true;
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                    {
                        MyLogger.Trace("Message :: " + AccessControlByOtherMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                        return;
                    }
                    if (checkResult.InitMode.ToLower().Equals("edit"))
                    {
                        #region Edit Entity
                        CfgProductGroupEntity modifyEntity = new CfgProductGroupEntity();
                        modifyEntity.Product = viewModel.CfgProduct;
                        modifyEntity.ProductGroup = viewModel.CfgProductGroup;
                        foreach (var obj in CfgProductGroupList)
                        {
                            if (obj.Product.Equals(viewModel.CfgProduct) && obj.ProductGroup.Equals(viewModel.CfgProductGroup))
                            {
                                string strMsg = "Have exists!";
                                MyLogger.Trace("Message :: " + strMsg);
                                System.Windows.Forms.MessageBox.Show(strMsg);
                                return;
                            }
                        }

                        SelectedProductGroup.Product = viewModel.CfgProduct;
                        SelectedProductGroup.ProductGroup = viewModel.CfgProductGroup;

                        ObservableCollection<CfgProductGroupEntity> list = new ObservableCollection<CfgProductGroupEntity>(CfgProductGroupList);
                        CfgProductGroupList.Clear();
                        CfgProductGroupList = new ObservableCollection<CfgProductGroupEntity>(list);
                        #endregion
                    }
                    else if (checkResult.InitMode.ToLower().Equals("view"))
                    {
                        MyLogger.Trace("Message :: " + AccessControlViewModeMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                    }
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CfgProductGroup Delete Button Click
        /// </summary>
        void OnCfgProductGroupDeleteClick()
        {
            try
            {
                if (SelectedProductGroup == null)
                {
                    string strMsg = "Please select a row!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                //if (CfgProductGroupList.Count == 1)
                //{
                //    string strMsg = "Only one record!";
                //    MyLogger.Trace("Message :: " + strMsg);
                //    System.Windows.Forms.MessageBox.Show(strMsg); ;
                //    return;
                //}

                string strJson = JsonHelp.SerializeObject(SelectedProductGroup);
                MyLogger.Trace("EventFun:: " +
                                string.Format("DeleteRow<{0}>", strJson));

                if (SelectedProductGroup.Action.Equals("Add"))
                {
                    CfgProductGroupList.Remove(SelectedProductGroup);
                    return;
                }

                #region Access Control
                bool isCheckOnly = false;
                string OptAction = "Delete";
                CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId,ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 2, "", "", SelectedProductGroup.Product, SelectedProductGroup.ProductGroup, CfgArea, "", OptAction, ProductGroupQueryTime, isCheckOnly);
                if (checkResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_AccessControlCheck Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (checkResult.ReturnCode.Equals("-1"))
                {
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    return;
                }
                else if (checkResult.ReturnCode.Equals("0"))
                {
                    //IsUserGroupSettingEdit = true;
                }
                else if (checkResult.ReturnCode.Equals("1"))
                {
                    //IsUserGroupSettingEdit = true;
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                {
                    MyLogger.Trace("Message :: " + AccessControlByOtherMessage);
                    System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                    return;
                }
                if (checkResult.InitMode.ToLower().Equals("edit"))
                {
                    #region Delete Entity
                    CfgProductGroupList.Remove(SelectedProductGroup);
                    #endregion
                }
                else if (checkResult.InitMode.ToLower().Equals("view"))
                {
                    MyLogger.Trace("Message :: " + AccessControlViewModeMessage);
                    System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                }
                #endregion
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CfgProductGroup Save Button Click
        /// </summary>
        void OnCfgProductGroupSaveClick()
        {
            try
            {
                #region test
                //List<CfgProductGroupEntity> SourceList = new List<CfgProductGroupEntity>();
                //List<CfgProductGroupEntity> UpdateList = new List<CfgProductGroupEntity>();
                //for (int i = 0; i < 6; i++)
                //{
                //    CfgProductGroupEntity entity = new CfgProductGroupEntity();
                //    entity.Product = "Product" + i;
                //    entity.ProductGroup= "ProductGroup" + i;
                //    if (i < 2)
                //    {
                //        entity.Product = "Product" + i;
                //        entity.ProductGroup = "ProductGroup" + (i + 7);
                //        SourceList.Add(entity);
                //    }
                //    else if (i == 2 || i==3)
                //    {
                //        entity.Product = "Product" + (i + 44);
                //        entity.ProductGroup = "ProductGroup" + (i+44);
                //        SourceList.Add(entity);
                //    }
                //    else
                //    {
                //        SourceList.Add(entity);
                //    }
                //}
                //for (int i = 0; i < 10; i++)
                //{
                //    CfgProductGroupEntity entity = new CfgProductGroupEntity();
                //    entity.Product = "Product" + i;
                //    entity.ProductGroup = "ProductGroup" + i;
                //    UpdateList.Add(entity);
                //}
                //List<CfgProductGroupEntity> entityList = new List<CfgProductGroupEntity>();
                //entityList = GetProductGroupAdd(SourceList, UpdateList);
                //entityList = GetProductGroupModify(SourceList, UpdateList);
                //entityList = GetProductGroupDelete(SourceList, UpdateList);
                #endregion

                List<string> productAddList = new List<string>();
                List<string> productGroupAddList = new List<string>();

                List<string> productModifyList = new List<string>();
                List<string> productGroupModifyList = new List<string>();

                List<string> productDeleteList = new List<string>();
                List<string> productGroupDeleteList = new List<string>();

                List<CfgProductGroupEntity> entityList = new List<CfgProductGroupEntity>();
                entityList = GetProductGroupAdd(CfgProductGroupListSource, CfgProductGroupList.ToList());
                foreach (var obj in entityList)
                {
                    productAddList.Add(obj.Product);
                    productGroupAddList.Add(obj.ProductGroup);
                }

                entityList = GetProductGroupModify(CfgProductGroupListSource, CfgProductGroupList.ToList());
                foreach (var obj in entityList)
                {
                    productModifyList.Add(obj.Product);
                    productGroupModifyList.Add(obj.ProductGroup);
                }

                entityList = GetProductGroupDelete(CfgProductGroupListSource, CfgProductGroupList.ToList());
                foreach (var obj in entityList)
                {
                    productDeleteList.Add(obj.Product);
                    productGroupDeleteList.Add(obj.ProductGroup);
                }

                CfgUpdateResult result = this.AdminService.R2R_UI_Config_ProductGroupSave(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, CfgArea,
                    productAddList.ToArray(), productGroupAddList.ToArray(),
                    productModifyList.ToArray(), productGroupModifyList.ToArray(),
                    productDeleteList.ToArray(), productGroupDeleteList.ToArray());
                if (result != null)
                {
                    if (result.ReturnCode.Equals("0"))
                    {
                        OnCfgProductGroupSearchClick();
                    }
                    MyLogger.Trace("Message :: " + result.ReturnText);
                    System.Windows.Forms.MessageBox.Show(result.ReturnText);
                }
                else
                {
                    string strMsg = "Invoke R2R_UI_Config_ProductGroupSave Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region CfgPriorityLevel Filed Define
        private bool _IsPriorityLevelEditEnable = true;
        public bool IsPriorityLevelEditEnable
        {
            get { return this._IsPriorityLevelEditEnable; }
            set { SetProperty(ref this._IsPriorityLevelEditEnable, value); }
        }

        private bool _IsPriorityLevelReadOnly = true;
        public bool IsPriorityLevelReadOnly
        {
            get { return this._IsPriorityLevelReadOnly; }
            set { SetProperty(ref this._IsPriorityLevelReadOnly, value); }
        }

        private List<string> _CfgUIConfigList = new List<string>() {"*", "LITHO"};
        public List<string> CfgUIConfigList
        {
            get { return this._CfgUIConfigList; }
            set { SetProperty(ref this._CfgUIConfigList, value); }
        }

        private List<string> _CfgPriorityLevelGroupList = new List<string>() {"*", "Edit","View" };
        public List<string> CfgPriorityLevelGroupList
        {
            get { return this._CfgPriorityLevelGroupList; }
            set { SetProperty(ref this._CfgPriorityLevelGroupList, value); }
        }

        private string _CfgPriorityUserGroup="*";
        public string CfgPriorityUserGroup
        {
            get { return this._CfgPriorityUserGroup; }
            set { SetProperty(ref this._CfgPriorityUserGroup, value); }
        }

        private string _CfgPriorityProductGroup="*";
        public string CfgPriorityProductGroup
        {
            get { return this._CfgPriorityProductGroup; }
            set { SetProperty(ref this._CfgPriorityProductGroup, value); }
        }

        private string _CfgUIConfig="*";
        public string CfgUIConfig
        {
            get { return this._CfgUIConfig; }
            set { SetProperty(ref this._CfgUIConfig, value); }
        }

        private string _CfgPriorityLevel="*";
        public string CfgPriorityLevel
        {
            get { return this._CfgPriorityLevel; }
            set { SetProperty(ref this._CfgPriorityLevel, value); }
        }

        private CfgPriorityLevelEntity _SelectedPriorityLevel;
        public CfgPriorityLevelEntity SelectedPriorityLevel
        {
            get { return this._SelectedPriorityLevel; }
            set { SetProperty(ref this._SelectedPriorityLevel, value); }
        }

        private ObservableCollection<CfgPriorityLevelEntity> _CfgPriorityLevelList = new ObservableCollection<CfgPriorityLevelEntity>();
        public ObservableCollection<CfgPriorityLevelEntity> CfgPriorityLevelList
        {
            get { return _CfgPriorityLevelList; }
            set { SetProperty(ref _CfgPriorityLevelList, value); }
        }
        #endregion

        #region CfgPriorityLevel Event Define
        private DelegateCommand _PriorityLevelSelectionChangedCommand;
        public DelegateCommand PriorityLevelSelectionChangedCommand =>
            _PriorityLevelSelectionChangedCommand ?? (_PriorityLevelSelectionChangedCommand = new DelegateCommand(OnCfgPriorityLevelSelectionChanged));

        private DelegateCommand _PriorityLevelLostFocusCommand;
        public DelegateCommand PriorityLevelLostFocusCommand =>
            _PriorityLevelLostFocusCommand ?? (_PriorityLevelLostFocusCommand = new DelegateCommand(OnCfgPriorityLevelLostFocus));

        private DelegateCommand _BtnCfgPriorityLevelSearchCommand;
        public DelegateCommand BtnCfgPriorityLevelSearchCommand =>
            _BtnCfgPriorityLevelSearchCommand ?? (_BtnCfgPriorityLevelSearchCommand = new DelegateCommand(OnCfgPriorityLevelSearchClick));       

        private DelegateCommand _BtnCfgPriorityLevelAddCommand;
        public DelegateCommand BtnCfgPriorityLevelAddCommand =>
            _BtnCfgPriorityLevelAddCommand ?? (_BtnCfgPriorityLevelAddCommand = new DelegateCommand(OnCfgPriorityLevelAddClick));

        private DelegateCommand _BtnCfgPriorityLevelEditCommand;
        public DelegateCommand BtnCfgPriorityLevelEditCommand =>
            _BtnCfgPriorityLevelEditCommand ?? (_BtnCfgPriorityLevelEditCommand = new DelegateCommand(OnCfgPriorityLevelEditClick));

        private DelegateCommand _BtnCfgPriorityLevelDeleteCommand;
        public DelegateCommand BtnCfgPriorityLevelDeleteCommand =>
            _BtnCfgPriorityLevelDeleteCommand ?? (_BtnCfgPriorityLevelDeleteCommand = new DelegateCommand(OnCfgPriorityLevelDeleteClick));

        private DelegateCommand _BtnCfgPriorityLevelSaveCommand;
        public DelegateCommand BtnCfgPriorityLevelSaveCommand =>
            _BtnCfgPriorityLevelSaveCommand ?? (_BtnCfgPriorityLevelSaveCommand = new DelegateCommand(OnCfgPriorityLevelSaveClick));
        #endregion

        #region CfgPriorityLevel Event Function
        /// <summary>
        /// CfgPriorityLevel Search Button Click
        /// </summary>
        void OnCfgPriorityLevelSearchClick()
        {
            try
            {
                if (string.IsNullOrEmpty(CfgArea) || string.IsNullOrEmpty(CfgPriorityUserGroup) || string.IsNullOrEmpty(CfgPriorityProductGroup) ||  string.IsNullOrEmpty(CfgPriorityLevel))
                {
                    string strMsg = "Area/UserGroup/ProductGroup/PriorityLevel cannot be empty!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                CfgPriorityLevelListSource = new List<CfgPriorityLevelEntity>();
                CfgPriorityLevelList = new ObservableCollection<CfgPriorityLevelEntity>();
                CfgAdminGetResult CfgAdminResult = this.AdminService.R2R_UI_Config_AdminConfigGet(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 3, CfgPriorityUserGroup, "", CfgPriorityProductGroup, CfgArea, CfgPriorityLevel);
                if (CfgAdminResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_AdminConfigGet Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                if (CfgAdminResult.IsOutputNull)
                {
                    string strMsg = "Output Null!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                for (int i = 0; i < CfgAdminResult.PriorityLevel.Count; i++)
                {
                    CfgPriorityLevelEntity entity = new CfgPriorityLevelEntity();
                    entity.UserGroup = CfgAdminResult.UserGroup[i];
                    entity.ProductGroup = CfgAdminResult.ProductGroup[i];
                    entity.UIConfig = CfgAdminResult.UI_Config[i];
                    entity.PriorityLevel = CfgAdminResult.PriorityLevel[i];
                    entity.Action = "Add";
                    CfgPriorityLevelListSource.Add(entity);
                    //CfgPriorityLevelList.Add(entity);
                }
                string strSource = JsonHelp.SerializeObject(CfgPriorityLevelListSource);
                //CfgPriorityLevelListSource = JsonHelp.DeserializeJsonToList<CfgPriorityLevelEntity>(strSource);

                CfgPriorityLevelList.Clear();
                CfgPriorityLevelList = new ObservableCollection<CfgPriorityLevelEntity>(JsonHelp.DeserializeJsonToList<CfgPriorityLevelEntity>(strSource));

                PriorityLevelQueryTime = CommonHelp.GetQueryTime();

                strLastArea = CfgArea;
                IsPriorityLevelSerachClick = true;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CfgPriorityLevel SelectionChanged
        /// </summary>
        void OnCfgPriorityLevelSelectionChanged()
        {
            try
            {
                if (SelectedPriorityLevel != null)
                {
                    #region Access Control
                    //bool isCheckOnly = false;
                    //string OptAction = "Edit";
                    //CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 3,"", SelectedPriorityLevel.UserGroup, "", SelectedPriorityLevel.ProductGroup, SelectedPriorityLevel.UIConfig, SelectedPriorityLevel.PriorityLevel, OptAction, PriorityLevelQueryTime, isCheckOnly);
                    //if (checkResult.ReturnCode.Equals("-1"))
                    //{
                    //    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    //    return;
                    //}
                    //else if (checkResult.ReturnCode.Equals("0"))
                    //{
                    //    //IsUserGroupSettingEdit = true;
                    //}
                    //else if (checkResult.ReturnCode.Equals("1"))
                    //{
                    //    //IsUserGroupSettingEdit = true;
                    //    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    //}
                    //if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                    //{
                    //    System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                    //    return;
                    //}
                    //if (checkResult.InitMode.ToLower().Equals("edit"))
                    //{
                    //    IsBtnCfgPriorityLevelEditEnable = true;
                    //    IsBtnCfgPriorityLevelDeleteEnable = true;
                    //}
                    //else if (checkResult.InitMode.ToLower().Equals("view"))
                    //{
                    //    //System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                    //    //IsBtnCfgPriorityLevelEditEnable = false;
                    //    //IsBtnCfgPriorityLevelDeleteEnable = false;
                    //}
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CfgPriorityLevel LostFocus
        /// </summary>
        void OnCfgPriorityLevelLostFocus()
        {
            try
            {
                //IsPriorityLevelReadOnly = true;
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CfgPriorityLevel Add Button Click
        /// </summary>
        void OnCfgPriorityLevelAddClick()
        {
            try
            {
                var window = new MetroWindow();//Windows窗体      
                PriorityLevelSetting view = new PriorityLevelSetting();
                PriorityLevelSettingViewModel viewModel = (PriorityLevelSettingViewModel)view.DataContext;

                string strCfgPriorityUserGroup = "";
                string strCfgPriorityProductGroup = "";
                string strCfgUIConfig = "";
                string strCfgPriorityLevel = "";
                if (SelectedPriorityLevel != null)
                {
                    strCfgPriorityUserGroup = SelectedPriorityLevel.UserGroup;
                    strCfgPriorityProductGroup = SelectedPriorityLevel.ProductGroup;
                    strCfgUIConfig = SelectedPriorityLevel.UIConfig;
                    strCfgPriorityLevel = SelectedPriorityLevel.PriorityLevel;
                }
                viewModel.CurrentWindow = window;
                viewModel.CfgUserGroup = strCfgPriorityUserGroup;
                viewModel.CfgProductGroup = strCfgPriorityProductGroup;
                viewModel.CfgUIConfig = strCfgUIConfig;
                viewModel.CfgPriorityLevel = strCfgPriorityLevel;
                viewModel.CfgUIConfigList = new List<string>(CfgAreaList);
                viewModel.IsKeyEnable = true;

                window.Content = view;
                window.Title = "PriorityLevel Add Setting";
                window.Height = 320;
                window.Width = 480;
                //window.ResizeMode = ResizeMode.NoResize;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();
                if (viewModel.IsBtnOkClick)
                {
                    CfgPriorityLevelEntity addEntity = new CfgPriorityLevelEntity();
                    addEntity.UserGroup = viewModel.CfgUserGroup;
                    addEntity.ProductGroup = viewModel.CfgProductGroup;
                    addEntity.UIConfig = viewModel.CfgUIConfig;
                    addEntity.PriorityLevel = viewModel.CfgPriorityLevel;
                    addEntity.Action = "Add";

                    string strJson = JsonHelp.SerializeObject(addEntity);
                    MyLogger.Trace("EventFun:: " +
                                    string.Format("AddRow<{0}>", strJson));

                    #region Access Control
                    bool isCheckOnly = false;
                    string OptAction = "Add";
                    CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 3,"", viewModel.CfgUserGroup, "", viewModel.CfgProductGroup, viewModel.CfgUIConfig, viewModel.CfgPriorityLevel, OptAction, PriorityLevelQueryTime, isCheckOnly);
                    if (checkResult.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                        return;
                    }
                    else if (checkResult.ReturnCode.Equals("0"))
                    {
                        //IsUserGroupSettingEdit = true;
                    }
                    else if (checkResult.ReturnCode.Equals("1"))
                    {
                        //IsUserGroupSettingEdit = true;
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                    {
                        MyLogger.Trace("Message :: " + AccessControlByOtherMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                        return;
                    }
                    if (checkResult.InitMode.ToLower().Equals("edit"))
                    {
                        #region Add Entity
                        CfgPriorityLevelEntity modifyEntity = new CfgPriorityLevelEntity();
                        modifyEntity.UserGroup = viewModel.CfgUserGroup;
                        modifyEntity.ProductGroup = viewModel.CfgProductGroup;
                        modifyEntity.UIConfig = viewModel.CfgUIConfig;
                        modifyEntity.PriorityLevel = viewModel.CfgPriorityLevel;
                        modifyEntity.Action = "Add";

                        foreach (var obj in CfgPriorityLevelList)
                        {
                            if (obj.UserGroup.Equals(viewModel.CfgUserGroup) && obj.ProductGroup.Equals(viewModel.CfgProductGroup) && obj.UIConfig.Equals(viewModel.CfgUIConfig) && obj.PriorityLevel.Equals(viewModel.CfgPriorityLevel))
                            {
                                string strMsg = "Have exists!";
                                MyLogger.Trace("Message :: " + strMsg);
                                System.Windows.Forms.MessageBox.Show(strMsg);
                                return;
                            }
                        }

                        CfgPriorityLevelList.Add(modifyEntity);
                        SelectedPriorityLevel = modifyEntity;
                        #endregion
                    }
                    else if (checkResult.InitMode.ToLower().Equals("view"))
                    {
                        MyLogger.Trace("Message :: " + AccessControlViewModeMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                    }
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CfgPriorityLevel Edit Button Click
        /// </summary>
        void OnCfgPriorityLevelEditClick()
        {
            try
            {
                if (this.SelectedPriorityLevel == null)
                {
                    string strMsg = "Row is not selected!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }

                string strJson = JsonHelp.SerializeObject(SelectedPriorityLevel);
                MyLogger.Trace("EventFun:: " +
                                string.Format("EditRow<{0}>", strJson));

                var window = new MetroWindow();//Windows窗体      
                PriorityLevelSetting view = new PriorityLevelSetting();
                PriorityLevelSettingViewModel viewModel = (PriorityLevelSettingViewModel)view.DataContext;

                string strCfgPriorityUserGroup = SelectedPriorityLevel.UserGroup;
                string strCfgPriorityProductGroup = SelectedPriorityLevel.ProductGroup;
                string strCfgUIConfig = SelectedPriorityLevel.UIConfig;
                string strCfgPriorityLevel = SelectedPriorityLevel.PriorityLevel;

                viewModel.CurrentWindow = window;
                viewModel.CfgUserGroup = strCfgPriorityUserGroup;
                viewModel.CfgProductGroup = strCfgPriorityProductGroup;
                viewModel.CfgUIConfig = strCfgUIConfig;
                viewModel.CfgPriorityLevel = strCfgPriorityLevel;
                viewModel.CfgUIConfigList = new List<string>(CfgAreaList);
                viewModel.IsKeyEnable = false;

                window.Content = view;
                window.Title = "PriorityLevel Edit Setting";
                window.Height = 320;
                window.Width = 480;
                //window.ResizeMode = ResizeMode.NoResize;
                window.ResizeMode = ResizeMode.CanMinimize;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();
                if (viewModel.IsBtnOkClick)
                {
                    CfgPriorityLevelEntity editEntity = new CfgPriorityLevelEntity();
                    editEntity.UserGroup = viewModel.CfgUserGroup;
                    editEntity.ProductGroup = viewModel.CfgProductGroup;
                    editEntity.UIConfig = viewModel.CfgUIConfig;
                    editEntity.PriorityLevel = viewModel.CfgPriorityLevel;
                    strJson = JsonHelp.SerializeObject(editEntity);
                    MyLogger.Trace("EventFun:: " +
                                    string.Format("EditResult<{0}>", strJson));

                    #region Access Control
                    bool isCheckOnly = false;
                    string OptAction = "Edit";
                    CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 3, "", viewModel.CfgUserGroup, "", viewModel.CfgProductGroup, viewModel.CfgUIConfig, viewModel.CfgPriorityLevel, OptAction, PriorityLevelQueryTime, isCheckOnly);
                    if (checkResult.ReturnCode.Equals("-1"))
                    {
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                        return;
                    }
                    else if (checkResult.ReturnCode.Equals("0"))
                    {
                        //IsUserGroupSettingEdit = true;
                    }
                    else if (checkResult.ReturnCode.Equals("1"))
                    {
                        //IsUserGroupSettingEdit = true;
                        MyLogger.Trace("Message :: " + checkResult.ReturnText);
                        System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    }
                    if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                    {
                        MyLogger.Trace("Message :: " + AccessControlByOtherMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                        return;
                    }
                    if (checkResult.InitMode.ToLower().Equals("edit"))
                    {
                        #region Edit Entity
                        CfgPriorityLevelEntity modifyEntity = new CfgPriorityLevelEntity();
                        modifyEntity.UserGroup = viewModel.CfgUserGroup;
                        modifyEntity.ProductGroup = viewModel.CfgProductGroup;
                        modifyEntity.UIConfig = viewModel.CfgUIConfig;
                        modifyEntity.PriorityLevel = viewModel.CfgPriorityLevel;
                        foreach (var obj in CfgPriorityLevelList)
                        {
                            if (obj.UserGroup.Equals(viewModel.CfgUserGroup) && obj.ProductGroup.Equals(viewModel.CfgProductGroup) && obj.UIConfig.Equals(viewModel.CfgUIConfig) && obj.PriorityLevel.Equals(viewModel.CfgPriorityLevel))
                            {
                                string strMsg = "Have exists!";
                                MyLogger.Trace("Message :: " + strMsg);
                                System.Windows.Forms.MessageBox.Show(strMsg);
                                return;
                            }
                        }

                        SelectedPriorityLevel.UserGroup = viewModel.CfgUserGroup;
                        SelectedPriorityLevel.ProductGroup = viewModel.CfgProductGroup;
                        SelectedPriorityLevel.UIConfig = viewModel.CfgUIConfig;
                        SelectedPriorityLevel.PriorityLevel = viewModel.CfgPriorityLevel;

                        ObservableCollection<CfgPriorityLevelEntity> list = new ObservableCollection<CfgPriorityLevelEntity>(CfgPriorityLevelList);
                        CfgPriorityLevelList.Clear();
                        CfgPriorityLevelList = new ObservableCollection<CfgPriorityLevelEntity>(list);
                        #endregion
                    }
                    else if (checkResult.InitMode.ToLower().Equals("view"))
                    {
                        MyLogger.Trace("Message :: " + AccessControlViewModeMessage);
                        System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                    }
                    #endregion
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// CfgPriorityLevel Delete Button Click
        /// </summary>
        void OnCfgPriorityLevelDeleteClick()
        {
            try
            {
                if (SelectedPriorityLevel == null)
                {
                    string strMsg = "Please select a row!";
                    MyLogger.Trace("Message :: " + strMsg);

                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                //if (CfgPriorityLevelList.Count == 1)
                //{
                //    string strMsg = "Only one record!";
                //    MyLogger.Trace("Message :: " + strMsg);
                    
                //    System.Windows.Forms.MessageBox.Show(strMsg);
                //    return;
                //}

                string strJson = JsonHelp.SerializeObject(SelectedPriorityLevel);
                MyLogger.Trace("EventFun:: " +
                                string.Format("DeleteRow<{0}>", strJson));

                if (SelectedPriorityLevel.Action.Equals("Add"))
                {
                    CfgPriorityLevelList.Remove(SelectedPriorityLevel);
                    return;
                }

                #region Access Control
                bool isCheckOnly = false;
                string OptAction = "Delete";
                CfgAccessControlResult checkResult = this.AdminService.R2R_UI_Config_AccessControlCheck(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, 3, "", SelectedPriorityLevel.UserGroup, "", SelectedPriorityLevel.ProductGroup, SelectedPriorityLevel.UIConfig, SelectedPriorityLevel.PriorityLevel, OptAction, PriorityLevelQueryTime, isCheckOnly);
                if (checkResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_AccessControlCheck Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
                if (checkResult.ReturnCode.Equals("-1"))
                {
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                    return;
                }
                else if (checkResult.ReturnCode.Equals("0"))
                {
                    //IsUserGroupSettingEdit = true;
                }
                else if (checkResult.ReturnCode.Equals("1"))
                {
                    //IsUserGroupSettingEdit = true;
                    MyLogger.Trace("Message :: " + checkResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(checkResult.ReturnText);
                }
                if (checkResult.IsDataTooOld || checkResult.IsOccupiedByOther)
                {
                    MyLogger.Trace("Message :: " + AccessControlByOtherMessage);
                    System.Windows.Forms.MessageBox.Show(AccessControlByOtherMessage);
                    return;
                }
                if (checkResult.InitMode.ToLower().Equals("edit"))
                {
                    #region Delete Entity
                    CfgPriorityLevelList.Remove(SelectedPriorityLevel);
                    #endregion
                }
                else if (checkResult.InitMode.ToLower().Equals("view"))
                {
                    MyLogger.Trace("Message :: " + AccessControlViewModeMessage);
                    System.Windows.Forms.MessageBox.Show(AccessControlViewModeMessage);
                }
                #endregion
                
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// CfgPriorityLevel Save Button Click
        /// </summary>
        void OnCfgPriorityLevelSaveClick()
        {
            try
            {
                List<string> userGroupAddList = new List<string>();
                List<string> productGroupAddList = new List<string>();
                List<string> uiConfigAddList = new List<string>();
                List<string> priorityLevelAddList = new List<string>();

                List<string> userGroupModifyList = new List<string>();
                List<string> productGroupModifyList = new List<string>();
                List<string> uiConfigModifyList = new List<string>();
                List<string> priorityLevelModifyList = new List<string>();

                List<string> userGroupDeleteList = new List<string>();
                List<string> productGroupDeleteList = new List<string>();
                List<string> uiConfigDeleteList = new List<string>();
                List<string> priorityLevelDeleteList = new List<string>();

                List<CfgPriorityLevelEntity> entityList = new List<CfgPriorityLevelEntity>();
                entityList = GetPriorityLevelAdd(CfgPriorityLevelListSource, CfgPriorityLevelList.ToList());
                foreach (var obj in entityList)
                {
                    userGroupAddList.Add(obj.UserGroup);
                    productGroupAddList.Add(obj.ProductGroup);
                    uiConfigAddList.Add(obj.UIConfig);
                    priorityLevelAddList.Add(obj.PriorityLevel);
                }

                entityList = GetPriorityLevelModify(CfgPriorityLevelListSource, CfgPriorityLevelList.ToList());
                foreach (var obj in entityList)
                {
                    userGroupModifyList.Add(obj.UserGroup);
                    productGroupModifyList.Add(obj.ProductGroup);
                    uiConfigModifyList.Add(obj.UIConfig);
                    priorityLevelModifyList.Add(obj.PriorityLevel);
                }

                entityList = GetPriorityLevelDelete(CfgPriorityLevelListSource, CfgPriorityLevelList.ToList());
                foreach (var obj in entityList)
                {
                    userGroupDeleteList.Add(obj.UserGroup);
                    productGroupDeleteList.Add(obj.ProductGroup);
                    uiConfigDeleteList.Add(obj.UIConfig);
                    priorityLevelDeleteList.Add(obj.PriorityLevel);
                }

                CfgUpdateResult result = this.AdminService.R2R_UI_Config_PriorityLevelSave(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, CfgArea,
                    userGroupAddList.ToArray(), productGroupAddList.ToArray(), uiConfigAddList.ToArray(), priorityLevelAddList.ToArray(),
                    userGroupModifyList.ToArray(), productGroupModifyList.ToArray(), uiConfigModifyList.ToArray(), priorityLevelModifyList.ToArray(),
                    userGroupDeleteList.ToArray(), productGroupDeleteList.ToArray(), uiConfigDeleteList.ToArray(), priorityLevelDeleteList.ToArray());
                if (result != null)
                {
                    if (result.ReturnCode.Equals("0"))
                    {
                        OnCfgPriorityLevelSearchClick();
                    }
                    MyLogger.Trace("Message :: " + result.ReturnText);
                    System.Windows.Forms.MessageBox.Show(result.ReturnText);
                }
                else
                {
                    string strMsg = "Invoke R2R_UI_Config_PriorityLevelSave Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return;
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Fun
        List<string> GetAreaList()
        {
            List<string> ResultList = new List<string>();
            try
            {
                CfgAreaListGetResult CfgAreaListResult = this.AdminService.R2R_UI_Config_AreaListGet(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion);
                if (CfgAreaListResult == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_AreaListGet error!";
                    MyLogger.Trace("Message :: " + strMsg);

                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return new List<string>();
                }

                if (CfgAreaListResult.ReturnCode.Equals("0"))
                {
                    ResultList = new List<string>(CfgAreaListResult.Area_Content.Split(';'));
                }
                else if (CfgAreaListResult.ReturnCode.Equals("1"))
                {
                    MyLogger.Trace("Message :: " + CfgAreaListResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(CfgAreaListResult.ReturnText);
                    ResultList = new List<string>(CfgAreaListResult.Area_Content.Split(';'));
                }
                else if(CfgAreaListResult.ReturnCode.Equals("-1"))
                {
                    MyLogger.Trace("Message :: " + CfgAreaListResult.ReturnText);
                    System.Windows.Forms.MessageBox.Show(CfgAreaListResult.ReturnText);
                }
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return ResultList;
        }
        List<CfgUserGroupEntity> GetUserGroupAdd(List<CfgUserGroupEntity> sourceList, List<CfgUserGroupEntity> updateList)
        {
            List<CfgUserGroupEntity> entityList = new List<CfgUserGroupEntity>();
            try
            {
                foreach (var updateObj in updateList)
                {
                    bool bIsHave = false;
                    foreach (var sourceObj in sourceList)
                    {
                        if (sourceObj.UserId.Equals(updateObj.UserId) && sourceObj.UserGroup.Equals(updateObj.UserGroup))
                        {
                            bIsHave = true;
                            break;
                        }
                    }
                    if (!bIsHave)
                    {
                        CfgUserGroupEntity entity = new CfgUserGroupEntity();

                        entity.UserId = updateObj.UserId;
                        entity.UserGroup = updateObj.UserGroup;
                        entityList.Add(entity);
                    }
                }

                string strJson = JsonHelp.SerializeObject(sourceList);
                MyLogger.Trace("Input :: " +
                           string.Format("UserGroupSource<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(updateList);
                MyLogger.Trace("Input :: " +
                           string.Format("UserGroupUpdate<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(entityList);
                MyLogger.Trace("Return :: " +
                           string.Format("UserGroupAdd<{0}>", strJson));

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return entityList;
        }
        List<CfgUserGroupEntity> GetUserGroupDelete(List<CfgUserGroupEntity> sourceList, List<CfgUserGroupEntity> updateList)
        {
            List<CfgUserGroupEntity> entityList = new List<CfgUserGroupEntity>();
            try
            {
                foreach (var sourceObj in sourceList)
                {
                    bool bIsHave = false;
                    foreach (var updateObj in updateList)
                    {
                        if (sourceObj.UserId.Equals(updateObj.UserId) && sourceObj.UserGroup.Equals(updateObj.UserGroup))
                        {
                            bIsHave = true;
                            break;
                        }
                    }
                    if (!bIsHave)
                    {
                        CfgUserGroupEntity entity = new CfgUserGroupEntity();

                        entity.UserId = sourceObj.UserId;
                        entity.UserGroup = sourceObj.UserGroup;
                        entityList.Add(entity);
                    }
                }

                string strJson = JsonHelp.SerializeObject(sourceList);
                MyLogger.Trace("Input :: " +
                           string.Format("UserGroupSource<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(updateList);
                MyLogger.Trace("Input :: " +
                           string.Format("UserGroupUpdate<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(entityList);
                MyLogger.Trace("Return :: " +
                           string.Format("UserGroupDelete<{0}>", strJson));

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return entityList;
        }

        List<CfgProductGroupEntity> GetProductGroupAdd(List<CfgProductGroupEntity> sourceList, List<CfgProductGroupEntity> updateList)
        {
            List<CfgProductGroupEntity> entityList = new List<CfgProductGroupEntity>();
            try
            {
                foreach (var updateObj in updateList)
                {
                    bool bIsHave = false;
                    foreach (var sourceObj in sourceList)
                    {
                        if (sourceObj.Product.Equals(updateObj.Product))
                        {
                            bIsHave = true;
                            break;
                        }
                    }
                    if (!bIsHave)
                    {
                        CfgProductGroupEntity entity = new CfgProductGroupEntity();
                        entity.Product = updateObj.Product;
                        entity.ProductGroup = updateObj.ProductGroup;
                        entityList.Add(entity);
                    }
                }

                string strJson = JsonHelp.SerializeObject(sourceList);
                MyLogger.Trace("Input :: " +
                           string.Format("ProductGroupSource<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(updateList);
                MyLogger.Trace("Input :: " +
                           string.Format("ProductGroupUpdate<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(entityList);
                MyLogger.Trace("Return :: " +
                           string.Format("ProductGroupAdd<{0}>", strJson));

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return entityList;
        }

        List<CfgProductGroupEntity> GetProductGroupModify(List<CfgProductGroupEntity> sourceList, List<CfgProductGroupEntity> updateList)
        {
            List<CfgProductGroupEntity> entityList = new List<CfgProductGroupEntity>();
            try
            {
                foreach (var sourceObj in sourceList)
                {
                    bool bIsEdit = false;
                    string strUpdate = string.Empty;
                    foreach (var updateObj in updateList)
                    {
                        if (sourceObj.Product.Equals(updateObj.Product) && !sourceObj.ProductGroup.Equals(updateObj.ProductGroup))
                        {
                            bIsEdit = true;
                            strUpdate = updateObj.ProductGroup;
                            break;
                        }
                    }
                    if (bIsEdit)
                    {
                        CfgProductGroupEntity entity = new CfgProductGroupEntity();
                        entity.Product = sourceObj.Product;
                        entity.ProductGroup = strUpdate;// sourceObj.ProductGroup;
                        entityList.Add(entity);
                    }
                }

                string strJson = JsonHelp.SerializeObject(sourceList);
                MyLogger.Trace("Input :: " +
                           string.Format("ProductGroupSource<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(updateList);
                MyLogger.Trace("Input :: " +
                           string.Format("ProductGroupUpdate<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(entityList);
                MyLogger.Trace("Return :: " +
                           string.Format("ProductGroupModify<{0}>", strJson));

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return entityList;
        }
        List<CfgProductGroupEntity> GetProductGroupDelete(List<CfgProductGroupEntity> sourceList, List<CfgProductGroupEntity> updateList)
        {
            List<CfgProductGroupEntity> entityList = new List<CfgProductGroupEntity>();
            try
            {
                foreach (var sourceObj in sourceList)
                {
                    bool bIsHave = false;
                    foreach (var updateObj in updateList)
                    {
                        if (sourceObj.Product.Equals(updateObj.Product))
                        {
                            bIsHave = true;
                            break;
                        }
                    }
                    if (!bIsHave)
                    {
                        CfgProductGroupEntity entity = new CfgProductGroupEntity();

                        entity.Product = sourceObj.Product;
                        entity.ProductGroup = sourceObj.ProductGroup;
                        entityList.Add(entity);
                    }
                }

                string strJson = JsonHelp.SerializeObject(sourceList);
                MyLogger.Trace("Input :: " +
                           string.Format("ProductGroupSource<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(updateList);
                MyLogger.Trace("Input :: " +
                           string.Format("ProductGroupUpdate<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(entityList);
                MyLogger.Trace("Return :: " +
                           string.Format("ProductGroupDelete<{0}>", strJson));

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return entityList;
        }

        List<CfgPriorityLevelEntity> GetPriorityLevelAdd(List<CfgPriorityLevelEntity> sourceList, List<CfgPriorityLevelEntity> updateList)
        {
            List<CfgPriorityLevelEntity> entityList = new List<CfgPriorityLevelEntity>();
            try
            {
                foreach (var updateObj in updateList)
                {
                    bool bIsHave = false;
                    foreach (var sourceObj in sourceList)
                    {
                        if (sourceObj.UserGroup.Equals(updateObj.UserGroup) && sourceObj.ProductGroup.Equals(updateObj.ProductGroup) && sourceObj.UIConfig.Equals(updateObj.UIConfig))
                        {
                            bIsHave = true;
                            break;
                        }
                    }
                    if (!bIsHave)
                    {
                        CfgPriorityLevelEntity entity = new CfgPriorityLevelEntity();

                        entity.UserGroup = updateObj.UserGroup;
                        entity.ProductGroup = updateObj.ProductGroup;
                        entity.UIConfig = updateObj.UIConfig;
                        entity.PriorityLevel = updateObj.PriorityLevel;
                        entityList.Add(entity);
                    }
                }

                string strJson = JsonHelp.SerializeObject(sourceList);
                MyLogger.Trace("Input :: " +
                           string.Format("PriorityLevelSource<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(updateList);
                MyLogger.Trace("Input :: " +
                           string.Format("PriorityLevelUpdate<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(entityList);
                MyLogger.Trace("Return :: " +
                           string.Format("PriorityLevelAdd<{0}>", strJson));

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return entityList;
        }
        List<CfgPriorityLevelEntity> GetPriorityLevelModify(List<CfgPriorityLevelEntity> sourceList, List<CfgPriorityLevelEntity> updateList)
        {
            List<CfgPriorityLevelEntity> entityList = new List<CfgPriorityLevelEntity>();
            try
            {
                foreach (var sourceObj in sourceList)
                {
                    bool bIsEdit = false;
                    string strUpdate = string.Empty;
                    foreach (var updateObj in updateList)
                    {
                        if (sourceObj.UserGroup.Equals(updateObj.UserGroup) && sourceObj.ProductGroup.Equals(updateObj.ProductGroup) && sourceObj.UIConfig.Equals(updateObj.UIConfig) && !sourceObj.PriorityLevel.Equals(updateObj.PriorityLevel))
                        {
                            bIsEdit = true;
                            strUpdate = updateObj.PriorityLevel;
                            break;
                        }
                    }
                    if (bIsEdit)
                    {
                        CfgPriorityLevelEntity entity = new CfgPriorityLevelEntity();

                        entity.UserGroup = sourceObj.UserGroup;
                        entity.ProductGroup = sourceObj.ProductGroup;
                        entity.UIConfig = sourceObj.UIConfig;
                        entity.PriorityLevel = strUpdate;// sourceObj.PriorityLevel;
                        entityList.Add(entity);
                    }
                }

                string strJson = JsonHelp.SerializeObject(sourceList);
                MyLogger.Trace("Input :: " +
                           string.Format("PriorityLevelSource<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(updateList);
                MyLogger.Trace("Input :: " +
                           string.Format("PriorityLevelUpdate<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(entityList);
                MyLogger.Trace("Return :: " +
                           string.Format("PriorityLevelModify<{0}>", strJson));

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return entityList;
        }
        List<CfgPriorityLevelEntity> GetPriorityLevelDelete(List<CfgPriorityLevelEntity> sourceList, List<CfgPriorityLevelEntity> updateList)
        {
            List<CfgPriorityLevelEntity> entityList = new List<CfgPriorityLevelEntity>();
            try
            {
                foreach (var sourceObj in sourceList)
                {
                    bool bIsHave = false;
                    foreach (var updateObj in updateList)
                    {
                        if (sourceObj.UserGroup.Equals(updateObj.UserGroup) && sourceObj.ProductGroup.Equals(updateObj.ProductGroup) && sourceObj.UIConfig.Equals(updateObj.UIConfig))
                        {
                            bIsHave = true;
                            break;
                        }
                    }
                    if (!bIsHave)
                    {
                        CfgPriorityLevelEntity entity = new CfgPriorityLevelEntity();

                        entity.UserGroup = sourceObj.UserGroup;
                        entity.ProductGroup = sourceObj.ProductGroup;
                        entity.UIConfig = sourceObj.UIConfig;
                        entity.PriorityLevel = sourceObj.PriorityLevel;
                        entityList.Add(entity);
                    }
                }

                string strJson = JsonHelp.SerializeObject(sourceList);
                MyLogger.Trace("Input :: " +
                           string.Format("PriorityLevelSource<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(updateList);
                MyLogger.Trace("Input :: " +
                           string.Format("PriorityLevelUpdate<{0}>", strJson));

                strJson = JsonHelp.SerializeObject(entityList);
                MyLogger.Trace("Return :: " +
                           string.Format("PriorityLevelDelete<{0}>", strJson));

            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                System.Windows.Forms.MessageBox.Show(ee.Message);
            }
            return entityList;
        }
        #endregion
    }
}
