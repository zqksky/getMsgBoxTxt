﻿using System;
using System.Windows;
using System.Windows.Threading;
using R2R.Client.Shell.ViewModels;

namespace R2R.Client.Shell.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        DispatcherTimer _dateTimeTimer;
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
            Unloaded += MainWindow_Unloaded;
        }

        private void MainWindow_Unloaded(object sender, RoutedEventArgs e)
        {
            StopDateTimeTimer();
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            StartDateTimeTimer();
        }

        private void StartDateTimeTimer()
        {
            if (_dateTimeTimer == null)
            {
                _dateTimeTimer = new DispatcherTimer(DispatcherPriority.ApplicationIdle);
                _dateTimeTimer.Interval = TimeSpan.FromSeconds(1);
                _dateTimeTimer.Tick += _dateTimeTimer_Tick;
                _dateTimeTimer.Start();
            }
        }
        private void StopDateTimeTimer()
        {
            if (_dateTimeTimer == null)
            {
                _dateTimeTimer.Stop();
                _dateTimeTimer.Tick -= _dateTimeTimer_Tick;
                _dateTimeTimer = null;
            }
        }

        private void _dateTimeTimer_Tick(object sender, EventArgs e)
        {
            (this.DataContext as MainWindowViewModel).DateTimeText = DateTime.Now.ToString();
        }

        private void ActiveViews_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {

        }
    }
}
