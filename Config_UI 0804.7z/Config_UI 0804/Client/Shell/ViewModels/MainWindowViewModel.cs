﻿using System.Windows;
using R2R.Client.Framework;
using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using System.Collections.Generic;
using R2R.Common.Data;
using LoginManagement.Views;
using Prism.Ioc;
using LoginService.Models;
using LoginManagement.Event;
using R2R.Common.Data.CommonEntity;
using System;
using System.Windows.Forms;
using R2R.Common.Library;
using R2R.Client.Framework.Events;
using MahApps.Metro;

namespace R2R.Client.Shell.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        #region
        IEventAggregator ea;
        IContainerExtension _container;
        IRegionManager _regionManager;
        IRegion _region;
        Login loginView;

        public DelegateCommand LoadDataCommand { get; private set; }
        public MainWindowViewModel(IContainerExtension Container, IRegionManager regionManager, IEventAggregator eventAggregator)
        {
            Title = "R2R Client";
            VersionText = "Version:1.0.0";
            UserName = "Test";
            CurrentUser = "Test";
            CurrentServer = "Localhost";
            
            EventAggregator.GetEvent<StatusUpdatedEvent>().Subscribe(OnStatusUpdatedEvent);

            _regionManager = regionManager;
            _container = Container;
            LoadDataCommand = new DelegateCommand(loadData);

            #region 接受登陆消息
            Ea = eventAggregator;
            Ea.GetEvent<LoginSentEvent>().Subscribe(MessageReceived);
            #endregion

            EventAggregator.GetEvent<AdminUIConfigChangedEvent>().Subscribe(AdminUIConfigMessageReceived);
        }

        private string _AdminUIConfigMessages = "LITHO";
        public string AdminUIConfigMessages
        {
            get { return _AdminUIConfigMessages; }
            set { SetProperty(ref _AdminUIConfigMessages, value); }
        }

        private void AdminUIConfigMessageReceived(string strUIConfig)
        {
            AdminUIConfigMessages = strUIConfig;
        }

        /// <summary>
        /// Receive Login info
        /// </summary>
        /// <param name="info"></param>
        private void MessageReceived(LoginInfo info)
        {
            if (info.LoginState == 1)
            {
                _region.Deactivate(loginView);

                Title = "Client";
                Width = "1440";
                Height = "900";
                LoginVisiable = Visibility.Collapsed;
                MenuVisiable = Visibility.Visible;
                WinState = WindowState.Maximized;

                UserName = info.UserId;
                Password = info.Password;
                DomainName = info.DomainName;
                ServerAddress = info.ServerAddress;
                adminConfigVisible = info.IsAdminConfig ? "Visible" : "Hidden";

                CurrentUser = UserName;
                CurrentServer = ServerAddress;

                ClientInfo.CurrentServerName = info.ServerName;
                ClientInfo.CurrentServer = info.ServerAddress;
                ClientInfo.CurrentUser = info.UserId;
                ClientInfo.CurrentVersion = VersionText;

                //ClientInfo.UserId = info.UserId;
                ClientInfo.RequsetId = info.RequestId;
                ClientInfo.CurrentVersion = info.ClientVersion;
                ClientInfo.Password = info.Password;

                FlagLogin = true;
            }
            else if (info.LoginState == 2)
            {

            }
            else if (info.LoginState == 3)
            {
                System.Windows.Application.Current.MainWindow.Close();
            }
        }
        /// <summary>
        /// Load Data
        /// </summary>
        private void loadData()
        {
            _region = _regionManager.Regions["MainRegionLogin"];
            loginView = _container.Resolve<Login>();

            Title = "Login";
            Width = "500";
            Height = "400";
            _region.Add(loginView);
        }
        #endregion

        #region Parameter Define
        private string _title = "Prism Unity Application";
        public string title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }

        private string _Width = "500";
        public string Width
        {
            get { return _Width; }
            set { SetProperty(ref _Width, value); }
        }

        private string _Height = "400";
        public string Height
        {
            get { return _Height; }
            set { SetProperty(ref _Height, value); }
        }

        private WindowState _WinState = WindowState.Normal;
        public WindowState WinState
        {
            get { return _WinState; }
            set { SetProperty(ref _WinState, value); }
        }

        private Visibility _LoginVisiable = Visibility.Visible;
        public Visibility LoginVisiable
        {
            get{ return _LoginVisiable; }
            set{ SetProperty(ref _LoginVisiable, value); }
        }

        private Visibility _menuVisiable = Visibility.Collapsed;
        public Visibility MenuVisiable
        {
            get{ return _menuVisiable; }
            set{ SetProperty(ref _menuVisiable, value); }
        }
        #endregion

        #region Field Define
        private bool flagLogin =false;
        public bool FlagLogin
        {
            get { return flagLogin; }
            set { SetProperty(ref flagLogin, value); }
        }

        private string adminConfigVisible= "Visible";//Visible,Hidden
        public string AdminConfigVisible
        {
            get { return adminConfigVisible; }
            set { SetProperty(ref adminConfigVisible, value); }
        }

        private string dateTimeText;
        public string DateTimeText
        {
            get { return dateTimeText; }
            set { SetProperty(ref dateTimeText, value); }
        }

        private string _versionText;
        public string VersionText
        {
            get { return _versionText; }
            set { SetProperty(ref _versionText, value); }
        }

        private string _statusText;
        public string StatusText
        {
            get { return _statusText; }
            set { SetProperty(ref _statusText, value); }
        }

        private string _ServerAddress;
        public string ServerAddress
        {
            get { return _ServerAddress; }
            set { SetProperty(ref _ServerAddress, value); }
        }
        
        private string _CurrentServer;
        public string CurrentServer
        {
            get { return _CurrentServer; }
            set { SetProperty(ref _CurrentServer, value); }
        }

        private string _CurrentUser;
        public string CurrentUser
        {
            get { return _CurrentUser; }
            set { SetProperty(ref _CurrentUser, value); }
        }


        private string _UserName;
        public string UserName
        {
            get { return _UserName; }
            set { SetProperty(ref _UserName, value); }
        }

        private string _Password;
        public string Password
        {
            get { return _Password; }
            set { SetProperty(ref _Password, value); }
        }

        private string _DomainName;
        public string DomainName
        {
            get { return _DomainName; }
            set { SetProperty(ref _DomainName, value); }
        }
        #endregion field

        #region Event Define
        private DelegateCommand _ClosedCommand;
        public DelegateCommand ClosedCommand =>
            _ClosedCommand ?? (_ClosedCommand = new DelegateCommand(OnClosed));

        private DelegateCommand _exitCommand;
        public DelegateCommand ExitCommand =>
            _exitCommand ?? (_exitCommand = new DelegateCommand(OnExit));

        private DelegateCommand<string> _navigateToCommand;
        public DelegateCommand<string> NavigateToCommand =>
            _navigateToCommand ?? (_navigateToCommand = new DelegateCommand<string>(OnNavigateTo));

        public IEventAggregator Ea { get => ea; set => ea = value; }
        #endregion command

        #region Event Fun
        /// <summary>
        /// Version Updated Event Fun
        /// </summary>
        /// <param name="version"></param>
        private void OnVersionUpdatedEvent(string version)
        {
            VersionText = "Version:" + version;
        }
        /// <summary>
        /// Status Updated Event Fun
        /// </summary>
        /// <param name="status"></param>
        private void OnStatusUpdatedEvent(string status)
        {
            StatusText = status;
        }
        /// <summary>
        /// MainWindow Closed Event Fun
        /// </summary>
        void OnClosed()
        {
            try
            {
                if (FlagLogin)
                {
                    #region
                    bool falgResult = R2R_UI_Config_ClearEditOccupy(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, "LITHO");
                    if (falgResult)
                    {
                    }
                    #endregion

                    #region
                    EventAggregator.GetEvent<AdminUIConfigChangedEvent>().Subscribe(AdminUIConfigMessageReceived);
                    falgResult = R2R_UI_Config_ClearAdminOccupy(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, AdminUIConfigMessages);
                    if (falgResult)
                    {
                    }
                    #endregion
                    //Application.Current.MainWindow.Close();
                }
            }
            finally
            {
                MyLogger.PerformanceStop();
            }
        }
        /// <summary>
        ///  Menu Exit Event Fun
        /// </summary>
        void OnExit()
        {
            #region
            bool falgResult = R2R_UI_Config_ClearEditOccupy(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion,"LITHO");
            if (falgResult)
            {
            }

            EventAggregator.GetEvent<AdminUIConfigChangedEvent>().Subscribe(AdminUIConfigMessageReceived);
            falgResult = R2R_UI_Config_ClearAdminOccupy(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, AdminUIConfigMessages);
            if (falgResult)
            {
            }
            #endregion

            System.Windows.Application.Current.MainWindow.Close();
        }

        bool IsFirstSettingMain = true;
        bool IsFirstConfigMain = true;
        bool IsFirstAdminConfig = true;
        string strLastView = "";
        /// <summary>
        /// Page Switch Envnt Fun
        /// </summary>
        /// <param name="functionName"></param>
        void OnNavigateTo(string functionName)
        {
            try
            {
                if (functionName.Equals("ConfigMain"))
                {
                    IsFirstConfigMain = false;
                }

                if (functionName.Equals("SettingMain"))
                {
                    IsFirstSettingMain = false;
                }

                if (functionName.Equals("AdminConfig"))
                {
                    IsFirstAdminConfig = false;
                }

                if (functionName.Equals("SettingMain") && strLastView.Equals("AdminConfig"))
                {
                    if (!IsFirstAdminConfig)
                    {
                        if (System.Windows.Forms.MessageBox.Show("The current page content will be refreshed and unsaved data will be lost", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {
                            EventAggregator.GetEvent<AdminUIConfigChangedEvent>().Subscribe(AdminUIConfigMessageReceived);
                            #region
                            bool falgResult = R2R_UI_Config_ClearAdminOccupy(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, AdminUIConfigMessages);
                            if (falgResult)
                            {
                            }
                            #endregion
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else if (functionName.Equals("AdminConfig") && strLastView.Equals("SettingMain"))
                {
                    if (!IsFirstSettingMain)
                    {
                        if (System.Windows.Forms.MessageBox.Show("The current page content will be refreshed and unsaved data will be lost", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {
                            #region
                            bool falgResult = R2R_UI_Config_ClearEditOccupy(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, "LITHO");
                            if (falgResult)
                            {
                            }
                            #endregion
                        }
                        else
                        {
                            return;
                        }
                    }
                }

                else if (functionName.Equals("ConfigMain") && strLastView.Equals("AdminConfig"))
                {
                    if (!IsFirstSettingMain)
                    {
                        if (System.Windows.Forms.MessageBox.Show("The current page content will be refreshed and unsaved data will be lost", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {
                            #region
                            bool falgResult = R2R_UI_Config_ClearAdminOccupy(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, "LITHO");
                            if (falgResult)
                            {
                            }
                            #endregion
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else if (functionName.Equals("ConfigMain") && strLastView.Equals("SettingMain"))
                {
                    if (!IsFirstAdminConfig)
                    {
                        if (System.Windows.Forms.MessageBox.Show("The current page content will be refreshed and unsaved data will be lost", "Confirm Message", MessageBoxButtons.OKCancel) == DialogResult.OK)
                        {
                            EventAggregator.GetEvent<AdminUIConfigChangedEvent>().Subscribe(AdminUIConfigMessageReceived);
                            #region
                            bool falgResult = R2R_UI_Config_ClearEditOccupy(ClientInfo.CurrentServer, ClientInfo.RequsetId, ClientInfo.CurrentUser, ClientInfo.CurrentVersion, AdminUIConfigMessages);
                            if (falgResult)
                            {
                            }
                            #endregion
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                strLastView = functionName;

                MyLogger.PerformanceStart();
                RegionManager.Regions[RegionNames.MainRegion].RequestNavigate(functionName, (nr) =>
                {
                    if (nr.Error != null)
                    {
                        MyLogger.Error(nr.Error);
                        System.Windows.MessageBox.Show(nr.Error.ToString(), "Navigation failed!", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                });
            }
            finally
            {
                MyLogger.PerformanceStop();
            }
        }
        #endregion private function

        #region Clear Edit Control Webservice
        /// <summary>
        /// Invoke R2R_UI_Config_ClearEditOccupy webservice Fun
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="uiConfig"></param>
        /// <returns></returns>
        bool R2R_UI_Config_ClearEditOccupy(string strServerAddress, string requestId, string userId, string clientVersion, string uiConfig)
        {
            bool flag = false;
            CfgUpdateResult result = new CfgUpdateResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("UI_Config", uiConfig);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_ClearEditOccupy, arguDic, strServerAddress);
                if (strResult.Equals("error"))
                {
                    string strMsg = "Invoke R2R_UI_Config_ClearEditOccupy Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return false;
                }
                result = JsonHelp.DeserializeJsonToObject<CfgUpdateResult>(strResult);
                if (result == null)
                {
                    return false;
                }

                MyLogger.Trace("Reply :: " +
                                string.Format("RequestId<{0}>", result.RequestId) +
                                string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                string.Format("ReturnText<{0}>", result.ReturnText));
                if (result.ReturnCode.Equals("0"))
                {
                    flag = true;
                }
                else if (result.ReturnCode.Equals("-1"))
                {
                    System.Windows.Forms.MessageBox.Show(result.ReturnText);
                    flag = false;
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return flag;
        }

        // <summary>
        /// Invoke R2R_UI_Config_ClearAdminOccupy webservice Fun
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="userId"></param>
        /// <param name="clientVersion"></param>
        /// <param name="uiConfig"></param>
        /// <returns></returns>
        bool R2R_UI_Config_ClearAdminOccupy(string strServerAddress, string requestId, string userId, string clientVersion, string uiConfig)
        {
            bool flag = false;
            CfgUpdateResult result = new CfgUpdateResult();
            MyLogger.Trace("Request:: " +
                           string.Format("ServerAddress<{0}>", strServerAddress) +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("UI_Config", uiConfig);
            try
            {
                //WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_ClearAdminOccupy, arguDic, strServerAddress);

                //if (!CommonHelp.ArgumentIsNull(arguDic))
                string strResult = WebServiceHelp.GetResponseString(EMethod.R2R_UI_Config_ClearAdminOccupy, arguDic, strServerAddress);
                if (strResult.Equals("error"))
                {
                    string strMsg = "Invoke R2R_UI_Config_ClearAdminOccupy Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    System.Windows.Forms.MessageBox.Show(strMsg);
                    return false;
                }
                result = JsonHelp.DeserializeJsonToObject<CfgUpdateResult>(strResult);
                if (result == null)
                {
                    return false;
                }

                MyLogger.Trace("Reply :: " +
                                string.Format("RequestId<{0}>", result.RequestId) +
                                string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                string.Format("ReturnText<{0}>", result.ReturnText));
                if (result.ReturnCode.Equals("0"))
                {
                    flag = true;
                }
                else if (result.ReturnCode.Equals("-1"))
                {
                    System.Windows.Forms.MessageBox.Show(result.ReturnText);
                    flag = false;
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("Error :: " + ex.Message);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return flag;
        }
        #endregion

    }
}
