﻿using LoginService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginManagement.Event
{
    public class LoginSentEvent : Prism.Events.PubSubEvent<LoginInfo> { }
}
