﻿using LoginManagement.Views;
using LoginService.IService;
using LoginService.Service;
using Prism.Ioc;
using Prism.Modularity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginManagement
{
    public class LoginManageModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {

        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<Login>();
            containerRegistry.RegisterSingleton<ILoginManageService, LoginManageService>();
        }
    }
}
