﻿using LoginManagement.Event;
using LoginService.IService;
using LoginService.Models;
using MahApps.Metro;
using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using R2R.Client.Framework;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace LoginManagement.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        IEventAggregator _ea;

        public ILoginManageService LoginService { get; set; }
        public LoginViewModel(ILoginManageService loginService, IEventAggregator ea)
        {
            _ea = ea;
            this.LoginService = loginService;
            Title = "Login";

            DomainNameList = this.LoginService.GetDomainName(Environment.CurrentDirectory + "\\LoginConfigFile.xml");
            ServerAddressList = this.LoginService.GetServerAddress(Environment.CurrentDirectory + "\\LoginConfigFile.xml");
            clientInfo= this.LoginService.GetClientInfoConfig(Environment.CurrentDirectory + "\\LoginConfigFile.xml");
        }


        #region Filed Define
        ClientInfoValue clientInfo = new ClientInfoValue();

        private string _UserName;
        public string UserName
        {
            get { return this._UserName; }
            set { SetProperty(ref this._UserName, value); }
        }

        private string _Password;
        public string Password
        {
            get { return this._Password; }
            set { SetProperty(ref this._Password, value); }
        }

        private string _DomainName;
        public string DomainName
        {
            get { return this._DomainName; }
            set { SetProperty(ref this._DomainName, value); }
        }

        private List<string> _DomainNameList;
        public List<string> DomainNameList
        {
            get { return this._DomainNameList; }
            set { SetProperty(ref this._DomainNameList, value); }
        }

        private ServerAddressInfo _ServerAddress;
        public ServerAddressInfo ServerAddress
        {
            get { return this._ServerAddress; }
            set { SetProperty(ref this._ServerAddress, value); }
        }

        private List<ServerAddressInfo> __ServerAddressList;
        public List<ServerAddressInfo> ServerAddressList
        {
            get { return this.__ServerAddressList; }
            set { SetProperty(ref this.__ServerAddressList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _BtnOkCommand;
        public DelegateCommand BtnOkCommand =>
            _BtnOkCommand ?? (_BtnOkCommand = new DelegateCommand(OnBtnOkClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));

        #endregion

        #region Event Fun
        /// <summary>
        /// Ok Button Click Event Fun
        /// </summary>
        void OnBtnOkClick()
        {
            try
            {
                if (string.IsNullOrEmpty(UserName) || string.IsNullOrEmpty(Password))
                {
                    string strMsg = "User name and password cannot be empty!";
                    MyLogger.Trace("Message:: " + strMsg);
                    MessageBox.Show(strMsg);

                    return;
                }

                LoginInfo info = new LoginInfo();
                info.RequestId = clientInfo.RequestId;
                info.ClientVersion = clientInfo.ClientVersion;
                info.UserId = UserName; 
                info.DomainName = DomainName;
                info.Password = Password;
                info.ServerAddress = ServerAddress.Server;
                info.ServerName = ServerAddress.Name;

                CfgLoginResult result = new CfgLoginResult();
                result = this.LoginService.R2R_UI_Config_Login(clientInfo.RequestId, clientInfo.ClientVersion, UserName, Password, DomainName, ServerAddress.Server);
                if (result == null)
                {
                    string strMsg = "Invoke R2R_UI_Config_Login Error!";
                    MyLogger.Trace("Message :: " + strMsg);
                    MessageBox.Show(strMsg);
                    return;
                }
                if (result.ReturnCode.Equals("0"))
                {
                    //登陆操作                   
                    info.LoginState = 1;
                    //ChangeTheme(info.ServerName, "BaseLight");
                }
                else
                {
                    info.LoginState = 2;
                }

                info.IsAdminConfig = result.IsAdminConfig;

                //登陆操作成功后，发送消息
                _ea.GetEvent<LoginSentEvent>().Publish(info);
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }
        }
        /// <summary>
        /// Cancel Button Click Event Fun
        /// </summary>
        void OnBtnCancelClick()
        {
            try
            {
                LoginInfo info = new LoginInfo();
                info.LoginState = 3;
                _ea.GetEvent<LoginSentEvent>().Publish(info);
            }
            catch (Exception ee)
            {
                MyLogger.Error("Error :: " + ee.Message);
                MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// 设置App样式
        /// </summary>
        private void ChangeTheme(string strType, string themeName)
        {
            if (string.IsNullOrEmpty(strType))
            {
                return;
            }
            Accent accent = new Accent();
            AppTheme expectedTheme = ThemeManager.GetAppTheme(themeName);  //"BaseDark"
            if (strType.ToUpper().Contains("PRODUCT"))
            {
                accent = ThemeManager.GetAccent("Red");
            }
            else if (strType.ToUpper().Contains("PIRUN"))
            {
                accent = ThemeManager.GetAccent("Blue");
            }
            else if (strType.ToUpper().Contains("TEST"))
            {
                accent = ThemeManager.GetAccent("Sienna");
            }
            else
            {
                accent = ThemeManager.GetAccent("Blue");
            }

            ThemeManager.ChangeAppStyle(Application.Current, accent, expectedTheme);
        }
        #endregion
    }
}
