﻿using Prism.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Client.Framework.Events
{
    public class CPEEDynamicChangedEvent : PubSubEvent<List<string>>
    {
    }
}
