﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using R2R.Client.Framework.Interfaces;
using R2R.Common.Library;

namespace R2R.Client.Framework
{
    public class ErrorHandler : IErrorHandler
    {
        public void Handle(Exception ex)
        {
            MyLogger.Error(ex);
            // TODO: use style message window.
            MessageBox.Show(ex.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
