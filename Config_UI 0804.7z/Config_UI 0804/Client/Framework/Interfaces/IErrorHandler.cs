﻿using System;

namespace R2R.Client.Framework.Interfaces
{
    public interface IErrorHandler
    {
        void Handle(Exception ex);
    }
}
